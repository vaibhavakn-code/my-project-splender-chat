import React from 'react';
import { SettingsModal } from './SettingsModal';

interface PrivacySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * Consolidated single-source-of-truth router for Privacy settings
 */
export const PrivacySettingsModal: React.FC<PrivacySettingsModalProps> = ({ isOpen, onClose }) => {
  return <SettingsModal isOpen={isOpen} onClose={onClose} initialCategory="privacy" />;
};
