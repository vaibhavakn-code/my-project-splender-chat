import React, { useState } from 'react';
import {
  Camera,
  Search,
  MoreVertical,
  X,
  FileText,
  Image as ImageIcon,
  Video,
  Link2,
  FileAudio,
  QrCode,
  Users,
  Radio,
  Star,
  User,
  Settings,
  Moon,
  Sun,
  CheckCheck,
  Lock,
  Languages,
} from 'lucide-react';
import { playClickSound } from '../lib/sound';
import { useChat } from '../context/ChatContext';
import { SplenderLogo } from './SplenderLogo';

export interface TopStatusBarProps {
  onSearchClick?: () => void;
  onSettingsClick?: () => void;
  onCameraClick?: () => void;
  onNewGroupClick?: () => void;
  onNewBroadcastClick?: () => void;
  onProfileClick?: () => void;
  onStarredMessagesClick?: () => void;
  onIdentityClick?: () => void;
  currentUser?: { name: string; avatarUrl?: string };
}

export type SearchFilterType =
  | 'all'
  | 'unread'
  | 'messages'
  | 'photos'
  | 'videos'
  | 'links'
  | 'gifs'
  | 'audio'
  | 'documents';

export const TopStatusBar: React.FC<TopStatusBarProps> = ({
  onSearchClick,
  onSettingsClick,
  onCameraClick,
  onNewGroupClick,
  onNewBroadcastClick,
  onProfileClick,
  onStarredMessagesClick,
}) => {
  const chatContext = useChat();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [isSearchActive, setIsSearchActive] = useState(false);
  const searchQuery = chatContext.globalSearchQuery;
  const activeFilter = chatContext.globalSearchFilter as SearchFilterType;

  const setSearchQuery = (q: string) => {
    chatContext.setGlobalSearchQuery(q);
  };

  const setActiveFilter = (f: SearchFilterType) => {
    chatContext.setGlobalSearchFilter(f);
  };

  const filterChips: { id: SearchFilterType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'unread', label: chatContext.t('filterUnread'), icon: CheckCheck },
    { id: 'photos', label: chatContext.t('filterPhotos'), icon: ImageIcon },
    { id: 'videos', label: chatContext.t('filterVideos'), icon: Video },
    { id: 'links', label: chatContext.t('filterLinks'), icon: Link2 },
    { id: 'audio', label: chatContext.t('filterAudio'), icon: FileAudio },
    { id: 'documents', label: chatContext.t('filterDocs'), icon: FileText },
  ];

  const handleOpenSearch = () => {
    playClickSound();
    setIsSearchActive(true);
    if (onSearchClick) onSearchClick();
  };

  const handleCloseSearch = () => {
    playClickSound();
    setIsSearchActive(false);
    setSearchQuery('');
    setActiveFilter('all');
  };

  return (
    <header
      className="sticky top-0 z-30 w-full min-h-[46px] lg:min-h-[54px] bg-white/88 dark:bg-[#080B14]/88 backdrop-blur-xl border-b border-slate-200/80 dark:border-[#293650]/85 text-slate-900 dark:text-[#F4F7FF] select-none transition-colors shrink-0"
    >
      {!isSearchActive ? (
        <div className="px-3 h-[46px] lg:h-[54px] flex items-center justify-between gap-2">
          {/* Brand Zone: Single clean wordmark lockup */}
          <div className="flex items-center gap-2.5 min-w-0 shrink-0">
            <SplenderLogo size="sm" />
            <h1 className="font-display text-[15px] lg:text-base font-bold tracking-tight text-slate-900 dark:text-[#F4F7FF] whitespace-nowrap truncate">
              Splender Chat
            </h1>
          </div>

          {/* Right Contextual Actions (>= 44px touch targets) */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                if (onCameraClick) onCameraClick();
              }}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] hover:bg-slate-100 dark:hover:bg-[#131D32] transition-colors cursor-pointer"
              title="Camera"
              aria-label="Camera"
            >
              <Camera className="w-[18px] h-[18px]" />
            </button>

            <button
              type="button"
              onClick={handleOpenSearch}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] hover:bg-slate-100 dark:hover:bg-[#131D32] transition-colors cursor-pointer"
              title="Search"
              aria-label="Search"
            >
              <Search className="w-[18px] h-[18px]" />
            </button>

            <button
              type="button"
              onClick={() => {
                playClickSound();
                chatContext.toggleDarkMode();
              }}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] hover:bg-slate-100 dark:hover:bg-[#131D32] transition-colors cursor-pointer"
              title={chatContext.darkMode ? 'Switch to Daylight Mode' : 'Switch to Aurora Nebula Dark'}
              aria-label="Toggle Theme"
            >
              {chatContext.darkMode ? (
                <Sun className="w-[18px] h-[18px] text-[#22D3EE]" />
              ) : (
                <Moon className="w-[18px] h-[18px] text-[#8B5CF6]" />
              )}
            </button>

            {/* Quick Language Switcher */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setIsLangMenuOpen((prev) => !prev);
                }}
                className="min-w-[44px] min-h-[44px] px-2 flex items-center justify-center gap-1 rounded-xl text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] hover:bg-slate-100 dark:hover:bg-[#131D32] font-mono font-semibold text-[11px] transition-colors cursor-pointer whitespace-nowrap"
                title="Language"
                aria-label="Language"
              >
                <Languages className="w-4 h-4" />
                <span>{chatContext.language.toUpperCase()}</span>
              </button>

              {isLangMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsLangMenuOpen(false)} />
                  <div className="absolute right-0 top-11 z-50 w-44 py-1.5 rounded-2xl bg-white dark:bg-[#0D1424]/95 backdrop-blur-xl text-slate-900 dark:text-[#F4F7FF] shadow-2xl border border-slate-200 dark:border-[#293650]">
                    {[
                      { id: 'mr' as const, label: 'मराठी (MR)' },
                      { id: 'hi' as const, label: 'हिंदी (HI)' },
                      { id: 'en' as const, label: 'English (EN)' },
                      { id: 'es' as const, label: 'Español (ES)' },
                      { id: 'fr' as const, label: 'Français (FR)' },
                      { id: 'de' as const, label: 'Deutsch (DE)' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          playClickSound();
                          chatContext.setLanguage(item.id);
                          setIsLangMenuOpen(false);
                          chatContext.showToast('Language Updated', item.label, 'info');
                        }}
                        className={`w-full min-h-[40px] px-3.5 py-2 text-left text-xs flex items-center justify-between cursor-pointer transition-colors whitespace-nowrap ${
                          chatContext.language === item.id
                            ? 'bg-[#3B82F6]/12 dark:bg-[#22D3EE]/14 text-[#2563EB] dark:text-[#22D3EE] font-semibold'
                            : 'hover:bg-slate-100 dark:hover:bg-[#131D32]'
                        }`}
                      >
                        <span>{item.label}</span>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Overflow Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setIsMenuOpen((prev) => !prev);
                }}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] hover:bg-slate-100 dark:hover:bg-[#131D32] transition-colors cursor-pointer"
                title="More options"
                aria-label="More options"
              >
                <MoreVertical className="w-[18px] h-[18px]" />
              </button>

              {isMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsMenuOpen(false)} />
                  <div className="absolute right-0 top-11 z-50 w-52 py-1.5 rounded-2xl bg-white dark:bg-[#0D1424]/95 backdrop-blur-xl text-slate-900 dark:text-[#F4F7FF] shadow-2xl border border-slate-200 dark:border-[#293650]">
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        if (onNewGroupClick) onNewGroupClick();
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <Users className="w-4 h-4 text-[#3B82F6] dark:text-[#22D3EE]" />
                      <span>New group</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        if (onNewBroadcastClick) onNewBroadcastClick();
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <Radio className="w-4 h-4 text-[#8B5CF6]" />
                      <span>New broadcast</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        chatContext.setIsQrScannerOpen(true);
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <QrCode className="w-4 h-4 text-[#3B82F6] dark:text-[#22D3EE]" />
                      <span>Linked devices & QR</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        if (onStarredMessagesClick) onStarredMessagesClick();
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <Star className="w-4 h-4 text-amber-400" />
                      <span>Starred messages</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        if (onProfileClick) onProfileClick();
                        else chatContext.setIsIdentityModalOpen(true);
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <User className="w-4 h-4 text-[#8B5CF6]" />
                      <span>Sovereign Identity</span>
                    </button>

                    <div className="h-px bg-slate-200 dark:bg-[#293650] my-1" />

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        if (onSettingsClick) onSettingsClick();
                        else chatContext.setIsSettingsModalOpen(true);
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer whitespace-nowrap"
                    >
                      <Settings className="w-4 h-4 text-slate-500 dark:text-[#A8B3CC]" />
                      <span>Settings</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setIsMenuOpen(false);
                        chatContext.lockApp();
                      }}
                      className="w-full min-h-[44px] px-4 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-2.5 cursor-pointer text-amber-600 dark:text-amber-400 whitespace-nowrap"
                    >
                      <Lock className="w-4 h-4" />
                      <span>Lock Application</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-2 space-y-2">
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-[#131D32] rounded-xl px-3 min-h-[40px] border border-slate-200 dark:border-[#293650]">
            <button
              type="button"
              onClick={handleCloseSearch}
              className="min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-500 hover:text-slate-800 dark:text-[#A8B3CC] dark:hover:text-[#F4F7FF] cursor-pointer"
              aria-label="Close search"
            >
              <X className="w-4 h-4" />
            </button>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={chatContext.t('searchPlaceholder')}
              autoFocus
              className="flex-1 bg-transparent text-xs text-slate-900 dark:text-[#F4F7FF] outline-none placeholder:text-slate-400 dark:placeholder:text-[#A8B3CC]/65"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5 text-[11px]">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setActiveFilter('all');
              }}
              className={`px-3 py-1 rounded-lg whitespace-nowrap font-medium transition-colors cursor-pointer shrink-0 ${
                activeFilter === 'all'
                  ? 'bg-[#3B82F6] dark:bg-[#22D3EE] text-white dark:text-[#080B14] font-semibold'
                  : 'bg-slate-100 dark:bg-[#131D32] text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF]'
              }`}
            >
              {chatContext.t('filterAll')}
            </button>
            {filterChips.map((chip) => {
              const ChipIcon = chip.icon;
              const isSelected = activeFilter === chip.id;
              return (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setActiveFilter(chip.id);
                  }}
                  className={`px-2.5 py-1 rounded-lg whitespace-nowrap flex items-center gap-1 font-medium transition-colors cursor-pointer shrink-0 ${
                    isSelected
                      ? 'bg-[#3B82F6] dark:bg-[#22D3EE] text-white dark:text-[#080B14] font-semibold'
                      : 'bg-slate-100 dark:bg-[#131D32] text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF]'
                  }`}
                >
                  <ChipIcon className="w-3 h-3" />
                  <span>{chip.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
