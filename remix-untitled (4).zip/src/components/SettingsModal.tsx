import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  X,
  Key,
  Lock,
  MessageSquare,
  Bell,
  HardDrive,
  Globe,
  HelpCircle,
  QrCode,
  Shield,
  Smartphone,
  ChevronRight,
  Check,
  Moon,
  Sun,
  Palette,
  Download,
  Trash2,
  FileText,
  AlertTriangle,
  Fingerprint,
  Radio,
  Share2,
  Eye,
  EyeOff,
  UserX,
  Phone,
  Database,
  RefreshCw,
  Sliders,
  Image as ImageIcon,
  Bot,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, isSoundEnabled, setSoundEnabled, isHapticsEnabled, setHapticsEnabled } from '../lib/sound';
import {
  areNotificationsEnabled,
  setNotificationsEnabled,
  getNotificationPermission,
  requestNotificationPermission,
  sendTestNotification,
} from '../lib/notifications';
import { MEDIA_QUALITY_OPTIONS } from '../lib/compression';
import { BackupEngine } from '../lib/masterFeatures';
import { AutoBackupScheduler } from '../lib/enterpriseSuite';
import {
  ThemeSelectorPanel,
  NetworkCallLinksPanel,
  AccountSecurityPanel,
  AiFeaturesPanel,
  ConnectivityPrivacyPanel,
  MediaStorageEnginePanel,
  LanguageAccessibilityPanel,
} from './LuxuriousSettingsPanels';
import { QuickActionsBar } from './QuickActionsBar';
import { getThemeConfig } from '../lib/themeEngine';
import { WallpaperEngineModal } from './WallpaperEngineModal';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

export type SettingsSection =
  | null
  | 'themes'
  | 'network_calls'
  | 'security'
  | 'ai_features'
  | 'account'
  | 'privacy'
  | 'chats'
  | 'notifications'
  | 'storage'
  | 'language'
  | 'help';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCategory?: SettingsSection;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  initialCategory = null,
}) => {
  const {
    currentUserProfile,
    firebaseUser,
    updateProfile,
    mediaQuality,
    setMediaQuality,
    lockApp,
    setIsQrScannerOpen,
    contacts,
    conversations,
    messages,
    showToast,
    signOutUser,
    deleteAccountAndWipeData,
    darkMode,
    toggleDarkMode,
    themeMode,
    setThemeMode,
    visualTheme,
    setVisualTheme,
    theme,
    clearConversationMessages,
    unblockContact,
    blockContact,
    language,
    setLanguage,
    t,
    setIsP2PStorageDashboardOpen,
    setIsE2eeHealthModalOpen,
    setIsOfflineQueueModalOpen,
  } = useChat();

  const [activeSection, setActiveSection] = useState<SettingsSection>(initialCategory);

  // ---------------------------------------------------------------------------
  // Real Persistent State Variables
  // ---------------------------------------------------------------------------
  // Account
  const [securityNotifs, setSecurityNotifs] = useState<boolean>(() => {
    return localStorage.getItem('splender_security_notifs') !== 'false';
  });
  const [twoStepPin, setTwoStepPin] = useState<string | null>(() => {
    return localStorage.getItem('splender_two_step_pin') || null;
  });
  const [showTwoStepModal, setShowTwoStepModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [showChangeNumberModal, setShowChangeNumberModal] = useState(false);
  const [oldPhoneNumber, setOldPhoneNumber] = useState('+1 (555) 019-2831');
  const [newPhoneNumber, setNewPhoneNumber] = useState('');
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = useState('');

  // Privacy
  const [readReceipts, setReadReceipts] = useState<boolean>(() => {
    return localStorage.getItem('splender_read_receipts') !== 'false';
  });
  const [lastSeen, setLastSeen] = useState<'everyone' | 'contacts' | 'nobody'>(
    currentUserProfile?.lastSeenPrivacy || 'contacts'
  );
  const [profilePhotoPrivacy, setProfilePhotoPrivacy] = useState<'everyone' | 'contacts' | 'nobody'>(() => {
    return (localStorage.getItem('splender_photo_privacy') as any) || 'everyone';
  });
  const [aboutPrivacy, setAboutPrivacy] = useState<'everyone' | 'contacts' | 'nobody'>(() => {
    return (localStorage.getItem('splender_about_privacy') as any) || 'contacts';
  });
  const [statusPrivacy, setStatusPrivacy] = useState<'everyone' | 'contacts' | 'nobody'>(() => {
    return (localStorage.getItem('splender_status_privacy') as any) || 'contacts';
  });
  const [defaultTimer, setDefaultTimer] = useState<number>(() => {
    return Number(localStorage.getItem('splender_default_timer') || 0);
  });
  const [appLockEnabled, setAppLockEnabled] = useState<boolean>(() => {
    return localStorage.getItem('splender_app_lock_enabled') === 'true';
  });
  const [showBlockedModal, setShowBlockedModal] = useState(false);
  const [blockedUsers, setBlockedUsers] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_blocked_users') || '[]');
    } catch {
      return [];
    }
  });

  // Chats
  const [chatWallpaper, setChatWallpaper] = useState<string>(() => {
    return localStorage.getItem('splender_global_wallpaper') || 'Default Splender Doodle';
  });
  const [wallpaperCustomUrl, setWallpaperCustomUrl] = useState<string>(() => {
    return localStorage.getItem('splender_global_wallpaper_url') || '';
  });
  const [showWallpaperPicker, setShowWallpaperPicker] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [mediaVisibility, setMediaVisibility] = useState<boolean>(() => {
    return localStorage.getItem('splender_media_visibility') !== 'false';
  });
  const [keepArchived, setKeepArchived] = useState<boolean>(() => {
    return localStorage.getItem('splender_keep_archived') !== 'false';
  });
  const [enterIsSend, setEnterIsSend] = useState<boolean>(() => {
    return localStorage.getItem('splender_enter_is_send') === 'true';
  });
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [lastBackupTime, setLastBackupTime] = useState<string>(() => {
    return localStorage.getItem('splender_last_backup_time') || 'Never';
  });

  // Notifications
  const [pushEnabled, setPushEnabled] = useState(() => areNotificationsEnabled());
  const [soundOn, setSoundOn] = useState(() => isSoundEnabled());
  const [hapticsOn, setHapticsOn] = useState(() => isHapticsEnabled());
  const [highPriorityNotifs, setHighPriorityNotifs] = useState(() => {
    return localStorage.getItem('splender_high_priority_notifs') !== 'false';
  });

  // Storage
  const [showManageStorageModal, setShowManageStorageModal] = useState(false);
  const [showNetworkUsageModal, setShowNetworkUsageModal] = useState(false);
  const [autoDownload, setAutoDownload] = useState<'always' | 'wifi' | 'never'>(() => {
    return (localStorage.getItem('splender_auto_download') as any) || 'wifi';
  });
  const [lowDataCalls, setLowDataCalls] = useState<boolean>(() => {
    return localStorage.getItem('splender_low_data_calls') === 'true';
  });

  // Language & Profile Edit
  const [selectedLanguage, setSelectedLanguage] = useState(() => {
    return localStorage.getItem('splender_language') || 'English';
  });
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(currentUserProfile?.displayName || '');
  const [editBio, setEditBio] = useState(currentUserProfile?.bio || '');
  const wallpaperInputRef = useRef<HTMLInputElement | null>(null);

  // Operational Sub-Modals for Help & Legal
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showAppInfoModal, setShowAppInfoModal] = useState(false);
  const [showInviteFriendModal, setShowInviteFriendModal] = useState(false);
  const [faqIndex, setFaqIndex] = useState<number | null>(null);
  const [supportQuery, setSupportQuery] = useState('');
  const [isCheckingUpdates, setIsCheckingUpdates] = useState(false);
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [isWallpaperEngineOpen, setIsWallpaperEngineOpen] = useState(false);

  useEffect(() => {
    const handleOpenWallpaperEngine = () => {
      setIsWallpaperEngineOpen(true);
    };
    window.addEventListener('open_wallpaper_engine', handleOpenWallpaperEngine);
    return () => window.removeEventListener('open_wallpaper_engine', handleOpenWallpaperEngine);
  }, []);

  if (!isOpen || !currentUserProfile) return null;

  // ---------------------------------------------------------------------------
  // Handlers
  // ---------------------------------------------------------------------------

  const handleToggleSecurityNotifs = () => {
    playClickSound();
    const next = !securityNotifs;
    setSecurityNotifs(next);
    localStorage.setItem('splender_security_notifs', String(next));
    showToast(
      next ? 'Security Notifications Enabled' : 'Security Notifications Disabled',
      'You will be notified if a contact’s security encryption code changes.',
      'info'
    );
  };

  const handleSaveTwoStepPin = () => {
    if (pinInput.length !== 6 || !/^\d+$/.test(pinInput)) {
      showToast('Invalid PIN', 'Please enter a 6-digit numeric passcode', 'warning');
      return;
    }
    playClickSound();
    setTwoStepPin(pinInput);
    localStorage.setItem('splender_two_step_pin', pinInput);
    setShowTwoStepModal(false);
    setPinInput('');
    showToast('Two-Step Verification Active', 'Your 6-digit PIN has been set and verified', 'success');
  };

  const handleDisableTwoStepPin = () => {
    playClickSound();
    setTwoStepPin(null);
    localStorage.removeItem('splender_two_step_pin');
    setShowTwoStepModal(false);
    setPinInput('');
    showToast('Two-Step Verification Disabled', undefined, 'info');
  };

  const handleChangePhoneNumber = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhoneNumber.trim() || newPhoneNumber.trim().length < 7) {
      showToast('Invalid Number', 'Please enter a valid phone number with country code', 'warning');
      return;
    }
    playClickSound();
    const formatted = newPhoneNumber.trim();
    setOldPhoneNumber(formatted);
    localStorage.setItem('splender_phone_number', formatted);
    setShowChangeNumberModal(false);
    setNewPhoneNumber('');
    showToast('Phone Number Updated', `Credentials migrated to ${formatted}`, 'success');
  };

  const handleRequestAccountData = () => {
    playClickSound();
    const accountData = {
      profile: {
        uid: currentUserProfile.uid,
        displayName: currentUserProfile.displayName,
        splenderId: currentUserProfile.splenderId,
        bio: currentUserProfile.bio,
        createdAt: currentUserProfile.createdAt,
      },
      settings: {
        securityNotifs,
        twoStepEnabled: !!twoStepPin,
        readReceipts,
        lastSeen,
        profilePhotoPrivacy,
        aboutPrivacy,
        mediaVisibility,
        selectedLanguage,
      },
      exportTimestamp: new Date().toISOString(),
      e2eeProtocol: 'Splender Double Ratchet / Signal Protocol v3',
    };

    const blob = new Blob([JSON.stringify(accountData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `splender_account_info_${currentUserProfile.splenderId}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Account Info Downloaded', 'Downloaded account report JSON', 'success');
  };

  const handlePurgeAccount = async () => {
    if (deleteConfirmationText.trim().toUpperCase() !== 'DELETE') {
      showToast('Confirmation Mismatch', 'Type DELETE to permanently erase account', 'warning');
      return;
    }
    playClickSound();
    setShowDeleteConfirmModal(false);
    await deleteAccountAndWipeData();
  };

  const handleToggleReadReceipts = () => {
    playClickSound();
    const next = !readReceipts;
    setReadReceipts(next);
    localStorage.setItem('splender_read_receipts', String(next));
    updateProfile({ readReceipts: next });
    showToast('Read Receipts', next ? 'Blue double checkmarks enabled' : 'Receipts turned off (gray double checkmarks)', 'info');
  };

  const handleToggleAppLock = () => {
    playClickSound();
    const next = !appLockEnabled;
    setAppLockEnabled(next);
    localStorage.setItem('splender_app_lock_enabled', String(next));
    if (next) {
      showToast('App Lock Enabled', 'Biometric / PIN required to open app', 'success');
    } else {
      showToast('App Lock Disabled', undefined, 'info');
    }
  };

  const handleToggleBlockContact = async (uid: string, name: string) => {
    playClickSound();
    const isBlocked = blockedUsers.includes(uid);
    if (isBlocked) {
      await unblockContact(uid);
      const next = blockedUsers.filter((id) => id !== uid);
      setBlockedUsers(next);
      localStorage.setItem('splender_blocked_users', JSON.stringify(next));
      showToast('Contact Unblocked', `${name} is unblocked`, 'info');
    } else {
      await blockContact(uid);
      const next = [...blockedUsers, uid];
      setBlockedUsers(next);
      localStorage.setItem('splender_blocked_users', JSON.stringify(next));
      showToast('Contact Blocked', `${name} is blocked`, 'warning');
    }
  };

  const backupFileInputRef = useRef<HTMLInputElement>(null);

  const handleCreateChatBackup = async () => {
    playClickSound();
    setIsBackingUp(true);

    try {
      const backupData = {
        app: 'Splender Chat',
        version: '1.0.0',
        createdAt: new Date().toISOString(),
        user: {
          uid: currentUserProfile.uid,
          displayName: currentUserProfile.displayName,
          splenderId: currentUserProfile.splenderId,
        },
        conversationsCount: conversations.length,
        messagesCount: messages.length,
        conversations,
        messages,
      };

      await BackupEngine.exportBackup(backupData, '0000');
      if (firebaseUser?.uid) {
        await AutoBackupScheduler.scheduleBackup(firebaseUser.uid, backupData);
      }

      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setLastBackupTime(`Today at ${timestamp}`);
      localStorage.setItem('splender_last_backup_time', `Today at ${timestamp}`);
      setIsBackingUp(false);
      showToast('Encrypted Backup Created', 'Exported .splender backup file', 'success');
    } catch {
      setIsBackingUp(false);
      showToast('Backup Failed', 'Could not generate backup file', 'error');
    }
  };

  const handleRestoreBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      playClickSound();
      showToast('Restoring Backup', 'Verifying encrypted backup file...', 'info');
      const parsed = await BackupEngine.importBackup(file);
      const restoredItemsCount = parsed.itemCount || parsed.messagesCount || (parsed.chats?.messages?.length) || 0;
      showToast('Backup Restored', `Loaded ${restoredItemsCount} chat items from .splender archive`, 'success');
      e.target.value = '';
    } catch (err: any) {
      showToast('Restore Failed', typeof err === 'string' ? err : 'Invalid backup format', 'error');
    }
  };

  const handleCustomWallpaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setWallpaperCustomUrl(dataUrl);
      setChatWallpaper('Custom Photo Wallpaper');
      localStorage.setItem('splender_global_wallpaper', 'Custom Photo Wallpaper');
      localStorage.setItem('splender_global_wallpaper_url', dataUrl);
      setShowWallpaperPicker(false);
      showToast('Wallpaper Updated', 'Custom photo applied to chat rooms', 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleSelectWallpaperPreset = (name: string, bgValue: string) => {
    playClickSound();
    setChatWallpaper(name);
    setWallpaperCustomUrl(bgValue);
    localStorage.setItem('splender_global_wallpaper', name);
    localStorage.setItem('splender_global_wallpaper_url', bgValue);
    setShowWallpaperPicker(false);
    showToast('Wallpaper Applied', name, 'success');
  };

  const handleTogglePush = async () => {
    playClickSound();
    if (!pushEnabled) {
      const granted = await requestNotificationPermission();
      setPushEnabled(true);
      setNotificationsEnabled(true);
      showToast('Notifications Active', granted ? 'Browser native push alerts enabled' : 'In-app alert banner enabled', 'success');
    } else {
      setPushEnabled(false);
      setNotificationsEnabled(false);
      showToast('Notifications Muted', 'Push and alert notifications turned off', 'info');
    }
  };

  const handleSaveProfile = async () => {
    playClickSound();
    await updateProfile({
      displayName: editName.trim() || currentUserProfile.displayName,
      bio: editBio.trim() || currentUserProfile.bio,
    });
    setIsEditingProfile(false);
    showToast('Profile Updated', 'Name and About synchronized', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end lg:justify-center bg-[#080B14]/78 backdrop-blur-md animate-in fade-in select-none">
      <input
        type="file"
        ref={wallpaperInputRef}
        accept="image/*"
        onChange={handleCustomWallpaperUpload}
        className="hidden"
      />

      <div className="w-full max-w-lg mx-auto rounded-t-3xl lg:rounded-3xl bg-[#0D1424] border-t lg:border border-[#293650] max-h-[92vh] flex flex-col shadow-[0_24px_64px_rgba(0,0,0,0.7)] modal-slide-up text-[#F4F7FF] overflow-hidden">
        <div className="w-10 h-1 bg-[#293650] rounded-full mx-auto mt-2.5 lg:hidden shrink-0" />

        {/* Top App Bar */}
        <div className="px-4 py-2.5 flex items-center justify-between border-b border-[#293650]/80 bg-[#080B14]/88 backdrop-blur-xl text-[#F4F7FF] transition-colors shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            {activeSection !== null && (
              <button
                onClick={() => {
                  playClickSound();
                  setActiveSection(null);
                }}
                className="min-w-[44px] min-h-[44px] -ml-2 flex items-center justify-center rounded-xl text-[#A8B3CC] hover:text-[#F4F7FF] hover:bg-[#131D32] transition-colors cursor-pointer shrink-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <h2 className="text-base font-semibold tracking-tight font-['Outfit'] truncate">
              {activeSection === null
                ? 'Settings & Preferences'
                : activeSection === 'themes'
                ? 'Aurora Nebula Themes'
                : activeSection === 'network_calls'
                ? 'Network & Call Links'
                : activeSection === 'security'
                ? 'Account & Security'
                : activeSection === 'ai_features'
                ? 'Smart Assistance'
                : activeSection === 'privacy'
                ? 'Connectivity & Privacy'
                : activeSection === 'storage'
                ? 'Media & Storage Engine'
                : activeSection === 'language'
                ? 'Language & Accessibility'
                : activeSection}
            </h2>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-[#A8B3CC] hover:text-[#F4F7FF] hover:bg-[#131D32] transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* ROOT LIST (CATEGORIES) */}
          {activeSection === null && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Profile Overview Card */}
              <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="p-[2px] rounded-full bg-gradient-to-tr from-[#22D3EE] via-[#3B82F6] to-[#8B5CF6] shrink-0">
                    <img
                      src={currentUserProfile.avatar}
                      alt={currentUserProfile.displayName}
                      referrerPolicy="no-referrer"
                      className="w-13 h-13 rounded-full object-cover border-2 border-[#0D1424]"
                    />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold text-[#F4F7FF] truncate">{currentUserProfile.displayName}</h3>
                    <p className="text-xs text-[#A8B3CC] truncate mt-0.5">
                      {currentUserProfile.bio || 'Hey there! I am using Splender Chat.'}
                    </p>
                    <p className="text-xs font-mono tabular-nums text-[#22D3EE] mt-0.5 truncate">
                      {currentUserProfile.splenderId}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsEditingProfile(!isEditingProfile)}
                  className="px-3.5 py-2 rounded-xl bg-[#080B14] border border-[#293650] hover:border-[#22D3EE]/60 text-[#22D3EE] text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {isEditingProfile ? 'Cancel' : 'Edit'}
                </button>
              </div>

              {/* Inline Profile Editor */}
              {isEditingProfile && (
                <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] space-y-3 animate-in fade-in">
                  <div>
                    <label className="text-xs font-medium text-[#A8B3CC]">Display Name</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full mt-1.5 px-3.5 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-[#A8B3CC]">About & Status</label>
                    <input
                      type="text"
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      className="w-full mt-1.5 px-3.5 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                    />
                  </div>
                  <button
                    onClick={handleSaveProfile}
                    className="w-full py-2.5 rounded-xl aurora-cta-gradient text-white text-xs font-semibold transition-transform active:scale-[0.98] cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              )}

              {/* Quick Actions Bar Shortcuts */}
              <div className="space-y-1.5">
                <p className="px-1 text-xs font-semibold text-[#A8B3CC]">
                  Quick Actions
                </p>
                <QuickActionsBar onNewGroupClick={() => { onClose(); }} />
              </div>

              {/* 1. Theme Selector Panel */}
              <ThemeSelectorPanel />

              {/* 2. Network & Call Links Panel */}
              <NetworkCallLinksPanel />

              {/* 3. Account & Security Panel */}
              <AccountSecurityPanel />

              {/* 4. AI Features Panel */}
              <AiFeaturesPanel />

              {/* 5. Connectivity & Privacy Panel */}
              <ConnectivityPrivacyPanel />

              {/* 6. Media & Storage Engine Widget */}
              <MediaStorageEnginePanel />

              {/* 7. Language & Accessibility Panel */}
              <LanguageAccessibilityPanel />

              {/* Main Categories Menu */}
              <div className="space-y-1.5 pt-2">
                <p className="px-1 text-xs font-semibold text-[#A8B3CC]">
                  Preferences & Advanced
                </p>
                <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {[
                  {
                    id: 'themes' as const,
                    title: 'Themes & Aesthetics',
                    desc: 'Indigo Dawn, Midnight OLED, Cyber Indigo & 6 more palettes',
                    icon: Palette,
                  },
                  {
                    id: 'network_calls' as const,
                    title: 'Network & Call Links',
                    desc: 'Disappearing mode, link expiry duration slider',
                    icon: Sliders,
                  },
                  {
                    id: 'ai_features' as const,
                    title: 'Smart Assistance',
                    desc: 'Thread summaries, quick replies & contextual reminders',
                    icon: Bot,
                  },
                  {
                    id: 'account' as const,
                    title: 'Account',
                    desc: 'Security notifications, passkeys, two-step verification',
                    icon: Key,
                  },
                  {
                    id: 'privacy' as const,
                    title: 'Privacy',
                    desc: 'Block contacts, read receipts, disappearing timer, app lock',
                    icon: Lock,
                  },
                  {
                    id: 'chats' as const,
                    title: 'Chats',
                    desc: 'Theme, wallpapers, encrypted chat history backup',
                    icon: MessageSquare,
                  },
                  {
                    id: 'notifications' as const,
                    title: 'Notifications',
                    desc: 'Message, group & call alert tones',
                    icon: Bell,
                  },
                  {
                    id: 'storage' as const,
                    title: 'Storage & Data',
                    desc: 'Manage storage, network usage, upload quality',
                    icon: HardDrive,
                  },
                  {
                    id: 'language' as const,
                    title: 'App Language',
                    desc: selectedLanguage,
                    icon: Globe,
                  },
                  {
                    id: 'p2p_storage' as const,
                    title: 'P2P Storage & Cleanup (1GB+)',
                    desc: 'Manage high-speed peer file cache and storage space',
                    icon: HardDrive,
                  },
                  {
                    id: 'e2ee_health' as const,
                    title: 'Live E2EE Health Suite',
                    desc: 'Signal Double Ratchet status, cipher state & peer verification',
                    icon: Shield,
                  },
                  {
                    id: 'offline_queue' as const,
                    title: 'Offline Message Queue',
                    desc: 'View pending outbound messages and background resync',
                    icon: RefreshCw,
                  },
                  {
                    id: 'help' as const,
                    title: 'Help & About',
                    desc: 'Help center, terms, app build specifications',
                    icon: HelpCircle,
                  },
                  {
                    id: 'invite' as const,
                    title: 'Invite a Friend',
                    desc: 'Share Splender Chat link with peers',
                    icon: Share2,
                  },
                ].map((item) => {
                  const ItemIcon = item.icon;
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        playClickSound();
                        if (item.id === 'invite') {
                          setShowInviteFriendModal(true);
                        } else if (item.id === 'p2p_storage') {
                          setIsP2PStorageDashboardOpen(true);
                        } else if (item.id === 'e2ee_health') {
                          setIsE2eeHealthModalOpen(true);
                        } else if (item.id === 'offline_queue') {
                          setIsOfflineQueueModalOpen(true);
                        } else {
                          setActiveSection(item.id as any);
                        }
                      }}
                      className="px-4 py-3.5 min-h-[58px] flex items-center justify-between hover:bg-[#0D1424]/70 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-center shrink-0">
                          <ItemIcon className="w-4 h-4 text-[#22D3EE]" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-[#F4F7FF] leading-tight">{item.title}</p>
                          <p className="text-xs text-[#A8B3CC] truncate mt-0.5">
                            {item.desc}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#A8B3CC] shrink-0" />
                    </div>
                  );
                })}
                </div>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION: THEMES */}
          {/* ============================================================== */}
          {activeSection === 'themes' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <ThemeSelectorPanel />
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION: NETWORK & CALL LINKS */}
          {/* ============================================================== */}
          {activeSection === 'network_calls' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <NetworkCallLinksPanel />
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION: AI FEATURES */}
          {/* ============================================================== */}
          {activeSection === 'ai_features' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <AiFeaturesPanel />
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION: SECURITY */}
          {/* ============================================================== */}
          {activeSection === 'security' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <AccountSecurityPanel />
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION: ACCOUNT */}
          {/* ============================================================== */}
          {activeSection === 'account' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <AccountSecurityPanel />
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {/* Security Notifications Toggle */}
                <div
                  onClick={handleToggleSecurityNotifs}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Security notifications</p>
                    <p className="text-xs text-[#A8B3CC]">Get notified when peer safety numbers change</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      securityNotifs ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        securityNotifs ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Passkeys Active Display */}
                <div
                  onClick={() => {
                    playClickSound();
                    showToast('Passkey Verified', 'Biometric credential active: PASSKEY-ED25519-P2P', 'success');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Passkeys</p>
                    <p className="text-xs text-[#10B981] font-medium">
                      Active · Hardware key configured
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* Two-Step Verification */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowTwoStepModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Two-step verification</p>
                    <p className="text-xs text-[#A8B3CC]">
                      {twoStepPin ? '6-digit PIN protection enabled' : 'Disabled · Tap to configure'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {twoStepPin && (
                      <span className="text-xs font-semibold text-[#10B981]">
                        Enabled
                      </span>
                    )}
                    <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                  </div>
                </div>

                {/* Change Number */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowChangeNumberModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Change number</p>
                    <p className="text-xs text-[#A8B3CC] font-mono tabular-nums">Current: {oldPhoneNumber}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* Request Account Info */}
                <div
                  onClick={handleRequestAccountData}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Request account info</p>
                    <p className="text-xs text-[#A8B3CC]">Export downloadable JSON report of account and sessions</p>
                  </div>
                  <Download className="w-4 h-4 text-[#22D3EE] shrink-0" />
                </div>

                {/* Delete Account */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowDeleteConfirmModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between cursor-pointer text-[#F472B6] hover:bg-[#F472B6]/10"
                >
                  <span className="text-xs font-semibold">Delete account</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          )}

          {/* SECTION: PRIVACY */}
          {activeSection === 'privacy' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <ConnectivityPrivacyPanel />
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {/* Last Seen & Online */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Last seen and online</p>
                    <p className="text-xs text-[#A8B3CC] capitalize">{lastSeen}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          playClickSound();
                          setLastSeen(opt);
                          updateProfile({ lastSeenPrivacy: opt });
                          localStorage.setItem('splender_last_seen', opt);
                          showToast('Privacy Saved', `Last seen visible to: ${opt}`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg capitalize font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          lastSeen === opt
                            ? 'bg-[#8B5CF6] text-white'
                            : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Profile Photo Visibility */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Profile photo</p>
                    <p className="text-xs text-[#A8B3CC] capitalize">{profilePhotoPrivacy}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          playClickSound();
                          setProfilePhotoPrivacy(opt);
                          localStorage.setItem('splender_photo_privacy', opt);
                          showToast('Profile Photo Visibility', `Set to ${opt}`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg capitalize font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          profilePhotoPrivacy === opt
                            ? 'bg-[#8B5CF6] text-white'
                            : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* About Visibility */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">About</p>
                    <p className="text-xs text-[#A8B3CC] capitalize">{aboutPrivacy}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          playClickSound();
                          setAboutPrivacy(opt);
                          localStorage.setItem('splender_about_privacy', opt);
                          showToast('About Visibility', `Set to ${opt}`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg capitalize font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          aboutPrivacy === opt
                            ? 'bg-[#8B5CF6] text-white'
                            : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Status / Stories Visibility */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Status & Moments</p>
                    <p className="text-xs text-[#A8B3CC] capitalize">{statusPrivacy}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          playClickSound();
                          setStatusPrivacy(opt);
                          localStorage.setItem('splender_status_privacy', opt);
                          showToast('Status Visibility', `Set to ${opt}`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg capitalize font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          statusPrivacy === opt
                            ? 'bg-[#8B5CF6] text-white'
                            : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Read Receipts */}
                <div
                  onClick={handleToggleReadReceipts}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Read receipts</p>
                    <p className="text-xs text-[#A8B3CC]">
                      {readReceipts
                        ? 'Cyan read checkmarks active for read messages'
                        : 'Off: read checkmarks disabled in direct chats'}
                    </p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      readReceipts ? 'bg-[#22D3EE]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        readReceipts ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Default Message Timer */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Default message timer</p>
                    <p className="text-xs text-[#A8B3CC]">Start new chats with disappearing messages</p>
                  </div>
                  <select
                    value={defaultTimer}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setDefaultTimer(val);
                      localStorage.setItem('splender_default_timer', String(val));
                      showToast('Default Disappearing Timer', val === 0 ? 'Turned Off' : `${val / 3600} hours`, 'info');
                    }}
                    className="text-xs bg-[#080B14] border border-[#293650] rounded-lg px-2.5 py-1.5 outline-none text-[#22D3EE] font-semibold cursor-pointer"
                  >
                    <option value={0}>Off</option>
                    <option value={86400}>24 hours</option>
                    <option value={604800}>7 days</option>
                    <option value={7776000}>90 days</option>
                  </select>
                </div>

                {/* Blocked Contacts */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowBlockedModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Blocked contacts</p>
                    <p className="text-xs text-[#A8B3CC] tabular-nums">
                      {blockedUsers.length} contact{blockedUsers.length !== 1 ? 's' : ''} blocked
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* App Lock */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div
                    onClick={handleToggleAppLock}
                    className="flex-1 cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Fingerprint className="w-4 h-4 text-[#22D3EE]" />
                      <span className="text-xs font-semibold text-[#F4F7FF]">App lock (Biometric / PIN)</span>
                    </div>
                    <p className="text-xs text-[#A8B3CC] mt-0.5">
                      {appLockEnabled ? 'Require passcode or fingerprint when opening' : 'Disabled'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {appLockEnabled && (
                      <button
                        onClick={() => {
                          playClickSound();
                          onClose();
                          lockApp();
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#080B14] border border-[#293650] text-[#22D3EE] hover:border-[#22D3EE]/60 cursor-pointer whitespace-nowrap"
                      >
                        Lock Now
                      </button>
                    )}
                    <button
                      onClick={handleToggleAppLock}
                      className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                        appLockEnabled ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                          appLockEnabled ? 'left-5.5' : 'left-0.5'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION: CHATS */}
          {activeSection === 'chats' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <ThemeSelectorPanel />
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {/* Theme Selector */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowThemeModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div className="flex items-center gap-2.5">
                    {darkMode ? <Moon className="w-4 h-4 text-[#8B5CF6]" /> : <Sun className="w-4 h-4 text-[#22D3EE]" />}
                    <div>
                      <p className="text-xs font-semibold text-[#F4F7FF]">Appearance Mode</p>
                      <p className="text-xs text-[#A8B3CC] capitalize">
                        {themeMode === 'system' ? 'System default' : themeMode === 'dark' ? 'Dark' : 'Light'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-[#22D3EE]">
                      {themeMode === 'system' ? 'System default' : themeMode === 'dark' ? 'Dark' : 'Light'}
                    </span>
                    <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                  </div>
                </div>

                {/* Wallpaper */}
                <div
                  onClick={() => {
                    playClickSound();
                    setIsWallpaperEngineOpen(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div className="flex items-center gap-2.5">
                    <Palette className="w-4 h-4 text-[#22D3EE]" />
                    <div>
                      <p className="text-xs font-semibold text-[#F4F7FF]">Wallpaper</p>
                      <p className="text-xs text-[#A8B3CC]">Aurora Nebula mesh, gradients & custom photos</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* Media Visibility */}
                <div
                  onClick={() => {
                    playClickSound();
                    const next = !mediaVisibility;
                    setMediaVisibility(next);
                    localStorage.setItem('splender_media_visibility', String(next));
                    showToast('Media Visibility', next ? 'Newly received media saved to gallery' : 'Media kept in app storage only', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Media visibility</p>
                    <p className="text-xs text-[#A8B3CC]">Show newly downloaded media in your device gallery</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      mediaVisibility ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        mediaVisibility ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Keep Chats Archived */}
                <div
                  onClick={() => {
                    playClickSound();
                    const next = !keepArchived;
                    setKeepArchived(next);
                    localStorage.setItem('splender_keep_archived', String(next));
                    showToast('Keep Archived', next ? 'Archived chats stay hidden' : 'Archived chats will unarchive on message', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Keep chats archived</p>
                    <p className="text-xs text-[#A8B3CC]">Archived chats remain archived when a new message arrives</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      keepArchived ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        keepArchived ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Enter is send */}
                <div
                  onClick={() => {
                    playClickSound();
                    const next = !enterIsSend;
                    setEnterIsSend(next);
                    localStorage.setItem('splender_enter_is_send', String(next));
                    showToast('Enter Key Mode', next ? 'Enter sends message' : 'Enter adds new line', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Enter is send</p>
                    <p className="text-xs text-[#A8B3CC]">Enter key sends message immediately</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      enterIsSend ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        enterIsSend ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Chat Backup & Restore */}
                <div className="p-3.5 space-y-3">
                  <input
                    type="file"
                    ref={backupFileInputRef}
                    accept=".splender,.json"
                    onChange={handleRestoreBackupFile}
                    className="hidden"
                  />
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#F4F7FF]">Chat Backup & Restore (.splender)</p>
                      <p className="text-xs text-[#A8B3CC] truncate">
                        {isBackingUp ? 'Packaging encrypted archive...' : `Last backup: ${lastBackupTime}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          playClickSound();
                          backupFileInputRef.current?.click();
                        }}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-[#080B14] border border-[#293650] text-[#F4F7FF] flex items-center gap-1.5 hover:border-[#22D3EE]/60 cursor-pointer whitespace-nowrap"
                        title="Restore .splender file"
                      >
                        <Download className="w-3.5 h-3.5 text-[#22D3EE]" />
                        <span>Restore</span>
                      </button>
                      <button
                        onClick={handleCreateChatBackup}
                        disabled={isBackingUp}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold aurora-cta-gradient text-white flex items-center gap-1.5 disabled:opacity-50 cursor-pointer whitespace-nowrap"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isBackingUp ? 'animate-spin' : ''}`} />
                        <span>Back Up</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION: NOTIFICATIONS */}
          {activeSection === 'notifications' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {/* Push Notifications Toggle */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Push notifications</p>
                    <p className="text-xs text-[#A8B3CC]">Real-time alerts for incoming messages and calls</p>
                  </div>
                  <button
                    onClick={handleTogglePush}
                    className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer shrink-0 ${
                      pushEnabled ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        pushEnabled ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </button>
                </div>

                {/* Conversation tones */}
                <div
                  onClick={() => {
                    const next = !soundOn;
                    setSoundOn(next);
                    setSoundEnabled(next);
                    showToast('Sound Effects', next ? 'Conversation tones enabled' : 'Tones muted', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Conversation tones</p>
                    <p className="text-xs text-[#A8B3CC]">Play sounds for incoming and sent messages</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      soundOn ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        soundOn ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Haptic Vibration */}
                <div
                  onClick={() => {
                    const next = !hapticsOn;
                    setHapticsOn(next);
                    setHapticsEnabled(next);
                    showToast('Vibration', next ? 'Haptic feedback on' : 'Haptics off', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Vibration & haptics</p>
                    <p className="text-xs text-[#A8B3CC]">Subtle tactile feedback on tap and message arrival</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      hapticsOn ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        hapticsOn ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* High Priority Alerts */}
                <div
                  onClick={() => {
                    playClickSound();
                    const next = !highPriorityNotifs;
                    setHighPriorityNotifs(next);
                    localStorage.setItem('splender_high_priority_notifs', String(next));
                    showToast('High Priority Notifications', next ? 'Banners show top previews' : 'Previews hidden', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">High priority notifications</p>
                    <p className="text-xs text-[#A8B3CC]">Show notification banners at the top of the screen</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      highPriorityNotifs ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        highPriorityNotifs ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>

                {/* Test Chime */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Test sound chime</p>
                    <p className="text-xs text-[#A8B3CC]">Play standard Splender notification chime</p>
                  </div>
                  <button
                    onClick={() => {
                      sendTestNotification();
                      showToast('Chime Tested', 'Splender harmonic chime played', 'info');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#080B14] border border-[#293650] hover:border-[#22D3EE]/60 text-[#22D3EE] text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Play Chime
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SECTION: STORAGE AND DATA */}
          {activeSection === 'storage' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <MediaStorageEnginePanel />
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                {/* Manage Storage */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowManageStorageModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Manage storage</p>
                    <p className="text-xs text-[#A8B3CC] tabular-nums">
                      {(messages.length * 1.8 + 14.2).toFixed(1)} MB used across {conversations.length} chats
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* Network Usage */}
                <div
                  onClick={() => {
                    playClickSound();
                    setShowNetworkUsageModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Network usage</p>
                    <p className="text-xs text-[#A8B3CC] tabular-nums">
                      {messages.length * 24} KB sent · {messages.length * 18} KB received
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>

                {/* Media Auto-Download */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Media auto-download</p>
                    <p className="text-xs text-[#A8B3CC]">Photos and audio automatically</p>
                  </div>
                  <select
                    value={autoDownload}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      setAutoDownload(val);
                      localStorage.setItem('splender_auto_download', val);
                      showToast('Auto-Download Updated', `Auto-download on ${val}`, 'info');
                    }}
                    className="text-xs bg-[#080B14] border border-[#293650] rounded-lg px-2.5 py-1.5 outline-none text-[#22D3EE] font-semibold cursor-pointer"
                  >
                    <option value="wifi">Wi-Fi only</option>
                    <option value="always">Wi-Fi and mobile data</option>
                    <option value="never">Never</option>
                  </select>
                </div>

                {/* Media Upload Quality */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Media upload quality</p>
                    <p className="text-xs text-[#A8B3CC]">HD photos and videos preserve high clarity</p>
                  </div>
                  <select
                    value={mediaQuality || 'high'}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      setMediaQuality(val);
                      showToast('Upload Quality', `Set to ${val.toUpperCase()}`, 'info');
                    }}
                    className="text-xs bg-[#080B14] border border-[#293650] rounded-lg px-2.5 py-1.5 outline-none text-[#22D3EE] font-semibold cursor-pointer"
                  >
                    <option value="medium">Standard quality</option>
                    <option value="high">High quality</option>
                    <option value="hd">HD 4K clarity</option>
                  </select>
                </div>

                {/* Use Less Data for Calls */}
                <div
                  onClick={() => {
                    playClickSound();
                    const next = !lowDataCalls;
                    setLowDataCalls(next);
                    localStorage.setItem('splender_low_data_calls', String(next));
                    showToast('Call Data Saver', next ? 'Low data call encoding on' : 'HD call bitrate active', 'info');
                  }}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Use less data for calls</p>
                    <p className="text-xs text-[#A8B3CC]">Compress WebRTC peer streams on mobile networks</p>
                  </div>
                  <div
                    className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                      lowDataCalls ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                        lowDataCalls ? 'left-5.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION: LANGUAGE */}
          {activeSection === 'language' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <LanguageAccessibilityPanel />
              <div className="space-y-2">
              {[
                { id: 'mr' as const, name: 'मराठी (Marathi)', desc: 'महाराष्ट्र प्रादेशिक भाषा (Default)' },
                { id: 'hi' as const, name: 'हिन्दी (Hindi)', desc: 'राष्ट्रीय मानक भाषा' },
                { id: 'en' as const, name: 'English', desc: 'English (US & Global)' },
                { id: 'es' as const, name: 'Español (Spanish)', desc: 'Idioma global español' },
                { id: 'fr' as const, name: 'Français (French)', desc: 'Langue française' },
                { id: 'de' as const, name: 'Deutsch (German)', desc: 'Deutsche Sprache' },
              ].map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    playClickSound();
                    setLanguage(item.id);
                    setSelectedLanguage(item.name);
                    localStorage.setItem('splender_language', item.name);
                    showToast('Language Updated', `Switched interface to ${item.name}`, 'success');
                  }}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-colors ${
                    language === item.id
                      ? 'border-[#22D3EE] bg-[#131D32] font-semibold'
                      : 'border-[#293650] bg-[#131D32]/60 hover:bg-[#131D32]'
                  }`}
                >
                  <div>
                    <span className="text-xs font-semibold text-[#F4F7FF]">{item.name}</span>
                    <p className="text-xs text-[#A8B3CC] mt-0.5">{item.desc}</p>
                  </div>
                  {language === item.id && <Check className="w-4 h-4 text-[#22D3EE] stroke-[2.5]" />}
                </div>
              ))}
              </div>
            </div>
          )}

          {/* SECTION: HELP */}
          {activeSection === 'help' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="divide-y divide-[#293650]/70 rounded-2xl bg-[#131D32]/90 border border-[#293650] overflow-hidden">
                <div
                  onClick={() => {
                    playClickSound();
                    setShowHelpModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Help Center</p>
                    <p className="text-xs text-[#A8B3CC]">Frequently asked questions and support</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>
                <div
                  onClick={() => {
                    playClickSound();
                    setShowTermsModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">Terms and Privacy Policy</p>
                    <p className="text-xs text-[#A8B3CC]">Signal protocol end-to-end encryption guarantees</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A8B3CC]" />
                </div>
                <div
                  onClick={() => {
                    playClickSound();
                    setShowAppInfoModal(true);
                  }}
                  className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-[#0D1424]/70"
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">App Info</p>
                    <p className="text-xs text-[#A8B3CC] font-mono tabular-nums">Splender Chat · Android 17 API 37</p>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-[#22D3EE] font-semibold">Verified</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUB-MODAL 1: TWO-STEP VERIFICATION PIN */}
      {/* ========================================================================= */}
      {showTwoStepModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-semibold font-['Outfit']">Two-Step Verification</h3>
              </div>
              <button onClick={() => setShowTwoStepModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#A8B3CC] leading-relaxed">
              Enter a 6-digit numeric PIN required when registering your account with Splender Chat again:
            </p>

            <div className="flex justify-center py-2">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                placeholder="••••••"
                className="w-48 text-center text-2xl tracking-[0.5em] font-mono tabular-nums font-bold py-2.5 rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                autoFocus
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              {twoStepPin && (
                <button
                  onClick={handleDisableTwoStepPin}
                  className="flex-1 py-2.5 rounded-xl border border-[#F472B6]/60 text-[#F472B6] font-semibold text-xs hover:bg-[#F472B6]/10 transition-colors cursor-pointer"
                >
                  Turn Off
                </button>
              )}
              <button
                onClick={handleSaveTwoStepPin}
                className="flex-1 py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs cursor-pointer"
              >
                Save PIN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 2: CHANGE NUMBER FORM */}
      {showChangeNumberModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <form
            onSubmit={handleChangePhoneNumber}
            className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]"
          >
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-semibold font-['Outfit']">Change Phone Number</h3>
              </div>
              <button type="button" onClick={() => setShowChangeNumberModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#A8B3CC] leading-relaxed">
              Changing your phone number migrates your account info, groups, and settings to the new number.
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-[#A8B3CC]">Current Phone Number</label>
                <input
                  type="text"
                  disabled
                  value={oldPhoneNumber}
                  className="w-full mt-1 px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl bg-[#080B14]/70 border border-[#293650] text-[#A8B3CC]"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#A8B3CC]">New Phone Number (with Country Code)</label>
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={newPhoneNumber}
                  onChange={(e) => setNewPhoneNumber(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                  autoFocus
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs cursor-pointer"
            >
              Verify & Migrate Number
            </button>
          </form>
        </div>
      )}

      {/* SUB-MODAL 3: DELETE ACCOUNT PURGE CONFIRMATION */}
      {showDeleteConfirmModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/85 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-rose-500/40 p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]">
            <div className="flex items-center gap-2.5 text-rose-400">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-semibold font-['Outfit']">Delete This Account?</h3>
            </div>

            <p className="text-xs text-[#F4F7FF] leading-relaxed">
              This action is permanent and cannot be undone:
            </p>
            <ul className="text-xs text-[#A8B3CC] space-y-1 list-disc pl-4">
              <li>All chat history and media will be erased</li>
              <li>You will be removed from all groups</li>
              <li>Your local cryptographic keys will be destroyed</li>
            </ul>

            <div>
              <label className="text-xs font-medium text-[#A8B3CC]">Type DELETE to confirm:</label>
              <input
                type="text"
                placeholder="DELETE"
                value={deleteConfirmationText}
                onChange={(e) => setDeleteConfirmationText(e.target.value)}
                className="w-full mt-1 px-3.5 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none uppercase font-mono focus:border-rose-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowDeleteConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-[#131D32] border border-[#293650] text-[#F4F7FF] font-semibold text-xs hover:bg-[#080B14] cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handlePurgeAccount}
                disabled={deleteConfirmationText.trim().toUpperCase() !== 'DELETE'}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white font-semibold text-xs hover:bg-rose-700 disabled:opacity-40 transition-colors cursor-pointer"
              >
                Erase Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 4: BLOCKED CONTACTS SHEET */}
      {showBlockedModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 max-h-[80vh] flex flex-col text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5 shrink-0">
              <div className="flex items-center gap-2">
                <UserX className="w-4 h-4 text-[#F472B6]" />
                <h3 className="text-sm font-semibold font-['Outfit'] tabular-nums">Blocked Contacts ({blockedUsers.length})</h3>
              </div>
              <button onClick={() => setShowBlockedModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar divide-y divide-[#293650]/70">
              {blockedUsers.length === 0 ? (
                <div className="py-8 text-center text-[#A8B3CC] text-xs">
                  <UserX className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  <p>No blocked contacts</p>
                </div>
              ) : (
                blockedUsers.map((uid) => {
                  const contact = contacts.find((c) => c.targetUid === uid);
                  const name = contact?.displayName || `User ${uid.slice(-4)}`;
                  return (
                    <div key={uid} className="py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={contact?.avatar || createDeterministicAvatarDataUri(name, '#8B5CF6')}
                          alt={name}
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <span className="text-xs font-semibold text-[#F4F7FF]">{name}</span>
                      </div>
                      <button
                        onClick={() => handleToggleBlockContact(uid, name)}
                        className="px-3 py-1 rounded-xl bg-[#131D32] border border-[#293650] text-xs font-semibold text-[#22D3EE] hover:border-[#22D3EE]/60 cursor-pointer"
                      >
                        Unblock
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            <button
              onClick={() => setShowBlockedModal(false)}
              className="w-full py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* SUB-MODAL 5: WALLPAPER PICKER */}
      {showWallpaperPicker && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-semibold font-['Outfit']">Chat Wallpaper</h3>
              </div>
              <button onClick={() => setShowWallpaperPicker(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {[
                { name: 'Aurora Nebula Deep Space', color: '#080B14', preview: 'bg-[#080B14]' },
                { name: 'Electric Violet Glow', color: '#1E1B4B', preview: 'bg-[#1E1B4B]' },
                { name: 'Deep Midnight Slate', color: '#0F172A', preview: 'bg-[#0F172A]' },
                { name: 'Cyber Indigo Mesh', color: '#312E81', preview: 'bg-[#312E81]' },
                { name: 'Sovereign Emerald Dark', color: '#064E3B', preview: 'bg-[#064E3B]' },
              ].map((wp) => (
                <div
                  key={wp.name}
                  onClick={() => handleSelectWallpaperPreset(wp.name, wp.color)}
                  className="p-2.5 rounded-xl border border-[#293650] bg-[#131D32]/80 flex items-center justify-between hover:border-[#22D3EE]/50 cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg ${wp.preview} border border-white/15`} />
                    <span className="text-xs font-semibold text-[#F4F7FF]">{wp.name}</span>
                  </div>
                  {chatWallpaper === wp.name && <Check className="w-4 h-4 text-[#22D3EE]" />}
                </div>
              ))}

              {/* Upload Custom Photo */}
              <div
                onClick={() => wallpaperInputRef.current?.click()}
                className="p-2.5 rounded-xl border border-dashed border-[#22D3EE]/60 flex items-center gap-3 cursor-pointer hover:bg-[#131D32] text-[#22D3EE]"
              >
                <div className="w-8 h-8 rounded-lg bg-[#22D3EE]/10 flex items-center justify-center">
                  <ImageIcon className="w-4 h-4" />
                </div>
                <span className="text-xs font-semibold">Choose from Photos / Gallery</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 6: MANAGE STORAGE BREAKDOWN */}
      {showManageStorageModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 max-h-[85vh] flex flex-col text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5 shrink-0">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-semibold font-['Outfit']">Manage Storage</h3>
              </div>
              <button onClick={() => setShowManageStorageModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Storage Progress Bar */}
            <div className="p-3.5 bg-[#131D32] border border-[#293650] rounded-2xl space-y-2.5 shrink-0">
              <div className="flex items-center justify-between text-xs font-semibold tabular-nums">
                <span>{(messages.length * 1.8 + 14.2).toFixed(1)} MB Used</span>
                <span className="text-[#A8B3CC] font-mono tabular-nums">128 GB Free</span>
              </div>
              <div className="h-2 w-full bg-[#080B14] border border-[#293650] rounded-full overflow-hidden flex">
                <div className="bg-[#8B5CF6] h-full" style={{ width: '18%' }} />
                <div className="bg-[#22D3EE] h-full" style={{ width: '8%' }} />
              </div>
              <div className="flex items-center gap-3 text-xs text-[#A8B3CC] tabular-nums">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-sm bg-[#8B5CF6]" />
                  <span>Media Cache (14.2 MB)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-sm bg-[#22D3EE]" />
                  <span>Messages ({(messages.length * 1.8).toFixed(1)} MB)</span>
                </div>
              </div>
            </div>

            {/* Per-Conversation Storage List */}
            <div className="flex-1 overflow-y-auto no-scrollbar space-y-2">
              <p className="text-xs font-semibold text-[#A8B3CC]">Chats & Channels</p>
              {conversations.map((conv) => {
                const convMsgs = messages.filter((m) => m.conversationId === conv.id);
                const sizeEstimate = Math.max(0.4, convMsgs.length * 1.2).toFixed(1);
                return (
                  <div
                    key={conv.id}
                    className="p-3 rounded-xl border border-[#293650] bg-[#131D32]/70 flex items-center justify-between"
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      <p className="text-xs font-semibold text-[#F4F7FF] truncate">{conv.groupName || 'Direct Chat'}</p>
                      <p className="text-xs text-[#A8B3CC] tabular-nums">{convMsgs.length} messages</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs font-mono tabular-nums font-semibold text-[#F4F7FF]">
                        {sizeEstimate} MB
                      </span>
                      <button
                        onClick={async () => {
                          playClickSound();
                          await clearConversationMessages(conv.id);
                        }}
                        className="p-1.5 rounded-lg hover:bg-rose-500/15 text-[#A8B3CC] hover:text-rose-400 cursor-pointer transition-colors"
                        title="Clear conversation messages"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => {
                playClickSound();
                showToast('Storage Cache Cleaned', 'Temporary media cache cleared (14.2 MB freed)', 'success');
                setShowManageStorageModal(false);
              }}
              className="w-full py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs cursor-pointer"
            >
              Clear Cached Media
            </button>
          </div>
        </div>
      )}

      {/* SUB-MODAL 7: NETWORK USAGE */}
      {showNetworkUsageModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-semibold font-['Outfit']">Network Usage</h3>
              </div>
              <button onClick={() => setShowNetworkUsageModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs divide-y divide-[#293650]/70">
              <div className="flex items-center justify-between py-2">
                <span className="text-[#A8B3CC]">Messages sent</span>
                <span className="font-mono tabular-nums font-semibold">{messages.length}</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-[#A8B3CC]">Total bytes sent</span>
                <span className="font-mono tabular-nums font-semibold">{(messages.length * 24.4).toFixed(1)} KB</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-[#A8B3CC]">Total bytes received</span>
                <span className="font-mono tabular-nums font-semibold">{(messages.length * 18.2).toFixed(1)} KB</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-[#A8B3CC]">Media uploaded</span>
                <span className="font-mono tabular-nums font-semibold">14.8 MB</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-[#A8B3CC]">WebRTC Call time</span>
                <span className="font-mono tabular-nums font-semibold">14m 28s</span>
              </div>
            </div>

            <button
              onClick={() => {
                playClickSound();
                showToast('Statistics Reset', 'Network usage metrics reset to zero', 'info');
                setShowNetworkUsageModal(false);
              }}
              className="w-full py-2.5 rounded-xl bg-[#131D32] border border-[#293650] hover:border-[#22D3EE]/50 font-semibold text-xs text-[#F4F7FF] transition-colors cursor-pointer"
            >
              Reset Statistics
            </button>
          </div>
        </div>
      )}

      {/* SUB-MODAL 8: THEME SWITCHER */}
      {showThemeModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#080B14]/80 backdrop-blur-md animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#0D1424] border border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-[#293650] pb-2.5">
              <h3 className="text-sm font-semibold font-['Outfit']">Appearance & Palette</h3>
              <button onClick={() => setShowThemeModal(false)} className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {[
                { id: 'dark', label: 'Dark (Aurora Nebula)', desc: 'Obsidian Night & Deep Space contrast' },
                { id: 'system', label: 'System default', desc: 'Matches device color settings' },
                { id: 'light', label: 'Light', desc: 'Clean high-contrast daylight mode' },
              ].map((t) => (
                <div
                  key={t.id}
                  onClick={() => {
                    playClickSound();
                    setThemeMode(t.id as any);
                    showToast('Theme Changed', `Applied ${t.label} theme`, 'info');
                    setShowThemeModal(false);
                  }}
                  className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-colors ${
                    themeMode === t.id
                      ? 'border-[#22D3EE] bg-[#131D32] font-semibold'
                      : 'border-[#293650] bg-[#131D32]/60 hover:bg-[#131D32]'
                  }`}
                >
                  <div>
                    <p className="text-xs font-semibold text-[#F4F7FF]">{t.label}</p>
                    <p className="text-xs text-[#A8B3CC]">{t.desc}</p>
                  </div>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      themeMode === t.id ? 'border-[#22D3EE] bg-[#22D3EE]' : 'border-[#293650]'
                    }`}
                  >
                    {themeMode === t.id && <div className="w-1.5 h-1.5 rounded-full bg-[#080B14]" />}
                  </div>
                </div>
              ))}
            </div>

            {/* Visual Accent Theme Palette */}
            <div className="pt-2 border-t border-[#293650] space-y-2">
              <p className="text-xs font-semibold text-[#A8B3CC]">Visual Theme</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'indigo_dawn' as const, label: 'Indigo Dawn', color: '#8B5CF6' },
                  { id: 'midnight_oled' as const, label: 'Midnight OLED', color: '#000000' },
                  { id: 'cyber_indigo' as const, label: 'Cyber Indigo', color: '#3B82F6' },
                  { id: 'teal_dusk' as const, label: 'Teal Dusk', color: '#06B6D4' },
                  { id: 'emerald_luxury' as const, label: 'Emerald Lux', color: '#10B981' },
                  { id: 'dark_amber' as const, label: 'Dark Amber', color: '#F59E0B' },
                ].map((th) => (
                  <button
                    key={th.id}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setVisualTheme(th.id);
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center gap-1.5 transition-colors cursor-pointer ${
                      visualTheme === th.id
                        ? 'border-[#22D3EE] bg-[#131D32]'
                        : 'border-[#293650] bg-[#131D32]/60 hover:border-[#8B5CF6]/50'
                    }`}
                  >
                    <div
                      className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center"
                      style={{ backgroundColor: th.color }}
                    >
                      {visualTheme === th.id && <Check className="w-3 h-3 text-white" />}
                    </div>
                    <span className="text-[11px] font-medium text-center leading-tight truncate max-w-full">
                      {th.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowThemeModal(false)}
              className="w-full py-2.5 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Modern Wallpaper Engine Modal */}
      <WallpaperEngineModal
        isOpen={isWallpaperEngineOpen}
        onClose={() => setIsWallpaperEngineOpen(false)}
      />
    </div>
  );
};
