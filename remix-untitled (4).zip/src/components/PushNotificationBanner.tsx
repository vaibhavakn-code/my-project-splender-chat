import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Film, X, Bell, Send, Check } from 'lucide-react';
import { onNotification, InAppNotificationEvent } from '../lib/notifications';
import { useChat } from '../context/ChatContext';
import { playClickSound, triggerHeartHaptic } from '../lib/sound';

export const PushNotificationBanner: React.FC = () => {
  const [currentNotif, setCurrentNotif] = useState<InAppNotificationEvent | null>(null);
  const [quickReplyText, setQuickReplyText] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [replySentSuccess, setReplySentSuccess] = useState(false);
  const dismissTimerRef = useRef<NodeJS.Timeout | null>(null);

  const {
    setActiveTab,
    setActiveConversationId,
    sendMessage,
    showToast,
  } = useChat();

  const resetDismissTimer = (durationMs = 6000) => {
    if (dismissTimerRef.current) {
      clearTimeout(dismissTimerRef.current);
    }
    dismissTimerRef.current = setTimeout(() => {
      setCurrentNotif(null);
      setQuickReplyText('');
      setReplySentSuccess(false);
    }, durationMs);
  };

  useEffect(() => {
    const unsubscribe = onNotification((notif) => {
      setCurrentNotif(notif);
      setQuickReplyText('');
      setReplySentSuccess(false);
      resetDismissTimer(6500);
    });

    return () => {
      unsubscribe();
      if (dismissTimerRef.current) {
        clearTimeout(dismissTimerRef.current);
      }
    };
  }, []);

  if (!currentNotif) return null;

  const isStory = currentNotif.tag?.startsWith('story_');
  const isChat = currentNotif.tag?.startsWith('chat_') || Boolean(currentNotif.conversationId);
  const convId = currentNotif.conversationId;

  const handleOpenConversation = () => {
    playClickSound();
    if (isStory) {
      setActiveTab('stories');
    } else if (isChat) {
      setActiveTab('chats');
      if (convId) {
        setActiveConversationId(convId);
      }
    }
    setCurrentNotif(null);
  };

  const handleSendQuickReply = async (textToSend?: string) => {
    const text = (textToSend || quickReplyText).trim();
    if (!text || !convId) return;

    playClickSound();
    triggerHeartHaptic();
    setIsSendingReply(true);

    try {
      await sendMessage(text, 'text', undefined, undefined, undefined, undefined, undefined, {
        conversationId: convId,
      });

      setReplySentSuccess(true);
      setQuickReplyText('');
      showToast('Quick Reply Sent', text, 'success');

      setTimeout(() => {
        setCurrentNotif(null);
        setReplySentSuccess(false);
      }, 1200);
    } catch (err: any) {
      showToast('Reply Failed', err.message, 'error');
    } finally {
      setIsSendingReply(false);
    }
  };

  const quickChips = ['On my way', 'Sounds good', 'Okay', 'Got it'];

  return (
    <div className="fixed top-3 left-3 right-3 max-w-md mx-auto z-50 animate-in fade-in slide-in-from-top-3 duration-200 pointer-events-auto">
      <div className="w-full p-3.5 rounded-2xl border border-[#293650] bg-[#0D1424]/95 backdrop-blur-xl text-[#F4F7FF] shadow-[0_20px_48px_rgba(0,0,0,0.75)] flex flex-col gap-2.5">
        {/* Top Header Row */}
        <div
          onClick={handleOpenConversation}
          className="flex items-center gap-3 cursor-pointer group"
        >
          {/* Avatar / Icon */}
          <div className="relative shrink-0">
            {currentNotif.icon && currentNotif.icon !== '/icon.png' ? (
              <img
                src={currentNotif.icon}
                alt=""
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-[#22D3EE]/50 group-hover:scale-105 transition-transform"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[#131D32] border border-[#293650] text-[#22D3EE] flex items-center justify-center">
                {isStory ? (
                  <Film className="w-5 h-5 text-[#8B5CF6]" />
                ) : (
                  <MessageSquare className="w-5 h-5 text-[#22D3EE]" />
                )}
              </div>
            )}
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center border border-[#0D1424]">
              <Bell className="w-2.5 h-2.5" />
            </span>
          </div>

          {/* Text Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-semibold text-[#F4F7FF] truncate leading-tight">
                {currentNotif.title}
              </p>
              <span className="text-xs text-[#22D3EE] font-medium group-hover:underline whitespace-nowrap shrink-0">
                Open
              </span>
            </div>
            <p className="text-xs text-[#A8B3CC] truncate mt-0.5">
              {currentNotif.body}
            </p>
          </div>

          {/* Dismiss Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              playClickSound();
              setCurrentNotif(null);
            }}
            className="p-1.5 rounded-lg text-[#A8B3CC] hover:text-[#F4F7FF] hover:bg-[#131D32] transition-colors cursor-pointer shrink-0"
            title="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Interactive Quick Reply Engine */}
        {isChat && convId && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="pt-2 border-t border-[#293650]/80 space-y-2"
          >
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {quickChips.map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendQuickReply(chip)}
                  disabled={isSendingReply}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-[#131D32] hover:border-[#22D3EE]/60 text-[#F4F7FF] border border-[#293650] shrink-0 transition-colors cursor-pointer disabled:opacity-40 whitespace-nowrap"
                >
                  {chip}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={quickReplyText}
                onChange={(e) => {
                  setQuickReplyText(e.target.value);
                  if (dismissTimerRef.current) clearTimeout(dismissTimerRef.current);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSendQuickReply();
                  }
                }}
                placeholder="Type quick reply..."
                className="flex-1 px-3 py-1.5 text-xs rounded-xl bg-[#080B14] border border-[#293650] outline-none focus:border-[#22D3EE] text-[#F4F7FF]"
              />

              <button
                type="button"
                onClick={() => handleSendQuickReply()}
                disabled={!quickReplyText.trim() || isSendingReply}
                className="p-2 rounded-xl aurora-cta-gradient disabled:opacity-40 text-white transition-transform active:scale-95 cursor-pointer shrink-0 flex items-center justify-center"
                title="Send Reply"
              >
                {replySentSuccess ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
