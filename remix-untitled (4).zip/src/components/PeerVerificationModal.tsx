import React, { useState } from 'react';
import { Shield, ShieldCheck, X, QrCode, Copy, Check, Camera, RefreshCw } from 'lucide-react';
import { P2PCryptoEngine } from '../lib/p2pSecurity';
import { E2EEManager } from '../lib/masterFeatures';
import { playClickSound } from '../lib/sound';
import { useChat } from '../context/ChatContext';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

interface PeerVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  partnerUid: string;
  partnerName: string;
  partnerSplenderId: string;
  partnerAvatar?: string;
  isVerified?: boolean;
  onToggleVerified?: (verified: boolean) => void;
}

export const PeerVerificationModal: React.FC<PeerVerificationModalProps> = ({
  isOpen,
  onClose,
  partnerUid,
  partnerName,
  partnerSplenderId,
  partnerAvatar,
  isVerified: initialVerified = false,
  onToggleVerified,
}) => {
  const { firebaseUser, currentUserProfile, showToast } = useChat();
  const [activeTab, setActiveTab] = useState<'fingerprint' | 'scan'>('fingerprint');
  const [isVerified, setIsVerified] = useState(initialVerified);
  const [hasCopied, setHasCopied] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  if (!isOpen) return null;

  const myId = currentUserProfile?.splenderId || firebaseUser?.uid || 'MY_ID';
  const fingerprint = E2EEManager.generateSafetyNumber(myId, partnerSplenderId || partnerUid) || P2PCryptoEngine.generateSafetyFingerprint(myId, partnerSplenderId || partnerUid);
  const blocks = fingerprint.split(' ');

  const handleCopy = () => {
    playClickSound();
    navigator.clipboard.writeText(fingerprint);
    setHasCopied(true);
    showToast('Copied', 'Safety number copied to clipboard', 'info');
    setTimeout(() => setHasCopied(false), 2500);
  };

  const handleToggleVerify = () => {
    playClickSound();
    const next = !isVerified;
    setIsVerified(next);
    if (onToggleVerified) onToggleVerified(next);
    showToast(
      next ? 'Contact Verified' : 'Verification Cleared',
      next ? `Safety number confirmed for ${partnerName}` : `Marked unverified`,
      next ? 'success' : 'info'
    );
  };

  const handleSimulateScan = () => {
    setIsScanning(true);
    playClickSound();
    setTimeout(() => {
      setIsScanning(false);
      setIsVerified(true);
      if (onToggleVerified) onToggleVerified(true);
      showToast('QR Code Verified', `Safety number matched with ${partnerName}`, 'success');
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#FFFFFF] dark:bg-[#1F2C34] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#008069] to-[#00a884] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <div>
              <h3 className="text-sm font-bold">Verify Safety Number</h3>
              <p className="text-[10px] text-white/80 font-mono">Signal Double Ratchet E2EE</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* User Card */}
        <div className="p-4 bg-slate-50 dark:bg-[#111B21] border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={partnerAvatar || createDeterministicAvatarDataUri(partnerName, '#008069')}
              alt={partnerName}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-emerald-500/30"
            />
            <div>
              <p className="text-xs font-bold text-[#111B21] dark:text-[#E9EDEF]">{partnerName}</p>
              <p className="text-[10px] font-mono text-slate-400">{partnerSplenderId}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
            {isVerified ? (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>Verified</span>
              </>
            ) : (
              <>
                <Shield className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-amber-600 dark:text-amber-400">Unverified</span>
              </>
            )}
          </div>
        </div>

        {/* Tabs: Fingerprint vs Scan QR */}
        <div className="flex border-b border-slate-200 dark:border-slate-800">
          <button
            onClick={() => {
              playClickSound();
              setActiveTab('fingerprint');
            }}
            className={`flex-1 py-2 text-xs font-bold transition-colors cursor-pointer text-center ${
              activeTab === 'fingerprint'
                ? 'border-b-2 border-[#008069] dark:border-[#25D366] text-[#008069] dark:text-[#25D366]'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            60-Digit Fingerprint
          </button>
          <button
            onClick={() => {
              playClickSound();
              setActiveTab('scan');
            }}
            className={`flex-1 py-2 text-xs font-bold transition-colors cursor-pointer text-center ${
              activeTab === 'scan'
                ? 'border-b-2 border-[#008069] dark:border-[#25D366] text-[#008069] dark:text-[#25D366]'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
          >
            Scan QR Code
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          {activeTab === 'fingerprint' ? (
            <>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed text-center">
                Compare these 60 numbers with <strong>{partnerName}</strong> to verify that messages are end-to-end encrypted without third-party interception.
              </p>

              {/* 12 Blocks Grid */}
              <div className="grid grid-cols-3 gap-2 bg-slate-100 dark:bg-[#111B21] p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
                {blocks.map((block, i) => (
                  <div key={i} className="text-center py-1">
                    <span className="text-xs font-mono font-bold tracking-wider text-[#111B21] dark:text-[#E9EDEF]">
                      {block}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
                >
                  {hasCopied ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span>{hasCopied ? 'Copied' : 'Copy Numbers'}</span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center space-y-4 text-center py-2">
              {/* QR Simulator */}
              <div className="w-48 h-48 rounded-2xl bg-white p-3 shadow-md border-2 border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center relative">
                {isScanning ? (
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <RefreshCw className="w-8 h-8 text-[#008069] animate-spin" />
                    <span className="text-[10px] font-mono text-slate-600">Matching crypto keys...</span>
                  </div>
                ) : (
                  <>
                    <QrCode className="w-36 h-36 text-slate-900" />
                    <span className="text-[8px] font-mono text-slate-400 mt-1">SPLENDER-SEC-V3</span>
                  </>
                )}
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xs">
                Scan this code from {partnerName}'s device camera to automatically confirm identity verification.
              </p>

              <button
                onClick={handleSimulateScan}
                disabled={isScanning}
                className="w-full py-2.5 rounded-xl bg-[#008069] hover:bg-[#00705c] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
              >
                <Camera className="w-4 h-4" />
                <span>Simulate Camera QR Scan</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 bg-slate-50 dark:bg-[#111B21] border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <button
            onClick={handleToggleVerify}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              isVerified
                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isVerified ? 'Mark as Unverified' : 'Mark as Verified'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
