import React, { useState, useEffect } from 'react';
import {
  Phone,
  Video,
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  Link2,
  Plus,
  X,
  Share2,
  Copy,
  Check,
  Search,
  MessageSquare,
  Trash2,
  Clock,
  Shield,
  Info,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';
import { CallLogItem } from '../types';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

const INITIAL_CALL_LOGS: CallLogItem[] = [
  {
    id: 'call_1',
    partnerUid: 'peer_1',
    partnerName: 'Vaibhav Umbarkar',
    partnerAvatar: createDeterministicAvatarDataUri('Vaibhav Umbarkar', '#0F766E'),
    partnerSplenderId: 'SP-109283',
    type: 'video',
    direction: 'incoming',
    timestamp: Date.now() - 3600000 * 2,
    duration: 324,
  },
  {
    id: 'call_2',
    partnerUid: 'peer_2',
    partnerName: 'Sarah Jenkins',
    partnerAvatar: createDeterministicAvatarDataUri('Sarah Jenkins', '#7C3AED'),
    partnerSplenderId: 'SP-883921',
    type: 'voice',
    direction: 'missed',
    timestamp: Date.now() - 3600000 * 5,
  },
  {
    id: 'call_3',
    partnerUid: 'peer_3',
    partnerName: 'Tech Architects Group',
    partnerAvatar: createDeterministicAvatarDataUri('Tech Architects Group', '#0284C7'),
    partnerSplenderId: 'SP-992014',
    type: 'video',
    direction: 'outgoing',
    timestamp: Date.now() - 86400000,
    duration: 852,
  },
];

export const CallsTab: React.FC = () => {
  const {
    contacts,
    startCall,
    startDirectConversation,
    showToast,
    darkMode,
  } = useChat();

  const [isNewCallOpen, setIsNewCallOpen] = useState(false);
  const [showCallLinkModal, setShowCallLinkModal] = useState(false);
  const [callLinkType, setCallLinkType] = useState<'video' | 'voice'>('video');
  const [copiedLink, setCopiedLink] = useState(false);
  const [selectedCallLog, setSelectedCallLog] = useState<CallLogItem | null>(null);
  const [contactSearchQuery, setContactSearchQuery] = useState('');

  // Persistent call logs
  const [callLogs, setCallLogs] = useState<CallLogItem[]>(() => {
    try {
      const saved = localStorage.getItem('splender_call_logs');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_CALL_LOGS;
  });

  useEffect(() => {
    localStorage.setItem('splender_call_logs', JSON.stringify(callLogs));
  }, [callLogs]);

  const acceptedContacts = contacts.filter((c) => c.state === 'accepted');

  const filteredContacts = acceptedContacts.filter((c) => {
    if (!contactSearchQuery.trim()) return true;
    const q = contactSearchQuery.toLowerCase();
    return (
      c.displayName.toLowerCase().includes(q) ||
      c.splenderId.toLowerCase().includes(q)
    );
  });

  const handleStartCall = async (
    targetUid: string,
    targetName: string,
    targetAvatar: string,
    type: 'voice' | 'video'
  ) => {
    playClickSound();
    setIsNewCallOpen(false);
    setSelectedCallLog(null);

    // Add outgoing call to logs
    const newLog: CallLogItem = {
      id: `call_${Date.now()}`,
      partnerUid: targetUid,
      partnerName: targetName,
      partnerAvatar: targetAvatar,
      partnerSplenderId: `SP-${targetUid.slice(-6)}`,
      type,
      direction: 'outgoing',
      timestamp: Date.now(),
      duration: 0,
    };
    setCallLogs((prev) => [newLog, ...prev]);

    showToast(`Calling ${targetName}...`, `Initiating WebRTC P2P ${type} call`, 'info');
    await startCall(targetUid, targetName, targetAvatar, type);
  };

  const handleDeleteCallLog = (logId: string) => {
    playClickSound();
    setCallLogs((prev) => prev.filter((l) => l.id !== logId));
    setSelectedCallLog(null);
    showToast('Call Entry Removed', undefined, 'info');
  };

  const handleClearAllCalls = () => {
    playClickSound();
    setCallLogs([]);
    showToast('Call History Cleared', undefined, 'info');
  };

  const handleMessagePartner = (log: CallLogItem) => {
    playClickSound();
    setSelectedCallLog(null);
    startDirectConversation({
      uid: log.partnerUid,
      splenderId: log.partnerSplenderId,
      displayName: log.partnerName,
      avatar: log.partnerAvatar,
    });
  };

  const generatedCallLink = `https://splender.chat/v/p2p-${callLinkType === 'video' ? 'vid' : 'aud'}-${Math.random().toString(36).substring(2, 9)}`;

  const handleCopyCallLink = () => {
    playClickSound();
    navigator.clipboard?.writeText?.(generatedCallLink);
    setCopiedLink(true);
    showToast('Link Copied', 'Share this link with anyone to join your call', 'success');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return 'Missed';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto no-scrollbar pb-24 bg-[#F8FAFF] dark:bg-[#080B14] text-slate-900 dark:text-[#F4F7FF] select-none">
      {/* Create Call Link Section */}
      <div className="p-4 border-b border-slate-200/80 dark:border-[#293650]/75 bg-white/80 dark:bg-[#0D1424]/65">
        <div
          onClick={() => {
            playClickSound();
            setShowCallLinkModal(true);
          }}
          className="flex items-center gap-3.5 cursor-pointer hover:bg-slate-50 dark:hover:bg-[#131D32] p-2.5 rounded-2xl border border-transparent hover:border-slate-200 dark:hover:border-[#293650] transition-all"
        >
          <div className="w-11 h-11 rounded-2xl aurora-cta-gradient text-white flex items-center justify-center shrink-0 shadow-sm">
            <Link2 className="w-5 h-5 -rotate-45" />
          </div>
          <div>
            <h3 className="text-sm font-bold font-['Outfit'] leading-tight">Create call link</h3>
            <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-0.5">
              Share an encrypted WebRTC P2P link for your Splender call
            </p>
          </div>
        </div>
      </div>

      {/* Recent Calls Header with Clear History button */}
      <div className="px-4 pt-3.5 pb-1.5 flex items-center justify-between">
        <h3 className="text-xs font-semibold text-slate-500 dark:text-[#A8B3CC] tabular-nums">
          Recent calls · {callLogs.length}
        </h3>
        {callLogs.length > 0 && (
          <button
            onClick={handleClearAllCalls}
            className="text-[11px] font-medium text-slate-400 dark:text-[#A8B3CC] hover:text-rose-500 transition-colors cursor-pointer"
          >
            Clear history
          </button>
        )}
      </div>

      {/* Call History List */}
      {callLogs.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-20 px-6 text-center text-slate-400 dark:text-[#A8B3CC] space-y-2">
          <Phone className="w-12 h-12 opacity-40 stroke-[1.5]" />
          <p className="text-xs font-semibold text-slate-700 dark:text-[#F4F7FF]">No recent calls</p>
          <p className="text-[11px]">Tap the phone button below to start a secure WebRTC voice or video call</p>
        </div>
      ) : (
        <div className="divide-y divide-slate-200/60 dark:divide-[#293650]/50">
          {callLogs.map((log) => {
            const isMissed = log.direction === 'missed';
            return (
              <div
                key={log.id}
                onClick={() => {
                  playClickSound();
                  setSelectedCallLog(log);
                }}
                className="px-4 py-3 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-[#0D1424]/80 transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  <img
                    src={log.partnerAvatar}
                    alt={log.partnerName}
                    className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-[#293650] shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4
                      className={`text-sm font-semibold truncate ${
                        isMissed ? 'text-rose-500' : 'text-slate-900 dark:text-[#F4F7FF]'
                      }`}
                    >
                      {log.partnerName}
                    </h4>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-[#A8B3CC] mt-0.5 tabular-nums">
                      {log.direction === 'incoming' ? (
                        <PhoneIncoming className="w-3.5 h-3.5 text-[#10B981]" />
                      ) : log.direction === 'outgoing' ? (
                        <PhoneOutgoing className="w-3.5 h-3.5 text-[#22D3EE]" />
                      ) : (
                        <PhoneMissed className="w-3.5 h-3.5 text-rose-500" />
                      )}
                      <span>
                        {new Date(log.timestamp).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}
                        ,{' '}
                        {new Date(log.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      {log.duration ? (
                        <span className="text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                          · {formatDuration(log.duration)}
                        </span>
                      ) : null}
                    </div>
                  </div>
                </div>

                {/* Instant Dial Back Action */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleStartCall(log.partnerUid, log.partnerName, log.partnerAvatar, log.type);
                  }}
                  className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#0284C7] dark:text-[#22D3EE] hover:bg-slate-200 dark:hover:bg-[#131D32] rounded-full cursor-pointer transition-colors shrink-0 ml-2"
                  title={`Call ${log.partnerName}`}
                >
                  {log.type === 'video' ? <Video className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button for New Call */}
      <button
        onClick={() => {
          playClickSound();
          setIsNewCallOpen(true);
        }}
        className="fixed bottom-20 right-4 z-40 w-14 h-14 rounded-2xl aurora-cta-gradient text-white shadow-[0_14px_34px_rgba(59,130,246,0.4)] flex items-center justify-center cursor-pointer active:scale-90 transition-transform"
        title="Start Call"
      >
        <Phone className="w-6 h-6 stroke-[2.4]" />
      </button>

      {/* ========================================================================= */}
      {/* MODAL 1: CREATE CALL LINK */}
      {/* ========================================================================= */}
      {showCallLinkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-slate-900 dark:text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#293650] pb-2">
              <h3 className="text-sm font-bold font-['Outfit']">Create Call Link</h3>
              <button
                onClick={() => setShowCallLinkModal(false)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-[#A8B3CC]">
              Anyone with Splender Chat can use this link to join this encrypted call. Only share it with people you trust.
            </p>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650]">
              <span className="text-xs font-bold">Call type</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setCallLinkType('video')}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    callLinkType === 'video'
                      ? 'aurora-cta-gradient text-white'
                      : 'bg-slate-200 dark:bg-[#080B14] text-slate-700 dark:text-[#A8B3CC]'
                  }`}
                >
                  Video
                </button>
                <button
                  onClick={() => setCallLinkType('voice')}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    callLinkType === 'voice'
                      ? 'aurora-cta-gradient text-white'
                      : 'bg-slate-200 dark:bg-[#080B14] text-slate-700 dark:text-[#A8B3CC]'
                  }`}
                >
                  Voice
                </button>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] space-y-2">
              <p className="text-xs font-mono break-all text-slate-600 dark:text-[#22D3EE]">
                {generatedCallLink}
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleCopyCallLink}
                  className="flex-1 min-h-[42px] py-2 rounded-xl aurora-cta-gradient text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedLink ? 'Copied' : 'Copy link'}</span>
                </button>
                <button
                  onClick={() => {
                    playClickSound();
                    if (navigator.share) {
                      navigator.share({
                        title: 'Splender Call Link',
                        url: generatedCallLink,
                      });
                    } else {
                      handleCopyCallLink();
                    }
                  }}
                  className="min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 dark:border-[#293650] text-xs font-bold flex items-center justify-center gap-1 cursor-pointer hover:bg-slate-100 dark:hover:bg-[#080B14]"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: NEW CALL CONTACT PICKER */}
      {/* ========================================================================= */}
      {isNewCallOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] p-4 max-h-[85vh] flex flex-col shadow-2xl modal-slide-up text-slate-900 dark:text-[#F4F7FF]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#293650]">
              <div>
                <h3 className="text-sm font-bold font-['Outfit']">Start New Call</h3>
                <p className="text-[11px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                  {filteredContacts.length} contacts
                </p>
              </div>
              <button
                onClick={() => setIsNewCallOpen(false)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Contact Search Input */}
            <div className="py-2.5">
              <div className="flex items-center gap-2 bg-slate-100 dark:bg-[#131D32] border border-transparent dark:border-[#293650] px-3 py-2.5 rounded-xl">
                <Search className="w-4 h-4 text-slate-400 dark:text-[#A8B3CC]" />
                <input
                  type="text"
                  value={contactSearchQuery}
                  onChange={(e) => setContactSearchQuery(e.target.value)}
                  placeholder="Search contacts by name or Splender ID..."
                  className="flex-1 bg-transparent text-xs outline-none"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar py-1 divide-y divide-slate-100 dark:divide-[#293650]/60">
              {filteredContacts.length === 0 ? (
                <p className="text-xs text-slate-400 dark:text-[#A8B3CC] text-center py-8">No matching contacts</p>
              ) : (
                filteredContacts.map((contact) => (
                  <div
                    key={contact.targetUid}
                    className="py-2.5 px-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-[#131D32] rounded-xl"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={contact.avatar}
                        alt=""
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-[#293650] shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{contact.displayName}</p>
                        <p className="text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono truncate">
                          {contact.bio || contact.splenderId}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() =>
                          handleStartCall(contact.targetUid, contact.displayName, contact.avatar, 'voice')
                        }
                        className="min-w-[40px] min-h-[40px] flex items-center justify-center text-[#0284C7] dark:text-[#22D3EE] hover:bg-slate-200 dark:hover:bg-[#080B14] rounded-full cursor-pointer"
                        title="Voice Call"
                      >
                        <Phone className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() =>
                          handleStartCall(contact.targetUid, contact.displayName, contact.avatar, 'video')
                        }
                        className="min-w-[40px] min-h-[40px] flex items-center justify-center text-[#8B5CF6] hover:bg-slate-200 dark:hover:bg-[#080B14] rounded-full cursor-pointer"
                        title="Video Call"
                      >
                        <Video className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CALL DETAILS & ACTIONS SHEET */}
      {/* ========================================================================= */}
      {selectedCallLog && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4 text-slate-900 dark:text-[#F4F7FF]">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-[#293650] pb-2">
              <span className="text-xs font-bold font-['Outfit'] text-slate-500 dark:text-[#A8B3CC]">
                Call Details
              </span>
              <button
                onClick={() => setSelectedCallLog(null)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Partner Info */}
            <div className="flex items-center gap-4">
              <img
                src={selectedCallLog.partnerAvatar}
                alt=""
                className="w-14 h-14 rounded-full object-cover ring-2 ring-[#22D3EE]/40"
              />
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-bold font-['Outfit'] truncate">{selectedCallLog.partnerName}</h3>
                <p className="text-xs text-slate-400 dark:text-[#A8B3CC] font-mono">{selectedCallLog.partnerSplenderId}</p>
                <div className="flex items-center gap-1.5 text-xs text-[#0284C7] dark:text-[#22D3EE] mt-1">
                  <Shield className="w-3.5 h-3.5" />
                  <span>End-to-end encrypted WebRTC call</span>
                </div>
              </div>
            </div>

            {/* Metadata Card */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] space-y-2 text-xs tabular-nums">
              <div className="flex justify-between text-slate-500 dark:text-[#A8B3CC]">
                <span>Time</span>
                <span className="font-semibold text-slate-800 dark:text-[#F4F7FF]">
                  {new Date(selectedCallLog.timestamp).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-[#A8B3CC]">
                <span>Type</span>
                <span className="font-semibold capitalize text-slate-800 dark:text-[#F4F7FF]">
                  {selectedCallLog.type} Call ({selectedCallLog.direction})
                </span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-[#A8B3CC]">
                <span>Duration</span>
                <span className="font-semibold text-slate-800 dark:text-[#F4F7FF]">
                  {formatDuration(selectedCallLog.duration)}
                </span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-[#A8B3CC]">
                <span>Transport</span>
                <span className="font-semibold font-mono text-[#10B981]">
                  {selectedCallLog.duration ? `${(selectedCallLog.duration * 0.045).toFixed(1)} MB · DTLS-SRTP` : 'Unanswered'}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                onClick={() =>
                  handleStartCall(
                    selectedCallLog.partnerUid,
                    selectedCallLog.partnerName,
                    selectedCallLog.partnerAvatar,
                    'voice'
                  )
                }
                className="py-2.5 rounded-xl bg-slate-100 dark:bg-[#131D32] border border-transparent dark:border-[#293650] hover:border-[#22D3EE] transition-colors flex flex-col items-center gap-1 text-xs font-bold cursor-pointer"
              >
                <Phone className="w-4 h-4 text-[#22D3EE]" />
                <span>Voice Call</span>
              </button>

              <button
                onClick={() =>
                  handleStartCall(
                    selectedCallLog.partnerUid,
                    selectedCallLog.partnerName,
                    selectedCallLog.partnerAvatar,
                    'video'
                  )
                }
                className="py-2.5 rounded-xl bg-slate-100 dark:bg-[#131D32] border border-transparent dark:border-[#293650] hover:border-[#8B5CF6] transition-colors flex flex-col items-center gap-1 text-xs font-bold cursor-pointer"
              >
                <Video className="w-4 h-4 text-[#8B5CF6]" />
                <span>Video Call</span>
              </button>

              <button
                onClick={() => handleMessagePartner(selectedCallLog)}
                className="py-2.5 rounded-xl bg-slate-100 dark:bg-[#131D32] border border-transparent dark:border-[#293650] hover:border-[#3B82F6] transition-colors flex flex-col items-center gap-1 text-xs font-bold cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-[#3B82F6]" />
                <span>Message</span>
              </button>
            </div>

            {/* Delete call log */}
            <button
              onClick={() => handleDeleteCallLog(selectedCallLog.id)}
              className="w-full min-h-[44px] py-2.5 rounded-xl border border-rose-300 dark:border-rose-500/40 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete from Call Log</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
