import React, { useState } from 'react';
import { X, ZoomIn, ZoomOut, RotateCcw, Download, Share2, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { playClickSound } from '../lib/sound';

interface FullscreenMediaViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  senderName?: string;
  timestamp?: number;
  caption?: string;
}

export const FullscreenMediaViewerModal: React.FC<FullscreenMediaViewerModalProps> = ({
  isOpen,
  onClose,
  mediaUrl,
  mediaType,
  senderName,
  timestamp,
  caption,
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panPosition, setPanPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);

  if (!isOpen || !mediaUrl) return null;

  const handleZoomIn = () => {
    playClickSound();
    setZoomLevel((prev) => Math.min(prev + 0.5, 4));
  };

  const handleZoomOut = () => {
    playClickSound();
    setZoomLevel((prev) => {
      const next = Math.max(prev - 0.5, 1);
      if (next === 1) setPanPosition({ x: 0, y: 0 });
      return next;
    });
  };

  const handleResetZoom = () => {
    playClickSound();
    setZoomLevel(1);
    setPanPosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoomLevel <= 1) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - panPosition.x, y: e.clientY - panPosition.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPanPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleDownload = async () => {
    playClickSound();
    try {
      const response = await fetch(mediaUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `splender_${mediaType}_${Date.now()}.${mediaType === 'video' ? 'mp4' : 'jpg'}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch {
      // Fallback
      const a = document.createElement('a');
      a.href = mediaUrl;
      a.target = '_blank';
      a.download = `splender_${mediaType}_${Date.now()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const formattedTime = timestamp
    ? new Date(timestamp).toLocaleDateString([], {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  return (
    <div
      className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between select-none animate-in fade-in duration-200"
      onMouseUp={handleMouseUp}
    >
      {/* Top Controls Header */}
      <div className="z-30 p-4 flex items-center justify-between text-white bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <h3 className="text-sm font-bold">{senderName || 'Media'}</h3>
            {formattedTime && <p className="text-[11px] text-white/70">{formattedTime}</p>}
          </div>
        </div>

        {/* Action Buttons: Zoom, Reset, Download */}
        <div className="flex items-center gap-1.5">
          {mediaType === 'image' && (
            <>
              <button
                onClick={handleZoomIn}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
                title="Zoom in"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={handleZoomOut}
                disabled={zoomLevel <= 1}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-30 transition-colors cursor-pointer"
                title="Zoom out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              {zoomLevel > 1 && (
                <button
                  onClick={handleResetZoom}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer text-emerald-400"
                  title="Reset zoom"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </>
          )}

          <button
            onClick={handleDownload}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
            title="Download Media"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Media Viewport */}
      <div
        className="relative flex-1 flex items-center justify-center overflow-hidden cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
      >
        {mediaType === 'video' ? (
          <div className="relative max-h-full max-w-full flex items-center justify-center">
            <video
              src={mediaUrl}
              autoPlay
              controls
              playsInline
              loop
              muted={isMuted}
              className="max-h-[82vh] max-w-[92vw] object-contain rounded-lg shadow-2xl"
            />
          </div>
        ) : (
          <img
            src={mediaUrl}
            alt={caption || 'Preview'}
            style={{
              transform: `scale(${zoomLevel}) translate(${panPosition.x / zoomLevel}px, ${panPosition.y / zoomLevel}px)`,
              transition: isDragging ? 'none' : 'transform 0.15s ease-out',
            }}
            className="max-h-[82vh] max-w-[92vw] object-contain rounded-lg shadow-2xl pointer-events-auto"
            draggable={false}
          />
        )}
      </div>

      {/* Bottom Caption Overlay */}
      {caption && (
        <div className="z-30 p-4 bg-gradient-to-t from-black/80 to-transparent text-white text-center">
          <p className="text-sm font-medium leading-relaxed max-w-lg mx-auto bg-black/40 backdrop-blur-md p-2.5 rounded-2xl border border-white/10">
            {caption}
          </p>
        </div>
      )}
    </div>
  );
};
