/**
 * Splender Chat — Rich Markdown & Developer Code Snippet Parser (`src/components/RichMarkdownRenderer.tsx`)
 *
 * Zero-XSS React AST Markdown & Syntax Highlighter engineered for software developers inside chat bubbles:
 * - Fenced code blocks (```ts, ```kotlin, ```java, ```rust, ```python, ```json, ```bash, etc.)
 *   with lexical token highlighting (keywords, types, annotations, strings, comments, numbers),
 *   line numbers, language badge, and single-tap Copy button with Capacitor Haptics feedback.
 * - Inline code (`const x = 1`), **bold**, *italic*, ~~strikethrough~~, > blockquotes,
 *   bullet/numbered lists, and safe `https://` links.
 * - Preserves in-chat search query highlighting (`highlightQuery`).
 */

import React, { useState } from 'react';
import { Check, Copy, Terminal } from 'lucide-react';
import { HapticsService } from '../services/HapticsService';

export type CodeTokenKind =
  | 'plain'
  | 'keyword'
  | 'type'
  | 'string'
  | 'comment'
  | 'number'
  | 'annotation'
  | 'function';

export interface CodeToken {
  kind: CodeTokenKind;
  value: string;
}

export type MarkdownBlockNode =
  | { type: 'code_block'; language: string; code: string }
  | { type: 'blockquote'; lines: string[] }
  | { type: 'unordered_list'; items: string[] }
  | { type: 'ordered_list'; items: string[] }
  | { type: 'paragraph'; text: string };

const KEYWORDS_SET = new Set([
  // TS / JS
  'const', 'let', 'var', 'function', 'async', 'await', 'return', 'if', 'else', 'for', 'while',
  'switch', 'case', 'break', 'continue', 'try', 'catch', 'finally', 'throw', 'new', 'class',
  'extends', 'implements', 'interface', 'type', 'enum', 'import', 'from', 'export', 'default',
  'public', 'private', 'protected', 'readonly', 'static', 'true', 'false', 'null', 'undefined',
  'typeof', 'instanceof', 'void', 'yield',
  // Kotlin / Java
  'fun', 'val', 'override', 'object', 'companion', 'data', 'sealed', 'when', 'is', 'in',
  'package', 'synchronized', 'volatile', 'final', 'abstract', 'super', 'this', 'suspend',
  // Rust / C++ / Python / SQL / Bash
  'fn', 'mut', 'pub', 'struct', 'impl', 'trait', 'match', 'use', 'mod', 'crate', 'unsafe',
  'def', 'elif', 'lambda', 'with', 'as', 'pass', 'None', 'True', 'False', 'SELECT', 'FROM',
  'WHERE', 'INSERT', 'UPDATE', 'DELETE', 'JOIN', 'AND', 'OR', 'NOT',
]);

const TYPES_SET = new Set([
  'string', 'number', 'boolean', 'any', 'unknown', 'never', 'Record', 'Promise', 'Array',
  'Map', 'Set', 'Uint8Array', 'CryptoKey', 'React', 'FC', 'String', 'Int', 'Long', 'Boolean',
  'ByteArray', 'Unit', 'Context', 'Bundle', 'PluginCall', 'JSObject', 'Bitmap', 'Result',
  'Option', 'Vec', 'u8', 'u32', 'u64', 'usize', 'i32', 'i64', 'f32', 'f64',
]);

const TOKEN_REGEX =
  /(\/\/[^\n]*|\/\*[\s\S]*?\*\/|#[^\n]*)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(@[A-Za-z_][A-Za-z0-9_]*)|\b(0x[0-9a-fA-F]+|\d+(?:\.\d+)?)\b|\b([A-Za-z_][A-Za-z0-9_]*)(?=\s*\()|\b([A-Za-z_][A-Za-z0-9_]*)\b/g;

/**
 * Pure lexical tokenizer for multi-language developer code snippets.
 */
export function tokenizeCodeSnippet(code: string): CodeToken[] {
  const tokens: CodeToken[] = [];
  let lastIndex = 0;

  TOKEN_REGEX.lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = TOKEN_REGEX.exec(code)) !== null) {
    if (match.index > lastIndex) {
      tokens.push({ kind: 'plain', value: code.slice(lastIndex, match.index) });
    }

    const [full, comment, strLiteral, annotation, numLiteral, fnCall, identifier] = match;

    if (comment !== undefined) {
      tokens.push({ kind: 'comment', value: full });
    } else if (strLiteral !== undefined) {
      tokens.push({ kind: 'string', value: full });
    } else if (annotation !== undefined) {
      tokens.push({ kind: 'annotation', value: full });
    } else if (numLiteral !== undefined) {
      tokens.push({ kind: 'number', value: full });
    } else if (fnCall !== undefined) {
      if (KEYWORDS_SET.has(fnCall)) {
        tokens.push({ kind: 'keyword', value: full });
      } else {
        tokens.push({ kind: 'function', value: full });
      }
    } else if (identifier !== undefined) {
      if (KEYWORDS_SET.has(identifier)) {
        tokens.push({ kind: 'keyword', value: full });
      } else if (TYPES_SET.has(identifier) || /^[A-Z][A-Za-z0-9_]+$/.test(identifier)) {
        tokens.push({ kind: 'type', value: full });
      } else {
        tokens.push({ kind: 'plain', value: full });
      }
    } else {
      tokens.push({ kind: 'plain', value: full });
    }

    lastIndex = TOKEN_REGEX.lastIndex;
  }

  if (lastIndex < code.length) {
    tokens.push({ kind: 'plain', value: code.slice(lastIndex) });
  }

  return tokens;
}

/**
 * Parses raw chat markdown into structured block AST nodes without HTML injection risks.
 */
export function parseMarkdownBlocks(rawText: string): MarkdownBlockNode[] {
  if (!rawText) return [];

  const normalized = rawText.replace(/\r\n/g, '\n');
  const blocks: MarkdownBlockNode[] = [];
  const fenceRegex = /```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```/g;

  let cursor = 0;
  let fenceMatch: RegExpExecArray | null;

  const parseProseSection = (section: string) => {
    const lines = section.split('\n');
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];

      if (!line.trim()) {
        i += 1;
        continue;
      }

      // Blockquote (`> quote`)
      if (/^\s*>\s?/.test(line)) {
        const quoteLines: string[] = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          quoteLines.push(lines[i].replace(/^\s*>\s?/, ''));
          i += 1;
        }
        blocks.push({ type: 'blockquote', lines: quoteLines });
        continue;
      }

      // Unordered list (`- item` or `* item`)
      if (/^\s*[-*]\s+/.test(line)) {
        const items: string[] = [];
        while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
          items.push(lines[i].replace(/^\s*[-*]\s+/, ''));
          i += 1;
        }
        blocks.push({ type: 'unordered_list', items });
        continue;
      }

      // Ordered list (`1. item`)
      if (/^\s*\d+\.\s+/.test(line)) {
        const items: string[] = [];
        while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
          items.push(lines[i].replace(/^\s*\d+\.\s+/, ''));
          i += 1;
        }
        blocks.push({ type: 'ordered_list', items });
        continue;
      }

      // Regular paragraph lines until next structural block
      const paraLines: string[] = [];
      while (
        i < lines.length &&
        lines[i].trim() !== '' &&
        !/^\s*>\s?/.test(lines[i]) &&
        !/^\s*[-*]\s+/.test(lines[i]) &&
        !/^\s*\d+\.\s+/.test(lines[i])
      ) {
        paraLines.push(lines[i]);
        i += 1;
      }
      if (paraLines.length > 0) {
        blocks.push({ type: 'paragraph', text: paraLines.join('\n') });
      }
    }
  };

  while ((fenceMatch = fenceRegex.exec(normalized)) !== null) {
    if (fenceMatch.index > cursor) {
      parseProseSection(normalized.slice(cursor, fenceMatch.index));
    }

    const lang = (fenceMatch[1] || 'code').trim().toLowerCase();
    const rawCode = fenceMatch[2].replace(/\n$/, '');
    blocks.push({
      type: 'code_block',
      language: lang || 'code',
      code: rawCode,
    });

    cursor = fenceRegex.lastIndex;
  }

  if (cursor < normalized.length) {
    parseProseSection(normalized.slice(cursor));
  }

  return blocks;
}

function applySearchHighlight(text: string, query?: string): React.ReactNode {
  if (!query || !query.trim()) return text;
  const escaped = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const parts = text.split(new RegExp(`(${escaped})`, 'gi'));
  if (parts.length === 1) return text;

  return parts.map((part, idx) =>
    part.toLowerCase() === query.trim().toLowerCase() ? (
      <mark
        key={idx}
        className="bg-amber-300/90 text-slate-950 px-0.5 rounded font-semibold"
      >
        {part}
      </mark>
    ) : (
      part
    )
  );
}

function renderInlineMarkdown(
  text: string,
  isOutgoingBubble: boolean,
  highlightQuery?: string
): React.ReactNode[] {
  const inlineRegex =
    /(`[^`\n]+`)|(\*\*[^*\n]+\*\*)|(~~[^~\n]+~~)|(\*(?!\s)[^*\n]+(?<!\s)\*)|(https?:\/\/[^\s<]+)/g;

  const nodes: React.ReactNode[] = [];
  let lastIdx = 0;
  let match: RegExpExecArray | null;
  let keySeq = 0;

  while ((match = inlineRegex.exec(text)) !== null) {
    if (match.index > lastIdx) {
      const plainSlice = text.slice(lastIdx, match.index);
      nodes.push(
        <React.Fragment key={`t_${keySeq++}`}>
          {applySearchHighlight(plainSlice, highlightQuery)}
        </React.Fragment>
      );
    }

    const [full, inlineCode, boldText, strikeText, italicText, safeUrl] = match;

    if (inlineCode) {
      const inner = inlineCode.slice(1, -1);
      nodes.push(
        <code
          key={`c_${keySeq++}`}
          className={`font-mono text-[0.88em] px-1.5 py-0.5 rounded-md border ${
            isOutgoingBubble
              ? 'bg-black/25 border-white/20 text-emerald-100'
              : 'bg-slate-900/8 dark:bg-white/10 border-slate-300/60 dark:border-white/15 text-teal-800 dark:text-teal-300'
          }`}
        >
          {applySearchHighlight(inner, highlightQuery)}
        </code>
      );
    } else if (boldText) {
      const inner = boldText.slice(2, -2);
      nodes.push(
        <strong key={`b_${keySeq++}`} className="font-bold">
          {applySearchHighlight(inner, highlightQuery)}
        </strong>
      );
    } else if (strikeText) {
      const inner = strikeText.slice(2, -2);
      nodes.push(
        <del key={`s_${keySeq++}`} className="opacity-75 line-through">
          {applySearchHighlight(inner, highlightQuery)}
        </del>
      );
    } else if (italicText) {
      const inner = italicText.slice(1, -1);
      nodes.push(
        <em key={`i_${keySeq++}`} className="italic">
          {applySearchHighlight(inner, highlightQuery)}
        </em>
      );
    } else if (safeUrl) {
      nodes.push(
        <a
          key={`u_${keySeq++}`}
          href={safeUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className={`underline underline-offset-2 font-semibold break-all ${
            isOutgoingBubble
              ? 'text-emerald-100 hover:text-white'
              : 'text-teal-700 dark:text-teal-300 hover:opacity-80'
          }`}
        >
          {applySearchHighlight(full, highlightQuery)}
        </a>
      );
    }

    lastIdx = inlineRegex.lastIndex;
  }

  if (lastIdx < text.length) {
    nodes.push(
      <React.Fragment key={`t_end_${keySeq++}`}>
        {applySearchHighlight(text.slice(lastIdx), highlightQuery)}
      </React.Fragment>
    );
  }

  return nodes;
}

const TOKEN_COLOR_CLASSES: Record<CodeTokenKind, string> = {
  plain: 'text-slate-100',
  keyword: 'text-purple-300 font-semibold',
  type: 'text-cyan-300',
  string: 'text-emerald-300',
  comment: 'text-slate-400 italic',
  number: 'text-amber-300',
  annotation: 'text-teal-300 font-medium',
  function: 'text-sky-300',
};

const CodeSnippetCard: React.FC<{ language: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);
  const lines = code.split('\n');

  const handleCopyCode = async (e: React.MouseEvent) => {
    e.stopPropagation();
    void HapticsService.tapLight();
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard API restricted fallback
    }
  };

  return (
    <div
      data-testid="splender-code-snippet"
      onClick={(e) => e.stopPropagation()}
      className="my-1.5 rounded-xl overflow-hidden border border-slate-700/80 bg-[#0B0F17] text-slate-100 shadow-sm text-left"
    >
      {/* Code Header Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121826] border-b border-slate-800 text-[11px] font-mono">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Terminal className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="uppercase tracking-wider font-semibold text-emerald-300">
            {language || 'code'}
          </span>
          <span className="text-slate-500">• {lines.length} {lines.length === 1 ? 'line' : 'lines'}</span>
        </div>
        <button
          type="button"
          onClick={handleCopyCode}
          className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/8 hover:bg-white/15 text-slate-200 transition-colors cursor-pointer"
          title="Copy code snippet"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-300 font-semibold">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* Syntax Highlighted Body */}
      <pre className="p-3 overflow-x-auto text-[12px] leading-relaxed font-mono m-0">
        <code>
          {lines.map((lineText, lineIdx) => {
            const lineTokens = tokenizeCodeSnippet(lineText);
            return (
              <div key={lineIdx} className="table-row">
                <span className="table-cell pr-3 select-none text-right text-slate-600 text-[10px]">
                  {lineIdx + 1}
                </span>
                <span className="table-cell whitespace-pre">
                  {lineTokens.length === 0
                    ? '\u00A0'
                    : lineTokens.map((tok, tokIdx) => (
                        <span
                          key={tokIdx}
                          data-token-kind={tok.kind}
                          className={TOKEN_COLOR_CLASSES[tok.kind]}
                        >
                          {tok.value}
                        </span>
                      ))}
                </span>
              </div>
            );
          })}
        </code>
      </pre>
    </div>
  );
};

export interface RichMarkdownRendererProps {
  text: string;
  isOutgoing?: boolean;
  highlightQuery?: string;
  fontSizePx?: number;
  className?: string;
}

export const RichMarkdownRenderer: React.FC<RichMarkdownRendererProps> = ({
  text,
  isOutgoing = false,
  highlightQuery,
  fontSizePx = 13,
  className = '',
}) => {
  const blocks = parseMarkdownBlocks(text);
  const lineHeightPx = Math.round(fontSizePx * 1.46);

  return (
    <div
      style={{ fontSize: `${fontSizePx}px`, lineHeight: `${lineHeightPx}px` }}
      className={`space-y-1.5 break-words font-medium ${className}`}
    >
      {blocks.map((block, bIdx) => {
        switch (block.type) {
          case 'code_block':
            return <CodeSnippetCard key={bIdx} language={block.language} code={block.code} />;

          case 'blockquote':
            return (
              <blockquote
                key={bIdx}
                className={`pl-2.5 py-0.5 border-l-2 italic rounded-r ${
                  isOutgoing
                    ? 'border-emerald-200/80 bg-black/15 text-white/95'
                    : 'border-teal-600 bg-black/4 dark:bg-white/5 text-slate-700 dark:text-slate-200'
                }`}
              >
                {block.lines.map((ln, lIdx) => (
                  <p key={lIdx}>{renderInlineMarkdown(ln, isOutgoing, highlightQuery)}</p>
                ))}
              </blockquote>
            );

          case 'unordered_list':
            return (
              <ul key={bIdx} className="list-disc pl-4 space-y-0.5">
                {block.items.map((item, iIdx) => (
                  <li key={iIdx}>{renderInlineMarkdown(item, isOutgoing, highlightQuery)}</li>
                ))}
              </ul>
            );

          case 'ordered_list':
            return (
              <ol key={bIdx} className="list-decimal pl-4 space-y-0.5">
                {block.items.map((item, iIdx) => (
                  <li key={iIdx}>{renderInlineMarkdown(item, isOutgoing, highlightQuery)}</li>
                ))}
              </ol>
            );

          case 'paragraph': {
            const subLines = block.text.split('\n');
            return (
              <p key={bIdx}>
                {subLines.map((sub, sIdx) => (
                  <React.Fragment key={sIdx}>
                    {renderInlineMarkdown(sub, isOutgoing, highlightQuery)}
                    {sIdx < subLines.length - 1 && <br />}
                  </React.Fragment>
                ))}
              </p>
            );
          }
        }
      })}
    </div>
  );
};

export default RichMarkdownRenderer;
