import React, { useEffect, useRef } from 'react';
import { EyeOff, X, ShieldAlert, Lock } from 'lucide-react';
import { ScreenGuardManager } from '../lib/p2pSecurity';
import { playClickSound } from '../lib/sound';

interface ViewOnceModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  senderName: string;
}

export const ViewOnceModal: React.FC<ViewOnceModalProps> = ({
  isOpen,
  onClose,
  mediaUrl,
  mediaType,
  senderName,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isOpen) {
      ScreenGuardManager.activateGuard(() => {
        // Anti-screenshot triggered
        handleClose();
      });
    }
    return () => {
      ScreenGuardManager.deactivateGuard();
      if (videoRef.current) {
        try {
          videoRef.current.pause();
          videoRef.current.src = '';
        } catch {}
      }
    };
  }, [isOpen]);

  const handleClose = () => {
    playClickSound();
    if (videoRef.current) {
      try {
        videoRef.current.pause();
        videoRef.current.src = '';
      } catch {}
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      onContextMenu={(e) => e.preventDefault()}
      className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-4 animate-in fade-in select-none"
    >
      {/* Top Warning Banner & Close */}
      <div className="flex items-center justify-between text-white z-10 pt-2">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20">
          <Lock className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-xs font-bold font-mono">View-Once Media</span>
        </div>

        <button
          onClick={handleClose}
          className="p-2 rounded-full bg-white/20 text-white hover:bg-white/30 transition-colors cursor-pointer"
          title="Close and delete"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Media Content */}
      <div className="flex-1 flex items-center justify-center overflow-hidden my-4 relative">
        {mediaType === 'video' ? (
          <video
            ref={videoRef}
            src={mediaUrl}
            autoPlay
            controls
            playsInline
            className="max-h-full max-w-full object-contain rounded-2xl shadow-2xl pointer-events-auto"
          />
        ) : (
          <img
            src={mediaUrl}
            alt="View Once"
            className="max-h-full max-w-full object-contain rounded-2xl shadow-2xl"
          />
        )}
      </div>

      {/* Bottom Warning Notice */}
      <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 text-white text-center space-y-1 z-10">
        <div className="flex items-center justify-center gap-1.5 text-amber-300 text-xs font-bold">
          <ShieldAlert className="w-4 h-4" />
          <span>Self-Destruct Guard Active</span>
        </div>
        <p className="text-[11px] text-white/80">
          This photo/video from <strong>{senderName}</strong> will permanently self-destruct once closed. Screenshots and screen recordings are blocked.
        </p>
      </div>
    </div>
  );
};
