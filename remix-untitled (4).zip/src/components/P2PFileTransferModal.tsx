import React, { useState, useRef } from 'react';
import { HardDrive, X, Upload, Play, Pause, CheckCircle2, Shield, AlertCircle } from 'lucide-react';
import { P2PChunkedTransferManager, FileTransferSession } from '../lib/p2pFileTransfer';
import { SplenderWebRtcEngine } from '../lib/webrtcEngine';
import { P2PCryptoEngine } from '../lib/p2pSecurity';
import { uploadMediaToStorage } from '../lib/firebase';
import { playClickSound } from '../lib/sound';
import { useChat } from '../context/ChatContext';

interface P2PFileTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetConversationId: string;
}

export const P2PFileTransferModal: React.FC<P2PFileTransferModalProps> = ({
  isOpen,
  onClose,
  targetConversationId,
}) => {
  const { sendMessage, showToast, conversations, firebaseUser } = useChat();
  const [session, setSession] = useState<FileTransferSession | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const targetConv = conversations.find((c) => c.id === targetConversationId);
  const peerUid = targetConv?.participants.find((p) => p !== firebaseUser?.uid);
  const isDirectChannelOpen = Boolean(
    peerUid && SplenderWebRtcEngine.getInstance().isChannelOpen(peerUid)
  );

  const formatBytes = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleSelectFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !firebaseUser) return;

    playClickSound();
    const initial = P2PChunkedTransferManager.createSession(file, isDirectChannelOpen);
    setSession(initial);

    const finalSession = await P2PChunkedTransferManager.executeRealTransfer(
      initial.id,
      file,
      peerUid,
      firebaseUser.uid,
      (updated) => setSession(updated)
    );

    if (finalSession.status === 'completed') {
      if (finalSession.transport === 'webrtc_datachannel') {
        await sendMessage(
          `Sent P2P file: ${finalSession.fileName} (${formatBytes(finalSession.fileSize)})`,
          'document',
          undefined,
          undefined,
          undefined,
          'original',
          undefined,
          {
            fileName: finalSession.fileName,
            fileSize: formatBytes(finalSession.fileSize),
            conversationId: targetConversationId,
            transportMode: 'webrtc_p2p',
            fileTransferPayload: {
              fileName: finalSession.fileName,
              fileSize: finalSession.fileSize,
              chunksTotal: finalSession.totalChunks,
              chunksTransferred: finalSession.totalChunks,
              status: 'completed',
              hash: finalSession.checksum,
              speedKbps: finalSession.speedKbps,
              transport: 'webrtc_datachannel',
            },
          }
        );
        showToast('Direct P2P Transfer Complete', `SHA-256 verified (${finalSession.checksum.slice(0, 12)}…)`, 'success');
      } else {
        // Peer is not directly connected over WebRTC: encrypt binary blob client-side with a fresh 256-bit CEK
        let encryptedUrl: string | undefined;
        let mediaEncMeta: any;
        if (file.size <= 45 * 1024 * 1024) {
          const { encryptedBlob, metadata } = await P2PCryptoEngine.encryptBinaryBlob(file);
          const uploaded = await uploadMediaToStorage(
            'chats',
            targetConversationId,
            'files',
            'original',
            encryptedBlob,
            `${Date.now()}_e2ee.bin`
          );
          encryptedUrl = uploaded.url;
          mediaEncMeta = metadata;
        } else {
          showToast('File Exceeds Relay Limit', 'Direct WebRTC required for files over 45 MB', 'error');
          setSession((prev) =>
            prev ? { ...prev, status: 'failed', errorMessage: 'Exceeds 45 MB encrypted relay limit' } : null
          );
          return;
        }

        await sendMessage(
          `Encrypted file: ${finalSession.fileName} (${formatBytes(finalSession.fileSize)})`,
          'document',
          encryptedUrl,
          undefined,
          undefined,
          'original',
          undefined,
          {
            fileName: finalSession.fileName,
            fileSize: formatBytes(finalSession.fileSize),
            conversationId: targetConversationId,
            mediaEncryption: mediaEncMeta,
            transportMode: 'e2ee_relay',
            fileTransferPayload: {
              fileName: finalSession.fileName,
              fileSize: finalSession.fileSize,
              chunksTotal: finalSession.totalChunks,
              chunksTransferred: finalSession.totalChunks,
              status: 'completed',
              hash: finalSession.checksum,
              speedKbps: finalSession.speedKbps,
              transport: 'encrypted_relay',
            },
          }
        );
        showToast(
          'Encrypted File Queued',
          `Sealed with 256-bit CEK · SHA-256 ${finalSession.checksum.slice(0, 12)}…`,
          'success'
        );
      }
    } else if (finalSession.status === 'failed' && finalSession.errorMessage !== 'Transfer cancelled') {
      showToast('File Transfer Failed', finalSession.errorMessage || 'Unable to complete transfer', 'error');
    }
  };

  const handleTogglePause = () => {
    if (!session) return;
    playClickSound();
    const updated = P2PChunkedTransferManager.togglePause(session.id);
    if (updated) setSession(updated);
  };

  const handleClose = () => {
    if (session && session.status !== 'completed') {
      P2PChunkedTransferManager.cancelSession(session.id);
    }
    playClickSound();
    setSession(null);
    onClose();
  };

  const progressPercent = session
    ? Math.min(100, Math.round((session.transferredChunks / Math.max(1, session.totalChunks)) * 100))
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#FAF8F5] dark:bg-[#131A26] border border-stone-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        <div className="p-4 bg-[#0F766E] dark:bg-[#0B0F17] border-b border-white/10 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <HardDrive className="w-5 h-5 text-emerald-300" />
            <div>
              <h3 className="text-sm font-semibold">Chunked File Transfer</h3>
              <p className="text-[11px] text-white/75">
                {isDirectChannelOpen
                  ? 'Direct WebRTC DataChannel Open'
                  : 'Peer offline · Client-side E2EE Envelope'}
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            aria-label="Close file transfer modal"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full hover:bg-white/15 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="p-4 space-y-4 text-stone-900 dark:text-slate-100">
          <div className="flex items-start gap-2.5 px-3 py-2.5 rounded-2xl bg-stone-100 dark:bg-slate-900/80 text-stone-700 dark:text-slate-300 text-xs">
            <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>
              64 KB binary chunking with real FIPS 180-4 SHA-256 verification. Zero plaintext bytes are stored on Firebase.
            </span>
          </div>

          {!session ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full border border-dashed border-stone-300 dark:border-slate-700 hover:border-emerald-600 rounded-2xl p-6 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors bg-white dark:bg-[#0B0F17]"
            >
              <Upload className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
              <span className="text-xs font-semibold">Choose file from scoped picker</span>
              <span className="text-[11px] text-stone-500 dark:text-slate-400">
                Documents, archives, high-resolution media
              </span>
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleSelectFile}
                className="hidden"
              />
            </button>
          ) : (
            <div className="space-y-3 bg-white dark:bg-[#0B0F17] p-3.5 rounded-2xl border border-stone-200 dark:border-slate-800">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-semibold truncate">{session.fileName}</p>
                  <p className="text-[11px] text-stone-500 dark:text-slate-400 font-mono tabular-nums">
                    {formatBytes(session.fileSize)} · {session.speedKbps} KB/s
                  </p>
                </div>
                {session.status === 'completed' ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                ) : session.status === 'failed' ? (
                  <AlertCircle className="w-6 h-6 text-rose-500 shrink-0" />
                ) : (
                  <button
                    type="button"
                    onClick={handleTogglePause}
                    aria-label={session.status === 'paused' ? 'Resume transfer' : 'Pause transfer'}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer shrink-0"
                  >
                    {session.status === 'paused' ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  </button>
                )}
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-mono tabular-nums text-stone-500 dark:text-slate-400">
                  <span className="capitalize">{session.status}</span>
                  <span>{progressPercent}%</span>
                </div>
                <progress
                  value={progressPercent}
                  max={100}
                  aria-label="File transfer progress"
                  className="w-full h-2 rounded-full overflow-hidden accent-emerald-600 [&::-webkit-progress-bar]:bg-stone-200 dark:[&::-webkit-progress-bar]:bg-slate-800 [&::-webkit-progress-value]:bg-emerald-600 dark:[&::-webkit-progress-value]:bg-emerald-500 [&::-moz-progress-bar]:bg-emerald-600"
                />
              </div>

              <div className="pt-2 border-t border-stone-100 dark:border-slate-800 space-y-1 text-[10px] font-mono tabular-nums text-stone-500 dark:text-slate-400">
                <div className="flex items-center justify-between">
                  <span>Chunks: {session.transferredChunks}/{session.totalChunks}</span>
                  <span>
                    {session.transport === 'webrtc_datachannel' ? 'Direct WebRTC' : 'AES-GCM-256 E2EE'}
                  </span>
                </div>
                {session.checksum && (
                  <p className="truncate" title={session.checksum}>
                    SHA-256: {session.checksum}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="p-3 bg-stone-100/80 dark:bg-[#0B0F17] border-t border-stone-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={handleClose}
            className="min-h-[44px] px-5 py-2 rounded-xl text-xs font-semibold bg-stone-200 dark:bg-slate-800 hover:bg-stone-300 dark:hover:bg-slate-700 text-stone-900 dark:text-slate-100 cursor-pointer"
          >
            {session?.status === 'completed' ? 'Done' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
