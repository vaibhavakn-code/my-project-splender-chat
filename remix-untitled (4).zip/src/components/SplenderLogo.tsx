import React from 'react';

export interface SplenderLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_MAP: Record<NonNullable<SplenderLogoProps['size']>, { box: string; glyph: string }> = {
  xs: { box: 'w-5 h-5 rounded-md', glyph: 'text-[11px]' },
  sm: { box: 'w-7 h-7 rounded-lg', glyph: 'text-xs' },
  md: { box: 'w-9 h-9 rounded-xl', glyph: 'text-sm' },
  lg: { box: 'w-12 h-12 rounded-2xl', glyph: 'text-lg' },
  xl: { box: 'w-16 h-16 rounded-3xl', glyph: 'text-2xl' },
};

/**
 * Splender S-Logo Crest — Aurora Nebula 3D Faceted Prism
 * Combines a dual-node peer-to-peer geometric ribbon SVG with a crisp typographic monogram
 * rendered in Neon Cyan (#22D3EE), Aurora Blue (#3B82F6), and Electric Violet (#8B5CF6).
 */
export const SplenderLogo: React.FC<SplenderLogoProps> = ({ size = 'sm', className = '' }) => {
  const dims = SIZE_MAP[size];

  return (
    <div
      data-testid="splender-s-logo"
      className={`${dims.box} relative bg-gradient-to-br from-[#06B6D4] via-[#3B82F6] to-[#8B5CF6] flex items-center justify-center shadow-[0_6px_20px_-4px_rgba(59,130,246,0.52)] ring-1 ring-white/25 overflow-hidden shrink-0 select-none ${className}`}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(circle_at_24%_20%,rgba(255,255,255,0.34),transparent_55%)] pointer-events-none"
      />
      <svg
        aria-hidden="true"
        viewBox="0 0 48 48"
        className="absolute inset-0 w-full h-full pointer-events-none"
        fill="none"
      >
        <path
          d="M33 13.5C28.5 9.8 19.5 10.2 16.5 14.8C13.8 19 18.2 22.4 24 24C29.8 25.6 34.2 29 31.5 33.2C28.5 37.8 19.5 38.2 15 34.5"
          stroke="#F4F7FF"
          strokeOpacity="0.28"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <circle cx="34.5" cy="13.5" r="2.4" fill="#A5F3FC" fillOpacity="0.92" />
        <circle cx="13.5" cy="34.5" r="2.4" fill="#DDD6FE" fillOpacity="0.92" />
      </svg>
      <span className={`relative z-10 font-display font-bold tracking-tight text-[#F4F7FF] leading-none drop-shadow-xs ${dims.glyph}`}>
        S
      </span>
    </div>
  );
};
