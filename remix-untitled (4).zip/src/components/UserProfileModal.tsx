import React, { useState } from 'react';
import {
  ArrowLeft,
  X,
  Phone,
  Video,
  MessageSquare,
  Ban,
  Copy,
  Check,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { sound } from '../lib/sound';

export const UserProfileModal: React.FC = () => {
  const {
    viewingUserId,
    setViewingUserId,
    contacts,
    startDirectConversation,
    startCall,
    blockContact,
    unblockContact,
    showToast,
  } = useChat();

  const [copied, setCopied] = useState(false);

  if (!viewingUserId) return null;

  const contact = contacts.find((c) => c.targetUid === viewingUserId);
  if (!contact) return null;

  const isBlocked = contact.state === 'blocked';

  const handleCopy = () => {
    sound.playGlassClick();
    navigator.clipboard?.writeText?.(contact.splenderId);
    setCopied(true);
    showToast('Copied Splender ID', contact.splenderId, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStartChat = () => {
    sound.triggerInteraction();
    startDirectConversation({
      uid: contact.targetUid,
      splenderId: contact.splenderId,
      displayName: contact.displayName,
      avatar: contact.avatar,
    });
    setViewingUserId(null);
  };

  const handleVoiceCall = () => {
    sound.triggerInteraction();
    startCall(contact.targetUid, contact.displayName, contact.avatar, 'voice');
    setViewingUserId(null);
  };

  const handleVideoCall = () => {
    sound.triggerInteraction();
    startCall(contact.targetUid, contact.displayName, contact.avatar, 'video');
    setViewingUserId(null);
  };

  return (
    <div className="absolute inset-0 z-50 bg-[#2B2533]/40 backdrop-blur-md flex flex-col justify-end animate-in fade-in select-none text-[#2B2533]">
      <div className="glass-3d-panel rounded-t-[32px] max-h-[92%] flex flex-col shadow-2xl overflow-hidden bg-[#EFEAD8]/98 modal-slide-up">
        {/* Banner */}
        <div className="h-24 w-full glass-pod-ivory relative shrink-0 flex items-center justify-between px-4 border-b border-white/60">
          <button
            onClick={() => {
              sound.playGlassClick();
              setViewingUserId(null);
            }}
            className="p-2 rounded-xl glass-pod-ivory text-[#7C5C9B] hover:text-[#2B2533] transition-colors cursor-pointer elastic-tap shadow-sm"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5 text-[#7C5C9B]" />
          </button>
          <button
            onClick={() => {
              sound.playGlassClick();
              setViewingUserId(null);
            }}
            className="p-2 rounded-xl glass-pod-ivory text-[#6B6275] hover:text-[#2B2533] transition-colors cursor-pointer elastic-tap shadow-sm"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Content */}
        <div className="px-5 pb-6 overflow-y-auto space-y-4 no-scrollbar">
          {/* Avatar & Header */}
          <div className="flex items-end justify-between -mt-12">
            <div className="relative">
              <div className="w-20 h-20 rounded-3xl overflow-hidden border-4 border-white bg-[#E5DFCC] shadow-xl">
                <img
                  src={contact.avatar}
                  alt={contact.displayName}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleVoiceCall}
                className="p-2.5 rounded-2xl glass-pod-ivory hover:border-[#7C5C9B]/40 text-[#7C5C9B] transition-all cursor-pointer elastic-tap shadow-sm"
                title="Voice Call"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button
                onClick={handleVideoCall}
                className="p-2.5 rounded-2xl glass-pod-ivory hover:border-[#7C5C9B]/40 text-[#7C5C9B] transition-all cursor-pointer elastic-tap shadow-sm"
                title="Video Call"
              >
                <Video className="w-4 h-4" />
              </button>
              <button
                onClick={handleStartChat}
                className="px-4 py-2.5 rounded-2xl glass-purple-glow text-white text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5 elastic-tap"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Message</span>
              </button>
            </div>
          </div>

          {/* Name & ID */}
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-lg font-bold text-[#2B2533]">{contact.displayName}</h2>
              <ShieldCheck className="w-4 h-4 text-[#7C5C9B]" />
            </div>
            <p className="text-xs text-[#6B6275]">@{contact.username}</p>
          </div>

          {/* Splender ID Badge */}
          <div className="flex items-center justify-between glass-pod-ivory rounded-2xl p-3 shadow-sm border border-white/80">
            <div>
              <p className="text-[10px] text-[#6B6275] uppercase font-mono font-semibold">Splender ID</p>
              <p className="text-xs font-mono font-bold text-[#7C5C9B]">{contact.splenderId}</p>
            </div>
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-xl text-[#6B6275] hover:text-[#2B2533] cursor-pointer elastic-tap"
            >
              {copied ? <Check className="w-4 h-4 text-[#7C5C9B]" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Bio */}
          {contact.bio && (
            <div>
              <p className="text-[10px] font-bold text-[#6B6275] uppercase tracking-wider mb-1">
                About
              </p>
              <p className="text-xs text-[#2B2533] glass-pod-ivory p-3 rounded-2xl border border-white/80 leading-relaxed shadow-sm">
                {contact.bio}
              </p>
            </div>
          )}

          {/* Block / Safety Controls */}
          <div className="pt-2 border-t border-[#D8D0BA]">
            {isBlocked ? (
              <button
                onClick={() => {
                  sound.triggerInteraction();
                  unblockContact(contact.targetUid);
                }}
                className="w-full py-2.5 rounded-2xl glass-pod-ivory text-[#2B2533] text-xs font-bold cursor-pointer hover:border-[#7C5C9B]/40 elastic-tap shadow-sm"
              >
                Unblock Contact
              </button>
            ) : (
              <button
                onClick={() => {
                  sound.triggerInteraction();
                  blockContact(contact.targetUid);
                }}
                className="w-full py-2.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold cursor-pointer hover:bg-rose-100 flex items-center justify-center gap-1.5 elastic-tap shadow-sm"
              >
                <Ban className="w-4 h-4" />
                <span>Block Contact</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
