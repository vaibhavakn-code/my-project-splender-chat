import React, { useState } from 'react';
import { X, Users, Check, Camera, Link2, ArrowRight } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';
import { GroupAdminGovernance } from '../lib/masterFeatures';

interface NewGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewGroupModal: React.FC<NewGroupModalProps> = ({ isOpen, onClose }) => {
  const { contacts, createGroupConversation, showToast, firebaseUser, currentUserProfile, setActiveConversationId } = useChat();
  const [activeTab, setActiveTab] = useState<'create' | 'join'>('create');
  const [groupName, setGroupName] = useState('');
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [inviteInput, setInviteInput] = useState('');
  const [isJoining, setIsJoining] = useState(false);

  if (!isOpen) return null;

  const acceptedContacts = contacts.filter((c) => c.state === 'accepted');

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) {
      showToast('Group Subject Required', 'Please enter a name for the new group', 'warning');
      return;
    }
    const selectedMembers = acceptedContacts.filter((c) =>
      selectedParticipants.includes(c.targetUid)
    );
    if (selectedMembers.length === 0) {
      showToast('Select Participants', 'Select at least 1 contact to create group', 'warning');
      return;
    }

    playClickSound();
    await createGroupConversation(groupName.trim(), selectedMembers);
    showToast('Group Created', `${groupName.trim()} with ${selectedMembers.length} participants`, 'success');
    onClose();
    setGroupName('');
    setSelectedParticipants([]);
  };

  const handleJoinViaInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteInput.trim()) {
      showToast('Invite Required', 'Paste a valid group invite link or code', 'warning');
      return;
    }
    if (!firebaseUser || !currentUserProfile) {
      showToast('Authentication Required', 'Please sign in to join groups', 'error');
      return;
    }

    playClickSound();
    setIsJoining(true);

    try {
      let trimmed = inviteInput.trim();
      let groupId = '';
      let code = '';

      if (trimmed.includes('/join/')) {
        const parts = trimmed.split('/join/')[1]?.split('/');
        groupId = parts?.[0] || '';
        code = parts?.[1] || '';
      } else if (trimmed.includes('_')) {
        const parts = trimmed.split('_');
        groupId = parts[0];
        code = parts.slice(1).join('_');
      } else {
        groupId = trimmed;
        code = '';
      }

      if (!groupId) {
        showToast('Invalid Format', 'Could not parse group ID from invite', 'error');
        setIsJoining(false);
        return;
      }

      const res = await GroupAdminGovernance.joinGroupViaInvite(groupId, code, {
        uid: firebaseUser.uid,
        displayName: currentUserProfile.displayName,
        avatar: currentUserProfile.avatar,
        splenderId: currentUserProfile.splenderId,
      });

      if (res.success && res.conversationId) {
        showToast('Group Joined', res.message, 'success');
        setActiveConversationId(res.conversationId);
        onClose();
        setInviteInput('');
      } else {
        showToast('Could Not Join', res.message, 'error');
      }
    } catch (err: any) {
      showToast('Join Error', err.message, 'error');
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#FFFFFF] dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 p-5 shadow-2xl modal-slide-up space-y-4 text-[#111B21] dark:text-[#E9EDEF]">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#008069] dark:text-[#25D366]" />
            <h3 className="text-sm font-bold">Group Channels</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle: Create vs Join */}
        <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('create')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
              activeTab === 'create'
                ? 'bg-white dark:bg-[#008069] text-[#008069] dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            Create Group
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('join')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
              activeTab === 'join'
                ? 'bg-white dark:bg-[#008069] text-[#008069] dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            Join with Link
          </button>
        </div>

        {activeTab === 'create' ? (
          <form onSubmit={handleCreateGroup} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-500">Group Subject</label>
              <input
                type="text"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Type group subject here..."
                maxLength={30}
                required
                autoFocus
                className="w-full mt-1 px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 focus:border-[#008069]"
              />
            </div>

            <div>
              <div className="flex justify-between items-center text-xs font-bold text-slate-500 mb-1.5">
                <span>Select Participants</span>
                <span className="text-[#008069] dark:text-[#25D366] font-mono">
                  {selectedParticipants.length} selected
                </span>
              </div>

              <div className="max-h-52 overflow-y-auto no-scrollbar space-y-1.5 border border-slate-100 dark:border-slate-800 rounded-xl p-1">
                {acceptedContacts.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">No contacts available</p>
                ) : (
                  acceptedContacts.map((c) => {
                    const isSelected = selectedParticipants.includes(c.targetUid);
                    return (
                      <div
                        key={c.targetUid}
                        onClick={() => {
                          setSelectedParticipants((prev) =>
                            prev.includes(c.targetUid)
                              ? prev.filter((id) => id !== c.targetUid)
                              : [...prev, c.targetUid]
                          );
                        }}
                        className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                          isSelected
                            ? 'border-[#008069] bg-[#E7FCE8]/40 dark:bg-[#103629]/40'
                            : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <img src={c.avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
                          <div className="min-w-0">
                            <p className="text-xs font-semibold truncate">{c.displayName}</p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">{c.splenderId}</p>
                          </div>
                        </div>
                        <div
                          className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                            isSelected ? 'border-[#008069] bg-[#008069]' : 'border-slate-400'
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <button
              type="submit"
              disabled={!groupName.trim() || selectedParticipants.length === 0}
              className="w-full py-2.5 rounded-xl bg-[#008069] text-white font-bold text-xs disabled:opacity-40 hover:bg-[#00705c] transition-colors cursor-pointer"
            >
              Create Group ({selectedParticipants.length})
            </button>
          </form>
        ) : (
          <form onSubmit={handleJoinViaInvite} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500">Invite Link or Code</label>
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus-within:border-[#008069]">
                <Link2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <input
                  type="text"
                  value={inviteInput}
                  onChange={(e) => setInviteInput(e.target.value)}
                  placeholder="https://splender.chat/join/..."
                  required
                  autoFocus
                  className="w-full text-xs bg-transparent outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Paste the invitation link or code shared by a group admin to join the conversation.
              </p>
            </div>

            <button
              type="submit"
              disabled={!inviteInput.trim() || isJoining}
              className="w-full py-2.5 rounded-xl bg-[#008069] text-white font-bold text-xs disabled:opacity-40 hover:bg-[#00705c] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>{isJoining ? 'Joining Group...' : 'Join Group'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
