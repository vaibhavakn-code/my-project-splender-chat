import React from 'react';
import { Users, Bot, BarChart3 } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';

interface QuickActionsBarProps {
  onNewGroupClick?: () => void;
  className?: string;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  onNewGroupClick,
  className = '',
}) => {
  const { startAiAssistantChat, setIsQuickPollModalOpen, showToast } = useChat();

  const handleNewGroup = () => {
    playClickSound();
    if (onNewGroupClick) {
      onNewGroupClick();
    } else {
      showToast('New Group', 'Open group builder to select members', 'info');
    }
  };

  const handleAiChat = () => {
    playPopSound();
    startAiAssistantChat();
  };

  const handleQuickPoll = () => {
    playClickSound();
    setIsQuickPollModalOpen(true);
  };

  return (
    <div
      className={`mx-3 my-2 grid grid-cols-3 gap-2 select-none ${className}`}
    >
      <button
        type="button"
        onClick={handleNewGroup}
        className="min-h-[44px] flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-[#131D32]/90 hover:bg-slate-50 dark:hover:bg-[#192642] border border-slate-200 dark:border-[#293650] text-slate-800 dark:text-[#F4F7FF] transition-colors cursor-pointer active:scale-[0.98] whitespace-nowrap"
        title="Start a new group chat"
      >
        <Users className="w-4 h-4 text-[#22D3EE] shrink-0" />
        <span className="text-xs font-semibold truncate">New Group</span>
      </button>

      <button
        type="button"
        onClick={handleAiChat}
        className="min-h-[44px] flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-[#131D32]/90 hover:bg-slate-50 dark:hover:bg-[#192642] border border-slate-200 dark:border-[#293650] text-slate-800 dark:text-[#F4F7FF] transition-colors cursor-pointer active:scale-[0.98] whitespace-nowrap"
        title="Open Assistant Chat"
      >
        <Bot className="w-4 h-4 text-[#8B5CF6] shrink-0" />
        <span className="text-xs font-semibold truncate">Assistant</span>
      </button>

      <button
        type="button"
        onClick={handleQuickPoll}
        className="min-h-[44px] flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-[#131D32]/90 hover:bg-slate-50 dark:hover:bg-[#192642] border border-slate-200 dark:border-[#293650] text-slate-800 dark:text-[#F4F7FF] transition-colors cursor-pointer active:scale-[0.98] whitespace-nowrap"
        title="Create and send a live voting poll"
      >
        <BarChart3 className="w-4 h-4 text-[#3B82F6] shrink-0" />
        <span className="text-xs font-semibold truncate">Quick Poll</span>
      </button>
    </div>
  );
};
