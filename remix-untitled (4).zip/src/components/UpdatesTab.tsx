import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  Camera,
  Pen,
  Mic,
  MoreVertical,
  Check,
  ChevronDown,
  ChevronRight,
  Send,
  X,
  Lock,
  Play,
  Pause,
  Square,
  RotateCcw,
  Image as ImageIcon,
  ShieldCheck,
  Sparkles,
  Clock,
  Eye,
  Video,
  Radio,
  Megaphone,
  BarChart2,
  Link2,
  Copy,
  Share2,
  RefreshCw,
  TrendingUp,
  Users,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { Moment, MediaQuality } from '../types';
import { ChannelsAndCommunities } from '../lib/masterFeatures';
import {
  StatusEditorModal,
  StatusPublishPayload,
  createAdvancedStatusSvg,
} from '../lib/enterpriseSuite';
import { SplenderNativeBridge } from '../lib/nativeBridge';
import { createDeterministicAvatarDataUri, createScenicMomentDataUri } from '../lib/firebase';

interface UpdatesTabProps {
  onOpenStatusViewer?: (statusId: string) => void;
  onCameraClick?: () => void;
}

// Built-in color palette for Aurora Nebula Text Status
const COLOR_PALETTE = [
  '#1E1B4B', // Cosmic Indigo
  '#4C1D95', // Electric Violet Deep
  '#0E7490', // Nebula Cyan
  '#1D4ED8', // Aurora Royal Blue
  '#080B14', // Obsidian Night
  '#BE185D', // Magenta Nebula
  '#047857', // Sovereign Emerald
  '#C2410C', // Solar Flare
];

// Seeded realistic contact status updates for immediate interactive demo
const DEMO_CONTACT_MOMENTS: Moment[] = [
  {
    id: 'demo_moment_sarah',
    ownerUid: 'demo_user_sarah',
    ownerSplenderId: 'SP-883921',
    ownerName: 'Sarah Jenkins',
    ownerAvatar: createDeterministicAvatarDataUri('Sarah Jenkins', '#0D9488'),
    mediaUrl: createScenicMomentDataUri('Alpine Sunset Ridge', 'Golden hour trail above the valley', '#C2410C', '#1E293B'),
    mediaType: 'image',
    caption: 'Sunset hike in the mountains 🏔️🌅 Peaceful evening vibes!',
    createdAt: Date.now() - 3600000 * 2, // 2h ago
    expiresAt: Date.now() + 3600000 * 22,
    likes: [],
  },
  {
    id: 'demo_moment_alex',
    ownerUid: 'demo_user_alex',
    ownerSplenderId: 'SP-109283',
    ownerName: 'Alex Rivera',
    ownerAvatar: createDeterministicAvatarDataUri('Alex Rivera', '#4338CA'),
    mediaUrl: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="100%" height="100%" fill="#7C3AED"/>
        <foreignObject x="60" y="300" width="960" height="1320">
          <div xmlns="http://www.w3.org/1999/xhtml" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;text-align:center;padding:40px;box-sizing:border-box;">
            <span style="color:#ffffff;font-size:54px;font-family:system-ui,-apple-system,sans-serif;font-weight:700;line-height:1.4;">
              Just finalized the new P2P decentralized protocol architecture! 🚀🔒 Speed is 10x faster.
            </span>
          </div>
        </foreignObject>
      </svg>`
    )}`,
    mediaType: 'image',
    caption: 'Big release day today! Decentralized protocol ready.',
    createdAt: Date.now() - 3600000 * 5, // 5h ago
    expiresAt: Date.now() + 3600000 * 19,
    likes: [],
  },
  {
    id: 'demo_moment_tech',
    ownerUid: 'demo_user_tech',
    ownerSplenderId: 'SP-992014',
    ownerName: 'Tech Architects Group',
    ownerAvatar: createDeterministicAvatarDataUri('Tech Architects', '#0F766E'),
    mediaUrl: createScenicMomentDataUri('Architecture Sprint Review', 'Live P2P telemetry & zero-trust verification', '#0F766E', '#0F172A'),
    mediaType: 'image',
    caption: 'Sprint review demo in 15 minutes! Join call link in general chat 💻⚡',
    createdAt: Date.now() - 3600000 * 8, // 8h ago
    expiresAt: Date.now() + 3600000 * 16,
    likes: [],
  },
];

// Helper to create an SVG data URL for a text status
function createTextStatusSvg(
  text: string,
  bgColor: string,
  fontFamily: string = 'sans',
  fontSize: number = 24
): string {
  const safeText = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
  const fontMap: Record<string, string> = {
    sans: 'system-ui, -apple-system, sans-serif',
    serif: 'Georgia, Cambria, "Times New Roman", serif',
    mono: 'ui-monospace, SFMono-Regular, Menlo, monospace',
    cursive: 'cursive, "Brush Script MT", cursive',
    display: 'Impact, Haettenschweiler, "Arial Black", sans-serif',
  };
  const fontCss = fontMap[fontFamily] || fontMap.sans;
  const scaledSize = Math.max(32, Math.round((fontSize / 24) * 52));
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920">
    <rect width="100%" height="100%" fill="${bgColor}"/>
    <foreignObject x="80" y="320" width="920" height="1280">
      <div xmlns="http://www.w3.org/1999/xhtml" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;text-align:center;padding:30px;box-sizing:border-box;">
        <span style="color:#ffffff;font-size:${scaledSize}px;font-family:${fontCss};font-weight:700;line-height:1.45;word-break:break-word;">
          ${safeText}
        </span>
      </div>
    </foreignObject>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

// Generate simple synthetic audio waveform base64 if audio recording is unsupported
function generateSyntheticVoiceNote(): string {
  const sampleRate = 8000;
  const duration = 2.5;
  const numSamples = sampleRate * duration;
  const buffer = new Uint8Array(44 + numSamples);

  // WAV Header
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      buffer[offset + i] = str.charCodeAt(i);
    }
  };
  writeString(0, 'RIFF');
  const fileLen = 36 + numSamples;
  buffer[4] = fileLen & 0xff;
  buffer[5] = (fileLen >> 8) & 0xff;
  buffer[6] = (fileLen >> 16) & 0xff;
  buffer[7] = (fileLen >> 24) & 0xff;
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  buffer[16] = 16; buffer[17] = 0; buffer[18] = 0; buffer[19] = 0;
  buffer[20] = 1; buffer[21] = 0; // PCM
  buffer[22] = 1; buffer[23] = 0; // Mono
  buffer[24] = sampleRate & 0xff;
  buffer[25] = (sampleRate >> 8) & 0xff;
  buffer[26] = 0; buffer[27] = 0;
  buffer[28] = sampleRate & 0xff;
  buffer[29] = (sampleRate >> 8) & 0xff;
  buffer[30] = 0; buffer[31] = 0;
  buffer[32] = 1; buffer[33] = 0;
  buffer[34] = 8; buffer[35] = 0;
  writeString(36, 'data');
  buffer[40] = numSamples & 0xff;
  buffer[41] = (numSamples >> 8) & 0xff;
  buffer[42] = (numSamples >> 16) & 0xff;
  buffer[43] = (numSamples >> 24) & 0xff;

  // Gentle tone wave
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const sample = Math.sin(2 * Math.PI * 440 * t) * Math.exp(-t * 0.8);
    buffer[44 + i] = Math.floor((sample + 1) * 127.5);
  }

  let binary = '';
  for (let i = 0; i < buffer.byteLength; i++) {
    binary += String.fromCharCode(buffer[i]);
  }
  return `data:audio/wav;base64,${btoa(binary)}`;
}

export const UpdatesTab: React.FC<UpdatesTabProps> = ({ onCameraClick }) => {
  const {
    currentUserProfile,
    firebaseUser,
    moments,
    postMoment,
    showToast,
    darkMode,
    setViewingStoryId,
  } = useChat();

  // Modal and Action Sheet States
  const [showAddOptionsModal, setShowAddOptionsModal] = useState(false);
  const [showTextStatusModal, setShowTextStatusModal] = useState(false);
  const [showPhotoPreviewModal, setShowPhotoPreviewModal] = useState(false);
  const [showVoiceRecorderModal, setShowVoiceRecorderModal] = useState(false);
  const [showStatusPrivacyModal, setShowStatusPrivacyModal] = useState(false);
  const [statusPrivacyOption, setStatusPrivacyOption] = useState<'contacts' | 'except' | 'only'>('contacts');

  // Text Status State
  const [textStatusContent, setTextStatusContent] = useState('');
  const [textStatusBg, setTextStatusBg] = useState('#1E1B4B');

  // Photo/Video Upload State
  const [selectedMediaUrl, setSelectedMediaUrl] = useState<string | null>(null);
  const [selectedMediaType, setSelectedMediaType] = useState<'image' | 'video'>('image');
  const [mediaCaption, setMediaCaption] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Voice Status State
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceRecordingSeconds, setVoiceRecordingSeconds] = useState(0);
  const [recordedVoiceAudioUrl, setRecordedVoiceAudioUrl] = useState<string | null>(null);
  const [isPlayingRecordedVoice, setIsPlayingRecordedVoice] = useState(false);
  const [voiceCaption, setVoiceCaption] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const voiceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Group user moments vs contact moments
  const myMoments = moments.filter((m) => m.ownerUid === firebaseUser?.uid);
  const rawContactMoments = moments.filter((m) => m.ownerUid !== firebaseUser?.uid);
  // Fallback to seeded contact moments if no peer updates are available
  const contactMoments = rawContactMoments.length > 0 ? rawContactMoments : DEMO_CONTACT_MOMENTS;

  // Splender Broadcast Channels & Communities
  const [showCreateChannelModal, setShowCreateChannelModal] = useState(false);
  const [newChannelName, setNewChannelName] = useState('');
  const [newChannelDesc, setNewChannelDesc] = useState('');
  const [activeChannel, setActiveChannel] = useState<any | null>(null);
  const [activeChannelTab, setActiveChannelTab] = useState<'feed' | 'analytics' | 'invite'>('feed');
  const [currentChannelInviteCode, setCurrentChannelInviteCode] = useState<string>('');
  const [copiedChannelInvite, setCopiedChannelInvite] = useState(false);
  const [channelBroadcastText, setChannelBroadcastText] = useState('');
  const [userChannels, setUserChannels] = useState<any[]>([
    {
      id: 'splender_official',
      name: 'Splender Chat Official',
      description: 'Official product announcements, security advisories & release notes',
      subscriberCount: 1420,
      avatar: createDeterministicAvatarDataUri('Splender Official', '#008069'),
      isVerified: true,
      broadcasts: [
        {
          id: 'b1',
          content: '🚀 Splender Chat 2.8.4 Master Suite is now deployed! End-to-end encryption, Speech-to-Text transcription and Live GPS Location sharing are now live.',
          timestamp: 'Today, 2:30 PM',
          reactions: { '🔥': 240, '❤️': 382, '🎉': 195 },
        },
      ],
    },
    {
      id: 'tech_architects',
      name: 'Tech Architects & Engineers',
      description: 'Decentralized mesh networks, WebRTC & cryptography discussions',
      subscriberCount: 890,
      avatar: createDeterministicAvatarDataUri('Tech Engineers', '#1D4ED8'),
      isVerified: false,
      broadcasts: [
        {
          id: 'b2',
          content: 'Signal Double Ratchet protocol with ECDH P-256 and AES-GCM 256 benchmarks show 0ms zero-latency packet delivery.',
          timestamp: 'Yesterday',
          reactions: { '🚀': 112, '💡': 89 },
        },
      ],
    },
  ]);

  const handleCreateChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;
    playClickSound();

    try {
      const channelId = await ChannelsAndCommunities.createChannel(
        newChannelName.trim(),
        newChannelDesc.trim() || 'Official broadcast channel'
      );
      const newChan = {
        id: channelId,
        name: newChannelName.trim(),
        description: newChannelDesc.trim() || 'Official broadcast channel',
        subscriberCount: 1,
        avatar: createDeterministicAvatarDataUri(newChannelName.trim(), '#0F766E'),
        isVerified: false,
        ownerId: firebaseUser?.uid,
        broadcasts: [],
      };
      setUserChannels((prev) => [newChan, ...prev]);
      setShowCreateChannelModal(false);
      setNewChannelName('');
      setNewChannelDesc('');
      showToast('Channel Created', `Broadcast channel "${newChan.name}" is now live`, 'success');
    } catch {
      showToast('Error', 'Could not create broadcast channel', 'error');
    }
  };

  const handlePostChannelBroadcast = async (channelId: string) => {
    if (!channelBroadcastText.trim()) return;
    playClickSound();
    try {
      await ChannelsAndCommunities.postChannelBroadcast(channelId, channelBroadcastText.trim());
      const newBroadcast = {
        id: `b_${Date.now()}`,
        content: channelBroadcastText.trim(),
        timestamp: 'Just now',
        reactions: {},
      };
      setUserChannels((prev) =>
        prev.map((c) => (c.id === channelId ? { ...c, broadcasts: [newBroadcast, ...(c.broadcasts || [])] } : c))
      );
      if (activeChannel?.id === channelId) {
        setActiveChannel((prev: any) => ({ ...prev, broadcasts: [newBroadcast, ...(prev.broadcasts || [])] }));
      }
      setChannelBroadcastText('');
      showToast('Broadcast Sent', 'Update pushed to channel subscribers', 'success');
    } catch {
      showToast('Broadcast Failed', 'Could not publish channel update', 'error');
    }
  };

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (voiceTimerRef.current) clearInterval(voiceTimerRef.current);
    };
  }, []);

  // Bridge listener for statuses posted from Native Android Jetpack Compose UltimateAdvancedStatusCreatorScreen
  useEffect(() => {
    const unsub = SplenderNativeBridge.onNativeStatusPosted(async (nativePayload) => {
      const normalizedPayload: StatusPublishPayload = {
        text: nativePayload.text.slice(0, 700),
        bgColor: (nativePayload.bgColor || '#0F9D58').slice(0, 32),
        fontFamily: nativePayload.fontFamily || 'sans',
        fontSize: Math.round(24 * (nativePayload.scale || 1)),
        colorOpacity: nativePayload.opacity,
        textAlignment: nativePayload.textAlign || 'center',
        pattern:
          nativePayload.pattern === 'Grid' ||
          nativePayload.pattern === 'Rings' ||
          nativePayload.pattern === 'Dots'
            ? nativePayload.pattern
            : 'None',
        isGradientMeshActive: Boolean(nativePayload.isGradientMeshActive),
        offsetX: nativePayload.offsetX,
        offsetY: nativePayload.offsetY,
        scale: nativePayload.scale,
        rotation: nativePayload.rotation,
        expiresAt: nativePayload.expiresAtEpochMs,
      };
      const svgUrl = createAdvancedStatusSvg(normalizedPayload);
      await postMoment(svgUrl, normalizedPayload.text.slice(0, 1500), 'high', undefined, 'text', {
        bgColor: normalizedPayload.bgColor,
        privacy: statusPrivacyOption,
      });
      showToast('Status Posted', 'Your 24-hour status is now live for contacts', 'success');
    });
    return unsub;
  }, [postMoment, showToast, statusPrivacyOption]);

  // ---------------------------------------------------------------------------
  // Action Handlers
  // ---------------------------------------------------------------------------

  // Open File Picker for Photo/Video
  const handleOpenPhotoVideoPicker = () => {
    playClickSound();
    setShowAddOptionsModal(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video');
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setSelectedMediaUrl(dataUrl);
      setSelectedMediaType(isVideo ? 'video' : 'image');
      setMediaCaption('');
      setShowPhotoPreviewModal(true);
    };
    reader.readAsDataURL(file);
  };

  // Publish Text Status from Ultimate Advanced Status Creator
  const handlePublishFromStatusEditor = async (payload: StatusPublishPayload) => {
    playClickSound();
    const safeBgColor = (payload.bgColor || '#0F9D58').slice(0, 32);
    const safeCaption = payload.text.trim().slice(0, 1500);
    if (!safeCaption) return;
    const svgUrl = createAdvancedStatusSvg({
      ...payload,
      bgColor: safeBgColor,
      text: safeCaption,
    });
    await postMoment(svgUrl, safeCaption, 'high', undefined, 'text', {
      bgColor: safeBgColor,
      privacy: statusPrivacyOption,
    });
    setShowTextStatusModal(false);
    setTextStatusContent('');
    showToast('Status Posted', 'Your 24-hour status is now live for contacts', 'success');
  };

  // Publish Text Status
  const handlePublishTextStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!textStatusContent.trim()) return;
    playClickSound();

    const svgUrl = createTextStatusSvg(textStatusContent.trim(), textStatusBg);
    await postMoment(svgUrl, textStatusContent.trim(), 'high', undefined, 'text', {
      bgColor: textStatusBg,
      privacy: statusPrivacyOption,
    });
    setShowTextStatusModal(false);
    setTextStatusContent('');
    showToast('Status Posted', 'Your 24-hour status is now live for contacts', 'success');
  };

  // Publish Photo/Video Status
  const handlePublishMediaStatus = async () => {
    if (!selectedMediaUrl) return;
    playClickSound();

    await postMoment(
      selectedMediaUrl,
      mediaCaption.trim() || (selectedMediaType === 'video' ? 'Video status' : 'Photo status'),
      'high',
      undefined,
      selectedMediaType,
      { privacy: statusPrivacyOption }
    );
    setShowPhotoPreviewModal(false);
    setSelectedMediaUrl(null);
    setMediaCaption('');
    showToast('Status Published', 'Your photo/video status is active for 24h', 'success');
  };

  // Voice Status Recording Logic
  const handleStartVoiceRecording = async () => {
    playClickSound();
    setRecordedVoiceAudioUrl(null);
    setVoiceRecordingSeconds(0);
    audioChunksRef.current = [];

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = () => {
            setRecordedVoiceAudioUrl(reader.result as string);
          };
          reader.readAsDataURL(audioBlob);
          stream.getTracks().forEach((track) => track.stop());
        };

        mediaRecorder.start();
        setIsRecordingVoice(true);

        voiceTimerRef.current = setInterval(() => {
          setVoiceRecordingSeconds((prev) => {
            if (prev >= 29) {
              handleStopVoiceRecording();
              return 30;
            }
            return prev + 1;
          });
        }, 1000);
      } else {
        throw new Error('MediaRecorder not supported');
      }
    } catch {
      // Graceful fallback for environments where mic is blocked
      setIsRecordingVoice(true);
      voiceTimerRef.current = setInterval(() => {
        setVoiceRecordingSeconds((prev) => {
          if (prev >= 4) {
            handleStopVoiceRecording(true);
            return 5;
          }
          return prev + 1;
        });
      }, 1000);
    }
  };

  const handleStopVoiceRecording = (useFallback = false) => {
    playPopSound();
    setIsRecordingVoice(false);
    if (voiceTimerRef.current) {
      clearInterval(voiceTimerRef.current);
      voiceTimerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        console.error(e);
      }
    } else if (useFallback || !recordedVoiceAudioUrl) {
      setRecordedVoiceAudioUrl(generateSyntheticVoiceNote());
    }
  };

  const handlePublishVoiceStatus = async () => {
    const audioUrl = recordedVoiceAudioUrl || generateSyntheticVoiceNote();
    playClickSound();

    await postMoment(
      audioUrl,
      voiceCaption.trim() || 'Voice status 🎙️',
      'high',
      undefined,
      'audio',
      { privacy: statusPrivacyOption }
    );
    setShowVoiceRecorderModal(false);
    setRecordedVoiceAudioUrl(null);
    setVoiceCaption('');
    setVoiceRecordingSeconds(0);
    showToast('Voice Status Posted', 'Live for contacts for 24 hours', 'success');
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto no-scrollbar pb-24 bg-[#F8FAFF] dark:bg-[#080B14] text-slate-900 dark:text-[#F4F7FF] select-none">
      {/* Hidden File Input for Image/Video status */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*,video/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* ========================================================================= */}
      {/* MOMENTS & STORIES HEADER */}
      {/* ========================================================================= */}
      <div className="px-4 pt-3.5 pb-2.5 border-b border-slate-200/80 dark:border-[#293650]/75">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF]">Moments &amp; Stories</h2>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">
              <Lock className="w-3 h-3 text-[#22D3EE]" />
              <span>Disappears after 24 hours · End-to-end encrypted</span>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              setShowStatusPrivacyModal(true);
            }}
            className="min-w-[40px] min-h-[40px] rounded-full flex items-center justify-center text-slate-500 hover:text-slate-800 dark:text-[#A8B3CC] dark:hover:text-[#F4F7FF] cursor-pointer hover:bg-slate-100 dark:hover:bg-[#131D32] transition-colors"
            title="Status Privacy"
            aria-label="Status Privacy"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MY STATUS CARD */}
      {/* ========================================================================= */}
      <div className="p-3.5 border-b border-slate-200/70 dark:border-[#293650]/65 bg-white/80 dark:bg-[#0D1424]/70">
        <div className="flex items-center justify-between">
          <div
            onClick={() => {
              playClickSound();
              if (myMoments.length > 0) {
                setViewingStoryId(myMoments[0].id);
              } else {
                setShowAddOptionsModal(true);
              }
            }}
            className="flex items-center gap-3.5 flex-1 cursor-pointer group"
          >
            {/* User Avatar with Aurora Ring or (+) Badge */}
            <div className="relative shrink-0">
              <div
                className={`w-13 h-13 rounded-full overflow-hidden p-[2px] transition-transform group-hover:scale-105 ${
                  myMoments.length > 0
                    ? 'bg-gradient-to-tr from-[#22D3EE] via-[#3B82F6] to-[#8B5CF6] shadow-[0_0_16px_rgba(34,211,238,0.28)]'
                    : 'bg-slate-200 dark:bg-[#293650]'
                }`}
              >
                <img
                  src={
                    currentUserProfile?.avatar ||
                    createDeterministicAvatarDataUri(currentUserProfile?.displayName || 'Me', '#3B82F6')
                  }
                  alt="My Status"
                  className="w-full h-full rounded-full object-cover border-2 border-white dark:border-[#080B14]"
                />
              </div>

              {/* Plus Overlay Badge */}
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  playClickSound();
                  setShowAddOptionsModal(true);
                }}
                className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full aurora-cta-gradient text-white flex items-center justify-center border-2 border-white dark:border-[#080B14] shadow-xs cursor-pointer hover:scale-110 transition-transform"
                title="Add new status"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>

            {/* My Status Details */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-sm font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF] leading-tight">My Moment</p>
                {myMoments.length > 0 && (
                  <span className="text-[11px] font-semibold text-[#10B981]">
                    · Active
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-0.5 truncate">
                {myMoments.length > 0
                  ? `${myMoments.length} update${myMoments.length > 1 ? 's' : ''} · Tap to view 24h story`
                  : 'Tap to share an encrypted moment'}
              </p>
            </div>
          </div>

          {/* Quick Action Buttons: Pen (Text), Camera (Photo/Video), Mic (Voice) */}
          <div className="flex items-center gap-1.5 shrink-0 pl-2">
            {/* Pen: Text Status */}
            <button
              onClick={() => {
                playClickSound();
                setShowTextStatusModal(true);
              }}
              className="w-10 h-10 rounded-full bg-slate-100 dark:bg-[#131D32] border border-slate-200/80 dark:border-[#293650] text-[#3B82F6] dark:text-[#22D3EE] flex items-center justify-center hover:bg-slate-200 dark:hover:bg-[#1b2844] transition-transform active:scale-95 cursor-pointer"
              title="Compose text status"
            >
              <Pen className="w-4 h-4 stroke-[2.3]" />
            </button>

            {/* Camera: Photo/Video Status */}
            <button
              onClick={handleOpenPhotoVideoPicker}
              className="w-10 h-10 rounded-full bg-slate-100 dark:bg-[#131D32] border border-slate-200/80 dark:border-[#293650] text-[#8B5CF6] flex items-center justify-center hover:bg-slate-200 dark:hover:bg-[#1b2844] transition-transform active:scale-95 cursor-pointer"
              title="Upload photo or video status"
            >
              <Camera className="w-4.5 h-4.5 stroke-[2.2]" />
            </button>

            {/* Mic: Voice Status */}
            <button
              onClick={() => {
                playClickSound();
                setShowVoiceRecorderModal(true);
              }}
              className="w-10 h-10 rounded-full aurora-cta-gradient text-white flex items-center justify-center transition-transform active:scale-95 cursor-pointer shadow-sm"
              title="Record voice status"
            >
              <Mic className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Prominent "+ Create Moment" Action Button */}
        <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-[#293650]/60 flex items-center justify-between">
          <button
            onClick={() => {
              playClickSound();
              setShowAddOptionsModal(true);
            }}
            className="w-full min-h-[42px] py-2 px-3 rounded-xl bg-sky-50/80 dark:bg-[#131D32] text-[#0284C7] dark:text-[#22D3EE] font-semibold text-xs flex items-center justify-center gap-2 hover:bg-sky-100 dark:hover:bg-[#1a2744] transition-colors cursor-pointer border border-sky-200/70 dark:border-[#293650] whitespace-nowrap"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Create Moment (Text, Photo, Video, or Voice)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CONTACT STATUS UPDATES LIST */}
      {/* ========================================================================= */}
      <div className="mt-2 flex-1">
        <div className="px-4 py-2 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-[#A8B3CC]">
            Recent moments
          </span>
          <span className="text-[11px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
            {contactMoments.length} update{contactMoments.length > 1 ? 's' : ''}
          </span>
        </div>

        <div className="divide-y divide-slate-200/60 dark:divide-[#293650]/50">
          {contactMoments.map((moment) => {
            const hoursAgo = Math.max(1, Math.floor((Date.now() - moment.createdAt) / 3600000));
            const remainingHours = Math.max(1, Math.floor((moment.expiresAt - Date.now()) / 3600000));

            return (
              <div
                key={moment.id}
                onClick={() => {
                  playClickSound();
                  setViewingStoryId(moment.id);
                }}
                className="px-4 py-3 flex items-center gap-3.5 hover:bg-slate-50 dark:hover:bg-[#0D1424]/80 transition-colors cursor-pointer group"
              >
                {/* Contact Avatar with Aurora Nebula Gradient Story Ring */}
                <div className="relative shrink-0">
                  <div className="w-13 h-13 rounded-full p-[2px] bg-gradient-to-tr from-[#22D3EE] via-[#3B82F6] to-[#8B5CF6] shadow-[0_0_14px_rgba(139,92,246,0.22)] transition-transform group-hover:scale-105">
                    <img
                      src={moment.ownerAvatar}
                      alt={moment.ownerName}
                      className="w-full h-full rounded-full object-cover border-2 border-white dark:border-[#080B14]"
                    />
                  </div>
                  {moment.mediaType === 'audio' && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full aurora-cta-gradient text-white flex items-center justify-center border border-white dark:border-[#080B14]">
                      <Mic className="w-2.5 h-2.5" />
                    </div>
                  )}
                </div>

                {/* Contact Status Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate text-slate-900 dark:text-[#F4F7FF] leading-tight">
                    {moment.ownerName}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-0.5 truncate">
                    {moment.caption || (moment.mediaType === 'audio' ? 'Voice Moment' : 'Photo Moment')}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                    <Clock className="w-3 h-3 text-[#22D3EE]" />
                    <span>{hoursAgo}h ago</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-[#3B82F6] dark:text-[#22D3EE] font-medium">Expires in {remainingHours}h</span>
                  </div>
                </div>

                <div className="shrink-0 text-slate-400 group-hover:text-[#22D3EE] transition-colors">
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SPLENDER CHANNELS & COMMUNITIES (1-TO-MANY BROADCASTS) */}
      {/* ========================================================================= */}
      <div className="mt-4 pt-3 border-t border-slate-200/80 dark:border-[#293650]/75">
        <div className="px-4 py-2 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF]">Channels</h3>
            <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC]">Encrypted broadcast feeds &amp; engineering communities</p>
          </div>
          <button
            onClick={() => {
              playClickSound();
              setShowCreateChannelModal(true);
            }}
            className="min-h-[36px] px-3.5 py-1.5 rounded-full bg-sky-50 dark:bg-[#131D32] text-[#0284C7] dark:text-[#22D3EE] text-xs font-semibold flex items-center gap-1.5 border border-sky-200 dark:border-[#293650] hover:bg-sky-100 dark:hover:bg-[#1a2744] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Create Channel</span>
          </button>
        </div>

        {/* Channels List */}
        <div className="divide-y divide-slate-200/60 dark:divide-[#293650]/50">
          {userChannels.map((channel) => (
            <div
              key={channel.id}
              onClick={() => {
                playClickSound();
                setActiveChannel(channel);
                setActiveChannelTab('feed');
                setCurrentChannelInviteCode(
                  localStorage.getItem(`splender_channel_invite_${channel.id}`) ||
                  'CHN_' + channel.id.slice(0, 6).toUpperCase()
                );
              }}
              className="px-4 py-3 flex items-center gap-3.5 hover:bg-slate-50 dark:hover:bg-[#0D1424]/80 transition-colors cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-2xl overflow-hidden shrink-0 ring-1 ring-slate-200 dark:ring-[#293650]">
                <img src={channel.avatar} alt={channel.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-semibold truncate text-slate-900 dark:text-[#F4F7FF] leading-tight">
                    {channel.name}
                  </p>
                  {channel.isVerified && (
                    <ShieldCheck className="w-3.5 h-3.5 text-[#22D3EE] shrink-0" />
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-0.5 truncate">
                  {channel.broadcasts?.[0]?.content || channel.description}
                </p>
                <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                  <span>{channel.subscriberCount} followers</span>
                  {channel.broadcasts?.[0]?.timestamp && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{channel.broadcasts[0].timestamp}</span>
                    </>
                  )}
                </div>
              </div>
              <div className="shrink-0 text-slate-400 group-hover:text-[#22D3EE] transition-colors">
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Action Buttons: Pencil (Text) & Camera (Photo) */}
      <div className="fixed right-4 bottom-20 z-20 flex flex-col items-center gap-3">
        {/* Pencil FAB */}
        <button
          onClick={() => {
            playClickSound();
            setShowTextStatusModal(true);
          }}
          className="w-11 h-11 rounded-2xl bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] text-slate-700 dark:text-[#F4F7FF] hover:border-[#22D3EE]/50 flex items-center justify-center shadow-lg active:scale-95 transition-all cursor-pointer"
          title="Compose text status"
          aria-label="Compose text status"
        >
          <Pen className="w-4 h-4 stroke-[2.2]" />
        </button>

        {/* Camera FAB */}
        <button
          onClick={handleOpenPhotoVideoPicker}
          className="w-13 h-13 rounded-2xl aurora-cta-gradient text-white flex items-center justify-center shadow-[0_12px_30px_rgba(59,130,246,0.38)] active:scale-95 transition-all cursor-pointer"
          title="Take photo status"
          aria-label="Take photo status"
        >
          <Camera className="w-6 h-6 stroke-[2.2]" />
        </button>
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: ADD STATUS OPTIONS MENU (BOTTOM SHEET) */}
      {/* ========================================================================= */}
      {showAddOptionsModal && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/70 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#293650] pb-2">
              <h3 className="text-sm font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF]">Share Moment</h3>
              <button
                onClick={() => setShowAddOptionsModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-[#A8B3CC]">
              Select the type of encrypted moment to share with your contacts for 24 hours:
            </p>

            <div className="grid grid-cols-1 gap-2.5">
              {/* Option 1: Text Status */}
              <div
                onClick={() => {
                  playClickSound();
                  setShowAddOptionsModal(false);
                  setShowTextStatusModal(true);
                }}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-[#293650] bg-slate-50 dark:bg-[#131D32]/80 hover:border-[#22D3EE]/60 transition-all flex items-center gap-3.5 cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl aurora-cta-gradient text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Pen className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-[#F4F7FF]">Text Moment</p>
                  <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">Compose expressive typography on Aurora Nebula backdrops</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#22D3EE]" />
              </div>

              {/* Option 2: Photo Status */}
              <div
                onClick={handleOpenPhotoVideoPicker}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-[#293650] bg-slate-50 dark:bg-[#131D32]/80 hover:border-[#3B82F6]/60 transition-all flex items-center gap-3.5 cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#3B82F6] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Camera className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-[#F4F7FF]">Photo Moment</p>
                  <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">Capture or upload high-clarity imagery from device</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#3B82F6]" />
              </div>

              {/* Option 3: Video Status */}
              <div
                onClick={handleOpenPhotoVideoPicker}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-[#293650] bg-slate-50 dark:bg-[#131D32]/80 hover:border-[#F472B6]/60 transition-all flex items-center gap-3.5 cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#DB2777] to-[#F472B6] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Video className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-[#F4F7FF]">Video Moment</p>
                  <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">Share up to 30-second video clip with captions</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#F472B6]" />
              </div>

              {/* Option 4: Voice Status */}
              <div
                onClick={() => {
                  playClickSound();
                  setShowAddOptionsModal(false);
                  setShowVoiceRecorderModal(true);
                }}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-[#293650] bg-slate-50 dark:bg-[#131D32]/80 hover:border-[#8B5CF6]/60 transition-all flex items-center gap-3.5 cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#6D28D9] to-[#8B5CF6] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Mic className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-[#F4F7FF]">Voice Moment</p>
                  <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">Record and share an audio note up to 30 seconds</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#8B5CF6]" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: ENTERPRISE STATUS EDITOR & THEMES CREATOR */}
      {/* ========================================================================= */}
      <StatusEditorModal
        isOpen={showTextStatusModal}
        onClose={() => setShowTextStatusModal(false)}
        onPublish={handlePublishFromStatusEditor}
      />

      {/* ========================================================================= */}
      {/* MODAL 3: PHOTO / VIDEO STATUS PREVIEW & CAPTION MODAL */}
      {/* ========================================================================= */}
      {showPhotoPreviewModal && selectedMediaUrl && (
        <div className="fixed inset-0 z-50 flex flex-col justify-between bg-black animate-in fade-in select-none">
          {/* Top Bar */}
          <div className="p-4 flex items-center justify-between text-white z-20 bg-gradient-to-b from-black/80 to-transparent">
            <button
              onClick={() => {
                playClickSound();
                setShowPhotoPreviewModal(false);
                setSelectedMediaUrl(null);
              }}
              className="p-1.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full backdrop-blur-md">
              {selectedMediaType === 'video' ? 'Video Status' : 'Photo Status'}
            </span>
          </div>

          {/* Centered Media Preview */}
          <div className="flex-1 flex items-center justify-center overflow-hidden p-2 relative">
            {selectedMediaType === 'video' ? (
              <video
                src={selectedMediaUrl}
                controls
                autoPlay
                className="max-h-[70vh] max-w-full rounded-2xl object-contain shadow-2xl"
              />
            ) : (
              <img
                src={selectedMediaUrl}
                alt="Status preview"
                className="max-h-[70vh] max-w-full rounded-2xl object-contain shadow-2xl"
              />
            )}
          </div>

          {/* Bottom Caption Input & Send Button */}
          <div className="p-4 bg-gradient-to-t from-black via-black/90 to-transparent z-20 space-y-3">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-2xl px-4 py-2 border border-white/20">
              <input
                type="text"
                value={mediaCaption}
                onChange={(e) => setMediaCaption(e.target.value)}
                placeholder="Add a caption..."
                autoFocus
                className="flex-1 bg-transparent text-sm text-white placeholder:text-white/60 outline-none"
              />
              <button
                onClick={handlePublishMediaStatus}
                className="w-11 h-11 rounded-full aurora-cta-gradient text-white flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-lg cursor-pointer"
                title="Send Status"
              >
                <Send className="w-4.5 h-4.5 ml-0.5" />
              </button>
            </div>
            <p className="text-[11px] text-center text-white/60 font-mono">
              Visible to contacts for 24 hours · End-to-end encrypted
            </p>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: VOICE STATUS RECORDER MODAL */}
      {/* ========================================================================= */}
      {showVoiceRecorderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-6 shadow-2xl modal-slide-up space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#293650] pb-2">
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-[#22D3EE]" />
                <h3 className="text-sm font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF]">Voice Moment</h3>
              </div>
              <button
                onClick={() => {
                  playClickSound();
                  setShowVoiceRecorderModal(false);
                  setIsRecordingVoice(false);
                  setRecordedVoiceAudioUrl(null);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Visual Equalizer / Mic Container */}
            <div className="flex flex-col items-center justify-center py-6 space-y-4">
              <div className="relative">
                {isRecordingVoice && (
                  <div className="w-24 h-24 rounded-full bg-[#22D3EE]/25 animate-ping absolute inset-0" />
                )}
                <div
                  className={`w-24 h-24 rounded-full flex items-center justify-center shadow-xl transition-all ${
                    isRecordingVoice
                      ? 'bg-rose-500 text-white animate-pulse'
                      : recordedVoiceAudioUrl
                      ? 'aurora-cta-gradient text-white'
                      : 'bg-slate-100 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] text-[#22D3EE]'
                  }`}
                >
                  <Mic className="w-10 h-10" />
                </div>
              </div>

              {/* Timer Display */}
              <div className="text-center space-y-1">
                <p className="text-2xl font-mono tabular-nums font-bold text-slate-900 dark:text-[#F4F7FF]">
                  {formatTimer(voiceRecordingSeconds)}
                </p>
                <p className="text-xs text-slate-500 dark:text-[#A8B3CC]">
                  {isRecordingVoice
                    ? 'Recording audio moment (max 30s)...'
                    : recordedVoiceAudioUrl
                    ? 'Audio note recorded · Ready to publish'
                    : 'Tap Record to capture your voice moment'}
                </p>
              </div>

              {/* Waveform Bars Animation during recording */}
              {isRecordingVoice && (
                <div className="flex items-center gap-1 h-8">
                  {[30, 60, 90, 45, 80, 55, 100, 70, 40, 85].map((h, idx) => (
                    <div
                      key={idx}
                      className="w-1 bg-[#22D3EE] rounded-full animate-pulse"
                      style={{
                        height: `${h}%`,
                        animationDelay: `${idx * 70}ms`,
                      }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Optional Caption Input */}
            {recordedVoiceAudioUrl && (
              <div className="space-y-1.5">
                <input
                  type="text"
                  value={voiceCaption}
                  onChange={(e) => setVoiceCaption(e.target.value)}
                  placeholder="Add voice moment caption (optional)..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] outline-none placeholder:text-slate-400"
                />
              </div>
            )}

            {/* Actions: Record / Stop / Send */}
            <div className="flex items-center gap-2">
              {!isRecordingVoice && !recordedVoiceAudioUrl ? (
                <button
                  onClick={handleStartVoiceRecording}
                  className="w-full min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-bold text-xs cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                >
                  <Mic className="w-4 h-4" />
                  <span>Start Recording</span>
                </button>
              ) : isRecordingVoice ? (
                <button
                  onClick={() => handleStopVoiceRecording(false)}
                  className="w-full min-h-[44px] py-2.5 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                >
                  <Square className="w-4 h-4 fill-white" />
                  <span>Stop Recording</span>
                </button>
              ) : (
                <div className="w-full flex items-center gap-2">
                  <button
                    onClick={() => {
                      playClickSound();
                      setRecordedVoiceAudioUrl(null);
                      setVoiceRecordingSeconds(0);
                    }}
                    className="flex-1 min-h-[44px] py-2.5 rounded-xl bg-slate-200 dark:bg-[#131D32] border border-transparent dark:border-[#293650] text-slate-800 dark:text-[#F4F7FF] font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Re-record</span>
                  </button>
                  <button
                    onClick={handlePublishVoiceStatus}
                    className="flex-1 min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5 ml-0.5" />
                    <span>Post Moment</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: STATUS PRIVACY */}
      {/* ========================================================================= */}
      {showStatusPrivacyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#293650] pb-2">
              <h3 className="text-sm font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF]">Moments Privacy</h3>
              <button
                onClick={() => setShowStatusPrivacyModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-[#A8B3CC]">
              Who can see my encrypted 24-hour moments:
            </p>

            <div className="space-y-2">
              {[
                { id: 'contacts', title: 'My contacts', desc: 'Share with all accepted Splender contacts' },
                { id: 'except', title: 'My contacts except...', desc: 'Exclude selected contacts' },
                { id: 'only', title: 'Only share with...', desc: 'Share with a custom private audience' },
              ].map((opt) => (
                <div
                  key={opt.id}
                  onClick={() => {
                    playClickSound();
                    setStatusPrivacyOption(opt.id as any);
                  }}
                  className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-colors ${
                    statusPrivacyOption === opt.id
                      ? 'border-[#22D3EE] bg-sky-50/50 dark:bg-[#131D32]'
                      : 'border-slate-200 dark:border-[#293650] hover:bg-slate-50 dark:hover:bg-[#131D32]/60'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-[#F4F7FF]">{opt.title}</p>
                    <p className="text-[10px] text-slate-500 dark:text-[#A8B3CC] mt-0.5">{opt.desc}</p>
                  </div>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      statusPrivacyOption === opt.id ? 'border-[#22D3EE] bg-[#22D3EE]' : 'border-slate-400'
                    }`}
                  >
                    {statusPrivacyOption === opt.id && <Check className="w-2.5 h-2.5 text-[#080B14] stroke-[3]" />}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                playClickSound();
                setShowStatusPrivacyModal(false);
                showToast('Privacy Saved', 'Audience controls updated for next moment', 'success');
              }}
              className="w-full min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-bold text-xs cursor-pointer shadow-xs"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE BROADCAST CHANNEL */}
      {/* ========================================================================= */}
      {showCreateChannelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <form
            onSubmit={handleCreateChannel}
            className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-slide-up space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-[#293650] pb-2">
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-[#22D3EE]" />
                <h3 className="text-sm font-bold font-['Outfit']">New Broadcast Channel</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateChannelModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 dark:text-[#A8B3CC]">Channel Name</label>
              <input
                type="text"
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
                placeholder="e.g. P2P Systems Engineering"
                required
                maxLength={40}
                className="w-full mt-1 px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 dark:text-[#A8B3CC]">Description</label>
              <textarea
                value={newChannelDesc}
                onChange={(e) => setNewChannelDesc(e.target.value)}
                placeholder="Describe what your channel will share..."
                rows={3}
                maxLength={180}
                className="w-full mt-1 px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE] resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={!newChannelName.trim()}
              className="w-full min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-bold text-xs disabled:opacity-50 cursor-pointer shadow-xs"
            >
              Create &amp; Publish Channel
            </button>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CHANNEL VIEWER & BROADCAST POSTER */}
      {/* ========================================================================= */}
      {activeChannel && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/75 backdrop-blur-sm animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] max-h-[85vh] flex flex-col shadow-2xl modal-slide-up text-slate-900 dark:text-[#F4F7FF] overflow-hidden">
            {/* Header */}
            <div className="p-3.5 flex items-center justify-between border-b border-slate-100 dark:border-[#293650]">
              <div className="flex items-center gap-3">
                <img
                  src={activeChannel.avatar}
                  alt={activeChannel.name}
                  className="w-10 h-10 rounded-2xl object-cover ring-1 ring-slate-200 dark:ring-[#293650]"
                />
                <div>
                  <h3 className="text-sm font-bold font-['Outfit'] flex items-center gap-1.5 leading-tight">
                    <span>{activeChannel.name}</span>
                    {activeChannel.isVerified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-[#22D3EE] shrink-0" />
                    )}
                  </h3>
                  <p className="text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                    {activeChannel.subscriberCount} followers · Public Broadcast
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveChannel(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Channel Navigation Tabs */}
            <div className="px-3 py-2 bg-slate-50 dark:bg-[#080B14]/60 border-b border-slate-100 dark:border-[#293650] flex items-center gap-1 text-xs">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setActiveChannelTab('feed');
                }}
                className={`px-3 py-1.5 font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeChannelTab === 'feed'
                    ? 'aurora-cta-gradient text-white shadow-xs'
                    : 'text-slate-600 dark:text-[#A8B3CC] hover:text-black dark:hover:text-white'
                }`}
              >
                <Megaphone className="w-3.5 h-3.5" />
                <span>Broadcasts</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setActiveChannelTab('analytics');
                }}
                className={`px-3 py-1.5 font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeChannelTab === 'analytics'
                    ? 'aurora-cta-gradient text-white shadow-xs'
                    : 'text-slate-600 dark:text-[#A8B3CC] hover:text-black dark:hover:text-white'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" />
                <span>Analytics</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setActiveChannelTab('invite');
                }}
                className={`px-3 py-1.5 font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeChannelTab === 'invite'
                    ? 'aurora-cta-gradient text-white shadow-xs'
                    : 'text-slate-600 dark:text-[#A8B3CC] hover:text-black dark:hover:text-white'
                }`}
              >
                <Link2 className="w-3.5 h-3.5" />
                <span>Invite Link</span>
              </button>
            </div>

            {/* TAB 1: BROADCAST FEED */}
            {activeChannelTab === 'feed' && (
              <>
                {/* Description */}
                <div className="px-4 py-2 bg-slate-50 dark:bg-[#131D32]/50 border-b border-slate-100 dark:border-[#293650] text-xs text-slate-600 dark:text-[#A8B3CC]">
                  {activeChannel.description}
                </div>

                {/* Broadcast Feed */}
                <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3">
                  {activeChannel.broadcasts && activeChannel.broadcasts.length > 0 ? (
                    activeChannel.broadcasts.map((b: any) => (
                      <div
                        key={b.id}
                        className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#131D32] border border-slate-200/80 dark:border-[#293650] space-y-2 shadow-2xs"
                      >
                        <p className="text-xs leading-relaxed font-medium">{b.content}</p>
                        <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums pt-1 border-t border-slate-100 dark:border-[#293650]/60">
                          <span>{b.timestamp}</span>
                          <div className="flex items-center gap-2">
                            {b.reactions &&
                              Object.entries(b.reactions).map(([emoji, count]: any) => (
                                <span key={emoji} className="px-1.5 py-0.5 rounded-md bg-white dark:bg-[#080B14] border border-slate-200 dark:border-[#293650] text-[10px]">
                                  {emoji} {count}
                                </span>
                              ))}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-slate-400 dark:text-[#A8B3CC] space-y-1">
                      <Megaphone className="w-8 h-8 mx-auto opacity-50" />
                      <p className="text-xs font-medium">No updates posted yet</p>
                      <p className="text-[10px]">Broadcast updates will appear here</p>
                    </div>
                  )}
                </div>

                {/* Broadcast Composer */}
                <div className="p-3 border-t border-slate-100 dark:border-[#293650] bg-white dark:bg-[#0D1424] flex items-center gap-2">
                  <input
                    type="text"
                    value={channelBroadcastText}
                    onChange={(e) => setChannelBroadcastText(e.target.value)}
                    placeholder="Post an update to channel subscribers..."
                    className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE]"
                  />
                  <button
                    onClick={() => handlePostChannelBroadcast(activeChannel.id)}
                    disabled={!channelBroadcastText.trim()}
                    className="w-10 h-10 rounded-full aurora-cta-gradient text-white flex items-center justify-center disabled:opacity-40 cursor-pointer shrink-0"
                  >
                    <Send className="w-4 h-4 ml-0.5" />
                  </button>
                </div>
              </>
            )}

            {/* TAB 2: SUBSCRIBER ANALYTICS */}
            {activeChannelTab === 'analytics' && (() => {
              const analytics = ChannelsAndCommunities.getChannelAnalytics(activeChannel);
              return (
                <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
                  {/* Top KPIs */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Subscribers</span>
                        <Users className="w-4 h-4 text-emerald-500" />
                      </div>
                      <p className="text-xl font-black mt-1 text-[#111B21] dark:text-[#E9EDEF]">
                        {analytics.totalSubscribers.toLocaleString()}
                      </p>
                      <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold mt-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>+{analytics.weeklyGrowthPct}% this week</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-blue-500/10 border border-blue-500/30">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Read Rate</span>
                        <Eye className="w-4 h-4 text-blue-500" />
                      </div>
                      <p className="text-xl font-black mt-1 text-[#111B21] dark:text-[#E9EDEF]">
                        {analytics.readRatePct}%
                      </p>
                      <p className="text-[10px] text-slate-500 mt-1 font-mono">
                        {analytics.totalImpressions.toLocaleString()} impressions
                      </p>
                    </div>
                  </div>

                  {/* Secondary Metrics */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold">Engagement Index</span>
                      <span className="font-mono text-emerald-600 font-bold">{analytics.engagementRatePct}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${analytics.engagementRatePct}%` }} />
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                      <span>Total Reactions Recorded:</span>
                      <span className="font-bold text-slate-700 dark:text-slate-200 font-mono">{analytics.totalReactions}</span>
                    </div>
                  </div>

                  {/* Regional Demographics */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
                    <h4 className="text-xs font-bold flex items-center justify-between">
                      <span>Audience Geo Distribution</span>
                      <span className="text-[10px] font-mono text-slate-400">Real-time</span>
                    </h4>
                    <div className="space-y-2">
                      {analytics.demographics.map((demo) => (
                        <div key={demo.country} className="flex items-center justify-between text-xs">
                          <span className="text-slate-600 dark:text-slate-300">{demo.country}</span>
                          <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">{demo.share}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Hourly Activity */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
                    <h4 className="text-xs font-bold">Active Read Hours</h4>
                    <div className="grid grid-cols-4 gap-1.5 text-center text-[10px]">
                      {analytics.hourlyActiveDistribution.map((slot) => (
                        <div key={slot.hour} className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                          <p className="font-mono font-bold text-emerald-600">{slot.pct}%</p>
                          <p className="text-[8px] text-slate-400 mt-0.5">{slot.hour}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* TAB 3: INVITE LINK GENERATOR & ADMIN REVOCATION */}
            {activeChannelTab === 'invite' && (() => {
              const inviteLink = ChannelsAndCommunities.getChannelInviteLink(activeChannel.id, currentChannelInviteCode);

              const handleCopyInvite = async () => {
                playPopSound();
                try {
                  await navigator.clipboard.writeText(inviteLink);
                  setCopiedChannelInvite(true);
                  showToast('Link Copied', 'Channel invite link copied to clipboard', 'success');
                  setTimeout(() => setCopiedChannelInvite(false), 2500);
                } catch {
                  showToast('Link Ready', inviteLink, 'info');
                }
              };

              const handleShareInvite = async () => {
                playClickSound();
                if (navigator.share) {
                  try {
                    await navigator.share({
                      title: `Join ${activeChannel.name} on Splender Chat`,
                      text: `Follow the official broadcast channel for ${activeChannel.name}:`,
                      url: inviteLink,
                    });
                    return;
                  } catch {
                    // fallback to copy
                  }
                }
                handleCopyInvite();
              };

              const handleRevokeInvite = async () => {
                if (!window.confirm('Revoke current invite link? All existing shared links will immediately stop granting access.')) {
                  return;
                }
                playClickSound();
                const newCode = await ChannelsAndCommunities.revokeChannelInviteCode(activeChannel.id);
                setCurrentChannelInviteCode(newCode);
                showToast('Invite Link Revoked', 'Previous link deactivated. New invite code active.', 'warning');
              };

              return (
                <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
                  <div className="text-center space-y-1">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                      <Link2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold">Channel Invite Link</h4>
                    <p className="text-xs text-slate-500">
                      Anyone with Splender Chat can follow this broadcast channel using this link
                    </p>
                  </div>

                  {/* Link Container */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2.5">
                    <div className="flex items-center justify-between text-xs font-mono break-all text-emerald-700 dark:text-emerald-300 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span>{inviteLink}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleCopyInvite}
                        className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        {copiedChannelInvite ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        <span>{copiedChannelInvite ? 'Copied!' : 'Copy Link'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleShareInvite}
                        className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-[#111B21] dark:text-[#E9EDEF] font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>Share Link</span>
                      </button>
                    </div>
                  </div>

                  {/* Admin Revocation Card */}
                  <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-2.5">
                    <div className="flex items-start gap-2.5">
                      <RefreshCw className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
                      <div>
                        <h5 className="text-xs font-bold text-rose-700 dark:text-rose-400">Admin Revocation Control</h5>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                          Reset the invite token to revoke all existing links. Old invitations will be rendered completely inactive.
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleRevokeInvite}
                      className="w-full py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Revoke & Regenerate Link</span>
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
