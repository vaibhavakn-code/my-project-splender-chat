import React, { useRef, useEffect } from 'react';
import {
  Maximize2,
  PhoneOff,
  Mic,
  MicOff,
  Video,
  Shield,
  Volume2,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

export const CallPipMiniPlayer: React.FC = () => {
  const {
    activeCall,
    isCallMinimized,
    setIsCallMinimized,
    remoteStream,
    isCallMuted,
    toggleCallMute,
    endCall,
    callDuration,
    firebaseUser,
  } = useChat();

  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream, isCallMinimized]);

  if (!activeCall || !isCallMinimized) return null;

  const partnerName =
    activeCall.callerUid === firebaseUser?.uid
      ? activeCall.recipientSplenderId || 'Peer'
      : activeCall.callerName;
  const partnerAvatar =
    activeCall.callerUid === firebaseUser?.uid
      ? createDeterministicAvatarDataUri(partnerName, '#0F766E')
      : activeCall.callerAvatar || createDeterministicAvatarDataUri(partnerName, '#0F766E');

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      onClick={() => {
        playClickSound();
        setIsCallMinimized(false);
      }}
      className="fixed bottom-20 right-4 z-50 w-68 rounded-3xl bg-white/95 dark:bg-[#0D1424]/95 backdrop-blur-xl border border-slate-200 dark:border-[#293650] shadow-[0_20px_50px_rgba(0,0,0,0.5)] p-2.5 flex items-center gap-2.5 cursor-pointer hover:border-[#22D3EE]/50 transition-all duration-200 select-none animate-in fade-in slide-in-from-bottom-4"
      title="Click to maximize call HUD"
    >
      {/* Video Preview or Avatar */}
      <div className="relative w-12 h-12 rounded-2xl overflow-hidden shrink-0 bg-[#080B14] border border-black/10 dark:border-[#293650]">
        {activeCall.type === 'video' && remoteStream ? (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <img
            src={partnerAvatar}
            alt={partnerName}
            className="w-full h-full object-cover"
          />
        )}
        {/* Connected Status Dot */}
        <span className="absolute bottom-1 right-1 w-2.5 h-2.5 rounded-full bg-[#10B981] ring-2 ring-white dark:ring-[#080B14]" />
      </div>

      {/* Info details */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1">
          <p className="text-xs font-bold font-['Outfit'] text-slate-900 dark:text-[#F4F7FF] truncate">
            {partnerName}
          </p>
          <span className="text-[10px] text-[#0284C7] dark:text-[#22D3EE] font-mono font-semibold shrink-0">
            · P2P
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-mono tabular-nums text-[#10B981] font-bold mt-0.5">
          <span>{formatDuration(callDuration)}</span>
          <span className="text-[10px] text-slate-400 dark:text-[#A8B3CC] font-normal">· Active</span>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div
        className="flex items-center gap-1 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Mic Mute Toggle */}
        <button
          onClick={() => {
            playClickSound();
            toggleCallMute();
          }}
          className={`p-2 rounded-xl transition-colors cursor-pointer ${
            isCallMuted
              ? 'bg-rose-500/20 text-rose-500'
              : 'hover:bg-slate-100 dark:hover:bg-[#131D32] text-slate-600 dark:text-[#A8B3CC]'
          }`}
          title={isCallMuted ? 'Unmute' : 'Mute'}
        >
          {isCallMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
        </button>

        {/* Maximize Back to Full HUD */}
        <button
          onClick={() => {
            playClickSound();
            setIsCallMinimized(false);
          }}
          className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] text-[#0284C7] dark:text-[#22D3EE] transition-colors cursor-pointer"
          title="Restore Full Screen"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>

        {/* End Call Button */}
        <button
          onClick={() => {
            playClickSound();
            endCall();
          }}
          className="p-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white transition-colors cursor-pointer"
          title="End Call"
        >
          <PhoneOff className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
