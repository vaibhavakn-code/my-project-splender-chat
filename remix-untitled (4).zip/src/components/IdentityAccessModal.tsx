import React, { useState } from 'react';
import {
  ArrowLeft,
  X,
  Shield,
  Key,
  Copy,
  Check,
  Camera,
  Pen,
  User,
  Info,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

interface IdentityAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  createDeterministicAvatarDataUri('Aurora Violet', '#8B5CF6'),
  createDeterministicAvatarDataUri('Nebula Cyan', '#0891B2'),
  createDeterministicAvatarDataUri('Cosmic Blue', '#2563EB'),
  createDeterministicAvatarDataUri('Soft Magenta', '#DB2777'),
  createDeterministicAvatarDataUri('Sovereign Emerald', '#059669'),
  createDeterministicAvatarDataUri('Deep Space', '#1E293B'),
];

const STATUS_PRESETS = [
  'Hey there! I am using SPLENDER CHAT.',
  'Available for encrypted calls and messages',
  'Focused at work',
  'In a meeting',
  'Traveling offline',
  'Low battery — urgent messages only',
  'Available on P2P Direct',
];

export const IdentityAccessModal: React.FC<IdentityAccessModalProps> = ({ isOpen, onClose }) => {
  const { currentUserProfile, firebaseUser, updateProfile, showToast } = useChat();
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(currentUserProfile?.displayName || '');

  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioInput, setBioInput] = useState(
    currentUserProfile?.bio || 'Hey there! I am using SPLENDER CHAT.'
  );

  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  if (!isOpen || !currentUserProfile || !firebaseUser) return null;

  const handleSaveName = async () => {
    if (!nameInput.trim()) return;
    playClickSound();
    await updateProfile({ displayName: nameInput.trim() });
    setIsEditingName(false);
    showToast('Name Updated', 'Your profile name has been saved', 'success');
  };

  const handleSaveBio = async (newBio?: string) => {
    const text = newBio !== undefined ? newBio : bioInput;
    if (!text.trim()) return;
    playClickSound();
    await updateProfile({ bio: text.trim() });
    setBioInput(text.trim());
    setIsEditingBio(false);
    showToast('About Updated', 'Your status statement has been saved', 'success');
  };

  const handleSelectAvatar = async (avatarUrl: string) => {
    playPopSound();
    await updateProfile({ avatar: avatarUrl });
    setShowAvatarPicker(false);
    showToast('Profile Photo Updated', 'New avatar applied across chats', 'success');
  };

  const handleCopyId = () => {
    playClickSound();
    navigator.clipboard?.writeText?.(currentUserProfile.splenderId);
    setCopiedId(true);
    showToast('Splender ID Copied', currentUserProfile.splenderId, 'success');
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleCopyCredentials = () => {
    playClickSound();
    const creds = `Splender Identity Credentials:\nUID: ${firebaseUser.uid}\nSplender ID: ${currentUserProfile.splenderId}\nUsername: @${currentUserProfile.username}\nBackend Provider: Firebase Firestore\nSecurity: Signal Protocol Double Ratchet E2EE`;
    navigator.clipboard?.writeText?.(creds);
    setCopiedKey(true);
    showToast('Credentials Copied', 'Account credentials copied to clipboard', 'success');
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end lg:justify-center bg-[#080B14]/78 backdrop-blur-md animate-in fade-in select-none">
      <div className="w-full max-w-lg mx-auto rounded-t-3xl lg:rounded-3xl bg-[#0D1424] border-t lg:border border-[#293650] max-h-[92vh] flex flex-col shadow-[0_24px_64px_rgba(0,0,0,0.7)] modal-slide-up text-[#F4F7FF] overflow-hidden">
        <div className="w-10 h-1 bg-[#293650] rounded-full mx-auto mt-2.5 lg:hidden shrink-0" />

        {/* Header */}
        <div className="px-4 py-2.5 flex items-center justify-between border-b border-[#293650]/80 bg-[#080B14]/88 backdrop-blur-xl text-[#F4F7FF] shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="min-w-[44px] min-h-[44px] -ml-2 flex items-center justify-center rounded-xl text-[#A8B3CC] hover:text-[#F4F7FF] hover:bg-[#131D32] transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h3 className="text-base font-semibold tracking-tight font-['Outfit']">Profile & Identity</h3>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-[#A8B3CC] hover:text-[#F4F7FF] hover:bg-[#131D32] transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* Avatar Section with Camera Trigger */}
          <div className="flex flex-col items-center justify-center pt-1">
            <div className="relative group">
              <div className="p-[2.5px] rounded-full bg-gradient-to-tr from-[#22D3EE] via-[#3B82F6] to-[#8B5CF6] shadow-[0_0_28px_rgba(59,130,246,0.28)]">
                <div className="w-28 h-28 rounded-full overflow-hidden bg-[#080B14] border-2 border-[#0D1424]">
                  <img
                    src={currentUserProfile.avatar}
                    alt={currentUserProfile.displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <button
                onClick={() => {
                  playClickSound();
                  setShowAvatarPicker(!showAvatarPicker);
                }}
                className="absolute bottom-0 right-0 w-10 h-10 rounded-full aurora-cta-gradient text-white flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-transform cursor-pointer border-2 border-[#0D1424]"
                title="Change profile photo"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-2.5">Tap camera to update profile photo</p>

            {/* Avatar Picker Palette */}
            {showAvatarPicker && (
              <div className="mt-3 w-full p-3.5 rounded-2xl bg-[#131D32] border border-[#293650] space-y-2.5 animate-in fade-in">
                <p className="text-xs font-semibold text-[#A8B3CC] text-center">
                  Choose Avatar Preset
                </p>
                <div className="flex items-center justify-center gap-2.5 overflow-x-auto py-1">
                  {PRESET_AVATARS.map((url, i) => (
                    <button
                      key={i}
                      onClick={() => handleSelectAvatar(url)}
                      className={`w-11 h-11 rounded-full overflow-hidden border-2 transition-transform hover:scale-105 cursor-pointer shrink-0 ${
                        currentUserProfile.avatar === url
                          ? 'border-[#22D3EE] ring-2 ring-[#22D3EE]/30'
                          : 'border-transparent opacity-85 hover:opacity-100'
                      }`}
                    >
                      <img src={url} alt={`Avatar preset ${i + 1}`} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Editable Display Name Card */}
          <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[#A8B3CC] flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#22D3EE]" /> Display Name
              </span>
              {!isEditingName && (
                <button
                  onClick={() => {
                    playClickSound();
                    setNameInput(currentUserProfile.displayName);
                    setIsEditingName(true);
                  }}
                  className="min-w-[36px] min-h-[36px] -mr-1.5 -my-1.5 flex items-center justify-center text-[#22D3EE] hover:bg-[#080B14]/60 rounded-xl transition-colors cursor-pointer"
                  title="Edit name"
                >
                  <Pen className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {isEditingName ? (
              <div className="flex items-center gap-2 pt-1 animate-in fade-in">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  maxLength={30}
                  autoFocus
                  className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                />
                <button
                  onClick={handleSaveName}
                  className="px-3.5 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
                >
                  Save
                </button>
                <button
                  onClick={() => setIsEditingName(false)}
                  className="px-2.5 py-2 text-xs text-[#A8B3CC] hover:text-[#F4F7FF] cursor-pointer whitespace-nowrap shrink-0"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <div>
                <p className="text-sm font-semibold text-[#F4F7FF]">
                  {currentUserProfile.displayName}
                </p>
                <p className="text-xs text-[#A8B3CC] mt-0.5">
                  Visible to your encrypted P2P contacts. Not your username or PIN.
                </p>
              </div>
            )}
          </div>

          {/* Editable About / Bio Card */}
          <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[#A8B3CC] flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-[#8B5CF6]" /> About & Status
              </span>
              {!isEditingBio && (
                <button
                  onClick={() => {
                    playClickSound();
                    setBioInput(currentUserProfile.bio || 'Hey there! I am using SPLENDER CHAT.');
                    setIsEditingBio(true);
                  }}
                  className="min-w-[36px] min-h-[36px] -mr-1.5 -my-1.5 flex items-center justify-center text-[#22D3EE] hover:bg-[#080B14]/60 rounded-xl transition-colors cursor-pointer"
                  title="Edit status"
                >
                  <Pen className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {isEditingBio ? (
              <div className="space-y-2.5 pt-1 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={bioInput}
                    onChange={(e) => setBioInput(e.target.value)}
                    maxLength={120}
                    autoFocus
                    className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                  />
                  <button
                    onClick={() => handleSaveBio()}
                    className="px-3.5 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setIsEditingBio(false)}
                    className="px-2.5 py-2 text-xs text-[#A8B3CC] hover:text-[#F4F7FF] cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Cancel
                  </button>
                </div>

                {/* Interactive Status Preset Buttons */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {STATUS_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSaveBio(preset)}
                      className="px-3 py-1.5 rounded-xl text-xs bg-[#080B14] border border-[#293650] hover:border-[#22D3EE]/60 text-[#A8B3CC] hover:text-[#F4F7FF] transition-colors cursor-pointer"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-xs leading-relaxed text-[#F4F7FF]">
                {currentUserProfile.bio || 'Hey there! I am using SPLENDER CHAT.'}
              </p>
            )}
          </div>

          {/* Splender ID Card */}
          <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] flex items-center justify-between gap-3">
            <div className="min-w-0">
              <span className="text-xs text-[#A8B3CC] font-medium">
                Public Splender ID
              </span>
              <p className="text-sm font-mono tabular-nums font-semibold text-[#22D3EE] mt-0.5 truncate">
                {currentUserProfile.splenderId}
              </p>
            </div>
            <button
              onClick={handleCopyId}
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#080B14] border border-[#293650] hover:border-[#22D3EE]/60 text-[#22D3EE] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {copiedId ? <Check className="w-3.5 h-3.5 text-[#10B981]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedId ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Account Security & UID Specs */}
          <div className="p-4 rounded-2xl bg-[#131D32]/90 border border-[#293650] space-y-2.5 text-xs">
            <div className="flex items-center justify-between text-[#A8B3CC]">
              <span className="font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#10B981]" /> Encryption Protocol
              </span>
              <span className="font-mono tabular-nums text-[#10B981] font-semibold">
                Signal Protocol · E2EE
              </span>
            </div>
            <div className="flex items-center justify-between text-[#A8B3CC] border-t border-[#293650]/60 pt-2">
              <span className="font-medium">Account UID</span>
              <span className="font-mono tabular-nums text-[#F4F7FF] truncate max-w-[180px]">
                {firebaseUser.uid}
              </span>
            </div>
            {firebaseUser.email && (
              <div className="flex items-center justify-between text-[#A8B3CC] border-t border-[#293650]/60 pt-2">
                <span className="font-medium">Registered Email</span>
                <span className="font-mono text-[#F4F7FF] truncate max-w-[180px]">
                  {firebaseUser.email}
                </span>
              </div>
            )}
          </div>

          {/* Copy Account Credentials Button */}
          <button
            onClick={handleCopyCredentials}
            className="w-full min-h-[46px] py-2.5 px-4 rounded-xl aurora-cta-gradient text-white text-xs font-semibold flex items-center justify-center gap-2 transition-transform cursor-pointer active:scale-[0.98]"
          >
            {copiedKey ? <Check className="w-4 h-4" /> : <Key className="w-4 h-4" />}
            <span>{copiedKey ? 'Credentials Copied' : 'Copy Account Credentials'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
