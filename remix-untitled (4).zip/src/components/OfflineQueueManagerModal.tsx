import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Clock,
  CloudLightning,
  Lock,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { SyncService, SyncQueueRecord } from '../services/SyncService';
import { OfflineOutboxManager, QueuedOfflineMessage } from '../lib/p2pSecurity';
import { playClickSound, playPopSound } from '../lib/sound';

interface UnifiedOutboxViewItem {
  id: string;
  label: string;
  scope: string;
  timestamp: number;
  status: 'queued' | 'processing' | 'failed';
  retryCount: number;
}

export const OfflineQueueManagerModal: React.FC = () => {
  const {
    isOfflineQueueModalOpen,
    setIsOfflineQueueModalOpen,
    networkStatus,
    showToast,
  } = useChat();

  const [queue, setQueue] = useState<UnifiedOutboxViewItem[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  const loadLiveQueue = useCallback(async () => {
    try {
      const [syncRecords, sealedOutbox] = await Promise.all([
        SyncService.getQueuedItems(),
        OfflineOutboxManager.loadSealedSnapshot(),
      ]);

      const mappedSync: UnifiedOutboxViewItem[] = syncRecords.map((rec: SyncQueueRecord) => ({
        id: rec.id,
        label:
          rec.operationType === 'OUTGOING_MESSAGE'
            ? 'Encrypted E2EE Message Envelope'
            : rec.operationType === 'ENCRYPTION_KEY_PUBLISH'
            ? 'Public Identity Key Sync'
            : 'Profile Metadata Sync',
        scope: rec.conversationId ? `Room ${rec.conversationId.slice(0, 12)}` : `UID ${rec.uid.slice(0, 8)}`,
        timestamp: rec.createdAt,
        status: rec.status,
        retryCount: rec.retryCount,
      }));

      const seenIds = new Set(mappedSync.map((i) => i.id));
      const mappedSealed: UnifiedOutboxViewItem[] = sealedOutbox
        .filter((m: QueuedOfflineMessage) => !seenIds.has(`msg_${m.id}`) && !seenIds.has(m.id))
        .map((m: QueuedOfflineMessage) => ({
          id: m.id,
          label: 'KeyVault-Sealed Outbox Envelope',
          scope: `Room ${m.targetConversationId.slice(0, 12)}`,
          timestamp: m.timestamp,
          status: 'queued',
          retryCount: m.retryAttempts,
        }));

      setQueue(
        [...mappedSync, ...mappedSealed].sort((a, b) => a.timestamp - b.timestamp)
      );
    } catch {
      setQueue([]);
    }
  }, []);

  useEffect(() => {
    if (!isOfflineQueueModalOpen) return;
    void loadLiveQueue();
    const unsub = SyncService.subscribeStats(() => {
      void loadLiveQueue();
    });
    return () => unsub();
  }, [isOfflineQueueModalOpen, loadLiveQueue]);

  if (!isOfflineQueueModalOpen) return null;

  const handleFlushQueue = async () => {
    playClickSound();
    setIsSyncing(true);
    try {
      const result = await SyncService.flushQueue(true);
      await loadLiveQueue();
      playPopSound();
      if (result.remainingCount === 0) {
        showToast('Outbox Synchronized', `Flushed ${result.flushedCount} encrypted item(s)`, 'success');
      } else {
        showToast(
          'Partial Sync',
          `${result.remainingCount} item(s) still awaiting network connectivity`,
          'info'
        );
      }
    } finally {
      setIsSyncing(false);
    }
  };

  const handleClearQueue = async () => {
    playPopSound();
    await SyncService.clearQueue();
    OfflineOutboxManager.clear();
    await loadLiveQueue();
    showToast('Outbox Cleared', 'Local encrypted outbox queue emptied', 'info');
  };

  return (
    <div
      onClick={() => setIsOfflineQueueModalOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden modal-slide-up text-slate-800 dark:text-slate-100 flex flex-col"
      >
        <div className="p-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <CloudLightning className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold leading-tight">Encrypted Offline Outbox</h3>
              <p className="text-[10px] text-white/80">IndexedDB + KeyVault Store-and-Forward</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              setIsOfflineQueueModalOpen(false);
            }}
            aria-label="Close offline outbox modal"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-3.5 text-xs">
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <Lock className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
              <div className="min-w-0">
                <span className="font-bold text-amber-900 dark:text-amber-300 block truncate">
                  {queue.length > 0 ? `${queue.length} Sealed Item(s) Pending` : 'Outbox Synchronized'}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                  Idempotent delivery · Exponential backoff
                </span>
              </div>
            </div>
            <span className="text-[11px] font-mono tabular-nums font-semibold text-amber-700 dark:text-amber-400 shrink-0 capitalize">
              {networkStatus}
            </span>
          </div>

          <div className="space-y-2 max-h-52 overflow-y-auto no-scrollbar">
            {queue.length === 0 ? (
              <div className="p-6 text-center text-slate-400 space-y-1 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                <CheckCircle2 className="w-6 h-6 mx-auto text-emerald-500" />
                <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                  All Envelopes Delivered
                </p>
                <p className="text-[10px]">Zero pending items in local encrypted IndexedDB queue</p>
              </div>
            ) : (
              queue.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {item.label}
                    </p>
                    <span className="text-[10px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                      {item.scope}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(item.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span className="text-amber-700 dark:text-amber-400 font-semibold">
                      {item.status === 'processing'
                        ? 'Syncing…'
                        : item.status === 'failed'
                        ? `Deferred · Retry ${item.retryCount}`
                        : `Queued · Retry ${item.retryCount}`}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleFlushQueue}
              disabled={queue.length === 0 || isSyncing}
              className="flex-1 min-h-[44px] py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-sm whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Flushing Outbox…' : 'Flush & Send All'}</span>
            </button>

            {queue.length > 0 && (
              <button
                onClick={handleClearQueue}
                aria-label="Clear offline outbox"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                title="Clear outbox"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

