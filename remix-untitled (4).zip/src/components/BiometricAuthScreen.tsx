import React, { useState, useEffect } from 'react';
import { Fingerprint, Lock, Delete, ArrowLeft, ShieldAlert } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { verifyWebAuthn } from '../lib/compression';
import { sound } from '../lib/sound';
import { P2PCryptoEngine } from '../lib/p2pSecurity';
import { SplenderNativeBridge } from '../lib/nativeBridge';
import { HapticsService } from '../services/HapticsService';

interface BiometricAuthScreenProps {
  isOpen: boolean;
  onSuccess: () => void;
  title?: string;
  subtitle?: string;
  allowCancel?: boolean;
  onCancel?: () => void;
}

export const BiometricAuthScreen: React.FC<BiometricAuthScreenProps> = ({
  isOpen,
  onSuccess,
  title = 'Splender Security Gate',
  subtitle = 'Authenticate with WebAuthn biometrics or your personal security PIN',
  allowCancel = false,
  onCancel,
}) => {
  const { userPin, setUserPin, showToast } = useChat();
  const [pin, setPin] = useState<string>('');
  const [errorShake, setErrorShake] = useState(false);
  const [isScanningFingerprint, setIsScanningFingerprint] = useState(false);

  // Rate-limiting states
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutSeconds, setLockoutSeconds] = useState(0);

  useEffect(() => {
    if (lockoutSeconds <= 0) return;
    const timer = setInterval(() => {
      setLockoutSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [lockoutSeconds]);

  if (!isOpen) return null;

  const handleFingerprintTap = async () => {
    sound.triggerInteraction();
    if (lockoutSeconds > 0) {
      void HapticsService.notificationError();
      showToast('Security Lockout', `Please wait ${lockoutSeconds}s before retrying.`, 'warning');
      return;
    }
    setIsScanningFingerprint(true);
    try {
      const nativeVerified = await SplenderNativeBridge.authenticateBiometricSession(title, subtitle);
      if (nativeVerified === true) {
        void HapticsService.notificationSuccess();
        sound.playGlassSend();
        setPin('');
        setFailedAttempts(0);
        onSuccess();
        return;
      }

      const verified = await verifyWebAuthn();
      if (verified) {
        void HapticsService.notificationSuccess();
        sound.playGlassSend();
        setPin('');
        setFailedAttempts(0);
        onSuccess();
        return;
      }
      showToast('Biometric Sensor', 'Biometric prompt completed or unavailable in this browser frame. Use PIN instead.', 'info');
    } catch {
      showToast('Biometric Error', 'Fallback to PIN entry', 'info');
    } finally {
      setIsScanningFingerprint(false);
    }
  };

  const handleDigitPress = (digit: string) => {
    sound.playGlassClick();
    if (lockoutSeconds > 0) return;

    if (pin.length < 6) {
      const nextPin = pin + digit;
      setPin(nextPin);
      if (nextPin.length === 6) {
        if (!userPin) {
          sound.playGlassSend();
          setUserPin(nextPin);
          showToast('Security PIN Established', 'Your personal PIN has been saved securely on this device', 'success');
          setPin('');
          setFailedAttempts(0);
          onSuccess();
          return;
        }

        P2PCryptoEngine.verifySecurityPin(nextPin, userPin).then((isValid) => {
          if (isValid) {
            void HapticsService.notificationSuccess();
            sound.playGlassSend();
            setPin('');
            setFailedAttempts(0);
            onSuccess();
          } else {
            void HapticsService.notificationError();
            setErrorShake(true);
            const nextAttempts = failedAttempts + 1;
            setFailedAttempts(nextAttempts);

            if (nextAttempts >= 5) {
              setLockoutSeconds(30);
              showToast('Rate Limit Triggered', '5 failed PIN attempts. Cooling down for 30s.', 'error');
            }

            setTimeout(() => {
              setErrorShake(false);
              setPin('');
            }, 600);
          }
        });
      }
    }
  };

  const handleBackspace = () => {
    sound.playGlassClick();
    if (lockoutSeconds > 0) return;
    setPin((prev) => prev.slice(0, -1));
  };

  return (
    <div className="absolute inset-0 z-50 bg-[#F8FAFF]/96 dark:bg-[#080B14]/96 dark:aurora-nebula-bg backdrop-blur-2xl flex flex-col justify-between p-6 select-none text-slate-900 dark:text-[#F4F7FF]">
      {/* Top Header with Back Button if allowCancel */}
      <div className="w-full flex items-center justify-between">
        {allowCancel && onCancel ? (
          <button
            type="button"
            onClick={() => {
              sound.triggerInteraction();
              onCancel();
            }}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] text-slate-700 dark:text-[#F4F7FF] hover:border-[#22D3EE] transition-colors cursor-pointer elastic-tap"
            title="Back"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : (
          <div className="w-11" />
        )}
        <span className="text-xs font-mono text-slate-500 dark:text-[#A8B3CC] whitespace-nowrap">
          Biometric Vault · WebAuthn
        </span>
        <div className="w-11" />
      </div>

      {/* Top Lock Crest */}
      <div className="flex flex-col items-center text-center pt-2">
        <div className="w-14 h-14 rounded-2xl aurora-cta-gradient flex items-center justify-center text-[#F4F7FF] mb-3 shadow-lg">
          <Lock className="w-6 h-6" />
        </div>
        <h2 className="font-display text-xl font-bold text-slate-900 dark:text-[#F4F7FF] mb-1 text-balance">
          {title}
        </h2>
        <p className="text-xs text-slate-600 dark:text-[#A8B3CC] max-w-xs leading-relaxed">
          {lockoutSeconds > 0 ? (
            <span className="text-rose-500 font-semibold flex items-center justify-center gap-1 tabular-nums">
              <ShieldAlert className="w-3.5 h-3.5" />
              Rate limit active. Wait {lockoutSeconds} seconds.
            </span>
          ) : !userPin ? (
            'Set a 6-digit security PIN to protect your Splender session.'
          ) : (
            subtitle
          )}
        </p>
      </div>

      {/* Center Biometric Sensor & PIN Dots */}
      <div className="flex flex-col items-center my-auto py-2">
        <button
          type="button"
          onClick={handleFingerprintTap}
          disabled={lockoutSeconds > 0}
          className={`relative p-6 rounded-full cursor-pointer transition-transform duration-200 elastic-tap ${
            lockoutSeconds > 0
              ? 'opacity-40 pointer-events-none'
              : isScanningFingerprint
              ? 'scale-105 aurora-cta-gradient text-white'
              : 'bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] hover:border-[#22D3EE] shadow-[0_12px_32px_-8px_rgba(34,211,238,0.22)]'
          }`}
          aria-label="Authenticate with Biometrics"
        >
          <Fingerprint
            className={`w-16 h-16 transition-colors ${
              isScanningFingerprint
                ? 'text-white'
                : 'text-[#3B82F6] dark:text-[#22D3EE]'
            }`}
          />
        </button>
        <span className="text-[11px] font-mono text-slate-600 dark:text-[#A8B3CC] mt-2.5 tabular-nums">
          {lockoutSeconds > 0
            ? `Cooldown active (${lockoutSeconds}s)`
            : isScanningFingerprint
            ? 'Verifying hardware biometrics...'
            : 'Tap sensor for Biometrics'}
        </span>

        {/* 6 PIN Indicator Dots */}
        <div
          className={`flex items-center gap-3 mt-5 transition-transform ${
            errorShake ? 'translate-x-1 text-rose-500' : ''
          }`}
        >
          {[0, 1, 2, 3, 4, 5].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-3.5 h-3.5 rounded-full border-2 transition-all duration-150 ${
                  isFilled
                    ? 'bg-[#22D3EE] border-[#22D3EE] scale-110 shadow-[0_0_10px_rgba(34,211,238,0.5)]'
                    : 'border-slate-300 dark:border-[#293650] bg-slate-100 dark:bg-[#0D1424]'
                }`}
              />
            );
          })}
        </div>
        {errorShake && lockoutSeconds === 0 && (
          <p className="text-[11px] text-rose-500 font-semibold mt-2 tabular-nums">
            Incorrect PIN · Attempt {failedAttempts}/5
          </p>
        )}
      </div>

      {/* 10-Key Number Pad */}
      <div className={`w-full max-w-xs mx-auto pb-4 ${lockoutSeconds > 0 ? 'opacity-40 pointer-events-none' : ''}`}>
        <div className="grid grid-cols-3 gap-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              disabled={lockoutSeconds > 0}
              onClick={() => handleDigitPress(digit)}
              className="min-h-[52px] rounded-2xl bg-white dark:bg-[#131D32]/90 border border-slate-200 dark:border-[#293650] hover:border-[#3B82F6] dark:hover:border-[#22D3EE]/50 text-slate-900 dark:text-[#F4F7FF] text-lg font-mono font-bold tabular-nums active:scale-95 transition-transform cursor-pointer flex items-center justify-center disabled:cursor-not-allowed elastic-tap"
            >
              {digit}
            </button>
          ))}
          <div className="flex items-center justify-center text-[11px] text-slate-500 dark:text-[#A8B3CC] font-mono whitespace-nowrap">
            {userPin ? 'PIN Ready' : 'New PIN'}
          </div>
          <button
            type="button"
            disabled={lockoutSeconds > 0}
            onClick={() => handleDigitPress('0')}
            className="min-h-[52px] rounded-2xl bg-white dark:bg-[#131D32]/90 border border-slate-200 dark:border-[#293650] hover:border-[#3B82F6] dark:hover:border-[#22D3EE]/50 text-slate-900 dark:text-[#F4F7FF] text-lg font-mono font-bold tabular-nums active:scale-95 transition-transform cursor-pointer flex items-center justify-center disabled:cursor-not-allowed elastic-tap"
          >
            0
          </button>
          <button
            type="button"
            disabled={lockoutSeconds > 0}
            onClick={handleBackspace}
            className="min-h-[52px] rounded-2xl bg-white dark:bg-[#131D32]/90 border border-slate-200 dark:border-[#293650] hover:border-[#8B5CF6] text-slate-500 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] active:scale-95 transition-transform cursor-pointer flex items-center justify-center disabled:cursor-not-allowed elastic-tap"
            aria-label="Backspace"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
