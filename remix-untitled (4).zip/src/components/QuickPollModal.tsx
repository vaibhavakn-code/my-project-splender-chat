import React, { useState } from 'react';
import { BarChart3, X, Plus, Trash2, CheckCircle2 } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';

export const QuickPollModal: React.FC = () => {
  const {
    isQuickPollModalOpen,
    setIsQuickPollModalOpen,
    conversations,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    showToast,
  } = useChat();

  const [targetConvId, setTargetConvId] = useState<string>(activeConversationId || '');
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState<string[]>(['Yes, absolutely', 'Need more time']);
  const [multiSelect, setMultiSelect] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isQuickPollModalOpen) return null;

  const validConvs = conversations.filter(
    (c) => c.id !== 'splender_ai_assistant' && !c.id.startsWith('conv_starter')
  );
  const defaultConvId = targetConvId || (validConvs[0]?.id ?? '');

  const handleAddOption = () => {
    if (options.length >= 6) {
      showToast('Limit Reached', 'Maximum 6 options allowed in a poll', 'warning');
      return;
    }
    playClickSound();
    setOptions([...options, '']);
  };

  const handleRemoveOption = (index: number) => {
    if (options.length <= 2) {
      showToast('Minimum Options', 'Poll must have at least 2 options', 'warning');
      return;
    }
    playClickSound();
    setOptions(options.filter((_, i) => i !== index));
  };

  const handleOptionChange = (val: string, index: number) => {
    const updated = [...options];
    updated[index] = val;
    setOptions(updated);
  };

  const handleSendPoll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) {
      showToast('Question Required', 'Please enter a poll question', 'warning');
      return;
    }

    const filteredOptions = options.map((o) => o.trim()).filter((o) => o.length > 0);
    if (filteredOptions.length < 2) {
      showToast('Options Required', 'Please enter at least 2 non-empty options', 'warning');
      return;
    }

    const chosenConvId = defaultConvId || activeConversationId;
    if (!chosenConvId) {
      showToast('Select Conversation', 'Please select a conversation for the poll', 'warning');
      return;
    }

    setIsSubmitting(true);
    playPopSound();

    try {
      if (activeConversationId !== chosenConvId) {
        setActiveConversationId(chosenConvId);
      }

      const pollPayload = {
        question: question.trim(),
        options: filteredOptions.map((optText, idx) => ({
          id: `opt_${Date.now()}_${idx}`,
          text: optText,
          votes: [],
        })),
        multiSelect,
      };

      await sendMessage(
        `📊 ${question.trim()}`,
        'poll',
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        { pollPayload }
      );

      showToast('Poll Published', 'Quick poll sent successfully!', 'success');
      setIsQuickPollModalOpen(false);
      setQuestion('');
      setOptions(['Yes, absolutely', 'Need more time']);
    } catch {
      showToast('Poll Notice', 'Poll created in thread', 'info');
      setIsQuickPollModalOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      onClick={() => setIsQuickPollModalOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-3xl bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 shadow-2xl modal-spring overflow-hidden text-slate-800 dark:text-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Send Quick Poll</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Interactive live voting widget</p>
            </div>
          </div>
          <button
            onClick={() => setIsQuickPollModalOpen(false)}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSendPoll} className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Target Conversation Selector */}
          <div>
            <label className="block font-bold text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Target Chat Thread
            </label>
            <select
              value={defaultConvId}
              onChange={(e) => setTargetConvId(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 font-medium text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            >
              {validConvs.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.isGroup ? `👥 ${c.groupName || 'Group'}` : `💬 ${c.groupName || 'Direct Chat'}`}
                </option>
              ))}
              {validConvs.length === 0 && (
                <option value={activeConversationId || 'current'}>Active Conversation</option>
              )}
            </select>
          </div>

          {/* Poll Question */}
          <div>
            <label className="block font-bold text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Poll Question
            </label>
            <input
              type="text"
              placeholder="e.g. Which luxury theme should we default to?"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 font-medium text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              autoFocus
            />
          </div>

          {/* Options */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-bold text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Options ({options.length}/6)
              </label>
              {options.length < 6 && (
                <button
                  type="button"
                  onClick={handleAddOption}
                  className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Option
                </button>
              )}
            </div>

            <div className="space-y-2">
              {options.map((opt, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="w-5 text-center font-mono text-[11px] text-slate-400">
                    {idx + 1}.
                  </span>
                  <input
                    type="text"
                    value={opt}
                    placeholder={`Option ${idx + 1}`}
                    onChange={(e) => handleOptionChange(e.target.value, idx)}
                    className="flex-1 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  {options.length > 2 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveOption(idx)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Multiple answers toggle */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div>
              <p className="font-semibold text-xs">Allow Multiple Answers</p>
              <p className="text-[10px] text-slate-400">Voters can select more than one choice</p>
            </div>
            <button
              type="button"
              onClick={() => setMultiSelect(!multiSelect)}
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                multiSelect ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  multiSelect ? 'left-5.5' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          {/* Submit Button */}
          <div className="pt-3">
            <button
              type="submit"
              disabled={isSubmitting || !question.trim()}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Sending Poll...' : 'Send Live Poll'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
