import React, { useState, useRef, useLayoutEffect, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import {
  X,
  Type,
  AlignCenter,
  AlignLeft,
  AlignRight,
  Layers,
  Grid,
  Move,
  RotateCcw,
  Send,
  Sliders,
} from 'lucide-react';
import { playClickSound } from '../lib/sound';

export type StatusTextAlignment = 'center' | 'left' | 'right';
export type StatusBackdropPattern = 'None' | 'Grid' | 'Rings' | 'Dots';

export interface StatusPayload {
  text: string;
  color: string;
  font: string;
  offsetX: number;
  offsetY: number;
  scale: number;
  rotation: number;
  colorOpacity: number;
  textAlignment: StatusTextAlignment;
  pattern: StatusBackdropPattern;
  isGradientMeshActive: boolean;
  expiresAt: number;
}

export interface StatusPublishPayload {
  text: string;
  bgColor: string;
  fontFamily: string;
  fontSize: number;
  colorOpacity?: number;
  textAlignment?: StatusTextAlignment;
  pattern?: StatusBackdropPattern;
  isGradientMeshActive?: boolean;
  offsetX?: number;
  offsetY?: number;
  scale?: number;
  rotation?: number;
  expiresAt?: number;
}

export const STATUS_COLOR_SWATCHES: ReadonlyArray<{
  hex: string;
  label: string;
  swatchClass: string;
}> = [
  { hex: '#0F9D58', label: 'Sovereign Emerald', swatchClass: 'bg-[#0F9D58]' },
  { hex: '#1E1B4B', label: 'Cosmic Indigo', swatchClass: 'bg-[#1E1B4B]' },
  { hex: '#4C1D95', label: 'Electric Violet', swatchClass: 'bg-[#4C1D95]' },
  { hex: '#0E7490', label: 'Nebula Cyan', swatchClass: 'bg-[#0E7490]' },
  { hex: '#1D4ED8', label: 'Aurora Royal Blue', swatchClass: 'bg-[#1D4ED8]' },
  { hex: '#BE185D', label: 'Magenta Nebula', swatchClass: 'bg-[#BE185D]' },
  { hex: '#C2410C', label: 'Solar Amber', swatchClass: 'bg-[#C2410C]' },
  { hex: '#080B14', label: 'Obsidian Night', swatchClass: 'bg-[#080B14]' },
];

export const STATUS_FONT_OPTIONS: ReadonlyArray<{
  id: string;
  shortLabel: string;
  name: string;
  cssClass: string;
}> = [
  { id: 'sans', shortLabel: 'Sans', name: 'Plus Jakarta Sans', cssClass: 'font-sans' },
  { id: 'mono', shortLabel: 'Mono', name: 'JetBrains Mono', cssClass: 'font-mono' },
  { id: 'serif', shortLabel: 'Serif', name: 'Editorial Serif', cssClass: 'font-serif' },
  { id: 'display', shortLabel: 'Display', name: 'Outfit Display', cssClass: 'font-display font-bold tracking-tight' },
];

export const STATUS_PATTERNS: ReadonlyArray<StatusBackdropPattern> = [
  'None',
  'Grid',
  'Rings',
  'Dots',
];

const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;
const MAX_STATUS_CHARS = 700;

function clamp(val: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, val));
}

function escapeXml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Generates a 1080x1920 high-DPI SVG Data URI preserving background color, opacity,
 * sweep/mesh gradient, geometric backdrop pattern, font family, alignment, and
 * 2D transform (`offsetX`, `offsetY`, `scale`, `rotation`).
 */
export function createAdvancedStatusSvg(payload: StatusPublishPayload): string {
  const bgColor = /^#[0-9A-Fa-f]{3,8}$/.test(payload.bgColor) ? payload.bgColor : '#0F9D58';
  const opacity = clamp(typeof payload.colorOpacity === 'number' ? payload.colorOpacity : 1, 0.2, 1);
  const align: StatusTextAlignment =
    payload.textAlignment === 'left' || payload.textAlignment === 'right'
      ? payload.textAlignment
      : 'center';
  const pattern: StatusBackdropPattern =
    payload.pattern === 'Grid' || payload.pattern === 'Rings' || payload.pattern === 'Dots'
      ? payload.pattern
      : 'None';
  const isMesh = Boolean(payload.isGradientMeshActive);
  const scale = clamp(typeof payload.scale === 'number' ? payload.scale : 1, 0.5, 3.0);
  const rotation = typeof payload.rotation === 'number' ? Math.round(payload.rotation * 10) / 10 : 0;
  const svgOffsetX = Math.round(clamp(payload.offsetX || 0, -600, 600) * 2.1);
  const svgOffsetY = Math.round(clamp(payload.offsetY || 0, -900, 900) * 2.1);

  const fontMap: Record<string, string> = {
    sans: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
    serif: 'Georgia, Cambria, "Times New Roman", serif',
    display: '"Outfit", system-ui, -apple-system, sans-serif',
    cursive: 'cursive, sans-serif',
  };
  const fontCss = fontMap[payload.fontFamily] || fontMap.sans;
  const baseFontSize = clamp(payload.fontSize || 24, 16, 48);
  const scaledFontPx = Math.max(36, Math.round((baseFontSize / 24) * 54));

  const safeLinesHtml = escapeXml(payload.text.slice(0, MAX_STATUS_CHARS))
    .split('\n')
    .join('<br xmlns="http://www.w3.org/1999/xhtml"/>');

  const justifyCss =
    align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center';

  let patternMarkup = '';
  if (pattern === 'Grid') {
    patternMarkup = `
      <defs>
        <pattern id="stGrid" width="96" height="96" patternUnits="userSpaceOnUse">
          <path d="M 96 0 L 0 0 0 96" fill="none" stroke="#FFFFFF" stroke-opacity="0.12" stroke-width="2"/>
        </pattern>
      </defs>
      <rect width="1080" height="1920" fill="url(#stGrid)"/>`;
  } else if (pattern === 'Dots') {
    patternMarkup = `
      <defs>
        <pattern id="stDots" width="72" height="72" patternUnits="userSpaceOnUse">
          <circle cx="36" cy="36" r="4" fill="#FFFFFF" fill-opacity="0.15"/>
        </pattern>
      </defs>
      <rect width="1080" height="1920" fill="url(#stDots)"/>`;
  } else if (pattern === 'Rings') {
    patternMarkup = `
      <g fill="none" stroke="#FFFFFF" stroke-opacity="0.12" stroke-width="2.5">
        <circle cx="540" cy="960" r="160"/>
        <circle cx="540" cy="960" r="320"/>
        <circle cx="540" cy="960" r="480"/>
        <circle cx="540" cy="960" r="640"/>
        <circle cx="540" cy="960" r="800"/>
      </g>`;
  }

  const backdropMarkup = isMesh
    ? `<defs>
        <linearGradient id="meshDiag" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${bgColor}" stop-opacity="${opacity}"/>
          <stop offset="48%" stop-color="#D946EF" stop-opacity="${opacity}"/>
          <stop offset="100%" stop-color="#06B6D4" stop-opacity="${opacity}"/>
        </linearGradient>
        <radialGradient id="meshOrbA" cx="82%" cy="22%" r="62%">
          <stop offset="0%" stop-color="#22D3EE" stop-opacity="${(opacity * 0.72).toFixed(2)}"/>
          <stop offset="100%" stop-color="#22D3EE" stop-opacity="0"/>
        </radialGradient>
        <radialGradient id="meshOrbB" cx="18%" cy="78%" r="65%">
          <stop offset="0%" stop-color="#EC4899" stop-opacity="${(opacity * 0.68).toFixed(2)}"/>
          <stop offset="100%" stop-color="#EC4899" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <rect width="1080" height="1920" fill="url(#meshDiag)"/>
      <rect width="1080" height="1920" fill="url(#meshOrbA)"/>
      <rect width="1080" height="1920" fill="url(#meshOrbB)"/>`
    : `<rect width="1080" height="1920" fill="${bgColor}" fill-opacity="${opacity}"/>`;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920">
    <rect width="1080" height="1920" fill="#080B14"/>
    ${backdropMarkup}
    ${patternMarkup}
    <g transform="translate(540, 960) translate(${svgOffsetX}, ${svgOffsetY}) rotate(${rotation}) scale(${scale}) translate(-540, -960)">
      <foreignObject x="96" y="340" width="888" height="1240">
        <div xmlns="http://www.w3.org/1999/xhtml" style="width:100%;height:100%;display:flex;align-items:center;justify-content:${justifyCss};text-align:${align};padding:32px;box-sizing:border-box;">
          <span style="color:#FFFFFF;font-size:${scaledFontPx}px;font-family:${fontCss.replace(/"/g, "'")};font-weight:700;line-height:1.42;word-break:break-word;width:100%;">
            ${safeLinesHtml}
          </span>
        </div>
      </foreignObject>
    </g>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export interface UltimateAdvancedStatusCreatorProps {
  onPostStatus: (payload: StatusPayload) => void;
  onClose?: () => void;
}

export const UltimateAdvancedStatusCreatorScreen: React.FC<UltimateAdvancedStatusCreatorProps> = ({
  onPostStatus,
  onClose,
}) => {
  // 1. Styling States
  const [statusText, setStatusText] = useState('');
  const [selectedFontIndex, setSelectedFontIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [colorOpacity, setColorOpacity] = useState(1);
  const [textAlignment, setTextAlignment] = useState<StatusTextAlignment>('center');
  const [patternIndex, setPatternIndex] = useState(0);
  const [isGradientMeshActive, setIsGradientMeshActive] = useState(false);
  const [showTransformSliders, setShowTransformSliders] = useState(false);

  // 2. Interactive Gesture States (Drag, Zoom, Rotate)
  const [offsetX, setOffsetX] = useState(0);
  const [offsetY, setOffsetY] = useState(0);
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  const transformNodeRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Pointer drag tracking
  const dragSessionRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    originOffsetX: number;
    originOffsetY: number;
    isDragging: boolean;
    startedOnHandle: boolean;
  } | null>(null);

  // Multi-touch pinch-zoom & two-finger rotation tracking
  const touchGestureRef = useRef<{
    initialDistance: number;
    initialAngleDeg: number;
    initialMidX: number;
    initialMidY: number;
    originScale: number;
    originRotation: number;
    originOffsetX: number;
    originOffsetY: number;
  } | null>(null);

  const currentColor = STATUS_COLOR_SWATCHES[selectedColorIndex] || STATUS_COLOR_SWATCHES[0];
  const currentFont = STATUS_FONT_OPTIONS[selectedFontIndex] || STATUS_FONT_OPTIONS[0];
  const selectedPattern = STATUS_PATTERNS[patternIndex] || 'None';

  // Apply GPU-composited transform without JSX inline style props
  useLayoutEffect(() => {
    const node = transformNodeRef.current;
    if (!node) return;
    node.style.transform = `translate3d(${Math.round(offsetX)}px, ${Math.round(offsetY)}px, 0) scale(${scale}) rotate(${rotation}deg)`;
  }, [offsetX, offsetY, scale, rotation]);

  useEffect(() => {
    const timer = setTimeout(() => {
      textareaRef.current?.focus();
    }, 60);
    return () => clearTimeout(timer);
  }, []);

  const cycleFont = () => {
    playClickSound();
    setSelectedFontIndex((prev) => (prev + 1) % STATUS_FONT_OPTIONS.length);
  };

  const cycleAlignment = () => {
    playClickSound();
    setTextAlignment((prev) => {
      if (prev === 'center') return 'left';
      if (prev === 'left') return 'right';
      return 'center';
    });
  };

  const cyclePattern = () => {
    playClickSound();
    setPatternIndex((prev) => (prev + 1) % STATUS_PATTERNS.length);
  };

  const resetTransforms = () => {
    playClickSound();
    setOffsetX(0);
    setOffsetY(0);
    setScale(1);
    setRotation(0);
  };

  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLDivElement>, startedOnHandle = false) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    if (!startedOnHandle && (e.target as HTMLElement)?.tagName === 'TEXTAREA') {
      return;
    }
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    dragSessionRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originOffsetX: offsetX,
      originOffsetY: offsetY,
      isDragging: startedOnHandle,
      startedOnHandle,
    };
  };

  const handleCanvasPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const session = dragSessionRef.current;
    if (!session || session.pointerId !== e.pointerId) return;
    const dx = e.clientX - session.startX;
    const dy = e.clientY - session.startY;
    if (!session.isDragging && Math.hypot(dx, dy) > 4) {
      session.isDragging = true;
    }
    if (session.isDragging) {
      setOffsetX(clamp(session.originOffsetX + dx, -480, 480));
      setOffsetY(clamp(session.originOffsetY + dy, -720, 720));
    }
  };

  const handleCanvasPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const session = dragSessionRef.current;
    if (!session || session.pointerId !== e.pointerId) return;
    if (!session.isDragging && !session.startedOnHandle) {
      textareaRef.current?.focus();
    }
    dragSessionRef.current = null;
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      const t0 = e.touches[0];
      const t1 = e.touches[1];
      const dx = t1.clientX - t0.clientX;
      const dy = t1.clientY - t0.clientY;
      touchGestureRef.current = {
        initialDistance: Math.max(12, Math.hypot(dx, dy)),
        initialAngleDeg: (Math.atan2(dy, dx) * 180) / Math.PI,
        initialMidX: (t0.clientX + t1.clientX) / 2,
        initialMidY: (t0.clientY + t1.clientY) / 2,
        originScale: scale,
        originRotation: rotation,
        originOffsetX: offsetX,
        originOffsetY: offsetY,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && touchGestureRef.current) {
      const gesture = touchGestureRef.current;
      const t0 = e.touches[0];
      const t1 = e.touches[1];
      const dx = t1.clientX - t0.clientX;
      const dy = t1.clientY - t0.clientY;
      const dist = Math.max(12, Math.hypot(dx, dy));
      const angleDeg = (Math.atan2(dy, dx) * 180) / Math.PI;
      const midX = (t0.clientX + t1.clientX) / 2;
      const midY = (t0.clientY + t1.clientY) / 2;

      const nextScale = clamp(gesture.originScale * (dist / gesture.initialDistance), 0.5, 3.0);
      const nextRotation = clamp(gesture.originRotation + (angleDeg - gesture.initialAngleDeg), -180, 180);
      const nextOffsetX = clamp(gesture.originOffsetX + (midX - gesture.initialMidX), -480, 480);
      const nextOffsetY = clamp(gesture.originOffsetY + (midY - gesture.initialMidY), -720, 720);

      setScale(Math.round(nextScale * 100) / 100);
      setRotation(Math.round(nextRotation));
      setOffsetX(nextOffsetX);
      setOffsetY(nextOffsetY);
    }
  };

  const handleTouchEnd = () => {
    touchGestureRef.current = null;
  };

  const handleCanvasWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = -e.deltaY * 0.004;
      setScale((prev) => Math.round(clamp(prev + delta, 0.5, 3.0) * 100) / 100);
    } else if (e.shiftKey) {
      e.preventDefault();
      const rotDelta = e.deltaY > 0 ? 4 : -4;
      setRotation((prev) => clamp(prev + rotDelta, -180, 180));
    }
  };

  const handlePost = () => {
    const trimmed = statusText.trim();
    if (!trimmed) return;
    playClickSound();
    onPostStatus({
      text: trimmed.slice(0, MAX_STATUS_CHARS),
      color: currentColor.hex,
      font: currentFont.id,
      offsetX,
      offsetY,
      scale,
      rotation,
      colorOpacity,
      textAlignment,
      pattern: selectedPattern,
      isGradientMeshActive,
      expiresAt: Date.now() + TWENTY_FOUR_HOURS_MS,
    });
  };

  const isTransformed = offsetX !== 0 || offsetY !== 0 || scale !== 1 || rotation !== 0;
  const alignLabel =
    textAlignment === 'left' ? 'Left' : textAlignment === 'right' ? 'Right' : 'Center';
  const textAlignClass =
    textAlignment === 'left'
      ? 'text-left'
      : textAlignment === 'right'
      ? 'text-right'
      : 'text-center';

  return (
    <div
      data-testid="ultimate-status-creator"
      className="fixed inset-0 z-50 flex flex-col justify-between bg-[#080B14] text-white select-none overflow-hidden animate-in fade-in duration-150"
    >
      {/* Dynamic SVG Backdrop: Solid Color + Opacity OR Sweep/Mesh Gradient + Geometric Pattern */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        viewBox="0 0 1080 1920"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        <rect width="1080" height="1920" fill="#080B14" />
        {isGradientMeshActive ? (
          <>
            <defs>
              <linearGradient id="liveStatusMeshDiag" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={currentColor.hex} stopOpacity={colorOpacity} />
                <stop offset="48%" stopColor="#D946EF" stopOpacity={colorOpacity} />
                <stop offset="100%" stopColor="#06B6D4" stopOpacity={colorOpacity} />
              </linearGradient>
              <radialGradient id="liveStatusMeshOrbA" cx="82%" cy="22%" r="62%">
                <stop offset="0%" stopColor="#22D3EE" stopOpacity={colorOpacity * 0.72} />
                <stop offset="100%" stopColor="#22D3EE" stopOpacity={0} />
              </radialGradient>
              <radialGradient id="liveStatusMeshOrbB" cx="18%" cy="78%" r="65%">
                <stop offset="0%" stopColor="#EC4899" stopOpacity={colorOpacity * 0.68} />
                <stop offset="100%" stopColor="#EC4899" stopOpacity={0} />
              </radialGradient>
            </defs>
            <rect width="1080" height="1920" fill="url(#liveStatusMeshDiag)" />
            <rect width="1080" height="1920" fill="url(#liveStatusMeshOrbA)" />
            <rect width="1080" height="1920" fill="url(#liveStatusMeshOrbB)" />
          </>
        ) : (
          <rect width="1080" height="1920" fill={currentColor.hex} fillOpacity={colorOpacity} />
        )}

        {selectedPattern === 'Grid' && (
          <>
            <defs>
              <pattern id="liveGridPat" width="96" height="96" patternUnits="userSpaceOnUse">
                <path
                  d="M 96 0 L 0 0 0 96"
                  fill="none"
                  stroke="#FFFFFF"
                  strokeOpacity="0.12"
                  strokeWidth="2"
                />
              </pattern>
            </defs>
            <rect width="1080" height="1920" fill="url(#liveGridPat)" />
          </>
        )}

        {selectedPattern === 'Dots' && (
          <>
            <defs>
              <pattern id="liveDotsPat" width="72" height="72" patternUnits="userSpaceOnUse">
                <circle cx="36" cy="36" r="4" fill="#FFFFFF" fillOpacity="0.15" />
              </pattern>
            </defs>
            <rect width="1080" height="1920" fill="url(#liveDotsPat)" />
          </>
        )}

        {selectedPattern === 'Rings' && (
          <g fill="none" stroke="#FFFFFF" strokeOpacity="0.12" strokeWidth="2.5">
            <circle cx="540" cy="960" r="160" />
            <circle cx="540" cy="960" r="320" />
            <circle cx="540" cy="960" r="480" />
            <circle cx="540" cy="960" r="640" />
            <circle cx="540" cy="960" r="800" />
          </g>
        )}
      </svg>

      {/* Interactive Gesture Canvas Layer (Drag, Pinch-Zoom, Two-Finger Rotate) */}
      <div
        onPointerDown={(e) => handleCanvasPointerDown(e, false)}
        onPointerMove={handleCanvasPointerMove}
        onPointerUp={handleCanvasPointerUp}
        onPointerCancel={handleCanvasPointerUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onWheel={handleCanvasWheel}
        className="absolute inset-0 z-10 flex items-center justify-center p-6 touch-none cursor-grab active:cursor-grabbing"
      >
        <div
          ref={transformNodeRef}
          data-testid="status-transform-layer"
          className="w-full max-w-lg flex flex-col items-center gap-2 will-change-transform"
        >
          {/* Dedicated Drag Handle Pill for Mouse & Single-Finger Positioning */}
          <div
            onPointerDown={(e) => handleCanvasPointerDown(e, true)}
            onPointerMove={handleCanvasPointerMove}
            onPointerUp={handleCanvasPointerUp}
            onPointerCancel={handleCanvasPointerUp}
            title="Drag to position status text"
            className="px-3 py-1 rounded-full bg-black/30 hover:bg-black/45 border border-white/20 backdrop-blur-md flex items-center gap-1.5 text-[11px] text-white/80 cursor-grab active:cursor-grabbing transition-colors"
          >
            <Move className="w-3 h-3" />
            <span>Drag · Pinch · Rotate</span>
          </div>

          <textarea
            ref={textareaRef}
            value={statusText}
            onChange={(e) => setStatusText(e.target.value.slice(0, MAX_STATUS_CHARS))}
            placeholder="Type a futuristic status..."
            rows={4}
            maxLength={MAX_STATUS_CHARS}
            aria-label="Status text"
            className={`w-full bg-transparent text-white placeholder:text-white/70 text-2xl sm:text-3xl font-semibold leading-relaxed outline-none resize-none px-3 py-2 rounded-2xl focus-visible:ring-1 focus-visible:ring-white/40 cursor-text ${textAlignClass} ${currentFont.cssClass}`}
          />
        </div>
      </div>

      {/* Top Toolbar: Close, Font Selector, Pattern Toggle & Alignment Toggle */}
      <div className="relative z-20 px-4 pt-4 pb-2 flex items-center justify-between gap-2 bg-gradient-to-b from-black/55 to-transparent">
        <div className="flex items-center gap-2">
          {onClose && (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              aria-label="Close status creator"
              className="min-w-[44px] min-h-[44px] rounded-xl bg-black/40 hover:bg-black/60 border border-white/15 backdrop-blur-md flex items-center justify-center text-white transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <button
            type="button"
            onClick={cycleFont}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-black/40 hover:bg-black/60 border border-white/15 backdrop-blur-md text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Type className="w-4 h-4 shrink-0" />
            <span>Font: {currentFont.shortLabel}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={cyclePattern}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-black/40 hover:bg-black/60 border border-white/15 backdrop-blur-md text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Grid className="w-4 h-4 shrink-0" />
            <span>Pattern: {selectedPattern}</span>
          </button>

          <button
            type="button"
            onClick={cycleAlignment}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-black/40 hover:bg-black/60 border border-white/15 backdrop-blur-md text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            {textAlignment === 'left' ? (
              <AlignLeft className="w-4 h-4 shrink-0" />
            ) : textAlignment === 'right' ? (
              <AlignRight className="w-4 h-4 shrink-0" />
            ) : (
              <AlignCenter className="w-4 h-4 shrink-0" />
            )}
            <span>Align: {alignLabel}</span>
          </button>
        </div>
      </div>

      {/* Bottom Controls: Color Swatches, Opacity, Transform Fine-Tuning, Gradient Mesh & Post CTA */}
      <div className="relative z-20 px-4 pb-5 pt-6 bg-gradient-to-t from-black/80 via-black/50 to-transparent">
        <div className="max-w-lg mx-auto w-full space-y-3">
          {/* Fine Transform Controls Drawer (Scale & Rotation) + Reset */}
          <div className="flex items-center justify-between gap-2 text-xs text-white/85">
            <div className="flex items-center gap-2 font-mono tabular-nums">
              <span>Scale {scale.toFixed(1)}x</span>
              <span aria-hidden="true">·</span>
              <span>{Math.round(rotation)}°</span>
              <span aria-hidden="true">·</span>
              <span>Opacity {Math.round(colorOpacity * 100)}%</span>
            </div>

            <div className="flex items-center gap-2">
              {isTransformed && (
                <button
                  type="button"
                  onClick={resetTransforms}
                  className="min-h-[36px] px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-medium text-white flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setShowTransformSliders((prev) => !prev);
                }}
                className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  showTransformSliders
                    ? 'bg-white text-slate-950'
                    : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Transform</span>
              </button>
            </div>
          </div>

          {showTransformSliders && (
            <div className="p-3 rounded-2xl bg-black/45 border border-white/15 backdrop-blur-md space-y-2.5">
              <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
                <label htmlFor="status-scale-slider" className="w-16 text-white/80">
                  Scale
                </label>
                <input
                  id="status-scale-slider"
                  type="range"
                  min="0.5"
                  max="3"
                  step="0.05"
                  value={scale}
                  onChange={(e) => setScale(Number(e.target.value))}
                  className="flex-1 accent-cyan-400 cursor-pointer"
                />
                <span className="w-10 text-right">{scale.toFixed(2)}x</span>
              </div>

              <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
                <label htmlFor="status-rotation-slider" className="w-16 text-white/80">
                  Rotate
                </label>
                <input
                  id="status-rotation-slider"
                  type="range"
                  min="-180"
                  max="180"
                  step="1"
                  value={rotation}
                  onChange={(e) => setRotation(Number(e.target.value))}
                  className="flex-1 accent-cyan-400 cursor-pointer"
                />
                <span className="w-10 text-right">{Math.round(rotation)}°</span>
              </div>
            </div>
          )}

          {/* Color Palette Swatches */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto py-1 no-scrollbar">
            {STATUS_COLOR_SWATCHES.map((swatch, idx) => {
              const isSelected = idx === selectedColorIndex;
              return (
                <button
                  key={swatch.hex}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setSelectedColorIndex(idx);
                  }}
                  title={swatch.label}
                  aria-label={`Select ${swatch.label}`}
                  className={`w-9 h-9 rounded-full shrink-0 transition-transform cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white ${
                    swatch.swatchClass
                  } ${
                    isSelected
                      ? 'border-2 border-white scale-110 shadow-md'
                      : 'border border-white/40 opacity-85 hover:opacity-100'
                  }`}
                />
              );
            })}
          </div>

          {/* Opacity Slider (0.2f .. 1.0f) */}
          <div className="flex items-center gap-3 px-3.5 py-2 rounded-xl bg-black/40 border border-white/15 backdrop-blur-md text-xs">
            <label htmlFor="status-opacity-slider" className="font-medium text-white/85 whitespace-nowrap">
              Opacity
            </label>
            <input
              id="status-opacity-slider"
              type="range"
              min="0.2"
              max="1"
              step="0.02"
              value={colorOpacity}
              onChange={(e) => setColorOpacity(Number(e.target.value))}
              aria-label="Background opacity"
              className="flex-1 accent-white cursor-pointer"
            />
            <span className="font-mono tabular-nums text-white/80 w-10 text-right">
              {Math.round(colorOpacity * 100)}%
            </span>
          </div>

          {/* Gradient Mesh Toggle Button */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setIsGradientMeshActive((prev) => !prev);
            }}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-black/45 hover:bg-black/65 border border-white/20 backdrop-blur-md text-xs font-semibold text-white flex items-center justify-center gap-2 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Layers className="w-4 h-4 text-[#22D3EE]" />
            <span>{isGradientMeshActive ? 'Disable Gradient Mesh' : 'Enable Gradient Mesh'}</span>
          </button>

          {/* Post Button */}
          <button
            type="button"
            onClick={handlePost}
            disabled={!statusText.trim()}
            className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-black hover:bg-slate-950 disabled:opacity-45 border border-white/20 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Send className="w-4 h-4" />
            <span>Post Status (24 Hours Live)</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const StatusEditorModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onPublish: (payload: StatusPublishPayload) => void;
}> = ({ isOpen, onClose, onPublish }) => {
  if (!isOpen) return null;

  return (
    <UltimateAdvancedStatusCreatorScreen
      onClose={onClose}
      onPostStatus={(status) => {
        onPublish({
          text: status.text,
          bgColor: status.color,
          fontFamily: status.font,
          fontSize: Math.round(24 * status.scale),
          colorOpacity: status.colorOpacity,
          textAlignment: status.textAlignment,
          pattern: status.pattern,
          isGradientMeshActive: status.isGradientMeshActive,
          offsetX: status.offsetX,
          offsetY: status.offsetY,
          scale: status.scale,
          rotation: status.rotation,
          expiresAt: status.expiresAt,
        });
        onClose();
      }}
    />
  );
};

export function mountStandaloneStatusCreator(
  container: HTMLElement,
  props: UltimateAdvancedStatusCreatorProps
): () => void {
  const root = createRoot(container);
  root.render(<UltimateAdvancedStatusCreatorScreen {...props} />);
  return () => {
    root.unmount();
  };
}

