// src/components/ErrorBoundary.tsx
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw, Zap, Sparkles } from 'lucide-react';
import { SanjivaniResilience } from '../lib/sanjivaniResilience';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  isSelfHealing: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    isSelfHealing: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, isSelfHealing: false };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Sanjivani Resilience caught state boundary disturbance:', error, errorInfo);
  }

  private handleSanjivaniAutoHeal = async () => {
    this.setState({ isSelfHealing: true });
    try {
      const sanjivani = SanjivaniResilience.getInstance();
      await sanjivani.selfHealQueue();
      // Clear non-critical transient session keys while preserving auth identity
      sessionStorage.clear();
      setTimeout(() => {
        this.setState({ hasError: false, error: undefined, isSelfHealing: false });
      }, 600);
    } catch {
      window.location.reload();
    }
  };

  private handleFullReset = () => {
    localStorage.clear();
    sessionStorage.clear();
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#07090E] text-gray-100 flex flex-col items-center justify-center p-6 text-center select-none relative overflow-hidden">
          {/* Ambient Cosmic Background Halos */}
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#06B6D4]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          {/* Core Sanjivani Recovery Pod */}
          <div className="relative z-10 max-w-sm w-full p-6 rounded-3xl bg-[#0D111A]/90 border border-[#06B6D4]/30 shadow-2xl backdrop-blur-2xl">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#06B6D4]/20 to-[#D4AF37]/20 border border-[#06B6D4]/40 flex items-center justify-center mx-auto mb-4 text-[#06B6D4] shadow-lg shadow-[#06B6D4]/20 animate-pulse">
              <ShieldAlert className="w-8 h-8" />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#06B6D4]/10 border border-[#06B6D4]/30 text-[#06B6D4] text-[10px] font-mono tracking-widest uppercase mb-2">
              <Sparkles className="w-3 h-3" />
              <span>Sanjivani Resilience Active</span>
            </div>

            <h2 className="text-lg font-black tracking-tight text-white mb-1.5">
              Quantum State Restored
            </h2>
            <p className="text-xs text-gray-400 mb-6 leading-relaxed">
              A temporary runtime variance occurred. The Sanjivani self-healing engine can restore continuity without loss of credentials.
            </p>

            <div className="space-y-2.5">
              <button
                onClick={this.handleSanjivaniAutoHeal}
                disabled={this.state.isSelfHealing}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#06B6D4] via-[#0EA5E9] to-[#D4AF37] text-gray-950 font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-lg shadow-[#06B6D4]/25 hover:opacity-95 active:scale-[0.98] transition-all cursor-pointer"
              >
                {this.state.isSelfHealing ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-gray-950" />
                ) : (
                  <Zap className="w-4 h-4 text-gray-950" />
                )}
                <span>{this.state.isSelfHealing ? 'Re-aligning State...' : 'Self-Heal & Resume'}</span>
              </button>

              <button
                onClick={this.handleFullReset}
                className="w-full py-2.5 px-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-gray-400" />
                <span>Deep Node Reboot</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
