import React from 'react';
import { X, FileText, Download, Share2, ExternalLink, Printer } from 'lucide-react';
import { playClickSound } from '../lib/sound';

interface DocumentPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileName: string;
  fileSize?: string;
  fileUrl?: string;
  senderName?: string;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  isOpen,
  onClose,
  fileName,
  fileSize,
  fileUrl,
  senderName,
}) => {
  if (!isOpen) return null;

  const handleDownload = () => {
    playClickSound();
    if (!fileUrl) return;
    const a = document.createElement('a');
    a.href = fileUrl;
    a.download = fileName || 'document.pdf';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const isPdf = fileName.toLowerCase().endsWith('.pdf');

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-3xl bg-[#FFFFFF] dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-[#111B21] dark:text-[#E9EDEF]">
        {/* Header */}
        <div className="p-3.5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-[#008069] dark:bg-[#1F2C34] text-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs font-bold truncate">{fileName || 'Document Preview'}</h3>
              <p className="text-[10px] text-white/80">
                {fileSize || 'PDF Document'} {senderName ? `• Shared by ${senderName}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {fileUrl && (
              <button
                onClick={handleDownload}
                className="p-1.5 rounded-full text-white/90 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="p-1.5 rounded-full text-white/90 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Document Content Viewport */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 bg-slate-100 dark:bg-slate-900/50 flex flex-col items-center justify-center">
          {fileUrl && isPdf ? (
            <div className="w-full h-[60vh] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white shadow-inner">
              <iframe
                src={`${fileUrl}#toolbar=0`}
                title={fileName}
                className="w-full h-full border-0"
              />
            </div>
          ) : (
            /* Styled Realistic In-App Document Canvas Preview */
            <div className="w-full max-w-md bg-white dark:bg-[#1E293B] rounded-2xl p-6 shadow-lg border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold text-xs">
                    PDF
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-100">{fileName}</p>
                    <p className="text-[10px] text-slate-400">Verified cryptographic hash</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                  SECURE E2EE
                </span>
              </div>

              {/* Document Text Skeleton Simulation */}
              <div className="space-y-2.5 py-2">
                <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded-full w-3/4" />
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full w-full" />
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full w-5/6" />
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full w-full" />
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full w-2/3" />
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-center">
                <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
                  Ready to read or export
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  End-to-end encrypted file attachment transferred via Signal Protocol
                </p>
              </div>

              <button
                onClick={handleDownload}
                className="w-full py-2.5 rounded-xl bg-[#008069] dark:bg-[#25D366] text-white dark:text-[#111B21] font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:opacity-90 transition-opacity cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Save to Device</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
