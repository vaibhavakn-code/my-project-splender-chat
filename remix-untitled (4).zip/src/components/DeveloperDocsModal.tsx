import React, { useState } from 'react';
import {
  ArrowLeft,
  X,
  Code2,
  ShieldCheck,
  Server,
  Key,
  Copy,
  Check,
  Radio,
  Flame,
  AlertCircle,
  Network,
  Cpu,
  Zap,
  Sparkles,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { sound } from '../lib/sound';
import { OmniChatMasterEngine, OmniEvent } from '../lib/omniChatEngine';
import firebaseConfig from '../../firebase-applet-config.json';

interface DeveloperDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MASTER_MAP_ASCII = `===================================================================================
                     OMNICHAT ULTIMATE: SINGLE-WINDOW MASTER MAP
===================================================================================

       [ TAB 1: HOME ]        [ TAB 2: CHATS ]       [ TAB 3: CAMERA ]
   +--------------------+  +--------------------+  +--------------------+
   | - Pulse Streams    |  | - Signal E2EE      |  | - AR Shaders       |
   | - Community Posts  |  | - Direct Messages  |  | - Camera Filters   |
   | - Stories Carousel |  | - Ephemeral Streaks|  | - Quick Snaps      |
   | - Topic Discussions|  | - My Eyes Only Vault| | - Sound Effects    |
   +--------------------+  +--------------------+  +--------------------+
             |                      |                      |
             +----------------------+----------------------+
                                    |
                                    v
                   [ CENTRAL EVENT ROUTER ENGINE ]
                   (OmniChatMasterEngine.processUnifiedEvent)
                                    |
             +----------------------+----------------------+
             |                      |                      |
             v                      v                      v
       [ TAB 4: SHORTS ]     [ TAB 5: WORLD ]      [ SECURITY & LOGIC ]
   +--------------------+  +--------------------+  +--------------------+
   | - Spotlight Shorts |  | - Radar Map Pins   |  | - Signal Protocol  |
   | - Pulse Video Feed |  | - Ghost Mode Toggle|  | - Disappearing TTL |
   | - Creator Channels |  | - Marketplace Store|  | - Friction & Latency|
   | - AI Recommendation|  | - Local Events     |  | - Quantum Duality  |
   +--------------------+  +--------------------+  +--------------------+
===================================================================================`;

export const DeveloperDocsModal: React.FC<DeveloperDocsModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useChat();
  const [activeTab, setActiveTab] = useState<'master_map' | 'router_console' | 'deployment'>('master_map');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [testEventType, setTestEventType] = useState<'SEND_MESSAGE' | 'UPDATE_STREAK' | 'RANK_POST' | 'SET_GHOST_MODE' | 'CALCULATE_ENTANGLEMENT'>('SEND_MESSAGE');
  const [eventOutput, setEventOutput] = useState<any>(null);

  if (!isOpen) return null;

  const copyCode = (code: string, label: string) => {
    sound.playGlassClick();
    navigator.clipboard?.writeText?.(code);
    setCopiedSection(label);
    showToast('Copied to Clipboard', label, 'success');
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleTestEvent = () => {
    sound.playGlassClick();
    let eventPayload: OmniEvent;

    switch (testEventType) {
      case 'SEND_MESSAGE':
        eventPayload = {
          type: 'SEND_MESSAGE',
          payload: {
            id: `msg_${Date.now()}`,
            senderUid: 'sovereign_user',
            recipientUid: 'target_node',
            text: 'Hello via Signal Double Ratchet & Quantum Superposition!',
            disappearingTimer: '24h',
          },
        };
        break;
      case 'UPDATE_STREAK':
        eventPayload = {
          type: 'UPDATE_STREAK',
          payload: {
            partnerUid: 'user_alex',
            recordInteraction: true,
          },
        };
        break;
      case 'RANK_POST':
        eventPayload = {
          type: 'RANK_POST',
          payload: {
            likes: 450,
            comments: 55,
            shares: 28,
            saves: 95,
            watchTime: 180,
            createdAt: Date.now() - 3600 * 1000 * 2, // 2h ago
          },
        };
        break;
      case 'SET_GHOST_MODE':
        eventPayload = {
          type: 'SET_GHOST_MODE',
          payload: {
            enabled: true,
            blurRadiusKm: 15,
          },
        };
        break;
      case 'CALCULATE_ENTANGLEMENT':
        eventPayload = {
          type: 'CALCULATE_ENTANGLEMENT',
          payload: {
            userA: 'me',
            userB: 'user_alex',
            streakCount: 42,
          },
        };
        break;
    }

    const res = OmniChatMasterEngine.processUnifiedEvent(eventPayload);
    setEventOutput(res);
  };

  return (
    <div className="absolute inset-0 z-50 bg-[#2B2533]/40 backdrop-blur-md flex flex-col justify-end animate-in fade-in select-none text-[#2B2533]">
      <div className="glass-3d-panel rounded-t-[32px] max-h-[94%] flex flex-col shadow-2xl overflow-hidden bg-[#EFEAD8]/98">
        {/* Top Header with Back Arrow */}
        <div className="p-4 flex items-center justify-between border-b border-white/60 bg-white/30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sound.playGlassClick();
                onClose();
              }}
              className="p-1.5 rounded-full hover:bg-white/50 text-[#6B6275] hover:text-[#2B2533] transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5 text-[#7C5C9B]" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#06B6D4] to-[#D4AF37] flex items-center justify-center text-white shadow-sm">
                <Network className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#2B2533]">OmniChat Ultimate Engine</h3>
                <p className="text-[10px] text-[#6B6275] font-mono">Unified Master Map & Event Console</p>
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playGlassClick();
              onClose();
            }}
            className="p-1.5 rounded-full text-[#6B6275] hover:text-[#2B2533] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-Tabs (Master Map, Live Event Router, Deployment) */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-black/5 bg-white/20 text-xs font-bold">
          <button
            onClick={() => {
              sound.playGlassClick();
              setActiveTab('master_map');
            }}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTab === 'master_map'
                ? 'bg-[#06B6D4] text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            Master Architecture Map
          </button>
          <button
            onClick={() => {
              sound.playGlassClick();
              setActiveTab('router_console');
            }}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTab === 'router_console'
                ? 'bg-[#06B6D4] text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            Live Event Router
          </button>
          <button
            onClick={() => {
              sound.playGlassClick();
              setActiveTab('deployment');
            }}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTab === 'deployment'
                ? 'bg-[#06B6D4] text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            Deployment & Rules
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto space-y-4 no-scrollbar text-xs">
          {/* TAB 1: MASTER MAP ASCII VIEW */}
          {activeTab === 'master_map' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-black text-cyan-400 font-mono text-[10px] leading-tight overflow-x-auto no-scrollbar shadow-2xl border border-cyan-500/30 relative">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-cyan-500/20">
                  <span className="font-bold flex items-center gap-1.5 text-white">
                    <Cpu className="w-3.5 h-3.5 text-[#D4AF37]" />
                    OmniChat Single-Window Topology
                  </span>
                  <button
                    onClick={() => copyCode(MASTER_MAP_ASCII, 'Master Map ASCII')}
                    className="flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/50 hover:bg-cyan-900 transition-colors"
                  >
                    {copiedSection === 'Master Map ASCII' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>Copy Diagram</span>
                  </button>
                </div>
                <pre className="whitespace-pre">{MASTER_MAP_ASCII}</pre>
              </div>

              {/* 5-Pillar Summary Cards */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-xl border border-cyan-500/30 bg-white/60">
                  <span className="font-bold text-[#06B6D4] block mb-0.5">Pillar 1: Mechanical</span>
                  <p className="text-gray-600">5-Tab Dynamic Map: Home, Chats, Camera, Shorts, World.</p>
                </div>
                <div className="p-2.5 rounded-xl border border-emerald-500/30 bg-white/60">
                  <span className="font-bold text-emerald-600 block mb-0.5">Pillar 2: Logical & E2EE</span>
                  <p className="text-gray-600">Signal Protocol v3, 24h-90d TTL, My Eyes Only PIN Vault.</p>
                </div>
                <div className="p-2.5 rounded-xl border border-amber-500/30 bg-white/60">
                  <span className="font-bold text-amber-600 block mb-0.5">Pillar 3: Arithmetical</span>
                  <p className="text-gray-600">Gravity Decay Ranking Formula + Daily Active Streaks.</p>
                </div>
                <div className="p-2.5 rounded-xl border border-purple-500/30 bg-white/60">
                  <span className="font-bold text-purple-600 block mb-0.5">Pillar 4: Quantum & Physical</span>
                  <p className="text-gray-600">Friction Telemetry (ms, J, thermal) + Wave Superposition.</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE EVENT ROUTER INTERACTIVE TESTING */}
          {activeTab === 'router_console' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl glass-pod-ivory border border-white/80 space-y-2">
                <span className="font-bold text-xs flex items-center gap-1.5 text-[#06B6D4]">
                  <Zap className="w-3.5 h-3.5 text-[#D4AF37]" />
                  Dispatch Event to OmniChatMasterEngine
                </span>
                <p className="text-[11px] text-[#6B6275]">
                  Select an event type to route through <code>OmniChatMasterEngine.processUnifiedEvent</code>:
                </p>

                <div className="flex flex-wrap gap-1.5">
                  {(['SEND_MESSAGE', 'UPDATE_STREAK', 'RANK_POST', 'SET_GHOST_MODE', 'CALCULATE_ENTANGLEMENT'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setTestEventType(t)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                        testEventType === t
                          ? 'bg-[#06B6D4] text-white shadow-xs'
                          : 'bg-white/60 text-[#6B6275] hover:bg-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleTestEvent}
                  className="w-full mt-2 py-2 rounded-xl bg-gradient-to-r from-[#06B6D4] to-[#D4AF37] text-white font-bold text-xs shadow-md shadow-cyan-500/20 hover:brightness-110 active:scale-98 transition-all"
                >
                  ⚡ Execute Unified Event
                </button>
              </div>

              {/* JSON Output Viewer */}
              {eventOutput && (
                <div className="p-3 rounded-2xl bg-black text-emerald-400 font-mono text-[10px] space-y-1 border border-emerald-500/30 overflow-x-auto no-scrollbar">
                  <div className="flex items-center justify-between text-white border-b border-emerald-500/20 pb-1 mb-1">
                    <span className="font-bold">Output (took {eventOutput.executionDurationMs}ms)</span>
                    <span className="text-[9px] text-cyan-300">SUCCESS</span>
                  </div>
                  <pre className="whitespace-pre-wrap">{JSON.stringify(eventOutput, null, 2)}</pre>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: DEPLOYMENT & FIREBASE CONFIG */}
          {activeTab === 'deployment' && (
            <div className="space-y-4">
              {/* Real Firebase Project Overview */}
              <div className="p-4 rounded-2xl glass-pod-ivory space-y-2 shadow-sm border border-white/80">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#2B2533] font-bold">
                    <Flame className="w-4 h-4 text-[#7C5C9B]" />
                    <span>Active Project Environment</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#C5D8A4]/70 text-[#2B2533] border border-[#C5D8A4] font-bold">
                    CONNECTED
                  </span>
                </div>
                <div className="space-y-1 font-mono text-[11px] text-[#6B6275] bg-white/50 p-2.5 rounded-xl border border-white">
                  <p><span className="text-[#6B6275]">Project ID:</span> <span className="text-[#7C5C9B] font-bold">{firebaseConfig.projectId}</span></p>
                  <p><span className="text-[#6B6275]">Database ID:</span> <span className="text-[#7C5C9B] font-bold">{firebaseConfig.firestoreDatabaseId}</span></p>
                  <p><span className="text-[#6B6275]">Auth Domain:</span> <span className="text-[#2B2533]">{firebaseConfig.authDomain}</span></p>
                </div>
              </div>

              {/* Step 1: Authentication Providers in Firebase Console */}
              <div className="p-4 rounded-2xl glass-pod-ivory space-y-2.5 shadow-sm border border-white/80">
                <div className="flex items-center gap-2 text-[#2B2533] font-bold">
                  <Key className="w-4 h-4 text-[#7C5C9B]" />
                  <span>1. Enable Auth Providers in Firebase Console</span>
                </div>
                <p className="text-[#6B6275] leading-relaxed text-[11px]">
                  To support anonymous onboarding, 1-click Google Login, and password-based account recovery:
                </p>
                <ol className="list-decimal list-inside space-y-1.5 text-[#2B2533] text-[11px] pl-1">
                  <li>Open <span className="text-[#7C5C9B] font-mono font-semibold">Firebase Console &gt; Authentication &gt; Sign-in method</span></li>
                  <li>Enable <span className="font-bold text-[#2B2533]">Google</span> (provisioned by default)</li>
                  <li>Enable <span className="font-bold text-[#2B2533]">Anonymous</span> (allows seamless guest login without prompts)</li>
                  <li>Enable <span className="font-bold text-[#2B2533]">Email/Password</span> (allows linking account recovery credentials)</li>
                </ol>
              </div>

              {/* Step 2: Firestore & Storage Rules Deployment */}
              <div className="p-4 rounded-2xl glass-pod-ivory space-y-2.5 shadow-sm border border-white/80">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#2B2533] font-bold">
                    <ShieldCheck className="w-4 h-4 text-[#7C5C9B]" />
                    <span>2. Firestore Declarative Security Rules</span>
                  </div>
                  <button
                    onClick={() => copyCode('firebase deploy --only firestore:rules', 'Deploy Command')}
                    className="text-[10px] text-[#7C5C9B] font-bold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    {copiedSection === 'Deploy Command' ? <Check className="w-3 h-3 text-[#7C5C9B]" /> : <Copy className="w-3 h-3" />}
                    <span>Copy CLI</span>
                  </button>
                </div>
                <div className="bg-white/50 p-2.5 rounded-xl font-mono text-[10px] text-[#2B2533] overflow-x-auto no-scrollbar border border-white">
                  <code>firebase deploy --only firestore:rules</code>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
