import React, { useState } from 'react';
import { Info, CheckCircle2, ChevronDown, ChevronUp, Lock, KeyRound } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { sound } from '../lib/sound';
import { SplenderLogo } from './SplenderLogo';

export const OnboardingAuthScreen: React.FC = () => {
  const {
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    tryAnonymousAuth,
    authRestrictedInfo,
  } = useChat();

  const [mode, setMode] = useState<'google_quick' | 'email_login' | 'email_signup'>('google_quick');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [chosenUsername, setChosenUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showConsoleHelp, setShowConsoleHelp] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    sound.triggerInteraction();
    setIsLoading(true);
    setLocalError(null);
    try {
      const ok = await signInWithGoogle();
      if (!ok) {
        setLocalError('Google Sign-In was cancelled or could not complete.');
      } else {
        sound.playGlassSend();
      }
    } catch (err: any) {
      setLocalError(err.message || 'Google Sign-In failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    sound.triggerInteraction();
    setIsLoading(true);
    setLocalError(null);
    try {
      if (mode === 'email_signup') {
        const ok = await signUpWithEmail(email.trim(), password.trim(), chosenUsername.trim() || undefined);
        if (!ok) {
          setLocalError('Registration failed. Verify your email and password.');
        } else {
          sound.playGlassSend();
        }
      } else {
        const ok = await signInWithEmail(email.trim(), password.trim());
        if (!ok) {
          setLocalError('Sign-in failed. Check your email or password.');
        } else {
          sound.playGlassSend();
        }
      }
    } catch (err: any) {
      setLocalError(err.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryAnonymous = async () => {
    sound.triggerInteraction();
    setIsLoading(true);
    setLocalError(null);
    try {
      const ok = await tryAnonymousAuth();
      if (!ok) {
        setShowConsoleHelp(true);
      } else {
        sound.playGlassSend();
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F8FAFF] dark:bg-[#080B14] dark:aurora-nebula-bg p-6 overflow-y-auto no-scrollbar text-slate-900 dark:text-[#F4F7FF] select-none">
      <div className="max-w-md w-full mx-auto space-y-6 pt-4 lg:pt-8">
        {/* Sovereign Identity Brand Header */}
        <div className="flex flex-col items-center text-center space-y-3.5">
          <SplenderLogo size="xl" />
          <div className="space-y-1.5">
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F4F7FF] text-balance">
              Splender Chat
            </h1>
            <p className="text-xs text-slate-600 dark:text-[#A8B3CC] max-w-[310px] leading-relaxed">
              Peer-first end-to-end encrypted messaging with Signal Double Ratchet and direct WebRTC transport
            </p>
          </div>
        </div>

        {/* Status notice if Anonymous Auth was explicitly attempted while restricted */}
        {authRestrictedInfo?.isRestricted && (
          <div className="p-4 rounded-2xl bg-white/90 dark:bg-[#0D1424]/90 backdrop-blur-xl border border-slate-200 dark:border-[#293650] text-xs space-y-2.5 shadow-sm">
            <div className="flex items-start gap-2.5">
              <Info className="w-4 h-4 text-[#3B82F6] dark:text-[#22D3EE] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-900 dark:text-[#F4F7FF]">Identity Sign-In Required</p>
                <p className="text-[11px] text-slate-600 dark:text-[#A8B3CC] leading-relaxed mt-0.5">
                  Anonymous guest access is disabled in this Firebase project. Sign in with Google or enable Anonymous Sign-In in Firebase Console.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                sound.triggerInteraction();
                setShowConsoleHelp(!showConsoleHelp);
              }}
              className="min-h-[36px] text-[11px] text-[#3B82F6] dark:text-[#22D3EE] hover:underline flex items-center gap-1 font-semibold cursor-pointer whitespace-nowrap"
            >
              <span>{showConsoleHelp ? 'Hide guest setup instructions' : 'Enable guest mode in Firebase Console'}</span>
              {showConsoleHelp ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showConsoleHelp && (
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] text-[11px] text-slate-600 dark:text-[#A8B3CC] space-y-1.5">
                <p>1. Open Firebase Console → Authentication → Sign-in method.</p>
                <p>2. Select Anonymous and click Enable.</p>
                <button
                  type="button"
                  onClick={handleRetryAnonymous}
                  disabled={isLoading}
                  className="mt-2 w-full min-h-[44px] py-2 px-4 rounded-xl aurora-cta-gradient text-[#F4F7FF] font-semibold text-xs cursor-pointer disabled:opacity-50 transition-transform active:scale-[0.98]"
                >
                  {isLoading ? 'Checking...' : 'Retry Guest Node'}
                </button>
              </div>
            )}
          </div>
        )}

        {localError && (
          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/45 border border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200 text-xs">
            {localError}
          </div>
        )}

        {/* Aurora Nebula Glass Authentication Card */}
        <div className="rounded-3xl aurora-glass-card p-5 lg:p-6 space-y-4">
          {/* Segmented Mode Control */}
          <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-100 dark:bg-[#080B14]/85 border border-slate-200/70 dark:border-[#293650]/70 text-xs font-medium">
            <button
              type="button"
              onClick={() => {
                sound.playGlassClick();
                setMode('google_quick');
              }}
              className={`min-h-[40px] rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                mode === 'google_quick'
                  ? 'bg-white dark:bg-[#131D32] text-slate-900 dark:text-[#F4F7FF] font-semibold shadow-xs border border-slate-200/80 dark:border-[#293650]'
                  : 'text-slate-500 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF]'
              }`}
            >
              Google
            </button>
            <button
              type="button"
              onClick={() => {
                sound.playGlassClick();
                setMode('email_login');
              }}
              className={`min-h-[40px] rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                mode !== 'google_quick'
                  ? 'bg-white dark:bg-[#131D32] text-slate-900 dark:text-[#F4F7FF] font-semibold shadow-xs border border-slate-200/80 dark:border-[#293650]'
                  : 'text-slate-500 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF]'
              }`}
            >
              Email &amp; Password
            </button>
          </div>

          {mode === 'google_quick' ? (
            <div className="space-y-3 pt-1">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] hover:border-[#3B82F6] dark:hover:border-[#22D3EE]/60 text-slate-900 dark:text-[#F4F7FF] font-semibold text-xs flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 transition-colors whitespace-nowrap"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.04h3.88c2.28-2.09 3.66-5.18 3.66-9.14z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.04c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.28 21.43 7.35 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.28c-.25-.72-.38-1.49-.38-2.28s.13-1.56.38-2.28V6.59H1.25C.45 8.19 0 10.04 0 12s.45 3.81 1.25 5.41l4.03-3.13z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.28 2.57 1.25 6.59l4.03 3.13c.95-2.83 3.6-4.97 6.72-4.97z"
                  />
                </svg>
                <span>{isLoading ? 'Connecting...' : 'Continue with Google'}</span>
              </button>

              {!authRestrictedInfo?.isRestricted && (
                <button
                  type="button"
                  onClick={handleRetryAnonymous}
                  disabled={isLoading}
                  className="w-full min-h-[42px] py-2 px-4 rounded-xl bg-transparent hover:bg-slate-100/80 dark:hover:bg-[#131D32]/60 border border-slate-200/80 dark:border-[#293650]/70 text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] font-medium text-xs transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap"
                >
                  Continue as Guest Peer
                </button>
              )}

              <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-[#A8B3CC] justify-center pt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] dark:text-[#22D3EE] shrink-0" />
                <span>Provisions non-extractable ECDH &amp; AES-256 keys locally</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleEmailSubmit} className="space-y-3.5">
              {mode === 'email_signup' && (
                <div>
                  <label className="text-[11px] font-medium text-slate-600 dark:text-[#A8B3CC] block mb-1.5">
                    Splender Username (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="kalpak"
                    value={chosenUsername}
                    onChange={(e) => setChosenUsername(e.target.value)}
                    className="w-full min-h-[44px] bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F4F7FF] placeholder-slate-400 dark:placeholder-[#A8B3CC]/55 focus:outline-none focus:border-[#3B82F6] dark:focus:border-[#22D3EE] font-mono transition-colors"
                  />
                </div>
              )}

              <div>
                <label className="text-[11px] font-medium text-slate-600 dark:text-[#A8B3CC] block mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="peer@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full min-h-[44px] bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F4F7FF] placeholder-slate-400 dark:placeholder-[#A8B3CC]/55 focus:outline-none focus:border-[#3B82F6] dark:focus:border-[#22D3EE] transition-colors"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-medium text-slate-600 dark:text-[#A8B3CC] block mb-1.5">
                  Password
                </label>
                <input
                  type="password"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full min-h-[44px] bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F4F7FF] placeholder-slate-400 dark:placeholder-[#A8B3CC]/55 focus:outline-none focus:border-[#3B82F6] dark:focus:border-[#22D3EE] transition-colors"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full min-h-[48px] py-2.5 px-4 rounded-xl aurora-cta-gradient text-[#F4F7FF] text-xs font-semibold cursor-pointer disabled:opacity-50 transition-transform active:scale-[0.98] whitespace-nowrap"
              >
                {isLoading
                  ? 'Signing in...'
                  : mode === 'email_signup'
                  ? 'Create Splender Account'
                  : 'Sign In'}
              </button>

              <div className="flex items-center justify-center pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    sound.playGlassClick();
                    setMode(mode === 'email_signup' ? 'email_login' : 'email_signup');
                  }}
                  className="min-h-[36px] text-[#3B82F6] dark:text-[#22D3EE] font-semibold hover:underline cursor-pointer whitespace-nowrap"
                >
                  {mode === 'email_signup' ? 'Already registered? Sign In' : 'New to Splender? Create Account'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Unboxed Quiet Technical Footer */}
      <div className="pt-6 pb-2 text-center text-[11px] text-slate-500 dark:text-[#A8B3CC] flex items-center justify-center gap-2 flex-wrap">
        <span className="inline-flex items-center gap-1">
          <Lock className="w-3 h-3 text-[#3B82F6] dark:text-[#22D3EE]" />
          Signal Double Ratchet
        </span>
        <span aria-hidden="true">·</span>
        <span className="inline-flex items-center gap-1 font-mono tabular-nums">
          <KeyRound className="w-3 h-3 text-[#8B5CF6]" />
          Android 17 (API 37) Keystore
        </span>
      </div>
    </div>
  );
};
