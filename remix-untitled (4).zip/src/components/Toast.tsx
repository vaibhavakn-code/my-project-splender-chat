import React, { useState } from 'react';
import { CheckCircle2, AlertCircle, Info, XCircle, X, Send } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';

export const Toast: React.FC = () => {
  const { toasts, dismissToast } = useChat();
  const [replyInputs, setReplyInputs] = useState<Record<string, string>>({});

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-14 left-4 right-4 max-w-md mx-auto z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';
        const isWarning = toast.type === 'warning';

        const replyVal = replyInputs[toast.id] || '';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-2xl border shadow-[0_16px_40px_rgba(0,0,0,0.65)] flex flex-col gap-2 backdrop-blur-xl animate-in slide-in-from-top duration-200 bg-[#0D1424]/95 text-[#F4F7FF] ${
              isSuccess
                ? 'border-[#10B981]/50'
                : isError
                ? 'border-rose-500/60'
                : isWarning
                ? 'border-amber-500/60'
                : 'border-[#293650]'
            }`}
          >
            <div className="flex items-start gap-2.5">
              <div className="shrink-0 mt-0.5">
                {isSuccess && <CheckCircle2 className="w-4 h-4 text-[#10B981]" />}
                {isError && <XCircle className="w-4 h-4 text-rose-400" />}
                {isWarning && <AlertCircle className="w-4 h-4 text-amber-400" />}
                {(!toast.type || toast.type === 'info') && (
                  <Info className="w-4 h-4 text-[#22D3EE]" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold leading-tight text-[#F4F7FF]">{toast.title}</p>
                {toast.description && (
                  <p className="text-xs text-[#A8B3CC] leading-normal mt-0.5">
                    {toast.description}
                  </p>
                )}
              </div>

              {toast.onView && (
                <button
                  onClick={() => {
                    playClickSound();
                    toast.onView?.();
                    dismissToast(toast.id);
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold aurora-cta-gradient text-white transition-transform active:scale-95 shrink-0 cursor-pointer whitespace-nowrap"
                >
                  View
                </button>
              )}

              <button
                onClick={() => dismissToast(toast.id)}
                className="text-[#A8B3CC] hover:text-[#F4F7FF] shrink-0 p-1 rounded-lg hover:bg-[#131D32] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {toast.replyAction && (
              <div className="pt-2 border-t border-[#293650]/80 flex flex-col gap-2">
                {toast.quickReplies && (
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    {toast.quickReplies.map((qr, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          toast.replyAction?.(qr);
                          dismissToast(toast.id);
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium bg-[#131D32] hover:border-[#22D3EE]/50 text-[#F4F7FF] border border-[#293650] shrink-0 cursor-pointer whitespace-nowrap"
                      >
                        {qr}
                      </button>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={replyVal}
                    onChange={(e) =>
                      setReplyInputs((prev) => ({ ...prev, [toast.id]: e.target.value }))
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && replyVal.trim()) {
                        toast.replyAction?.(replyVal.trim());
                        dismissToast(toast.id);
                      }
                    }}
                    placeholder="Quick reply..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl bg-[#080B14] border border-[#293650] outline-none focus:border-[#22D3EE] text-[#F4F7FF]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (replyVal.trim()) {
                        toast.replyAction?.(replyVal.trim());
                        dismissToast(toast.id);
                      }
                    }}
                    className="p-2 rounded-xl aurora-cta-gradient text-white cursor-pointer shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
