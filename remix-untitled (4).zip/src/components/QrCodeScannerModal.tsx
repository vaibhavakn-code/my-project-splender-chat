import React, { useState } from 'react';
import {
  ArrowLeft,
  X,
  QrCode,
  Flashlight,
  Camera,
  Share2,
  Download,
  Check,
  Shield,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { sound } from '../lib/sound';

interface QrCodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QrCodeScannerModal: React.FC<QrCodeScannerModalProps> = ({ isOpen, onClose }) => {
  const { currentUserProfile, searchUserBySplenderOrUsername, sendContactRequest, showToast } = useChat();
  const [activeMode, setActiveMode] = useState<'scan' | 'my_qr'>('scan');
  const [manualInput, setManualInput] = useState('');
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [scannedSuccess, setScannedSuccess] = useState(false);

  if (!isOpen || !currentUserProfile) return null;

  const handleDeepLinkScan = async (code: string) => {
    sound.triggerInteraction();
    const cleanId = code.replace('splender://user/', '').trim();
    setScannedSuccess(true);
    try {
      const user = await searchUserBySplenderOrUsername(cleanId);
      if (user) {
        sound.playGlassSend();
        await sendContactRequest(user);
        setTimeout(() => {
          setScannedSuccess(false);
          onClose();
        }, 800);
      } else {
        setScannedSuccess(false);
        showToast('Invalid QR Code', 'No Splender user found matching this payload', 'warning');
      }
    } catch {
      setScannedSuccess(false);
    }
  };

  return (
    <div className="absolute inset-0 z-50 bg-[#2B2533]/40 backdrop-blur-md flex flex-col justify-end animate-in fade-in select-none text-[#2B2533]">
      <div className="glass-3d-panel rounded-t-[32px] max-h-[92%] flex flex-col shadow-2xl overflow-hidden bg-[#EFEAD8]/98">
        {/* Header with Top-Left Back Button */}
        <div className="p-4 flex items-center justify-between border-b border-white/60 bg-white/30">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                sound.playGlassClick();
                onClose();
              }}
              className="p-1.5 rounded-full hover:bg-white/50 text-[#6B6275] hover:text-[#2B2533] transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5 text-[#7C5C9B]" />
            </button>
            <div className="w-8 h-8 rounded-xl glass-purple-glow flex items-center justify-center text-white">
              <QrCode className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#2B2533]">Splender QR Gateway</h3>
          </div>
          <button
            onClick={() => {
              sound.playGlassClick();
              onClose();
            }}
            className="p-1 rounded-full text-[#6B6275] hover:text-[#2B2533] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="p-3 bg-white/30 border-b border-white/60 flex gap-2">
          <button
            onClick={() => {
              sound.playGlassClick();
              setActiveMode('scan');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all elastic-tap ${
              activeMode === 'scan'
                ? 'glass-purple-glow text-white shadow'
                : 'glass-pod-ivory text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            Scan Peer QR
          </button>
          <button
            onClick={() => {
              sound.playGlassClick();
              setActiveMode('my_qr');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all elastic-tap ${
              activeMode === 'my_qr'
                ? 'glass-purple-glow text-white shadow'
                : 'glass-pod-ivory text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            My QR Code
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex flex-col items-center justify-center no-scrollbar">
          {activeMode === 'scan' ? (
            <div className="w-full flex flex-col items-center">
              {/* Scanner Viewfinder */}
              <div className="relative w-64 h-64 rounded-3xl border-2 border-dashed border-[#7C5C9B]/60 glass-pod-ivory flex items-center justify-center overflow-hidden shadow-2xl">
                <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#7C5C9B] to-transparent shadow-lg shadow-[#7C5C9B]/50 animate-bounce" />

                {scannedSuccess ? (
                  <div className="flex flex-col items-center text-[#7C5C9B] animate-in zoom-in">
                    <Check className="w-12 h-12 stroke-[3]" />
                    <span className="text-xs font-mono font-bold mt-1">PEER DISCOVERED!</span>
                  </div>
                ) : (
                  <div className="text-center p-4">
                    <Camera className="w-10 h-10 text-[#7C5C9B]/60 mx-auto mb-2" />
                    <p className="text-[11px] text-[#6B6275] font-medium">
                      Align deep-link QR Code (splender://user/SP-XXXXXX) inside frame
                    </p>
                  </div>
                )}

                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#7C5C9B]" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#7C5C9B]" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#7C5C9B]" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#7C5C9B]" />
              </div>

              {/* Torch button */}
              <button
                onClick={() => {
                  sound.triggerInteraction();
                  setFlashlightOn(!flashlightOn);
                }}
                className={`mt-4 px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer elastic-tap ${
                  flashlightOn
                    ? 'glass-purple-glow text-white'
                    : 'glass-pod-ivory text-[#6B6275] hover:text-[#2B2533]'
                }`}
              >
                <Flashlight className="w-4 h-4" />
                <span>{flashlightOn ? 'Flashlight ON' : 'Flashlight OFF'}</span>
              </button>

              {/* Manual Deep Link / ID Input fallback */}
              <div className="w-full mt-5 pt-3 border-t border-[#D8D0BA]">
                <p className="text-[10px] text-[#6B6275] mb-1.5 text-center font-mono font-semibold">
                  Or paste deep-link QR string:
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="splender://user/SP-XXXXXX"
                    className="flex-1 glass-input-3d rounded-xl px-3 py-1.5 text-xs text-[#2B2533] placeholder-[#6B6275]/60 focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                  />
                  <button
                    onClick={() => handleDeepLinkScan(manualInput)}
                    className="px-3 py-1.5 rounded-xl glass-purple-glow text-white font-bold text-xs cursor-pointer elastic-tap"
                  >
                    Resolve
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="w-full flex flex-col items-center">
              {/* QR Code Presentation Card */}
              <div className="p-6 rounded-3xl glass-pod-ivory text-[#2B2533] flex flex-col items-center shadow-xl relative border border-white">
                <svg
                  viewBox="0 0 100 100"
                  className="w-48 h-48"
                  fill="currentColor"
                >
                  <rect x="5" y="5" width="25" height="25" rx="3" fill="#2B2533" />
                  <rect x="9" y="9" width="17" height="17" rx="2" fill="#fff" />
                  <rect x="13" y="13" width="9" height="9" rx="1" fill="#2B2533" />

                  <rect x="70" y="5" width="25" height="25" rx="3" fill="#2B2533" />
                  <rect x="74" y="9" width="17" height="17" rx="2" fill="#fff" />
                  <rect x="78" y="13" width="9" height="9" rx="1" fill="#2B2533" />

                  <rect x="5" y="70" width="25" height="25" rx="3" fill="#2B2533" />
                  <rect x="9" y="74" width="17" height="17" rx="2" fill="#fff" />
                  <rect x="13" y="78" width="9" height="9" rx="1" fill="#2B2533" />

                  <rect x="35" y="10" width="6" height="6" />
                  <rect x="45" y="10" width="6" height="6" />
                  <rect x="55" y="10" width="6" height="6" />
                  <rect x="35" y="20" width="6" height="6" />
                  <rect x="50" y="20" width="6" height="6" />

                  <rect x="10" y="38" width="6" height="6" />
                  <rect x="20" y="38" width="6" height="6" />
                  <rect x="35" y="38" width="6" height="6" />
                  <rect x="60" y="38" width="6" height="6" />
                  <rect x="75" y="38" width="6" height="6" />
                  <rect x="85" y="38" width="6" height="6" />

                  <rect x="10" y="48" width="6" height="6" />
                  <rect x="28" y="48" width="6" height="6" />
                  <rect x="40" y="48" width="6" height="6" />
                  <rect x="55" y="48" width="6" height="6" />
                  <rect x="70" y="48" width="6" height="6" />
                  <rect x="85" y="48" width="6" height="6" />

                  <rect x="10" y="58" width="6" height="6" />
                  <rect x="25" y="58" width="6" height="6" />
                  <rect x="45" y="58" width="6" height="6" />
                  <rect x="65" y="58" width="6" height="6" />
                  <rect x="80" y="58" width="6" height="6" />

                  <rect x="35" y="75" width="6" height="6" />
                  <rect x="50" y="75" width="6" height="6" />
                  <rect x="65" y="75" width="6" height="6" />
                  <rect x="80" y="75" width="6" height="6" />

                  <rect x="40" y="85" width="6" height="6" />
                  <rect x="55" y="85" width="6" height="6" />
                  <rect x="70" y="85" width="6" height="6" />
                </svg>

                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-10 h-10 rounded-full glass-purple-glow flex items-center justify-center text-white border-2 border-white shadow-md">
                    <Shield className="w-5 h-5" />
                  </div>
                </div>

                <p className="mt-3 text-xs font-mono font-bold tracking-wider text-[#7C5C9B]">
                  {currentUserProfile.splenderId}
                </p>
                <p className="text-[10px] text-[#6B6275] font-semibold">@{currentUserProfile.username}</p>
                <p className="text-[9px] text-[#6B6275] font-mono mt-0.5">
                  splender://user/{currentUserProfile.splenderId}
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-4 w-full">
                <button
                  onClick={() => {
                    sound.triggerInteraction();
                    showToast('QR Saved', 'Saved PNG to gallery', 'success');
                  }}
                  className="flex-1 py-2.5 rounded-2xl glass-pod-ivory text-[#2B2533] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer elastic-tap shadow-sm"
                >
                  <Download className="w-3.5 h-3.5 text-[#7C5C9B]" /> Save Image
                </button>
                <button
                  onClick={() => {
                    sound.playGlassClick();
                    navigator.clipboard?.writeText?.(`splender://user/${currentUserProfile.splenderId}`);
                    showToast('Deep Link Copied', `splender://user/${currentUserProfile.splenderId}`, 'info');
                  }}
                  className="flex-1 py-2.5 rounded-2xl glass-purple-glow text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-md elastic-tap"
                >
                  <Share2 className="w-3.5 h-3.5" /> Share Deep Link
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
