import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  X,
  Phone,
  Video,
  Search,
  Bell,
  Lock,
  Timer,
  ShieldCheck,
  Ban,
  Trash2,
  Share2,
  FileText,
  Image as ImageIcon,
  Link2,
  ChevronRight,
  Check,
  Download,
  ExternalLink,
  Copy,
  Maximize2,
  Film,
  CheckSquare,
  Square,
  Shield,
  UserCheck,
  Users,
  RefreshCw,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { ContactItem, Conversation, Message } from '../types';
import { GroupAdminGovernance } from '../lib/masterFeatures';
import { createDeterministicAvatarDataUri, createScenicMomentDataUri } from '../lib/firebase';

interface ContactInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  contact?: ContactItem;
  conversation?: Conversation;
  onOpenSearchInChat?: () => void;
}

export const ContactInfoModal: React.FC<ContactInfoModalProps> = ({
  isOpen,
  onClose,
  contact,
  conversation,
  onOpenSearchInChat,
}) => {
  const {
    startCall,
    blockContact,
    messages,
    setConversationDisappearingTimer,
    batchDeleteMessages,
    showToast,
    darkMode,
    currentUserProfile,
    firebaseUser,
  } = useChat();

  const [activeMediaTab, setActiveMediaTab] = useState<'media' | 'docs' | 'links'>('media');
  const [isMuted, setIsMuted] = useState(false);
  const [showTimerSelect, setShowTimerSelect] = useState(false);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [activeLightboxItem, setActiveLightboxItem] = useState<{
    url: string;
    type: 'image' | 'video';
    caption?: string;
  } | null>(null);

  const [disappearingSeconds, setDisappearingSeconds] = useState<number>(
    conversation?.disappearingTimerSeconds || 0
  );
  const [isChatLocked, setIsChatLocked] = useState(
    conversation?.isLockedWithBiometrics || false
  );
  const [onlyAdminsCanSend, setOnlyAdminsCanSend] = useState<boolean>(
    conversation?.onlyAdminsCanSend || false
  );
  const [rolesMap, setRolesMap] = useState<Record<string, 'admin' | 'moderator' | 'member'>>(
    conversation?.roles || {}
  );
  const [currentInviteCode, setCurrentInviteCode] = useState<string>(
    conversation?.inviteCode || (conversation?.id ? `inv_${conversation.id.slice(0, 8)}` : 'inv_default')
  );
  const [isCopiedInvite, setIsCopiedInvite] = useState(false);
  const [isRevokingInvite, setIsRevokingInvite] = useState(false);

  // Filter messages for this conversation
  const convId = conversation?.id;
  const convMessages = useMemo(() => {
    if (!convId) return messages;
    return messages.filter((m) => m.conversationId === convId && !m.isDeleted);
  }, [messages, convId]);

  // Categorize Media, Docs & Links
  const mediaItems = useMemo(() => {
    const list = convMessages.filter(
      (m) => (m.type === 'image' || m.type === 'video' || m.mediaUrl) && !m.isViewOnce
    );
    if (list.length > 0) return list;

    // Rich sample fallbacks if no media yet
    return [
      {
        id: 'sample-m1',
        type: 'image',
        mediaUrl: createScenicMomentDataUri('Architecture Concept', 'Shared Gallery Item', '#0F766E', '#0F172A'),
        timestamp: Date.now() - 3600000,
        senderName: contact?.displayName || 'Peer',
        text: 'Architecture Concept',
      },
      {
        id: 'sample-m2',
        type: 'image',
        mediaUrl: createScenicMomentDataUri('Abstract Visual', 'Shared Gallery Item', '#4338CA', '#1E1B4B'),
        timestamp: Date.now() - 7200000,
        senderName: contact?.displayName || 'Peer',
        text: 'Abstract Visual',
      },
      {
        id: 'sample-m3',
        type: 'image',
        mediaUrl: createScenicMomentDataUri('Design Inspiration', 'Shared Gallery Item', '#BE185D', '#1F2937'),
        timestamp: Date.now() - 10800000,
        senderName: contact?.displayName || 'Peer',
        text: 'Design Inspiration',
      },
      {
        id: 'sample-m4',
        type: 'image',
        mediaUrl: createScenicMomentDataUri('Beach Horizon', 'Shared Gallery Item', '#0369A1', '#0C4A6E'),
        timestamp: Date.now() - 14400000,
        senderName: contact?.displayName || 'Peer',
        text: 'Beach Horizon',
      },
    ] as unknown as Message[];
  }, [convMessages, contact?.displayName]);

  const docItems = useMemo(() => {
    const list = convMessages.filter(
      (m) => m.type === 'document' || m.fileName || (m.fileSize && m.mediaUrl)
    );
    if (list.length > 0) return list;

    // Curated document sample items
    return [
      {
        id: 'sample-d1',
        type: 'document',
        fileName: 'Project_Specification_v3.pdf',
        fileSize: '2.4 MB',
        mediaUrl: '#',
        timestamp: Date.now() - 5400000,
        senderName: contact?.displayName || 'Peer',
      },
      {
        id: 'sample-d2',
        type: 'document',
        fileName: 'Security_Audit_Report.docx',
        fileSize: '840 KB',
        mediaUrl: '#',
        timestamp: Date.now() - 12000000,
        senderName: contact?.displayName || 'Peer',
      },
    ] as unknown as Message[];
  }, [convMessages, contact?.displayName]);

  const linkItems = useMemo(() => {
    const list = convMessages.filter(
      (m) => m.text && (m.text.includes('http://') || m.text.includes('https://') || m.text.includes('www.'))
    );
    if (list.length > 0) return list;

    // Sample links
    return [
      {
        id: 'sample-l1',
        type: 'text',
        text: 'https://ai.google.dev - Google AI Studio Documentation & API Reference',
        timestamp: Date.now() - 8640000,
        senderName: contact?.displayName || 'Peer',
      },
      {
        id: 'sample-l2',
        type: 'text',
        text: 'https://webrtc.org - Real-Time Communication Mesh Architecture',
        timestamp: Date.now() - 18000000,
        senderName: contact?.displayName || 'Peer',
      },
    ] as unknown as Message[];
  }, [convMessages, contact?.displayName]);

  if (!isOpen) return null;

  const displayName = contact?.displayName || conversation?.groupName || 'Contact';
  const avatar =
    contact?.avatar ||
    conversation?.groupAvatar ||
    createDeterministicAvatarDataUri(displayName, '#008069');
  const bio = contact?.bio || 'Hey there! I am using SPLENDER CHAT.';
  const splenderId = contact?.splenderId || 'SP-829104';

  const timerOptions = [
    { label: 'Off', seconds: 0 },
    { label: '24 hours', seconds: 86400 },
    { label: '7 days', seconds: 604800 },
    { label: '90 days', seconds: 7776000 },
  ];

  const currentTabItems =
    activeMediaTab === 'media'
      ? mediaItems
      : activeMediaTab === 'docs'
      ? docItems
      : linkItems;

  const toggleSelectItem = (id: string) => {
    playClickSound();
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    playClickSound();
    if (selectedIds.length === currentTabItems.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(currentTabItems.map((m) => m.id));
    }
  };

  const handleBatchDownload = () => {
    playClickSound();
    selectedIds.forEach((id, idx) => {
      const item = currentTabItems.find((m) => m.id === id);
      if (item?.mediaUrl && item.mediaUrl !== '#') {
        setTimeout(() => {
          const a = document.createElement('a');
          a.href = item.mediaUrl!;
          a.download = item.fileName || `splender_file_${id}`;
          a.target = '_blank';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }, idx * 200);
      }
    });
    showToast('Download Started', `Downloading ${selectedIds.length} items`, 'success');
    setIsSelectMode(false);
    setSelectedIds([]);
  };

  const handleBatchForward = () => {
    playClickSound();
    showToast('Forwarding', `${selectedIds.length} items ready to forward to contacts`, 'info');
    setIsSelectMode(false);
    setSelectedIds([]);
  };

  const handleBatchDelete = async () => {
    playClickSound();
    if (convId) {
      await batchDeleteMessages(convId, selectedIds);
    } else {
      showToast('Deleted', `${selectedIds.length} items removed`, 'info');
    }
    setIsSelectMode(false);
    setSelectedIds([]);
  };

  const extractUrl = (text: string) => {
    const match = text.match(/(https?:\/\/[^\s]+|www\.[^\s]+)/i);
    return match ? match[0] : text;
  };

  const handleToggleOnlyAdmins = async () => {
    if (!convId) return;
    playClickSound();
    const next = !onlyAdminsCanSend;
    setOnlyAdminsCanSend(next);
    await GroupAdminGovernance.toggleAdminOnlyMessaging(convId, next);
    showToast(
      'Group Permissions Updated',
      next ? 'Only admins can now send messages' : 'All participants can send messages',
      'info'
    );
  };

  const handleUpdateRole = async (targetUid: string, role: 'admin' | 'moderator' | 'member') => {
    if (!convId) return;
    playClickSound();
    setRolesMap((prev) => ({ ...prev, [targetUid]: role }));
    await GroupAdminGovernance.updateUserRole(convId, targetUid, role);
    showToast('Role Updated', `Member role changed to ${role}`, 'success');
  };

  const handleCopyInviteLink = () => {
    if (!conversation) return;
    playClickSound();
    const url = GroupAdminGovernance.getGroupInviteUrl(conversation.id, currentInviteCode);
    navigator.clipboard.writeText(url).catch(() => {});
    setIsCopiedInvite(true);
    showToast('Invite Link Copied', url, 'success');
    setTimeout(() => setIsCopiedInvite(false), 2500);
  };

  const handleShareInviteLink = () => {
    if (!conversation) return;
    playClickSound();
    const url = GroupAdminGovernance.getGroupInviteUrl(conversation.id, currentInviteCode);
    if (navigator.share) {
      navigator.share({
        title: `Join ${conversation.groupName || 'Group'} on SPLENDER CHAT`,
        text: `Join our group chat: ${url}`,
        url,
      }).catch(() => {});
    } else {
      handleCopyInviteLink();
    }
  };

  const handleRevokeInviteLink = async () => {
    if (!conversation) return;
    playClickSound();
    const confirmed = window.confirm(
      'Revoke this invite link? The existing link will immediately stop working and a new invite link will be generated.'
    );
    if (!confirmed) return;

    setIsRevokingInvite(true);
    try {
      const newUrl = await GroupAdminGovernance.revokeInviteLink(conversation.id);
      const parts = newUrl.split('/');
      const newCode = parts[parts.length - 1];
      setCurrentInviteCode(newCode);
      showToast('Invite Link Revoked', 'Previous link is invalidated. New invite link generated.', 'info');
    } catch (err: any) {
      showToast('Revocation Failed', err.message, 'error');
    } finally {
      setIsRevokingInvite(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in select-none">
      <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-[#FFFFFF] dark:bg-[#111B21] border-t border-slate-200 dark:border-slate-800 max-h-[94vh] flex flex-col shadow-2xl modal-slide-up text-[#111B21] dark:text-[#E9EDEF] overflow-hidden">
        {/* Top Header */}
        <div className="p-3.5 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1 rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="text-sm font-bold">Contact & Media Info</span>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1 rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 p-4">
          {/* Avatar and Name Card */}
          <div className="flex flex-col items-center text-center space-y-2 pb-2">
            <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-[#008069]/20 shadow-md">
              <img src={avatar} alt={displayName} className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-lg font-bold leading-tight">{displayName}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">{splenderId}</p>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-6 pt-2">
              <button
                onClick={() => {
                  playClickSound();
                  if (contact) startCall(contact.targetUid, displayName, avatar, 'voice');
                  onClose();
                }}
                className="flex flex-col items-center gap-1 text-[#008069] dark:text-[#25D366] cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-full bg-[#E7FCE8] dark:bg-[#103629] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Phone className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-medium">Audio</span>
              </button>

              <button
                onClick={() => {
                  playClickSound();
                  if (contact) startCall(contact.targetUid, displayName, avatar, 'video');
                  onClose();
                }}
                className="flex flex-col items-center gap-1 text-[#008069] dark:text-[#25D366] cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-full bg-[#E7FCE8] dark:bg-[#103629] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Video className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-medium">Video</span>
              </button>

              <button
                onClick={() => {
                  playClickSound();
                  onClose();
                  if (onOpenSearchInChat) onOpenSearchInChat();
                }}
                className="flex flex-col items-center gap-1 text-[#008069] dark:text-[#25D366] cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-full bg-[#E7FCE8] dark:bg-[#103629] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Search className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-medium">Search</span>
              </button>
            </div>
          </div>

          {/* About / Bio section */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#1F2C34] border border-slate-200 dark:border-slate-800 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">About</span>
            <p className="text-xs font-medium leading-relaxed">{bio}</p>
          </div>

          {/* Media, Docs & Links Gallery Drawer */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#1F2C34] border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold">Media, Docs & Links Gallery</span>
                <span className="text-[10px] font-mono text-slate-400 block">
                  {currentTabItems.length} items in thread
                </span>
              </div>

              {/* Multi-Select Toggle Button */}
              <button
                onClick={() => {
                  playClickSound();
                  setIsSelectMode(!isSelectMode);
                  setSelectedIds([]);
                }}
                className={`px-3 py-1 text-xs rounded-xl font-bold cursor-pointer transition-colors ${
                  isSelectMode
                    ? 'bg-[#008069] text-white'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300'
                }`}
              >
                {isSelectMode ? 'Cancel' : 'Select'}
              </button>
            </div>

            {/* Gallery Category Tabs */}
            <div className="flex items-center gap-4 border-b border-slate-200 dark:border-slate-700 pb-1.5 text-xs font-medium">
              {(
                [
                  { id: 'media', label: `Media (${mediaItems.length})`, icon: ImageIcon },
                  { id: 'docs', label: `Docs (${docItems.length})`, icon: FileText },
                  { id: 'links', label: `Links (${linkItems.length})`, icon: Link2 },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveMediaTab(tab.id);
                      setSelectedIds([]);
                    }}
                    className={`flex items-center gap-1.5 pb-1 transition-colors cursor-pointer ${
                      activeMediaTab === tab.id
                        ? 'border-b-2 border-[#008069] text-[#008069] dark:text-[#25D366] font-bold'
                        : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* TAB CONTENT: Media (Photos & Videos Grid) */}
            {activeMediaTab === 'media' && (
              <div className="grid grid-cols-3 gap-2 pt-1 max-h-60 overflow-y-auto no-scrollbar">
                {mediaItems.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        if (isSelectMode) {
                          toggleSelectItem(item.id);
                        } else {
                          playClickSound();
                          setActiveLightboxItem({
                            url: item.mediaUrl || '',
                            type: item.type === 'video' ? 'video' : 'image',
                            caption: item.text,
                          });
                        }
                      }}
                      className={`relative aspect-square rounded-xl overflow-hidden cursor-pointer group border-2 transition-all ${
                        isSelected
                          ? 'border-[#008069] ring-2 ring-[#008069]/40 scale-95'
                          : 'border-transparent hover:opacity-90'
                      }`}
                    >
                      <img
                        src={item.mediaUrl || createScenicMomentDataUri('Shared Media', 'Gallery Item', '#0F766E', '#111827')}
                        alt=""
                        className="w-full h-full object-cover"
                      />
                      {item.type === 'video' && (
                        <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded-md bg-black/60 text-white text-[9px] font-mono flex items-center gap-1">
                          <Film className="w-2.5 h-2.5" />
                          <span>Video</span>
                        </div>
                      )}

                      {/* Select Mode Checkbox Circle */}
                      {isSelectMode && (
                        <div className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center">
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400 fill-emerald-500" />
                          ) : (
                            <Square className="w-4 h-4 text-white" />
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* TAB CONTENT: Docs (PDFs & Files List) */}
            {activeMediaTab === 'docs' && (
              <div className="space-y-2 pt-1 max-h-60 overflow-y-auto no-scrollbar">
                {docItems.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        if (isSelectMode) toggleSelectItem(item.id);
                      }}
                      className={`p-2.5 rounded-xl border flex items-center justify-between transition-colors cursor-pointer ${
                        isSelected
                          ? 'border-[#008069] bg-[#E7FCE8]/40 dark:bg-[#103629]/40'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-[#2A3942]/60 hover:bg-slate-100/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
                          <FileText className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold truncate">
                            {item.fileName || 'Encrypted_Doc.pdf'}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            {item.fileSize || '1.8 MB'} • {item.senderName}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {isSelectMode ? (
                          <div
                            className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                              isSelected ? 'border-[#008069] bg-[#008069]' : 'border-slate-400'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3 text-white" />}
                          </div>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              playClickSound();
                              if (item.mediaUrl && item.mediaUrl !== '#') {
                                const a = document.createElement('a');
                                a.href = item.mediaUrl;
                                a.download = item.fileName || 'document.pdf';
                                a.click();
                              }
                              showToast('Download', 'File downloaded to device storage', 'info');
                            }}
                            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 cursor-pointer"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* TAB CONTENT: Links (URLs List) */}
            {activeMediaTab === 'links' && (
              <div className="space-y-2 pt-1 max-h-60 overflow-y-auto no-scrollbar">
                {linkItems.map((item) => {
                  const url = extractUrl(item.text || '');
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        if (isSelectMode) toggleSelectItem(item.id);
                      }}
                      className={`p-2.5 rounded-xl border flex items-center justify-between transition-colors cursor-pointer ${
                        isSelected
                          ? 'border-[#008069] bg-[#E7FCE8]/40 dark:bg-[#103629]/40'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-[#2A3942]/60 hover:bg-slate-100/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center shrink-0">
                          <Link2 className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-blue-600 dark:text-blue-400 truncate underline">
                            {url}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate">
                            {item.text}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isSelectMode ? (
                          <div
                            className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                              isSelected ? 'border-[#008069] bg-[#008069]' : 'border-slate-400'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3 text-white" />}
                          </div>
                        ) : (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                playClickSound();
                                navigator.clipboard.writeText(url);
                                showToast('Copied', 'URL copied to clipboard', 'info');
                              }}
                              title="Copy URL"
                              className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 cursor-pointer"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={url.startsWith('http') ? url : `https://${url}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 cursor-pointer"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Multi-Select Floating Action Bar */}
            {isSelectMode && selectedIds.length > 0 && (
              <div className="p-2.5 rounded-xl bg-slate-900 text-white flex items-center justify-between shadow-xl animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold font-mono">
                    {selectedIds.length} Selected
                  </span>
                  <button
                    onClick={handleSelectAll}
                    className="text-[10px] text-emerald-400 hover:underline cursor-pointer"
                  >
                    {selectedIds.length === currentTabItems.length ? 'Clear' : 'Select All'}
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBatchDownload}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </button>
                  <button
                    onClick={handleBatchForward}
                    className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Share2 className="w-3 h-3" />
                    <span>Forward</span>
                  </button>
                  <button
                    onClick={handleBatchDelete}
                    className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Privacy & Security Features */}
          <div className="divide-y divide-slate-100 dark:divide-slate-800 rounded-2xl bg-slate-50 dark:bg-[#1F2C34] border border-slate-200 dark:border-slate-800 overflow-hidden">
            {/* Mute Notifications */}
            <div
              onClick={() => {
                playClickSound();
                setIsMuted(!isMuted);
                showToast(isMuted ? 'Unmuted' : 'Notifications Muted', undefined, 'info');
              }}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 dark:hover:bg-slate-800/40"
            >
              <div className="flex items-center gap-3">
                <Bell className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-medium">Mute notifications</span>
              </div>
              <div
                className={`w-10 h-5 rounded-full transition-colors relative ${
                  isMuted ? 'bg-[#008069]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                    isMuted ? 'left-5.5' : 'left-0.5'
                  }`}
                />
              </div>
            </div>

            {/* Disappearing Messages */}
            <div
              onClick={() => {
                playClickSound();
                setShowTimerSelect(!showTimerSelect);
              }}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 dark:hover:bg-slate-800/40"
            >
              <div className="flex items-center gap-3">
                <Timer className="w-4 h-4 text-amber-500" />
                <div>
                  <p className="text-xs font-medium">Disappearing messages</p>
                  <p className="text-[10px] text-slate-400">
                    {timerOptions.find((o) => o.seconds === disappearingSeconds)?.label || 'Off'}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            {/* Timer Options Drawer */}
            {showTimerSelect && (
              <div className="px-3.5 py-2 bg-white/60 dark:bg-slate-900/60 space-y-1">
                {timerOptions.map((opt) => (
                  <button
                    key={opt.seconds}
                    onClick={() => {
                      playClickSound();
                      setDisappearingSeconds(opt.seconds);
                      if (convId) {
                        setConversationDisappearingTimer(convId, opt.seconds);
                      }
                      setShowTimerSelect(false);
                    }}
                    className="w-full py-1.5 px-2 flex items-center justify-between text-xs hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                  >
                    <span>{opt.label}</span>
                    {disappearingSeconds === opt.seconds && (
                      <Check className="w-3.5 h-3.5 text-[#008069] dark:text-[#25D366]" />
                    )}
                  </button>
                ))}
              </div>
            )}

            {/* Chat Lock with Biometrics / PIN */}
            <div
              onClick={() => {
                playClickSound();
                const next = !isChatLocked;
                setIsChatLocked(next);
                showToast(
                  next ? 'Chat Locked' : 'Chat Unlocked',
                  next ? 'This chat requires biometric/PIN verification' : undefined,
                  'success'
                );
              }}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 dark:hover:bg-slate-800/40"
            >
              <div className="flex items-center gap-3">
                <Lock className="w-4 h-4 text-slate-500" />
                <div>
                  <p className="text-xs font-medium">Chat lock</p>
                  <p className="text-[10px] text-slate-400">Lock and hide this chat on this device</p>
                </div>
              </div>
              <div
                className={`w-10 h-5 rounded-full transition-colors relative ${
                  isChatLocked ? 'bg-[#008069]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                    isChatLocked ? 'left-5.5' : 'left-0.5'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Group Admin Governance & Permissions (When Group Chat) */}
          {conversation?.isGroup && (
            <div className="rounded-2xl bg-slate-50 dark:bg-[#1F2C34] border border-slate-200 dark:border-slate-800 p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-500" />
                  <span className="text-xs font-bold">Group Admin Governance</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {conversation.participants.length} Members
                </span>
              </div>

              {/* Only Admins Can Send Messages Toggle */}
              <div
                onClick={handleToggleOnlyAdmins}
                className="p-2.5 rounded-xl bg-white dark:bg-[#111B21] border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 dark:hover:bg-slate-800/40 transition-colors"
              >
                <div>
                  <p className="text-xs font-semibold">Send messages</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    {onlyAdminsCanSend ? 'Only admins can send' : 'All participants can send'}
                  </p>
                </div>
                <div
                  className={`w-10 h-5 rounded-full transition-colors relative ${
                    onlyAdminsCanSend ? 'bg-[#008069]' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${
                      onlyAdminsCanSend ? 'left-5.5' : 'left-0.5'
                    }`}
                  />
                </div>
              </div>

              {/* Group Invite Link Generator with Revocation Option */}
              <div className="p-3 rounded-xl bg-white dark:bg-[#111B21] border border-slate-200/80 dark:border-slate-700/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Link2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-xs font-bold">Group Invite Link</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Shareable</span>
                </div>

                <div className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <p className="text-[11px] font-mono text-slate-700 dark:text-slate-300 truncate flex-1 select-all">
                    {GroupAdminGovernance.getGroupInviteUrl(conversation.id, currentInviteCode)}
                  </p>
                  <button
                    onClick={handleCopyInviteLink}
                    className="p-1.5 rounded-md bg-emerald-500 hover:bg-emerald-600 text-white transition-all cursor-pointer shrink-0"
                    title="Copy Link"
                  >
                    {isCopiedInvite ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={handleShareInviteLink}
                    className="p-1.5 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-300 transition-all cursor-pointer shrink-0"
                    title="Share Link"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Revocation Option for Admins */}
                {(rolesMap[firebaseUser?.uid || ''] === 'admin' || conversation.groupAdminUid === firebaseUser?.uid) && (
                  <div className="flex items-center justify-between pt-1">
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Need to block unwanted joiners?
                    </p>
                    <button
                      onClick={handleRevokeInviteLink}
                      disabled={isRevokingInvite}
                      className="px-2.5 py-1 rounded-lg text-[10px] font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <RefreshCw className={`w-3 h-3 ${isRevokingInvite ? 'animate-spin' : ''}`} />
                      <span>{isRevokingInvite ? 'Revoking...' : 'Revoke Link'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Participants & Role Assignment */}
              <div className="space-y-1.5 pt-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Group Members & Roles</p>
                {conversation.participants.map((uid) => {
                  const pName = conversation.participantNames?.[uid] || (uid === firebaseUser?.uid ? 'You' : `User (${uid.slice(0, 5)})`);
                  const pAvatar = conversation.participantAvatars?.[uid] || createDeterministicAvatarDataUri(pName, '#0F766E');
                  const role = rolesMap[uid] || (conversation.groupAdminUid === uid ? 'admin' : 'member');
                  const isCurrentAdmin = rolesMap[firebaseUser?.uid || ''] === 'admin' || conversation.groupAdminUid === firebaseUser?.uid;

                  return (
                    <div
                      key={uid}
                      className="p-2 rounded-xl bg-white dark:bg-[#111B21] border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={pAvatar} alt={pName} className="w-7 h-7 rounded-full object-cover shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold truncate leading-tight">{pName}</p>
                          <span
                            className={`text-[9px] font-mono px-1 py-0.2 rounded font-bold uppercase ${
                              role === 'admin'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : role === 'moderator'
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                                : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                            }`}
                          >
                            {role}
                          </span>
                        </div>
                      </div>

                      {/* Role Promotion / Demotion Controls */}
                      {isCurrentAdmin && uid !== firebaseUser?.uid && (
                        <div className="flex items-center gap-1 shrink-0">
                          {role !== 'admin' ? (
                            <button
                              onClick={() => handleUpdateRole(uid, 'admin')}
                              className="px-2 py-0.5 rounded-lg text-[9px] font-bold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                              title="Promote to Admin"
                            >
                              Make Admin
                            </button>
                          ) : (
                            <button
                              onClick={() => handleUpdateRole(uid, 'member')}
                              className="px-2 py-0.5 rounded-lg text-[9px] font-bold bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-300 cursor-pointer"
                              title="Demote to Member"
                            >
                              Dismiss Admin
                            </button>
                          )}
                          {role !== 'moderator' && role !== 'admin' && (
                            <button
                              onClick={() => handleUpdateRole(uid, 'moderator')}
                              className="px-2 py-0.5 rounded-lg text-[9px] font-bold bg-blue-600 hover:bg-blue-500 text-white cursor-pointer"
                              title="Make Moderator"
                            >
                              Mod
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox Media Viewer Modal */}
      {activeLightboxItem && (
        <div
          onClick={() => setActiveLightboxItem(null)}
          className="fixed inset-0 z-60 bg-black/95 flex flex-col justify-between p-4 animate-in fade-in"
        >
          <div className="flex items-center justify-between text-white z-10">
            <span className="text-xs font-mono font-bold">
              {activeLightboxItem.type === 'video' ? 'Video Player' : 'Photo Viewer'}
            </span>
            <div className="flex items-center gap-3">
              <a
                href={activeLightboxItem.url}
                download="splender_media"
                target="_blank"
                rel="noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white cursor-pointer"
              >
                <Download className="w-5 h-5" />
              </a>
              <button
                onClick={() => setActiveLightboxItem(null)}
                className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center p-2 overflow-hidden">
            {activeLightboxItem.type === 'video' ? (
              <video
                src={activeLightboxItem.url}
                controls
                autoPlay
                className="max-h-[80vh] max-w-full rounded-2xl object-contain"
              />
            ) : (
              <img
                src={activeLightboxItem.url}
                alt=""
                className="max-h-[80vh] max-w-full rounded-2xl object-contain shadow-2xl"
              />
            )}
          </div>

          {activeLightboxItem.caption && (
            <div className="text-center text-white/90 text-sm font-medium py-2">
              {activeLightboxItem.caption}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
