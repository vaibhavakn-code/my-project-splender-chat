// src/components/MyEyesOnlyModal.tsx
import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  ShieldAlert,
  X,
  Plus,
  Eye,
  EyeOff,
  Image,
  FileText,
  Trash2,
  Sparkles,
} from 'lucide-react';
import { OmniChatMasterEngine, VaultSecretItem } from '../lib/omniChatEngine';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound, playCallConnectSound } from '../lib/sound';
import { createScenicMomentDataUri } from '../lib/firebase';

interface MyEyesOnlyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_VAULT_ITEMS: VaultSecretItem[] = [
  {
    id: 'vault-1',
    title: 'Biometric Recovery Seed Words',
    note: 'matrix quantum cyber cipher beacon zero horizon orbit eclipse prism sovereign',
    encryptedData: 'ENC_AES256_GCM_98a712f8...',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  },
  {
    id: 'vault-2',
    title: 'Confidential Prototype Screenshot',
    mediaUrl: createScenicMomentDataUri('Prototype Wireframe', 'Encrypted Vault Preview', '#312E81', '#0F172A'),
    note: 'Next-gen holographic UI wireframes for OmniChat super-app.',
    encryptedData: 'ENC_MEDIA_BLOB_8921a4...',
    createdAt: Date.now() - 1000 * 60 * 60 * 48,
  },
];

export const MyEyesOnlyModal: React.FC<MyEyesOnlyModalProps> = ({ isOpen, onClose }) => {
  const { darkMode, showToast } = useChat();
  const [pin, setPin] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [vaultItems, setVaultItems] = useState<VaultSecretItem[]>(DEFAULT_VAULT_ITEMS);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    playClickSound();
    if (pin.length < 6) {
      const nextPin = pin + num;
      setPin(nextPin);
      setErrorMessage('');

      if (nextPin.length === 6) {
        verifyPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    playClickSound();
    setPin((prev) => prev.slice(0, -1));
    setErrorMessage('');
  };

  const verifyPin = (enteredPin: string) => {
    const res = OmniChatMasterEngine.processUnifiedEvent({
      type: 'VAULT_VERIFY',
      payload: { pin: enteredPin },
    });

    if (res.data && res.data.verified) {
      playCallConnectSound();
      setIsUnlocked(true);
      setErrorMessage('');
      // Load current vault items from OmniChatMasterEngine
      const itemsRes = OmniChatMasterEngine.processUnifiedEvent({
        type: 'VAULT_GET_ITEMS',
        payload: {},
      });
      if (itemsRes.data && Array.isArray(itemsRes.data)) {
        setVaultItems(itemsRes.data);
      }
    } else {
      playPopSound();
      setErrorMessage('Incorrect PIN. Try 123456');
      setPin('');
    }
  };

  const handleSaveSecret = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    playPopSound();
    const newItem: VaultSecretItem = {
      id: `vault_${Date.now()}`,
      title: newTitle.trim(),
      note: newContent.trim(),
      encryptedData: `ENC_PAYLOAD_${Math.random().toString(36).substring(2, 9)}`,
      createdAt: Date.now(),
    };

    OmniChatMasterEngine.processUnifiedEvent({
      type: 'VAULT_STORE',
      payload: newItem,
    });

    setVaultItems([newItem, ...vaultItems]);
    setNewTitle('');
    setNewContent('');
    setIsAddingNote(false);

    showToast(
      'Secret Stored in My Eyes Only',
      'Your item has been AES-256 encrypted in the hardware security vault.',
      'success'
    );
  };

  const handleDeleteItem = (id: string) => {
    playClickSound();
    OmniChatMasterEngine.processUnifiedEvent({
      type: 'VAULT_DELETE_ITEM',
      payload: { id },
    });
    setVaultItems((prev) => prev.filter((i) => i.id !== id));
    showToast('Secret Deleted', 'Item permanently wiped from zero-knowledge storage.', 'info');
  };

  const handleLockAgain = () => {
    playClickSound();
    setIsUnlocked(false);
    setPin('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fade-in">
      <div className={`w-full max-w-sm rounded-3xl border shadow-2xl overflow-hidden ${darkMode ? 'bg-[#0F172A] border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}>
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-500/15 flex items-center justify-center text-emerald-500">
              {isUnlocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="text-xs font-bold tracking-tight">My Eyes Only Vault</h3>
              <p className="text-[11px] text-slate-400">Private Encrypted Vault</p>
            </div>
          </div>

          <button
            onClick={handleLockAgain}
            className="p-1 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* LOCKED STATE - PIN PAD */}
        {!isUnlocked ? (
          <div className="p-6 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mb-3">
              <Lock className="w-8 h-8 text-emerald-500 animate-pulse" />
            </div>

            <h4 className="text-sm font-bold">Enter 6-Digit Vault PIN</h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 mb-4 text-center">
              Protected with PIN access (Default PIN: 123456)
            </p>

            {/* PIN Dots */}
            <div className="flex gap-3 mb-6">
              {[0, 1, 2, 3, 4, 5].map((idx) => (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full border transition-all ${
                    idx < pin.length
                      ? 'bg-emerald-500 border-emerald-500 scale-110 shadow-sm shadow-emerald-500/50'
                      : 'border-slate-400 dark:border-slate-600 bg-transparent'
                  }`}
                />
              ))}
            </div>

            {errorMessage && (
              <p className="text-xs text-rose-500 font-bold mb-3 animate-shake">
                {errorMessage}
              </p>
            )}

            {/* 3x4 Keypad */}
            <div className="grid grid-cols-3 gap-3 w-full max-w-[220px]">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
                <button
                  key={n}
                  onClick={() => handleKeyPress(n)}
                  className={`h-12 rounded-2xl text-base font-bold font-mono border transition-all active:scale-95 ${
                    darkMode
                      ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                      : 'bg-black/5 border-black/10 hover:bg-black/10 text-black'
                  }`}
                >
                  {n}
                </button>
              ))}
              <div />
              <button
                onClick={() => handleKeyPress('0')}
                className={`h-12 rounded-2xl text-base font-bold font-mono border transition-all active:scale-95 ${
                  darkMode
                    ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                    : 'bg-black/5 border-black/10 hover:bg-black/10 text-black'
                }`}
              >
                0
              </button>
              <button
                onClick={handleBackspace}
                className="h-12 rounded-2xl text-xs font-bold border border-rose-500/20 text-rose-400 hover:bg-rose-500/10 flex items-center justify-center active:scale-95"
              >
                DEL
              </button>
            </div>
          </div>
        ) : (
          /* UNLOCKED VAULT CONTENT */
          <div className="p-4 flex flex-col max-h-[440px] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-cyan-400 font-mono">
                {vaultItems.length} Encrypted Items
              </span>
              <button
                onClick={() => setIsAddingNote(!isAddingNote)}
                className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-xl bg-[#06B6D4] text-white font-bold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Secret</span>
              </button>
            </div>

            {/* Form for adding a new secret */}
            {isAddingNote && (
              <form onSubmit={handleSaveSecret} className={`p-3 rounded-2xl border mb-3 ${darkMode ? 'bg-[#0E1422] border-cyan-500/30' : 'bg-gray-50 border-gray-300'}`}>
                <input
                  type="text"
                  placeholder="Secret Title..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-transparent text-xs font-bold outline-none mb-2"
                />
                <textarea
                  placeholder="Confidential Note or Password..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={2}
                  className="w-full bg-transparent text-xs outline-none resize-none mb-2"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingNote(false)}
                    className="px-2.5 py-1 text-[11px] text-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-cyan-500 text-white text-[11px] font-bold rounded-lg"
                  >
                    Encrypt & Save
                  </button>
                </div>
              </form>
            )}

            {/* List of items */}
            <div className="space-y-2.5">
              {vaultItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-2xl border flex flex-col gap-2 ${darkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200'}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      {item.mediaUrl ? <Image className="w-3.5 h-3.5 text-[#D4AF37]" /> : <FileText className="w-3.5 h-3.5 text-cyan-400" />}
                      <span>{item.title}</span>
                    </div>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-gray-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {item.mediaUrl && (
                    <div className="rounded-xl overflow-hidden max-h-36 border border-black/20">
                      <img src={item.mediaUrl} alt="Vault Media" className="w-full h-full object-cover" />
                    </div>
                  )}

                  {item.note && (
                    <p className="text-[11px] text-gray-300 font-mono leading-relaxed bg-black/30 p-2 rounded-lg break-all">
                      {item.note}
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[9px] text-gray-400 font-mono">
                    <span>{item.encryptedData.slice(0, 16)}...</span>
                    <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
