import React from 'react';
import { MessageSquare, CircleDashed, Phone, Settings } from 'lucide-react';
import { playClickSound } from '../lib/sound';
import { useChat } from '../context/ChatContext';
import { NavigationTab } from '../types';

export type TabType = 'chats' | 'updates' | 'calls' | 'settings';

export interface BottomNavBarProps {
  activeTab?: NavigationTab | TabType;
  setActiveTab?: (tab: any) => void;
  unreadCount?: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab: propActiveTab,
  setActiveTab: propSetActiveTab,
  unreadCount: propUnreadCount,
}) => {
  const chatContext = useChat();

  const totalUnread =
    propUnreadCount !== undefined
      ? propUnreadCount
      : chatContext.conversations.reduce((acc, c) => {
          if (!chatContext.firebaseUser) return acc;
          return acc + (c.unreadCounts?.[chatContext.firebaseUser.uid] || 0);
        }, 0);

  const rawTab = propActiveTab || chatContext.activeTab;

  const activeTab: TabType = chatContext.isSettingsModalOpen
    ? 'settings'
    : rawTab === 'calls'
    ? 'calls'
    : rawTab === 'stories' || rawTab === 'updates' || (rawTab as any) === 'moments'
    ? 'updates'
    : 'chats';

  const handleTabClick = (tabId: TabType) => {
    playClickSound();
    if (tabId === 'settings') {
      chatContext.setIsSettingsModalOpen(true);
      return;
    }
    chatContext.setIsSettingsModalOpen(false);
    if (propSetActiveTab) {
      propSetActiveTab(tabId);
    } else {
      chatContext.setActiveTab(tabId as any);
    }
  };

  const tabs: { id: TabType; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'chats', label: chatContext.t('chats') || 'Chats', icon: MessageSquare, badge: totalUnread },
    { id: 'updates', label: 'Moments', icon: CircleDashed },
    { id: 'calls', label: 'Calls', icon: Phone },
    { id: 'settings', label: chatContext.t('settings') || 'Settings', icon: Settings },
  ];

  return (
    <nav className="shrink-0 z-30 w-full h-[50px] lg:h-[56px] px-2 bg-white/92 dark:bg-[#080B14]/92 backdrop-blur-xl border-t border-slate-200/80 dark:border-[#293650]/85 select-none">
      <div className="grid grid-cols-4 items-center h-full max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              data-testid={`tab-${tab.id}`}
              onClick={() => handleTabClick(tab.id)}
              className={`relative min-h-[44px] flex flex-col items-center justify-center px-1 transition-colors duration-150 cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'text-[#3B82F6] dark:text-[#22D3EE] font-semibold'
                  : 'text-slate-500 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF]'
              }`}
            >
              <div
                className={`relative flex items-center justify-center px-3.5 py-0.5 rounded-full transition-colors ${
                  isActive
                    ? 'bg-[#3B82F6]/12 dark:bg-gradient-to-r dark:from-[#22D3EE]/16 dark:to-[#8B5CF6]/18'
                    : ''
                }`}
              >
                <Icon className={`w-[19px] h-[19px] ${isActive ? 'stroke-[2.4px]' : 'stroke-[1.9px]'}`} />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-1 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-[#F4F7FF] text-[10px] font-bold px-1.5 rounded-full min-w-[17px] text-center font-mono tabular-nums shadow-xs">
                    {tab.badge > 99 ? '99+' : tab.badge}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight whitespace-nowrap truncate max-w-full">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
