import React from 'react';
import { Star, X, MessageSquare, ArrowRight } from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';

interface StarredMessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StarredMessagesModal: React.FC<StarredMessagesModalProps> = ({ isOpen, onClose }) => {
  const { messages, conversations, setActiveConversationId, firebaseUser } = useChat();

  if (!isOpen) return null;

  // Filter messages that have been starred by current user
  const starredMessages = messages.filter((m) => {
    if (!firebaseUser) return false;
    return m.starred?.[firebaseUser.uid] || false;
  });

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in select-none">
      <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-[#FFFFFF] dark:bg-[#111B21] border-t border-slate-200 dark:border-slate-800 p-4 max-h-[85vh] flex flex-col shadow-2xl modal-slide-up text-[#111B21] dark:text-[#E9EDEF]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <h3 className="text-sm font-bold">Starred Messages</h3>
            <span className="text-[11px] font-mono text-slate-400">({starredMessages.length})</span>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto no-scrollbar py-3 space-y-2.5">
          {starredMessages.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-2 text-slate-400">
              <Star className="w-10 h-10 stroke-1" />
              <p className="text-xs font-medium">No starred messages yet</p>
              <p className="text-[11px] max-w-xs leading-relaxed text-slate-500">
                Tap and hold any message in a chat and tap the Star icon to easily find it here later.
              </p>
            </div>
          ) : (
            starredMessages.map((msg) => (
              <div
                key={msg.id}
                onClick={() => {
                  playClickSound();
                  setActiveConversationId(msg.conversationId);
                  onClose();
                }}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#F0F2F5] dark:bg-[#202C33] hover:border-[#008069] transition-colors cursor-pointer space-y-1.5"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#008069] dark:text-[#25D366]">{msg.senderName}</span>
                  <span className="text-slate-400 font-mono">
                    {new Date(msg.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                <p className="text-xs text-[#111B21] dark:text-[#E9EDEF] leading-relaxed">
                  {msg.text}
                </p>
                <div className="flex items-center justify-end text-[10px] text-slate-400 gap-1">
                  <span>Go to chat</span>
                  <ArrowRight className="w-3 h-3" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
