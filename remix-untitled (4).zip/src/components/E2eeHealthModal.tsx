import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  X,
  Lock,
  RefreshCw,
  Copy,
  Check,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { CryptoService } from '../services/CryptoService';
import { P2PCryptoEngine } from '../lib/p2pSecurity';
import { db, doc, getDoc, auth } from '../lib/firebase';
import { playClickSound, playPopSound } from '../lib/sound';

export const E2eeHealthModal: React.FC = () => {
  const {
    isE2eeHealthModalOpen,
    setIsE2eeHealthModalOpen,
    activeConversation,
    messages,
    firebaseUser,
    showToast,
  } = useChat();

  const [safetyFingerprint, setSafetyFingerprint] = useState<string>('Computing SHA-256 safety number…');
  const [keyFingerprint, setKeyFingerprint] = useState<string>('');
  const [ratchetCount, setRatchetCount] = useState<number>(1);
  const [isRotating, setIsRotating] = useState(false);
  const [copiedFingerprint, setCopiedFingerprint] = useState(false);

  useEffect(() => {
    if (!isE2eeHealthModalOpen) return;
    let cancelled = false;

    const loadLiveIdentity = async () => {
      try {
        const localIdentity = await CryptoService.getOrCreateRsaIdentity();
        if (cancelled) return;
        setKeyFingerprint(localIdentity.fingerprintHex.slice(0, 16));

        const myUid = firebaseUser?.uid || auth.currentUser?.uid || 'local_device';
        const peerUid =
          activeConversation?.participants.find((p) => p !== myUid) ||
          activeConversation?.id ||
          'self_vault';

        let peerKeyMaterial = peerUid;
        if (
          auth.currentUser &&
          peerUid !== 'self_vault' &&
          typeof navigator !== 'undefined' &&
          navigator.onLine
        ) {
          try {
            const peerSnap = await getDoc(doc(db, 'users', peerUid));
            const remotePub = peerSnap.exists() ? peerSnap.data()?.publicKey : null;
            if (typeof remotePub === 'string' && remotePub.length >= 64) {
              peerKeyMaterial = remotePub;
              CryptoService.registerPeerPublicKey(peerUid, remotePub);
            }
          } catch {
            // Offline fallback uses canonical peer UID + local SPKI key
          }
        }

        const sixtyDigitNumber = await P2PCryptoEngine.generateSafetyFingerprint(
          localIdentity.publicKeySpkiBase64,
          peerKeyMaterial
        );
        if (!cancelled) {
          setSafetyFingerprint(sixtyDigitNumber);
          const msgCount = messages.length || 1;
          setRatchetCount(Math.max(1, msgCount));
        }
      } catch {
        if (!cancelled) {
          const fallbackSafety = await P2PCryptoEngine.generateSafetyFingerprint(
            firebaseUser?.uid || 'local_identity',
            activeConversation?.id || 'peer_identity'
          );
          if (!cancelled) {
            setSafetyFingerprint(fallbackSafety);
          }
        }
      }
    };

    void loadLiveIdentity();
    return () => {
      cancelled = true;
    };
  }, [isE2eeHealthModalOpen, activeConversation, messages.length, firebaseUser]);

  if (!isE2eeHealthModalOpen) return null;

  const handleRotateKeys = async () => {
    playClickSound();
    setIsRotating(true);
    try {
      const targetConvId = activeConversation?.id || 'global_self_vault';
      const rotated = await CryptoService.rotateConversationSessionKey(targetConvId);
      setKeyFingerprint(rotated.keyFingerprint);
      setRatchetCount((prev) => prev + 1);
      playPopSound();
      showToast(
        'Session Root Rotated',
        `New 256-bit key sealed in KeyVault (${rotated.keyFingerprint.slice(0, 8)}…)`,
        'success'
      );
    } catch {
      showToast('Key Rotation Error', 'Unable to rotate local session key', 'error');
    } finally {
      setIsRotating(false);
    }
  };

  const handleCopyFingerprint = () => {
    playPopSound();
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      void navigator.clipboard.writeText(safetyFingerprint);
    }
    setCopiedFingerprint(true);
    showToast('Safety Number Copied', '60-digit SHA-256 safety number copied', 'info');
    setTimeout(() => setCopiedFingerprint(false), 2000);
  };

  return (
    <div
      onClick={() => setIsE2eeHealthModalOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden modal-slide-up text-slate-800 dark:text-slate-100 flex flex-col"
      >
        <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold leading-tight">End-to-End Encryption</h3>
              <p className="text-[10px] text-white/80">Hybrid RSA-OAEP-2048 & HKDF Ratchet</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              setIsE2eeHealthModalOpen(false);
            }}
            aria-label="Close encryption verification modal"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-3.5 text-xs">
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block">
                Non-Extractable Hardware / IndexedDB Vault
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate font-mono tabular-nums">
                Key ID: {keyFingerprint || 'initializing…'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                Payload Cipher
              </span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-100">
                AES-256-GCM
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                Key Wrapping
              </span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-100">
                RSA-OAEP-2048
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                Step Ratchet
              </span>
              <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                HKDF-SHA256
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                Chain Counter
              </span>
              <span className="font-mono tabular-nums font-bold text-indigo-600 dark:text-indigo-400">
                Step #{ratchetCount}
              </span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                60-Digit Safety Number (SHA-256)
              </span>
              <button
                onClick={handleCopyFingerprint}
                className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copiedFingerprint ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedFingerprint ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="font-mono tabular-nums text-center tracking-wider text-xs font-bold text-slate-700 dark:text-slate-200 py-2 px-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 leading-relaxed">
              {safetyFingerprint}
            </p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 text-center">
              Compare these 12 five-digit blocks out-of-band with your peer to verify identity keys.
            </p>
          </div>

          <button
            onClick={handleRotateKeys}
            disabled={isRotating}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm whitespace-nowrap"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
            <span>{isRotating ? 'Rotating Session Key…' : 'Rotate 256-Bit Session Key'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

