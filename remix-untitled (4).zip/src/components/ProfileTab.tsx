import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Settings,
  Shield,
  Key,
  QrCode,
  Lock,
  Copy,
  Check,
  Sliders,
  Edit2,
  Link as LinkIcon,
  Wifi,
  LogOut,
  Sparkles,
  Eye,
  CheckCheck,
  Ban,
  Bell,
  Volume2,
  VolumeX,
  Vibrate,
  Image as ImageIcon,
  Palette,
  Smartphone,
  User,
  Radio,
  Download,
  Trash2,
  Flame,
  Coins,
  Award,
  AlertTriangle,
  Moon,
  Sun,
  ShieldAlert,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { sound, playClickSound, isSoundEnabled, setSoundEnabled, isHapticsEnabled, setHapticsEnabled, triggerHeartHaptic } from '../lib/sound';
import { MEDIA_QUALITY_OPTIONS } from '../lib/compression';
import {
  getRewardsProfile,
  claimDailyStreak,
  unlockRewardItem,
  REWARD_THEMES,
  REWARD_BADGES,
} from '../lib/rewards';

export type SettingsCategory = 'privacy' | 'notifications' | 'chat_media' | 'account';

export const ProfileTab: React.FC = () => {
  const {
    currentUserProfile,
    firebaseUser,
    updateProfile,
    linkGoogleAccount,
    linkEmailAccount,
    signOutUser,
    deleteAccountAndWipeData,
    lockApp,
    setIsQrScannerOpen,
    setIsIdentityModalOpen,
    setIsPrivacySettingsModalOpen,
    setIsSettingsModalOpen,
    toggleDataSaver,
    mediaQuality,
    setMediaQuality,
    showToast,
    activeTab,
    contacts,
    unblockContact,
    networkStatus,
    darkMode,
    toggleDarkMode,
  } = useChat();

  // Top sub-view switcher: 'settings' or 'identity'
  const [viewMode, setViewMode] = useState<'settings' | 'identity'>(() =>
    (activeTab as string) === 'profile' || (activeTab as any) === 'identity' ? 'identity' : 'settings'
  );

  useEffect(() => {
    if (activeTab === 'settings') {
      setViewMode('settings');
    } else if ((activeTab as string) === 'profile' || (activeTab as any) === 'identity') {
      setViewMode('identity');
    }
  }, [activeTab]);

  // Consolidated 4-Category state
  const [activeCategory, setActiveCategory] = useState<SettingsCategory>('privacy');
  const [soundOn, setSoundOn] = useState(() => isSoundEnabled());
  const [hapticsOn, setHapticsOn] = useState(() => isHapticsEnabled());
  const [autoDownload, setAutoDownload] = useState<'always' | 'wifi' | 'never'>(() => {
    return (localStorage.getItem('splender_auto_download') as any) || 'always';
  });
  const [globalWallpaper, setGlobalWallpaper] = useState<string>(() => {
    return localStorage.getItem('splender_global_wallpaper') || 'soft_ivory';
  });
  const [storyVisibility, setStoryVisibility] = useState<'everyone' | 'contacts'>(() => {
    return (localStorage.getItem('splender_story_visibility') as any) || 'everyone';
  });
  const [antiScreenshot, setAntiScreenshot] = useState<boolean>(() => {
    return localStorage.getItem('splender_anti_screenshot') === 'true';
  });

  // Rewards Profile State
  const [rewardsProfile, setRewardsProfile] = useState(() => getRewardsProfile());
  const [streakClaimedToday, setStreakClaimedToday] = useState(() => {
    const p = getRewardsProfile();
    return p.lastClaimDate === new Date().toISOString().slice(0, 10);
  });

  // Account Deletion State
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Identity / Profile editing state
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [displayNameInput, setDisplayNameInput] = useState(currentUserProfile?.displayName || '');
  const [usernameInput, setUsernameInput] = useState(currentUserProfile?.username || '');
  const [bioInput, setBioInput] = useState(currentUserProfile?.bio || '');

  // Account linking state
  const [showLinkEmail, setShowLinkEmail] = useState(false);
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isLinking, setIsLinking] = useState(false);

  if (!currentUserProfile) return null;

  const blockedContacts = contacts.filter((c) => c.state === 'blocked');

  const handleCopyNumber = () => {
    playClickSound();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentUserProfile.splenderId);
      setCopiedNumber(true);
      showToast('Copied Splender ID', currentUserProfile.splenderId, 'success');
      setTimeout(() => setCopiedNumber(false), 2000);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    await updateProfile({
      displayName: displayNameInput.trim() || currentUserProfile.displayName,
      username: usernameInput.trim() || currentUserProfile.username,
      bio: bioInput.trim() || currentUserProfile.bio,
    });
    setIsEditingProfile(false);
    showToast('Profile Updated', 'Identity credentials synchronized', 'success');
  };

  const handleEmailLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim() || !passwordInput.trim()) return;
    playClickSound();
    setIsLinking(true);
    try {
      const ok = await linkEmailAccount(emailInput.trim(), passwordInput.trim());
      if (ok) {
        setShowLinkEmail(false);
        setEmailInput('');
        setPasswordInput('');
      }
    } finally {
      setIsLinking(false);
    }
  };

  const handleToggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    setSoundEnabled(next);
    if (next) playClickSound();
  };

  const handleToggleHaptics = () => {
    const next = !hapticsOn;
    setHapticsOn(next);
    setHapticsEnabled(next);
    playClickSound();
    if (next) triggerHeartHaptic();
  };

  const handleSelectWallpaper = (preset: string) => {
    playClickSound();
    setGlobalWallpaper(preset);
    localStorage.setItem('splender_global_wallpaper', preset);
    showToast('Wallpaper Updated', `Applied default ${preset} wallpaper`, 'success');
  };

  const handleSelectAutoDownload = (setting: 'always' | 'wifi' | 'never') => {
    playClickSound();
    setAutoDownload(setting);
    localStorage.setItem('splender_auto_download', setting);
    showToast('Media Limit Updated', `Auto-download set to ${setting}`, 'info');
  };

  const handleSelectStoryVisibility = (vis: 'everyone' | 'contacts') => {
    playClickSound();
    setStoryVisibility(vis);
    localStorage.setItem('splender_story_visibility', vis);
    showToast('Story Privacy', `Visibility set to ${vis}`, 'info');
  };

  const handleClaimStreak = () => {
    playClickSound();
    triggerHeartHaptic();
    const result = claimDailyStreak();
    if (result.success) {
      setRewardsProfile(getRewardsProfile());
      setStreakClaimedToday(true);
      showToast('Daily Streak Claimed! 🔥', `Earned +${result.coinsAwarded} Splender Coins!`, 'success');
    } else {
      showToast('Streak Already Claimed', 'Come back tomorrow to keep the flame burning!', 'info');
    }
  };

  const handlePermanentDeletion = async () => {
    playClickSound();
    setIsDeleting(true);
    try {
      const success = await deleteAccountAndWipeData();
      if (!success) {
        showToast('Deletion Failed', 'Unable to complete full data wipe. Check connection.', 'error');
        setIsDeleting(false);
      }
    } catch {
      showToast('Deletion Failed', 'Error removing cloud credentials.', 'error');
      setIsDeleting(false);
    }
  };

  return (
    <div className={`flex-1 flex flex-col overflow-y-auto ${darkMode ? 'bg-[#0F0F14] text-gray-100' : 'bg-[#EFEAD8] text-[#2B2533]'} p-3.5 space-y-3.5 no-scrollbar transition-colors duration-200 select-none pb-24`}>
      {/* Top 3D Header with Fast Sun/Moon Toggle & Mode Switcher */}
      <div className="pt-1 shrink-0 z-20 space-y-2.5">
        <div className="glass-3d-panel rounded-2xl px-4 py-2.5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl glass-purple-glow flex items-center justify-center text-white shadow-xs">
              {viewMode === 'settings' ? <Settings className="w-4 h-4" /> : <User className="w-4 h-4" />}
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight leading-tight">
                {viewMode === 'settings' ? 'Settings Hub' : 'Identity Profile'}
              </h1>
              <p className="text-[10px] text-[#6B6275] dark:text-gray-400 font-mono">
                {viewMode === 'settings' ? 'Consolidated 4-Category Configuration' : 'Keys, Sovereign Splender ID & Credentials'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* One-Tap Fast Theme Toggle (Sun/Moon) */}
            <button
              onClick={() => {
                playClickSound();
                toggleDarkMode();
              }}
              className="p-2 rounded-xl glass-pod-ivory hover:border-[#7C5C9B]/40 text-[#7C5C9B] dark:text-purple-300 transition-all cursor-pointer elastic-tap shadow-xs"
              title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Quick Lock */}
            <button
              onClick={() => {
                playClickSound();
                lockApp();
              }}
              title="Lock Application"
              className="p-2 rounded-xl glass-pod-ivory hover:border-[#7C5C9B]/40 text-[#7C5C9B] dark:text-purple-300 transition-all cursor-pointer elastic-tap shadow-xs"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* View Mode Segment Switcher */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl glass-pod-ivory shadow-xs">
          <button
            onClick={() => {
              playClickSound();
              setViewMode('settings');
            }}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              viewMode === 'settings'
                ? 'glass-purple-glow text-white shadow-xs'
                : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Settings Hub</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setViewMode('identity');
            }}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              viewMode === 'identity'
                ? 'glass-purple-glow text-white shadow-xs'
                : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Identity & Keys</span>
          </button>
        </div>
      </div>

      {/* ==============================================================
          MODE 1: CONSOLIDATED 4-CATEGORY SETTINGS HUB
      ============================================================== */}
      {viewMode === 'settings' && (
        <div data-testid="settings-hub-container" className="space-y-3.5 animate-in fade-in duration-200">
          {/* 4-Category Segment Navigation */}
          <div className="grid grid-cols-4 gap-1 p-1 rounded-2xl glass-pod-ivory shadow-xs">
            <button
              onClick={() => {
                playClickSound();
                setActiveCategory('privacy');
              }}
              className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                activeCategory === 'privacy'
                  ? 'glass-purple-glow text-white shadow-xs'
                  : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Privacy</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveCategory('notifications');
              }}
              className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                activeCategory === 'notifications'
                  ? 'glass-purple-glow text-white shadow-xs'
                  : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Sounds</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveCategory('chat_media');
              }}
              className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                activeCategory === 'chat_media'
                  ? 'glass-purple-glow text-white shadow-xs'
                  : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Media</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveCategory('account');
              }}
              className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                activeCategory === 'account'
                  ? 'glass-purple-glow text-white shadow-xs'
                  : 'text-[#6B6275] dark:text-gray-400 hover:text-[#2B2533] dark:hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Account</span>
            </button>
          </div>

          {/* ==============================================================
              CATEGORY 1: PRIVACY & SECURITY
          ============================================================== */}
          {activeCategory === 'privacy' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* Anti-Screenshot Guard Overlay */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  <ShieldAlert className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <div>
                    <p className="text-xs font-bold">Anti-Screenshot Guard</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Blur sensitive message bubbles during capture</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    playClickSound();
                    const next = !antiScreenshot;
                    setAntiScreenshot(next);
                    localStorage.setItem('splender_anti_screenshot', String(next));
                    showToast('Anti-Screenshot Guard', next ? 'Protection activated' : 'Protection disabled', 'info');
                  }}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    antiScreenshot ? 'glass-purple-glow' : 'bg-[#D8D0BA] dark:bg-gray-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 shadow transition-transform ${
                      antiScreenshot ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Biometric & 6-Digit PIN App Lock */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  <Lock className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <div>
                    <p className="text-xs font-bold">Biometric & PIN Lock</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Lock application immediately with WebAuthn/PIN</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    playClickSound();
                    lockApp();
                  }}
                  className="px-3 py-1.5 rounded-xl glass-purple-glow text-white font-bold text-[11px] shadow-xs cursor-pointer"
                >
                  Lock Now
                </button>
              </div>

              {/* Online Presence */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <Eye className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <span>Online & Active Presence</span>
                </div>
                <p className="text-[11px] text-[#6B6275] dark:text-gray-400">
                  Control who sees your active status and timestamp across chats:
                </p>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                    <button
                      key={opt}
                      onClick={() => {
                        playClickSound();
                        updateProfile({ lastSeenPrivacy: opt });
                      }}
                      className={`py-2 rounded-xl text-xs capitalize transition-all cursor-pointer font-semibold ${
                        currentUserProfile.lastSeenPrivacy === opt
                          ? 'glass-purple-glow text-white shadow-xs'
                          : 'bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Read Receipts */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  <CheckCheck className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <div>
                    <p className="text-xs font-bold">Read Receipts</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Show double ticks when messages are read</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    playClickSound();
                    updateProfile({ readReceipts: !currentUserProfile.readReceipts });
                  }}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    currentUserProfile.readReceipts ? 'glass-purple-glow' : 'bg-[#D8D0BA] dark:bg-gray-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 shadow transition-transform ${
                      currentUserProfile.readReceipts ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Stories & Moments Visibility */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <Radio className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <span>Story & Moment Visibility</span>
                </div>
                <p className="text-[11px] text-[#6B6275] dark:text-gray-400">
                  Audience for ephemeral 24-hour video and photo posts:
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => handleSelectStoryVisibility('everyone')}
                    className={`py-2 rounded-xl text-xs transition-all cursor-pointer font-semibold ${
                      storyVisibility === 'everyone'
                        ? 'glass-purple-glow text-white shadow-xs'
                        : 'bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white'
                    }`}
                  >
                    Everyone (Public)
                  </button>
                  <button
                    onClick={() => handleSelectStoryVisibility('contacts')}
                    className={`py-2 rounded-xl text-xs transition-all cursor-pointer font-semibold ${
                      storyVisibility === 'contacts'
                        ? 'glass-purple-glow text-white shadow-xs'
                        : 'bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white'
                    }`}
                  >
                    Contacts Only
                  </button>
                </div>
              </div>

              {/* Blocked Peers */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center justify-between text-xs font-bold">
                  <div className="flex items-center gap-2">
                    <Ban className="w-4 h-4 text-rose-500" />
                    <span>Blocked Peers ({blockedContacts.length})</span>
                  </div>
                </div>
                {blockedContacts.length === 0 ? (
                  <p className="text-[11px] text-[#6B6275] dark:text-gray-400">No peers currently blocked.</p>
                ) : (
                  <div className="space-y-1.5 pt-1">
                    {blockedContacts.map((contact) => (
                      <div
                        key={contact.targetUid}
                        className="flex items-center justify-between p-2 rounded-xl bg-white/40 dark:bg-white/5 border border-white/60 dark:border-white/10"
                      >
                        <div className="flex items-center gap-2">
                          <img
                            src={contact.avatar}
                            alt={contact.displayName}
                            className="w-7 h-7 rounded-full object-cover"
                          />
                          <div>
                            <p className="text-xs font-bold">{contact.displayName}</p>
                            <p className="text-[9px] font-mono text-[#6B6275] dark:text-gray-400">{contact.splenderId}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            playClickSound();
                            unblockContact(contact.targetUid);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400 text-[10px] font-bold cursor-pointer"
                        >
                          Unblock
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ==============================================================
              CATEGORY 2: NOTIFICATIONS & SOUNDS
          ============================================================== */}
          {activeCategory === 'notifications' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* Tactile Audio Feedback */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  {soundOn ? (
                    <Volume2 className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-[#6B6275] dark:text-gray-400" />
                  )}
                  <div>
                    <p className="text-xs font-bold">Tactile Glass Audio Feedback</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Audible synthesized glass clicks on explicit taps</p>
                  </div>
                </div>
                <button
                  onClick={handleToggleSound}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    soundOn ? 'glass-purple-glow' : 'bg-[#D8D0BA] dark:bg-gray-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 shadow transition-transform ${
                      soundOn ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Zero-Noise Haptic Feedback Engine */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  <Vibrate className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <div>
                    <p className="text-xs font-bold">Zero-Noise Haptic Engine</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">160ms duplicate event guard & soft double-pulse</p>
                  </div>
                </div>
                <button
                  onClick={handleToggleHaptics}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    hapticsOn ? 'glass-purple-glow' : 'bg-[#D8D0BA] dark:bg-gray-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 shadow transition-transform ${
                      hapticsOn ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Call Ringtone Selector */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <Bell className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <span>WebRTC Incoming Call Tone</span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {['cyber_pulse', 'velvet_chime', 'crystal_ping'].map((tone) => (
                    <button
                      key={tone}
                      onClick={() => {
                        playClickSound();
                        showToast('Ringtone Preview', `Set active melody to ${tone}`, 'info');
                      }}
                      className="py-2 rounded-xl text-xs capitalize bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white font-semibold cursor-pointer"
                    >
                      {tone.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==============================================================
              CATEGORY 3: CHAT & MEDIA
          ============================================================== */}
          {activeCategory === 'chat_media' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* One-Tap Fast Theme Toggle (Sun/Moon Cyber Dark) */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory flex items-center justify-between border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-3">
                  {darkMode ? (
                    <Moon className="w-4 h-4 text-purple-400" />
                  ) : (
                    <Sun className="w-4 h-4 text-amber-500" />
                  )}
                  <div>
                    <p className="text-xs font-bold">Cyber Dark Dual-Theme Engine</p>
                    <p className="text-[10px] text-[#6B6275] dark:text-gray-400">
                      {darkMode ? '#0F0F14 deep cyber dark with ambient halos' : 'Warm ivory frosted glassmorphism'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    playClickSound();
                    toggleDarkMode();
                  }}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    darkMode ? 'glass-purple-glow' : 'bg-[#D8D0BA] dark:bg-gray-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 shadow transition-transform ${
                      darkMode ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Compression Quality */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold">
                    <Sliders className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                    <span>Media Compression Quality</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full glass-pod-purple-subtle font-bold">
                    {MEDIA_QUALITY_OPTIONS.find((o) => o.id === (mediaQuality || 'high'))?.badge || 'HQ'}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {MEDIA_QUALITY_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => {
                        playClickSound();
                        setMediaQuality(opt.id);
                        showToast('Quality Updated', `Set media compression to ${opt.label}`, 'success');
                      }}
                      className={`p-2 rounded-xl text-left border cursor-pointer transition-all ${
                        mediaQuality === opt.id
                          ? 'glass-purple-glow text-white shadow-xs'
                          : 'bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white'
                      }`}
                    >
                      <p className="text-xs font-bold leading-tight">{opt.label}</p>
                      <p className={`text-[9px] mt-0.5 opacity-80`}>{opt.badge}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat Wallpaper Presets */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <Palette className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <span>Default Chat Wallpaper</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {[
                    { id: 'soft_ivory', name: 'Soft Ivory', color: '#EFEAD8' },
                    { id: 'pistachio_mist', name: 'Pistachio Mist', color: '#DCE7CF' },
                    { id: 'lavender_glass', name: 'Lavender Glass', color: '#E2DAEB' },
                    { id: 'midnight_obsidian', name: 'Midnight', color: '#0F0F14' },
                  ].map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => handleSelectWallpaper(preset.id)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                        globalWallpaper === preset.id
                          ? 'bg-white/80 dark:bg-white/15 border-[#7C5C9B] shadow-xs'
                          : 'bg-white/30 dark:bg-white/5 border-white/60 dark:border-white/10 hover:bg-white/50 dark:hover:bg-white/10'
                      }`}
                    >
                      <div
                        className="w-5 h-5 rounded-full border border-black/10 shrink-0"
                        style={{ backgroundColor: preset.color }}
                      />
                      <span className="text-xs font-semibold">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Cellular Auto-Download */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <Download className="w-4 h-4 text-[#7C5C9B] dark:text-purple-400" />
                  <span>Cellular Auto-Download Limits</span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {[
                    { id: 'always', label: 'Always' },
                    { id: 'wifi', label: 'Wi-Fi Only' },
                    { id: 'never', label: 'Manual' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSelectAutoDownload(item.id as any)}
                      className={`py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        autoDownload === item.id
                          ? 'glass-purple-glow text-white shadow-xs'
                          : 'bg-white/50 dark:bg-white/5 text-[#6B6275] dark:text-gray-300 border border-white/80 dark:border-white/10 hover:text-[#2B2533] dark:hover:text-white'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==============================================================
              CATEGORY 4: ACCOUNT CREDENTIALS & DELETION
          ============================================================== */}
          {activeCategory === 'account' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* Splender Rewards Engine Status */}
              <div className="p-4 rounded-2xl glass-pod-ivory border border-white/80 dark:border-white/10 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
                      <Flame className="w-4 h-4 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider">Splender Rewards Engine</h4>
                      <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Daily streaks & gamified reward coins</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-600 dark:text-amber-400 font-mono font-bold text-xs">
                    <Coins className="w-3.5 h-3.5" />
                    <span>{rewardsProfile.coins}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="p-2.5 rounded-xl bg-white/40 dark:bg-white/5 border border-white/60 dark:border-white/10">
                    <span className="text-[10px] text-[#6B6275] dark:text-gray-400 block">Current Streak</span>
                    <span className="text-sm font-black text-[#7C5C9B] dark:text-purple-300">
                      {rewardsProfile.streakDays} Day{rewardsProfile.streakDays !== 1 ? 's' : ''} 🔥
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/40 dark:bg-white/5 border border-white/60 dark:border-white/10">
                    <span className="text-[10px] text-[#6B6275] dark:text-gray-400 block">Badges Unlocked</span>
                    <span className="text-sm font-black text-[#7C5C9B] dark:text-purple-300">
                      {rewardsProfile.unlockedBadges.length} Badge{rewardsProfile.unlockedBadges.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleClaimStreak}
                  disabled={streakClaimedToday}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer elastic-tap shadow-sm ${
                    streakClaimedToday
                      ? 'bg-white/40 dark:bg-white/5 text-[#6B6275] dark:text-gray-400 cursor-not-allowed border border-white/60 dark:border-white/10'
                      : 'glass-purple-glow text-white shadow-purple-500/30'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5 text-amber-300" />
                  <span>{streakClaimedToday ? 'Daily Streak Claimed Today' : 'Claim Daily Streak Reward (+15 Coins)'}</span>
                </button>
              </div>

              {/* Account Security & Identity Badges */}
              <div className="p-3.5 rounded-2xl glass-pod-ivory space-y-2 border border-white/80 dark:border-white/10 shadow-xs">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-[11px] uppercase tracking-wider text-[#6B6275] dark:text-gray-400">Node Status</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                    Connected • {networkStatus}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-[11px] text-[#6B6275] dark:text-gray-400">Account Type</span>
                  <span className="font-mono text-xs font-bold">
                    {currentUserProfile.isAnonymous ? 'Anonymous Node' : 'Permanent Verified Node'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[11px] text-[#6B6275] dark:text-gray-400">Splender ID</span>
                  <span className="font-mono text-xs font-bold text-[#7C5C9B] dark:text-purple-300">
                    {currentUserProfile.splenderId}
                  </span>
                </div>
              </div>

              {/* Sign Out Node */}
              <button
                onClick={() => {
                  playClickSound();
                  signOutUser();
                }}
                className="w-full p-3 rounded-2xl glass-pod-ivory hover:border-amber-400 text-amber-600 dark:text-amber-400 flex items-center justify-center gap-2 text-xs font-bold cursor-pointer transition-colors elastic-tap shadow-xs"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out of Current Session</span>
              </button>

              {/* Transparent 1-Tap Permanent Account Deletion with Full Data Wipe */}
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/25 space-y-2.5">
                <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400">
                  <AlertTriangle className="w-4 h-4" />
                  <h4 className="text-xs font-black uppercase tracking-wider">Permanent Account Deletion</h4>
                </div>
                <p className="text-[10px] text-rose-700 dark:text-rose-300 leading-relaxed">
                  Transparent 1-tap complete data wipe. Erases your profile, contacts, chat histories, active WebRTC keys, and signed credentials from Cloud Firestore and local storage.
                </p>
                <button
                  onClick={() => {
                    playClickSound();
                    setShowDeleteModal(true);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm cursor-pointer elastic-tap transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Account & Wipe All Data</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==============================================================
          MODE 2: IDENTITY PROFILE & RECOVERY
      ============================================================== */}
      {viewMode === 'identity' && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          {/* Main Identity 3D Glass Card */}
          <div className="rounded-3xl glass-3d-panel p-4 relative overflow-hidden shadow-xl border border-white/80 dark:border-white/10">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3.5">
                <div className="relative">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-white/80 dark:border-white/20 shadow-md">
                    <img
                      src={currentUserProfile.avatar}
                      alt={currentUserProfile.displayName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <button
                    onClick={() => {
                      playClickSound();
                      setIsEditingProfile(true);
                    }}
                    className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full glass-purple-glow text-white flex items-center justify-center border-2 border-white dark:border-gray-800 shadow cursor-pointer elastic-tap"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h2 className="text-base font-bold">{currentUserProfile.displayName}</h2>
                    <span className="w-2.5 h-2.5 rounded-full bg-[#7C5C9B] animate-pulse shadow-sm" />
                  </div>
                  <p className="text-xs text-[#6B6275] dark:text-gray-400">@{currentUserProfile.username}</p>
                  <div className="inline-flex items-center gap-1 mt-1 text-[10px] font-mono text-[#7C5C9B] dark:text-purple-300 glass-pod-purple-subtle px-2 py-0.5 rounded-full font-semibold">
                    <Shield className="w-2.5 h-2.5" />
                    <span>{currentUserProfile.isAnonymous ? 'Ephemeral Node' : 'Secured Permanent Account'}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  playClickSound();
                  setIsEditingProfile(!isEditingProfile);
                }}
                className="p-1.5 px-3 rounded-xl glass-pod-ivory hover:border-[#7C5C9B]/40 text-[#7C5C9B] dark:text-purple-300 font-semibold text-xs cursor-pointer elastic-tap shadow-sm"
              >
                Edit
              </button>
            </div>

            {/* Bio */}
            <p className="text-xs mt-3 glass-pod-ivory p-2.5 rounded-xl border border-white/60 dark:border-white/10">
              {currentUserProfile.bio}
            </p>

            {/* Splender ID 3D Pod */}
            <div className="mt-3 flex items-center justify-between glass-pod-ivory border border-white/80 dark:border-white/10 rounded-2xl px-3.5 py-2.5 shadow-sm">
              <div>
                <span className="text-[10px] font-mono uppercase text-[#6B6275] dark:text-gray-400 block">
                  Splender ID (Collision-Safe)
                </span>
                <span className="text-xs font-mono font-bold text-[#7C5C9B] dark:text-purple-300">
                  {currentUserProfile.splenderId}
                </span>
              </div>
              <button
                onClick={handleCopyNumber}
                className="p-2 rounded-xl glass-purple-glow text-white cursor-pointer transition-transform elastic-tap shadow-md"
              >
                {copiedNumber ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Edit Profile Form */}
          {isEditingProfile && (
            <form
              onSubmit={handleSaveProfile}
              className="p-4 rounded-3xl glass-3d-panel space-y-3 shadow-xl animate-in fade-in border border-white/80 dark:border-white/10"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setIsEditingProfile(false);
                    }}
                    className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#6B6275] dark:text-gray-400 transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4 text-[#7C5C9B] dark:text-purple-300" />
                  </button>
                  <h3 className="text-xs font-bold uppercase tracking-wider">Edit Profile</h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setIsEditingProfile(false);
                  }}
                  className="text-xs text-[#6B6275] dark:text-gray-400 cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="text-[10px] font-bold text-[#6B6275] dark:text-gray-400 block mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={displayNameInput}
                  onChange={(e) => setDisplayNameInput(e.target.value)}
                  className="w-full glass-input-3d rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-[#6B6275] dark:text-gray-400 block mb-1">
                  Username (@unique)
                </label>
                <input
                  type="text"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  className="w-full glass-input-3d rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-[#6B6275] dark:text-gray-400 block mb-1">Bio / Status</label>
                <input
                  type="text"
                  value={bioInput}
                  onChange={(e) => setBioInput(e.target.value)}
                  className="w-full glass-input-3d rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl glass-purple-glow text-white text-xs font-bold shadow-md cursor-pointer elastic-tap"
              >
                Save Changes
              </button>
            </form>
          )}

          {/* Account Security & Non-Destructive Linking Section */}
          <div className="rounded-3xl glass-3d-panel p-4 space-y-3 shadow-lg border border-white/80 dark:border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-[#7C5C9B] dark:text-purple-400" />
                  <span>Account Security & Recovery</span>
                </h3>
                <p className="text-[10px] text-[#6B6275] dark:text-gray-400 mt-0.5">
                  Link Google or Email to preserve your identity across devices
                </p>
              </div>
            </div>

            {currentUserProfile.isAnonymous ? (
              <div className="space-y-2 pt-1">
                <button
                  onClick={() => {
                    playClickSound();
                    linkGoogleAccount();
                  }}
                  className="w-full p-2.5 rounded-xl glass-pod-ivory hover:border-[#7C5C9B]/50 flex items-center justify-between text-xs cursor-pointer transition-all elastic-tap shadow-sm"
                >
                  <span className="font-semibold">Link with Google</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full glass-purple-glow text-white font-mono font-medium">
                    Google OAuth
                  </span>
                </button>

                <button
                  onClick={() => {
                    playClickSound();
                    setShowLinkEmail(!showLinkEmail);
                  }}
                  className="w-full p-2.5 rounded-xl glass-pod-ivory hover:border-[#7C5C9B]/50 flex items-center justify-between text-xs cursor-pointer transition-all elastic-tap shadow-sm"
                >
                  <span className="font-semibold">Link Email & Password</span>
                  <span className="text-[10px] text-[#7C5C9B] dark:text-purple-300 font-semibold">{showLinkEmail ? 'Collapse' : 'Expand'}</span>
                </button>

                {showLinkEmail && (
                  <form onSubmit={handleEmailLinkSubmit} className="space-y-2 p-3 glass-pod-ivory rounded-2xl border border-white/80 dark:border-white/10 animate-in fade-in">
                    <input
                      type="email"
                      placeholder="name@domain.com"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full glass-input-3d rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                      required
                    />
                    <input
                      type="password"
                      placeholder="Strong backup password"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      className="w-full glass-input-3d rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#7C5C9B]"
                      required
                    />
                    <button
                      type="submit"
                      disabled={isLinking}
                      className="w-full py-2 rounded-xl glass-purple-glow text-white text-xs font-bold cursor-pointer disabled:opacity-50 elastic-tap shadow-md"
                    >
                      {isLinking ? 'Attaching Credentials...' : 'Secure & Link Account'}
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-2 text-xs">
                <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Account linked securely. UID and Splender ID are permanently backed up.</span>
              </div>
            )}
          </div>

          {/* Quick Action Matrix */}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => {
                playClickSound();
                setIsQrScannerOpen(true);
              }}
              className="p-3.5 rounded-2xl glass-pod-ivory hover:border-[#7C5C9B]/50 flex flex-col items-start gap-2 transition-all cursor-pointer group elastic-tap shadow-sm"
            >
              <div className="p-2 rounded-xl glass-pod-purple-subtle text-[#7C5C9B] dark:text-purple-300 group-hover:scale-105 transition-transform">
                <QrCode className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold">Sovereign QR</p>
                <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Share or scan address</p>
              </div>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setIsIdentityModalOpen(true);
              }}
              className="p-3.5 rounded-2xl glass-pod-ivory hover:border-[#7C5C9B]/50 flex flex-col items-start gap-2 transition-all cursor-pointer group elastic-tap shadow-sm"
            >
              <div className="p-2 rounded-xl glass-pod-purple-subtle text-[#7C5C9B] dark:text-purple-300 group-hover:scale-105 transition-transform">
                <Key className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold">Firebase UID</p>
                <p className="text-[10px] text-[#6B6275] dark:text-gray-400">Owner backend details</p>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Permanent Account Deletion */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm glass-3d-panel rounded-3xl p-5 border border-rose-500/40 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6 animate-pulse" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-rose-600 dark:text-rose-400">Confirm Full Data Wipe?</h3>
              <p className="text-xs text-[#6B6275] dark:text-gray-300 leading-relaxed">
                This action is <span className="font-bold text-rose-500">permanent and irreversible</span>. All your conversations, sent media, contacts, rewards, and Firebase credentials will be permanently erased.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={handlePermanentDeletion}
                disabled={isDeleting}
                className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 transition-all"
              >
                {isDeleting ? (
                  <span>Wiping Cloud Node & Storage...</span>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Yes, Permanently Delete My Account</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  playClickSound();
                  setShowDeleteModal(false);
                }}
                disabled={isDeleting}
                className="w-full py-2.5 rounded-xl bg-white/40 dark:bg-white/10 hover:bg-white/60 dark:hover:bg-white/20 text-xs font-semibold cursor-pointer transition-all"
              >
                Cancel & Keep Account
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
