import React, { useState, useRef } from 'react';
import {
  Search,
  Pin,
  VolumeX,
  CheckCheck,
  Check,
  Plus,
  QrCode,
  Shield,
  Lock,
  Mic,
  Image as ImageIcon,
  Users,
  MoreVertical,
  X,
  UserPlus,
  Archive,
  ArchiveRestore,
  MessageSquare,
  Star,
  Camera,
  Trash2,
  Unlock,
  Fingerprint,
  ArrowLeft,
  Volume2,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { Conversation, ContactItem } from '../types';
import { playClickSound, playPopSound } from '../lib/sound';
import { QuickActionsBar } from './QuickActionsBar';
import { getThemeConfig } from '../lib/themeEngine';
import { db, doc, updateDoc, createDeterministicAvatarDataUri } from '../lib/firebase';

export type ChatFilterType = 'all' | 'unread' | 'favorites' | 'groups' | 'archived';

export const ChatsList: React.FC = () => {
  const {
    conversations,
    messages,
    setActiveConversationId,
    setTargetJumpMessageId,
    togglePinConversation,
    toggleMuteConversation,
    contacts,
    startDirectConversation,
    createGroupConversation,
    lockApp,
    setIsQrScannerOpen,
    firebaseUser,
    currentUserProfile,
    isUserOnline,
    showToast,
    darkMode,
    globalSearchQuery,
    globalSearchFilter,
    userPin,
    activeCategory,
    setActiveCategory,
    setCommandPaletteOpen,
    theme,
    t,
  } = useChat();

  const themeConfig = getThemeConfig(theme);

  const [conversationCategories, setConversationCategories] = useState<Record<string, 'personal' | 'work' | 'college'>>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_chat_categories') || '{}');
    } catch {
      return {};
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<ChatFilterType>('all');
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [isNewGroupModalOpen, setIsNewGroupModalOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedGroupParticipants, setSelectedGroupParticipants] = useState<string[]>([]);
  const [actionMenuConvId, setActionMenuConvId] = useState<string | null>(null);
  const [showArchivedView, setShowArchivedView] = useState(false);
  const [newContactSplenderId, setNewContactSplenderId] = useState('');

  const [archivedConvIds, setArchivedConvIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_archived_convs') || '[]');
    } catch {
      return [];
    }
  });

  const [pinnedConvIds, setPinnedConvIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_pinned_convs') || '[]');
    } catch {
      return [];
    }
  });

  const [swipedConvId, setSwipedConvId] = useState<string | null>(null);
  const touchStartXRef = useRef<number>(0);
  const touchStartYRef = useRef<number>(0);

  const [favoriteConvIds, setFavoriteConvIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_fav_convs') || '[]');
    } catch {
      return [];
    }
  });

  const [lockedConvIds, setLockedConvIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_locked_convs') || '[]');
    } catch {
      return [];
    }
  });

  const [showLockedView, setShowLockedView] = useState(false);
  const [isLockedAuthenticated, setIsLockedAuthenticated] = useState(false);
  const [showUnlockPrompt, setShowUnlockPrompt] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const toggleLockConversation = (convId: string) => {
    playClickSound();
    setLockedConvIds((prev) => {
      const isLocked = prev.includes(convId);
      const next = isLocked ? prev.filter((id) => id !== convId) : [...prev, convId];
      localStorage.setItem('splender_locked_convs', JSON.stringify(next));
      showToast(
        isLocked ? 'Chat Unlocked' : 'Chat Locked',
        isLocked ? 'Restored to regular chats' : 'Moved to Locked Chats folder',
        'success'
      );
      return next;
    });
  };

  const toggleArchiveConversation = (convId: string) => {
    playClickSound();
    let willBeArchived = false;
    setArchivedConvIds((prev) => {
      const isArchived = prev.includes(convId);
      willBeArchived = !isArchived;
      const next = isArchived ? prev.filter((id) => id !== convId) : [...prev, convId];
      localStorage.setItem('splender_archived_convs', JSON.stringify(next));
      showToast(
        isArchived ? 'Chat Unarchived' : 'Chat Archived',
        isArchived ? 'Restored to regular chats' : 'Conversation moved to Archived',
        'info'
      );
      return next;
    });

    if (firebaseUser) {
      try {
        updateDoc(doc(db, 'conversations', convId), {
          [`isArchived.${firebaseUser.uid}`]: willBeArchived,
        }).catch((err) => console.debug('Archive update error:', err));
      } catch (err) {
        console.debug('Archive sync error:', err);
      }
    }
  };

  const handleTogglePin = (convId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    playPopSound();
    togglePinConversation(convId);
    setPinnedConvIds((prev) => {
      const isPinned = prev.includes(convId);
      const next = isPinned ? prev.filter((id) => id !== convId) : [...prev, convId];
      localStorage.setItem('splender_pinned_convs', JSON.stringify(next));
      return next;
    });
    setSwipedConvId(null);
  };

  const handleToggleArchive = (convId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    toggleArchiveConversation(convId);
    setSwipedConvId(null);
  };

  const [deletedConvIds, setDeletedConvIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('splender_deleted_convs') || '[]');
    } catch {
      return [];
    }
  });

  const handleDeleteConversation = (convId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    playPopSound();
    setDeletedConvIds((prev) => {
      const next = prev.includes(convId) ? prev : [...prev, convId];
      localStorage.setItem('splender_deleted_convs', JSON.stringify(next));
      return next;
    });
    setSwipedConvId(null);
    showToast('Chat Deleted', 'Conversation removed from chats list', 'info');
  };

  const handleTouchStart = (convId: string, e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (convId: string, e: React.TouchEvent) => {
    const deltaX = e.changedTouches[0].clientX - touchStartXRef.current;
    const deltaY = e.changedTouches[0].clientY - touchStartYRef.current;
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 40) {
      if (deltaX < 0) {
        // Swiped left - open quick actions drawer
        setSwipedConvId(convId);
      } else {
        // Swiped right - close drawer
        setSwipedConvId((curr) => (curr === convId ? null : curr));
      }
    }
  };

  const toggleFavoriteConversation = (convId: string) => {
    playClickSound();
    setFavoriteConvIds((prev) => {
      const isFav = prev.includes(convId);
      const next = isFav ? prev.filter((id) => id !== convId) : [...prev, convId];
      localStorage.setItem('splender_fav_convs', JSON.stringify(next));
      showToast(isFav ? 'Removed from Favorites' : 'Added to Favorites', undefined, 'info');
      return next;
    });
  };

  const myUid = firebaseUser?.uid;
  const acceptedContacts = contacts.filter((c) => c.state === 'accepted');

  // Filter conversations
  const effectiveQuery = (globalSearchQuery || searchQuery).trim().toLowerCase();

  const allArchivedCount = conversations.filter(
    (c) => Boolean((myUid && c.isArchived?.[myUid]) || archivedConvIds.includes(c.id))
  ).length;

  const filteredConversations = conversations
    .filter((conv) => {
      if (deletedConvIds.includes(conv.id)) return false;
      if (effectiveQuery) {
        const convName = conv.isGroup
          ? conv.groupName || 'Group'
          : Object.entries(conv.participantNames || {}).find(([uid]) => uid !== myUid)?.[1] || 'Direct Chat';
        const matchesName = convName.toLowerCase().includes(effectiveQuery);
        const matchesLastMsg = conv.lastMessage?.text?.toLowerCase().includes(effectiveQuery);
        const matchesAnyMsg = messages.some(
          (m) => m.conversationId === conv.id && m.text && m.text.toLowerCase().includes(effectiveQuery) && !m.isDeleted
        );
        if (!matchesName && !matchesLastMsg && !matchesAnyMsg) return false;
      }

      // Check global deep media filter if set
      if (globalSearchFilter && globalSearchFilter !== 'all') {
        const lastMsg = conv.lastMessage;
        if (globalSearchFilter === 'photos' && lastMsg?.type !== 'image') return false;
        if (globalSearchFilter === 'videos' && (lastMsg?.type as string) !== 'video') return false;
        if (globalSearchFilter === 'links' && (!lastMsg?.text || (!lastMsg.text.includes('http') && !lastMsg.text.includes('www.')))) return false;
        if ((globalSearchFilter === 'docs' || globalSearchFilter === 'documents') && lastMsg?.type !== 'document') return false;
        if (globalSearchFilter === 'audio' && lastMsg?.type !== 'audio') return false;
        if (globalSearchFilter === 'unread') {
          const unreadCount = myUid ? (conv.unreadCounts?.[myUid] || 0) : 0;
          if (unreadCount <= 0) return false;
        }
      }

      const isLocked = lockedConvIds.includes(conv.id);
      if (showLockedView) {
        return isLocked;
      }
      if (isLocked) return false;

      const isArchived = Boolean((myUid && conv.isArchived?.[myUid]) || archivedConvIds.includes(conv.id));
      if (showArchivedView || activeFilter === 'archived') {
        return isArchived;
      }
      if (isArchived) return false;

      const isPinned = Boolean((myUid && conv.pinned?.[myUid]) || pinnedConvIds.includes(conv.id));
      const unread = myUid ? (conv.unreadCounts?.[myUid] || 0) : 0;
      const isFav = favoriteConvIds.includes(conv.id);

      // Category filter check (personal, work, college, unread)
      if (activeCategory === 'unread') {
        if (unread <= 0) return false;
      } else if (activeCategory === 'personal' || activeCategory === 'work' || activeCategory === 'college') {
        const cat = conv.category || conversationCategories[conv.id] || (conv.isGroup ? 'work' : 'personal');
        if (cat !== activeCategory) return false;
      }

      if (activeFilter === 'unread') return unread > 0;
      if (activeFilter === 'favorites') return isFav;
      if (activeFilter === 'groups') return conv.isGroup;
      return true;
    })
    .sort((a, b) => {
      const aPinned = Boolean((myUid && a.pinned?.[myUid]) || pinnedConvIds.includes(a.id));
      const bPinned = Boolean((myUid && b.pinned?.[myUid]) || pinnedConvIds.includes(b.id));
      if (aPinned && !bPinned) return -1;
      if (!aPinned && bPinned) return 1;
      return (b.updatedAt || 0) - (a.updatedAt || 0);
    });

  const matchingMessages = React.useMemo(() => {
    if (!effectiveQuery || effectiveQuery.length < 2) return [];
    return messages
      .filter((m) => m.text && m.text.toLowerCase().includes(effectiveQuery) && !m.isDeleted)
      .slice(0, 8);
  }, [messages, effectiveQuery]);

  const formatMessageTime = (timestamp?: number) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    }
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }
    return date.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: '2-digit' });
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) {
      showToast('Group Subject Required', 'Please enter a name for the new group', 'warning');
      return;
    }
    const selectedMembers = acceptedContacts.filter((c) =>
      selectedGroupParticipants.includes(c.targetUid)
    );
    if (selectedMembers.length === 0) {
      showToast('Select Participants', 'Select at least 1 contact to create group', 'warning');
      return;
    }
    await createGroupConversation(newGroupName.trim(), selectedMembers);
    setIsNewGroupModalOpen(false);
    setNewGroupName('');
    setSelectedGroupParticipants([]);
  };

  const handleAddNewContact = () => {
    if (!newContactSplenderId.trim()) return;
    playClickSound();
    startDirectConversation({
      uid: `user_${Date.now()}`,
      splenderId: newContactSplenderId.trim().toUpperCase(),
      displayName: `Peer ${newContactSplenderId.trim().slice(-4)}`,
      avatar: createDeterministicAvatarDataUri(`Peer ${newContactSplenderId.trim().slice(-4)}`, '#3B82F6'),
    });
    setIsNewChatModalOpen(false);
    setNewContactSplenderId('');
    showToast('Chat Initiated', 'Direct E2EE chat created', 'success');
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#F8FAFF] dark:bg-[#080B14] text-slate-900 dark:text-[#F4F7FF] select-none relative">
      {/* Category & Filter Controls */}
      {!showArchivedView && (
        <div className="px-3 pt-2.5 pb-2 flex items-center gap-1.5 text-xs shrink-0 overflow-x-auto no-scrollbar border-b border-slate-200/80 dark:border-[#293650]/75 bg-[#F8FAFF] dark:bg-[#0D1424]/75">
          {([
            { id: 'all' as const, label: 'All' },
            { id: 'personal' as const, label: 'Personal' },
            { id: 'work' as const, label: 'Work' },
            { id: 'college' as const, label: 'College' },
            { id: 'unread' as const, label: 'Unread' },
            { id: 'favorites' as const, label: 'Favorites' },
            { id: 'groups' as const, label: 'Groups' },
            { id: 'archived' as const, label: `Archived${allArchivedCount > 0 ? ` (${allArchivedCount})` : ''}` },
          ]).map((item) => {
            const isSelected =
              item.id === 'archived'
                ? showArchivedView || activeFilter === 'archived'
                : !showArchivedView && (activeCategory === item.id || (activeCategory === 'all' && activeFilter === item.id));
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  if (item.id === 'archived') {
                    setShowArchivedView(true);
                    setActiveFilter('archived');
                    return;
                  }
                  setShowArchivedView(false);
                  if (item.id === 'personal' || item.id === 'work' || item.id === 'college' || item.id === 'all') {
                    setActiveCategory(item.id);
                    setActiveFilter('all');
                  } else if (item.id === 'unread') {
                    setActiveCategory('unread');
                    setActiveFilter('unread');
                  } else {
                    setActiveCategory('all');
                    setActiveFilter(item.id as any);
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-[#3B82F6] dark:bg-[#22D3EE]/16 text-white dark:text-[#22D3EE] font-semibold border border-[#3B82F6] dark:border-[#22D3EE]/40'
                    : 'bg-slate-100 dark:bg-[#131D32] text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] border border-transparent dark:border-[#293650]/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setCommandPaletteOpen(true);
            }}
            title="Open Command Palette (Cmd+K)"
            className="px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold transition-colors cursor-pointer bg-slate-100 dark:bg-[#131D32] text-slate-600 dark:text-[#A8B3CC] hover:text-[#3B82F6] dark:hover:text-[#22D3EE] border border-slate-200 dark:border-[#293650] ml-auto shrink-0 flex items-center gap-1 whitespace-nowrap"
          >
            <span>⌘K</span>
          </button>
        </div>
      )}

      {/* Quick Actions Bar */}
      {!showArchivedView && !showLockedView && !searchQuery.trim() && (
        <QuickActionsBar onNewGroupClick={() => setIsNewGroupModalOpen(true)} />
      )}

      {/* Archived View Header Banner */}
      {showArchivedView && (
        <div className="p-3 bg-slate-100 dark:bg-[#0D1424] flex items-center justify-between border-b border-slate-200 dark:border-[#293650]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowArchivedView(false)}
              className="p-1 text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold tabular-nums">Archived chats ({archivedConvIds.length})</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC]">Muted in main inbox</p>
        </div>
      )}

      {/* Locked Chats View Header Banner */}
      {showLockedView && (
        <div className="p-3 bg-slate-100 dark:bg-[#0D1424] flex items-center justify-between border-b border-slate-200 dark:border-[#293650]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowLockedView(false)}
              className="p-1 text-slate-600 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#3B82F6] dark:text-[#22D3EE]" />
              <span className="text-xs font-semibold tabular-nums">Locked Vault ({lockedConvIds.length})</span>
              <span aria-hidden="true" className="text-slate-400">·</span>
              <span className="text-[11px] text-slate-500 dark:text-[#A8B3CC]">E2EE</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              playPopSound();
              setIsLockedAuthenticated(false);
              setShowLockedView(false);
              showToast('Vault Locked', 'Confidential conversations secured', 'info');
            }}
            className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-white dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] hover:border-[#22D3EE] text-slate-700 dark:text-[#F4F7FF] cursor-pointer flex items-center gap-1 whitespace-nowrap"
          >
            <Lock className="w-3 h-3" />
            <span>Lock Vault</span>
          </button>
        </div>
      )}

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto no-scrollbar divide-y divide-slate-200/60 dark:divide-[#293650]/55">
        {/* Locked Chats Entry */}
        {!showArchivedView && !showLockedView && activeFilter === 'all' && (
          <div
            onClick={() => {
              playClickSound();
              if (isLockedAuthenticated) {
                setShowLockedView(true);
              } else {
                setShowUnlockPrompt(true);
              }
            }}
            className="px-4 py-3 flex items-center justify-between hover:bg-slate-100/70 dark:hover:bg-[#131D32]/65 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#3B82F6]/12 dark:bg-[#22D3EE]/12 border border-[#3B82F6]/20 dark:border-[#22D3EE]/25 text-[#3B82F6] dark:text-[#22D3EE] flex items-center justify-center shrink-0">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-900 dark:text-[#F4F7FF]">{t('lockedChats')}</p>
                <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC]">Biometric &amp; PIN protected threads</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {lockedConvIds.length > 0 && (
                <span className="text-xs font-mono font-semibold text-[#3B82F6] dark:text-[#22D3EE] tabular-nums">
                  {lockedConvIds.length}
                </span>
              )}
              <ChevronRight className="w-4 h-4 text-slate-400 dark:text-[#A8B3CC]" />
            </div>
          </div>
        )}

        {/* Archived Row */}
        {!showArchivedView && allArchivedCount > 0 && activeFilter === 'all' && (
          <div
            onClick={() => {
              playClickSound();
              setShowArchivedView(true);
            }}
            className="px-4 py-3 flex items-center justify-between hover:bg-slate-100/70 dark:hover:bg-[#131D32]/65 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#8B5CF6]/12 border border-[#8B5CF6]/25 text-[#8B5CF6] flex items-center justify-center shrink-0">
                <Archive className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-900 dark:text-[#F4F7FF]">{t('archivedChats')}</span>
                <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC]">Archived threads hidden from main inbox</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-mono font-semibold text-[#8B5CF6] tabular-nums">
                {allArchivedCount}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400 dark:text-[#A8B3CC]" />
            </div>
          </div>
        )}

        {/* Empty State */}
        {filteredConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-6 text-center text-slate-500 dark:text-[#A8B3CC] space-y-2.5">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] flex items-center justify-center">
              {showArchivedView ? (
                <Archive className="w-6 h-6 text-[#8B5CF6]" />
              ) : (
                <MessageSquare className="w-6 h-6 text-[#22D3EE]" />
              )}
            </div>
            <p className="font-display text-sm font-bold text-slate-900 dark:text-[#F4F7FF]">
              {showArchivedView
                ? 'No archived conversations'
                : searchQuery.trim()
                ? `No chats matching "${searchQuery}"`
                : activeFilter !== 'all'
                ? `No ${activeFilter} chats`
                : 'No conversations yet'}
            </p>
            <p className="text-xs text-slate-500 dark:text-[#A8B3CC] max-w-xs leading-relaxed">
              {showArchivedView
                ? 'Swipe left on any conversation or open options to archive threads.'
                : 'Tap the compose button below to start a private, Signal-encrypted conversation.'}
            </p>
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const isPinned = Boolean((myUid && conv.pinned?.[myUid]) || pinnedConvIds.includes(conv.id));
            const isArchived = Boolean((myUid && conv.isArchived?.[myUid]) || archivedConvIds.includes(conv.id));
            const isMuted = myUid ? conv.muted?.[myUid] : false;
            const unreadCount = myUid ? (conv.unreadCounts?.[myUid] || 0) : 0;
            const otherUid = conv.participants.find((p) => p !== myUid);
            const isSwiped = swipedConvId === conv.id;

            const convTitle = conv.isGroup
              ? conv.groupName || 'Splender Group'
              : (otherUid && conv.participantNames?.[otherUid]) || 'Peer Chat';
            const convAvatar = conv.isGroup
              ? conv.groupAvatar || createDeterministicAvatarDataUri(convTitle, '#8B5CF6')
              : (otherUid && conv.participantAvatars?.[otherUid]) || createDeterministicAvatarDataUri(convTitle, '#3B82F6');

            const lastMsg = conv.lastMessage;
            const isMe = lastMsg?.senderUid === myUid;

            return (
              <div
                key={conv.id}
                className="relative overflow-hidden group select-none transition-colors"
              >
                {/* Swipe Action Drawer (Revealed on Swipe Left: Pin, Archive, Delete) */}
                <div className="absolute right-0 top-0 bottom-0 flex items-stretch w-48 z-0">
                  {/* Pin / Unpin Action */}
                  <button
                    type="button"
                    onClick={(e) => handleTogglePin(conv.id, e)}
                    className="flex-1 bg-amber-500 hover:bg-amber-600 text-white flex flex-col items-center justify-center gap-1 text-[10px] font-bold cursor-pointer transition-colors px-1"
                    title={isPinned ? 'Unpin conversation' : 'Pin conversation to top'}
                  >
                    <Pin className={`w-4 h-4 ${isPinned ? 'rotate-45 fill-white' : ''}`} />
                    <span>{isPinned ? 'Unpin' : 'Pin'}</span>
                  </button>

                  {/* Archive / Unarchive Action */}
                  <button
                    type="button"
                    onClick={(e) => handleToggleArchive(conv.id, e)}
                    className="flex-1 bg-teal-600 hover:bg-teal-700 text-white flex flex-col items-center justify-center gap-1 text-[10px] font-bold cursor-pointer transition-colors px-1"
                    title={isArchived ? 'Unarchive chat' : 'Archive chat'}
                  >
                    {isArchived ? <ArchiveRestore className="w-4 h-4" /> : <Archive className="w-4 h-4" />}
                    <span>{isArchived ? 'Restore' : 'Archive'}</span>
                  </button>

                  {/* Delete Action */}
                  <button
                    type="button"
                    onClick={(e) => handleDeleteConversation(conv.id, e)}
                    className="flex-1 bg-rose-600 hover:bg-rose-700 text-white flex flex-col items-center justify-center gap-1 text-[10px] font-bold cursor-pointer transition-colors px-1"
                    title="Delete chat"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>

                  {/* Dismiss Drawer */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSwipedConvId(null);
                    }}
                    className="w-8 bg-slate-700 hover:bg-slate-800 text-slate-300 flex items-center justify-center cursor-pointer"
                    title="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Main Front Row */}
                <div
                  onClick={() => {
                    if (isSwiped) {
                      setSwipedConvId(null);
                      return;
                    }
                    playClickSound();
                    setActiveConversationId(conv.id);
                  }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setActionMenuConvId(conv.id);
                  }}
                  onTouchStart={(e) => handleTouchStart(conv.id, e)}
                  onTouchEnd={(e) => handleTouchEnd(conv.id, e)}
                  style={{
                    transform: isSwiped ? 'translateX(-192px)' : 'translateX(0)',
                  }}
                  className={`px-4 py-3 flex items-center gap-3.5 transition-transform duration-150 cursor-pointer relative z-10 bg-[#F8FAFF] dark:bg-[#080B14] hover:bg-slate-100/80 dark:hover:bg-[#131D32]/65 ${
                    isPinned ? 'bg-[#3B82F6]/[0.04] dark:bg-[#8B5CF6]/[0.06]' : ''
                  }`}
                >
                  {/* Contact / Group Avatar */}
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-200 dark:bg-[#131D32] ring-1 ring-slate-200 dark:ring-[#293650]">
                      <img
                        src={convAvatar}
                        alt={convTitle}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {conv.isGroup ? (
                      <div className="absolute -bottom-0.5 -right-0.5 bg-[#8B5CF6] text-white p-0.5 rounded-full border-2 border-[#F8FAFF] dark:border-[#080B14]">
                        <Users className="w-2.5 h-2.5" />
                      </div>
                    ) : otherUid && isUserOnline(otherUid) ? (
                      <span
                        title="Online"
                        className="absolute bottom-0 right-0 w-3 h-3 bg-[#10B981] rounded-full border-2 border-[#F8FAFF] dark:border-[#080B14]"
                      />
                    ) : null}
                  </div>

                  {/* Conversation Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <h3 className="text-sm font-semibold truncate text-slate-900 dark:text-[#F4F7FF]">
                          {convTitle}
                        </h3>
                        {isPinned && (
                          <span
                            title="Pinned conversation"
                            className="inline-flex items-center text-amber-400 shrink-0"
                          >
                            <Pin className="w-3 h-3 fill-current rotate-45" />
                          </span>
                        )}
                      </div>
                      <span
                        className={`text-[11px] font-mono tabular-nums shrink-0 ml-2 ${
                          unreadCount > 0 ? 'text-[#3B82F6] dark:text-[#22D3EE] font-semibold' : 'text-slate-500 dark:text-[#A8B3CC]'
                        }`}
                      >
                        {formatMessageTime(conv.updatedAt || lastMsg?.timestamp)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1 min-w-0 text-xs text-slate-500 dark:text-[#A8B3CC] truncate">
                        {isMe && lastMsg && (
                          <span className="shrink-0">
                            {lastMsg.status === 'read' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-[#22D3EE]" />
                            ) : lastMsg.status === 'delivered' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-slate-400 dark:text-[#A8B3CC]" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-slate-400 dark:text-[#A8B3CC]" />
                            )}
                          </span>
                        )}
                        <p className={`truncate text-xs ${unreadCount > 0 ? 'text-slate-900 dark:text-[#F4F7FF] font-semibold' : ''}`}>
                          {lastMsg ? (
                            lastMsg.isViewOnce ? (
                              (lastMsg.isViewed || lastMsg.viewOnceOpened)
                                ? 'Opened view-once media'
                                : (lastMsg.type === 'video' ? 'View once video' : 'View once photo')
                            ) : (lastMsg.text || 'Media attachment')
                          ) : 'Tap to start encrypted chat'}
                        </p>
                      </div>

                      {/* Right Badges & Desktop Quick Actions */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <div className="hidden sm:flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            type="button"
                            onClick={(e) => handleTogglePin(conv.id, e)}
                            className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                              isPinned
                                ? 'text-amber-400 bg-amber-500/12 hover:bg-amber-500/20'
                                : 'text-slate-400 hover:text-amber-400 hover:bg-slate-100 dark:hover:bg-[#131D32]'
                            }`}
                            title={isPinned ? 'Unpin chat' : 'Pin chat to top'}
                          >
                            <Pin className={`w-3.5 h-3.5 ${isPinned ? 'rotate-45 fill-amber-400' : ''}`} />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleToggleArchive(conv.id, e)}
                            className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                              isArchived
                                ? 'text-[#8B5CF6] bg-[#8B5CF6]/12 hover:bg-[#8B5CF6]/20'
                                : 'text-slate-400 hover:text-[#8B5CF6] hover:bg-slate-100 dark:hover:bg-[#131D32]'
                            }`}
                            title={isArchived ? 'Unarchive chat' : 'Archive chat'}
                          >
                            {isArchived ? (
                              <ArchiveRestore className="w-3.5 h-3.5" />
                            ) : (
                              <Archive className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        {isMuted && <VolumeX className="w-3.5 h-3.5 text-slate-400 dark:text-[#A8B3CC]" />}
                        {isPinned && !isSwiped && (
                          <span className="sm:hidden text-amber-400">
                            <Pin className="w-3 h-3 fill-current rotate-45" />
                          </span>
                        )}
                        {unreadCount > 0 && (
                          <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-[#F4F7FF] text-[10px] font-mono font-bold tabular-nums flex items-center justify-center shadow-xs">
                            {unreadCount > 9 ? '9+' : unreadCount}
                          </span>
                        )}

                        {showArchivedView && (
                          <button
                            type="button"
                            onClick={(e) => handleToggleArchive(conv.id, e)}
                            className="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-100 dark:bg-[#131D32] hover:border-[#8B5CF6] text-[#8B5CF6] border border-slate-200 dark:border-[#293650] cursor-pointer flex items-center gap-1 transition-colors whitespace-nowrap"
                            title="Restore conversation to inbox"
                          >
                            <ArchiveRestore className="w-3 h-3" />
                            <span>Unarchive</span>
                          </button>
                        )}

                        {showLockedView && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleLockConversation(conv.id);
                            }}
                            className="p-1 text-[#3B82F6] dark:text-[#22D3EE] hover:bg-slate-200 dark:hover:bg-[#131D32] rounded-full cursor-pointer"
                            title="Unlock chat"
                          >
                            <Unlock className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            playClickSound();
                            setActionMenuConvId(conv.id);
                          }}
                          className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-[#F4F7FF] rounded-full opacity-60 group-hover:opacity-100 transition-opacity cursor-pointer"
                          title="Chat options"
                        >
                          <MoreVertical className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* Deep Universal Search Results: Matching Messages in Conversations */}
        {effectiveQuery && matchingMessages.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-[#293650] px-3 pb-8">
            <div className="flex items-center gap-2 mb-2 px-1">
              <Search className="w-3.5 h-3.5 text-[#3B82F6] dark:text-[#22D3EE]" />
              <span className="text-xs font-semibold text-slate-500 dark:text-[#A8B3CC] tabular-nums">
                Matching Messages ({matchingMessages.length})
              </span>
            </div>

            <div className="space-y-1.5">
              {matchingMessages.map((msg) => {
                const conv = conversations.find((c) => c.id === msg.conversationId);
                const convTitle = conv?.isGroup
                  ? conv.groupName || 'Group'
                  : conv?.participantNames?.[msg.senderUid] || msg.senderName || 'Chat';

                return (
                  <div
                    key={msg.id}
                    onClick={() => {
                      playClickSound();
                      setTargetJumpMessageId(msg.id);
                      setActiveConversationId(msg.conversationId);
                    }}
                    className="p-2.5 rounded-2xl bg-white dark:bg-[#131D32]/85 hover:border-[#22D3EE]/50 border border-slate-200 dark:border-[#293650] cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="font-semibold text-[#3B82F6] dark:text-[#22D3EE] truncate">
                        {convTitle} · {msg.senderName}
                      </span>
                      <span className="text-[10px] text-slate-400 dark:text-[#A8B3CC] font-mono tabular-nums">
                        {formatMessageTime(msg.timestamp)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-[#F4F7FF] line-clamp-2">
                      {(() => {
                        if (!effectiveQuery || !msg.text) return msg.text;
                        const escaped = effectiveQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                        const parts = msg.text.split(new RegExp(`(${escaped})`, 'gi'));
                        return parts.map((part, i) =>
                          part.toLowerCase() === effectiveQuery.toLowerCase() ? (
                            <mark key={i} className="bg-[#22D3EE]/30 dark:bg-[#22D3EE]/35 text-slate-950 dark:text-[#F4F7FF] font-semibold px-0.5 rounded-xs">
                              {part}
                            </mark>
                          ) : (
                            part
                          )
                        );
                      })()}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Floating Action Button (FAB) */}
      <button
        type="button"
        onClick={() => {
          playClickSound();
          setIsNewChatModalOpen(true);
        }}
        className="absolute bottom-4 right-4 z-40 w-13 h-13 rounded-2xl aurora-cta-gradient text-[#F4F7FF] shadow-[0_12px_28px_-6px_rgba(59,130,246,0.55)] flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        title="New Chat"
        aria-label="New Chat"
      >
        <MessageSquare className="w-5 h-5 stroke-[2.4]" />
      </button>

      {/* MODAL 1: NEW CHAT / CONTACT PICKER */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/65 backdrop-blur-sm select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] p-4 max-h-[85vh] flex flex-col shadow-2xl modal-slide-up text-slate-900 dark:text-[#F4F7FF]">
            <div className="w-10 h-1.5 bg-slate-300 dark:bg-[#293650] rounded-full mx-auto mb-3 shrink-0" />
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#293650]">
              <div>
                <h3 className="font-display text-sm font-bold">Select Contact</h3>
                <span className="text-[11px] text-slate-500 dark:text-[#A8B3CC] font-mono tabular-nums">
                  {acceptedContacts.length} verified peers
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsNewChatModalOpen(false)}
                className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-2 space-y-1.5 border-b border-slate-200 dark:border-[#293650]">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setIsNewChatModalOpen(false);
                  setIsNewGroupModalOpen(true);
                }}
                className="w-full p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-3 cursor-pointer transition-colors"
              >
                <div className="w-9 h-9 rounded-full aurora-cta-gradient text-white flex items-center justify-center shrink-0">
                  <Users className="w-4 h-4" />
                </div>
                <span className="text-xs font-semibold">New Group Conversation</span>
              </button>

              <div className="p-1.5 flex items-center gap-2">
                <input
                  type="text"
                  value={newContactSplenderId}
                  onChange={(e) => setNewContactSplenderId(e.target.value)}
                  placeholder="Enter Splender ID (e.g. SP-492817)..."
                  className="flex-1 min-h-[42px] px-3.5 py-2 text-xs font-mono rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE]"
                />
                <button
                  type="button"
                  onClick={handleAddNewContact}
                  disabled={!newContactSplenderId.trim()}
                  className="min-h-[42px] px-4 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold disabled:opacity-40 cursor-pointer whitespace-nowrap"
                >
                  Start
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar py-2 divide-y divide-slate-100 dark:divide-[#293650]/60">
              {acceptedContacts.map((contact) => (
                <div
                  key={contact.targetUid}
                  onClick={() => {
                    playClickSound();
                    startDirectConversation({
                      uid: contact.targetUid,
                      splenderId: contact.splenderId,
                      displayName: contact.displayName,
                      avatar: contact.avatar,
                    });
                    setIsNewChatModalOpen(false);
                  }}
                  className="py-2.5 px-2 flex items-center gap-3 hover:bg-slate-100 dark:hover:bg-[#131D32] rounded-xl cursor-pointer transition-colors"
                >
                  <img
                    src={contact.avatar}
                    alt={contact.displayName}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-[#293650]"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold truncate">{contact.displayName}</p>
                    <p className="text-[11px] text-slate-500 dark:text-[#A8B3CC] font-mono truncate">{contact.bio || contact.splenderId}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: NEW GROUP WIZARD */}
      {isNewGroupModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm select-none">
          <form
            onSubmit={handleCreateGroup}
            className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-spring space-y-4 text-slate-900 dark:text-[#F4F7FF]"
          >
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#293650] pb-2.5">
              <h3 className="font-display text-sm font-bold">New Group</h3>
              <button
                type="button"
                onClick={() => setIsNewGroupModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-600 dark:text-[#A8B3CC]">Group Subject</label>
              <input
                type="text"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="Type group subject here..."
                maxLength={30}
                required
                className="w-full min-h-[42px] mt-1.5 px-3.5 py-2 text-xs rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE]"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-600 dark:text-[#A8B3CC] tabular-nums">
                Select Participants ({selectedGroupParticipants.length})
              </label>
              <div className="mt-1.5 max-h-48 overflow-y-auto no-scrollbar space-y-1.5">
                {acceptedContacts.map((c) => {
                  const isSelected = selectedGroupParticipants.includes(c.targetUid);
                  return (
                    <div
                      key={c.targetUid}
                      onClick={() => {
                        setSelectedGroupParticipants((prev) =>
                          prev.includes(c.targetUid) ? prev.filter((id) => id !== c.targetUid) : [...prev, c.targetUid]
                        );
                      }}
                      className={`p-2.5 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                        isSelected
                          ? 'border-[#22D3EE] bg-[#3B82F6]/10 dark:bg-[#22D3EE]/12'
                          : 'border-slate-200 dark:border-[#293650] hover:bg-slate-50 dark:hover:bg-[#131D32]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={c.avatar} alt={c.displayName} referrerPolicy="no-referrer" className="w-7 h-7 rounded-full object-cover" />
                        <span className="text-xs font-semibold truncate">{c.displayName}</span>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          isSelected ? 'border-[#22D3EE] bg-[#22D3EE]' : 'border-slate-400 dark:border-[#A8B3CC]'
                        }`}
                      >
                        {isSelected && <Check className="w-2.5 h-2.5 text-[#080B14] stroke-[3]" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              disabled={!newGroupName.trim() || selectedGroupParticipants.length === 0}
              className="w-full min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs disabled:opacity-40 transition-transform active:scale-[0.98] cursor-pointer"
            >
              Create Group
            </button>
          </form>
        </div>
      )}

      {/* MODAL 3: UNLOCK LOCKED CHATS */}
      {showUnlockPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm select-none">
          <div className="w-full max-w-xs rounded-3xl bg-white dark:bg-[#0D1424] border border-slate-200 dark:border-[#293650] p-5 shadow-2xl modal-spring space-y-4 text-center text-slate-900 dark:text-[#F4F7FF]">
            <div className="w-14 h-14 rounded-2xl aurora-cta-gradient text-white flex items-center justify-center mx-auto shadow-md">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display text-sm font-bold">Unlock Locked Chats</h3>
              <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-1 leading-relaxed">
                Verify biometrics or enter your 6-digit PIN to open your locked vault
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                playPopSound();
                setIsLockedAuthenticated(true);
                setShowUnlockPrompt(false);
                setShowLockedView(true);
                setPinError('');
                setPinInput('');
                showToast('Identity Verified', 'Unlocked Secret Vault', 'success');
              }}
              className="w-full min-h-[44px] py-2.5 rounded-xl aurora-cta-gradient text-white font-semibold text-xs flex items-center justify-center gap-2 transition-transform active:scale-[0.98] cursor-pointer whitespace-nowrap"
            >
              <Fingerprint className="w-4 h-4" />
              <span>Verify Biometrics</span>
            </button>

            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-[#293650]">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError('');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && pinInput.length >= 4) {
                    const validPin = userPin || localStorage.getItem('splender_pin') || '123456';
                    if (pinInput === validPin) {
                      playPopSound();
                      setIsLockedAuthenticated(true);
                      setShowUnlockPrompt(false);
                      setShowLockedView(true);
                      setPinInput('');
                      setPinError('');
                      showToast('Unlocked', 'Access granted to Secret Vault', 'success');
                    } else {
                      playPopSound();
                      setPinError('Incorrect PIN (Default: 123456 or configured in Settings)');
                    }
                  }
                }}
                placeholder="Or enter 6-digit PIN..."
                className="w-full min-h-[42px] px-3 py-2 text-center tracking-widest font-mono text-xs rounded-xl bg-slate-100 dark:bg-[#131D32] outline-none border border-slate-200 dark:border-[#293650] focus:border-[#22D3EE]"
              />
              {pinError && (
                <p className="text-[11px] text-rose-500 font-medium leading-tight">{pinError}</p>
              )}
              <button
                type="button"
                disabled={pinInput.length < 4}
                onClick={() => {
                  const validPin = userPin || localStorage.getItem('splender_pin') || '123456';
                  if (pinInput === validPin) {
                    playPopSound();
                    setIsLockedAuthenticated(true);
                    setShowUnlockPrompt(false);
                    setShowLockedView(true);
                    setPinInput('');
                    setPinError('');
                    showToast('Unlocked', 'Access granted to Secret Vault', 'success');
                  } else {
                    playPopSound();
                    setPinError('Incorrect PIN (Default: 123456 or configured in Settings)');
                  }
                }}
                className="w-full min-h-[40px] py-2 rounded-xl bg-slate-100 dark:bg-[#131D32] border border-slate-200 dark:border-[#293650] text-xs font-semibold disabled:opacity-40 cursor-pointer hover:border-[#22D3EE]"
              >
                Submit PIN
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowUnlockPrompt(false)}
              className="text-xs text-slate-500 dark:text-[#A8B3CC] hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* MODAL 4: CHAT OPTIONS ACTION SHEET */}
      {actionMenuConvId && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/65 backdrop-blur-sm select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-white dark:bg-[#0D1424] border-t border-slate-200 dark:border-[#293650] p-4 shadow-2xl modal-slide-up space-y-1.5 text-slate-900 dark:text-[#F4F7FF]">
            <div className="w-10 h-1.5 bg-slate-300 dark:bg-[#293650] rounded-full mx-auto mb-2 shrink-0" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-[#293650]">
              <span className="font-display text-xs font-bold text-slate-600 dark:text-[#A8B3CC]">Conversation Options</span>
              <button
                type="button"
                onClick={() => setActionMenuConvId(null)}
                className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-[#F4F7FF] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                handleTogglePin(actionMenuConvId);
                setActionMenuConvId(null);
              }}
              className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center justify-between text-xs font-semibold cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <Pin className={`w-4 h-4 text-amber-400 ${
                  Boolean((myUid && conversations.find((c) => c.id === actionMenuConvId)?.pinned?.[myUid]) || pinnedConvIds.includes(actionMenuConvId)) ? 'rotate-45 fill-amber-400' : ''
                }`} />
                <span>
                  {Boolean((myUid && conversations.find((c) => c.id === actionMenuConvId)?.pinned?.[myUid]) || pinnedConvIds.includes(actionMenuConvId))
                    ? 'Unpin conversation'
                    : 'Pin conversation to top'}
                </span>
              </div>
              {Boolean((myUid && conversations.find((c) => c.id === actionMenuConvId)?.pinned?.[myUid]) || pinnedConvIds.includes(actionMenuConvId)) && (
                <span className="text-[11px] text-amber-500 font-medium">Pinned</span>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                toggleMuteConversation(actionMenuConvId);
                setActionMenuConvId(null);
              }}
              className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-3 text-xs font-semibold cursor-pointer"
            >
              <VolumeX className="w-4 h-4 text-slate-400 dark:text-[#A8B3CC]" />
              <span>{myUid && conversations.find((c) => c.id === actionMenuConvId)?.muted?.[myUid] ? 'Unmute notifications' : 'Mute notifications'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                toggleFavoriteConversation(actionMenuConvId);
                setActionMenuConvId(null);
              }}
              className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-3 text-xs font-semibold cursor-pointer"
            >
              <Star className="w-4 h-4 text-amber-400" />
              <span>{favoriteConvIds.includes(actionMenuConvId) ? 'Remove from favorites' : 'Add to favorites'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                handleToggleArchive(actionMenuConvId);
                setActionMenuConvId(null);
              }}
              className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center justify-between text-xs font-semibold cursor-pointer"
            >
              <div className="flex items-center gap-3">
                {Boolean((myUid && conversations.find((c) => c.id === actionMenuConvId)?.isArchived?.[myUid]) || archivedConvIds.includes(actionMenuConvId)) ? (
                  <ArchiveRestore className="w-4 h-4 text-[#8B5CF6]" />
                ) : (
                  <Archive className="w-4 h-4 text-[#8B5CF6]" />
                )}
                <span>
                  {Boolean((myUid && conversations.find((c) => c.id === actionMenuConvId)?.isArchived?.[myUid]) || archivedConvIds.includes(actionMenuConvId))
                    ? 'Unarchive conversation'
                    : 'Archive conversation'}
                </span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                toggleLockConversation(actionMenuConvId);
                setActionMenuConvId(null);
              }}
              className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#131D32] flex items-center gap-3 text-xs font-semibold cursor-pointer"
            >
              <Lock className="w-4 h-4 text-[#22D3EE]" />
              <span>{lockedConvIds.includes(actionMenuConvId) ? 'Unlock chat' : 'Lock chat'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
