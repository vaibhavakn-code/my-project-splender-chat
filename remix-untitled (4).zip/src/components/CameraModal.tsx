import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Camera,
  RotateCcw,
  Sparkles,
  Zap,
  ZapOff,
  Image as ImageIcon,
  Check,
  Send,
  Video,
  Play,
  Square,
  Circle,
  Download,
  Share2,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { createScenicMomentDataUri } from '../lib/firebase';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetConversationId?: string | null;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  onClose,
  targetConversationId,
}) => {
  const {
    showToast,
    postMoment,
    sendMessage,
    setActiveConversationId,
    conversations,
    contacts,
    firebaseUser,
  } = useChat();

  const [mode, setMode] = useState<'photo' | 'video'>('photo');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [flash, setFlash] = useState<'off' | 'on' | 'auto'>('off');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [capturedMedia, setCapturedMedia] = useState<{
    url: string;
    type: 'image' | 'video';
  } | null>(null);
  const [caption, setCaption] = useState('');
  const [selectedDestination, setSelectedDestination] = useState<'status' | 'chat'>('status');
  const [selectedConvId, setSelectedConvId] = useState<string>(
    targetConversationId || (conversations[0]?.id || '')
  );
  const [isViewOnceMedia, setIsViewOnceMedia] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recordTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Helper to stop all camera stream tracks cleanly and release camera hardware
  const stopCameraStream = () => {
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((track) => {
          track.stop();
          track.enabled = false;
        });
      } catch (err) {
        console.warn('Error stopping camera stream track:', err);
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      try {
        const srcObj = videoRef.current.srcObject;
        if (srcObj && 'getTracks' in srcObj && typeof (srcObj as any).getTracks === 'function') {
          (srcObj as MediaStream).getTracks().forEach((track) => {
            track.stop();
            track.enabled = false;
          });
        }
      } catch (err) {
        console.warn('Error stopping videoRef tracks:', err);
      }
      videoRef.current.srcObject = null;
    }
  };

  // Safe close handler that always guarantees camera stream tracks are cleanly stopped
  const handleClose = () => {
    stopCameraStream();
    if (isRecording) {
      setIsRecording(false);
    }
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    setCapturedMedia(null);
    setCaption('');
    setIsViewOnceMedia(false);
    onClose();
  };

  // Start webcam stream when open
  useEffect(() => {
    if (!isOpen || capturedMedia) {
      stopCameraStream();
      return;
    }

    let isMounted = true;
    navigator.mediaDevices
      ?.getUserMedia({
        video: { facingMode },
        audio: mode === 'video',
      })
      .then((stream) => {
        if (!isMounted) {
          stream.getTracks().forEach((t) => {
            t.stop();
            t.enabled = false;
          });
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      })
      .catch(() => {
        // Fallback gracefully to simulated interactive viewfinder
        streamRef.current = null;
      });

    return () => {
      isMounted = false;
      stopCameraStream();
    };
  }, [isOpen, facingMode, mode, capturedMedia]);

  // Clean up all tracks on unmount
  useEffect(() => {
    return () => {
      stopCameraStream();
      if (recordTimerRef.current) {
        clearInterval(recordTimerRef.current);
      }
    };
  }, []);

  // Video recording timer
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      recordTimerRef.current = setInterval(() => {
        setRecordingSeconds((s) => {
          if (s >= 30) {
            handleStopRecording();
            return 30;
          }
          return s + 1;
        });
      }, 1000);
    } else {
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    }
    return () => {
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    };
  }, [isRecording]);

  if (!isOpen) return null;

  const handleCapturePhoto = () => {
    playClickSound();
    let capturedUrl: string | null = null;
    if (videoRef.current && streamRef.current) {
      try {
        const video = videoRef.current;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 720;
        canvas.height = video.videoHeight || 1280;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          if (facingMode === 'user') {
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
          }
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          capturedUrl = canvas.toDataURL('image/jpeg', 0.85);
        }
      } catch (e) {
        console.error('Canvas capture failed:', e);
      }
    }

    // Stop active camera stream tracks immediately when media is captured/reviewed
    stopCameraStream();

    if (capturedUrl) {
      setCapturedMedia({ url: capturedUrl, type: 'image' });
      return;
    }

    // High quality photo snapshot simulation
    const samplePhotos = [
      createScenicMomentDataUri('Mountain Horizon', 'Splender Camera Snapshot', '#0F766E', '#0F172A'),
      createScenicMomentDataUri('Studio Workspace', 'Splender Camera Snapshot', '#4338CA', '#1E1B4B'),
      createScenicMomentDataUri('Golden Dusk', 'Splender Camera Snapshot', '#B45309', '#1F2937'),
    ];
    const picked = samplePhotos[Math.floor(Math.random() * samplePhotos.length)];
    setCapturedMedia({ url: picked, type: 'image' });
  };

  const handleStartRecording = () => {
    playClickSound();
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    playClickSound();
    setIsRecording(false);
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    // Stop active camera stream tracks immediately when recording stops
    stopCameraStream();
    // Captured video clip
    setCapturedMedia({
      url: 'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4',
      type: 'video',
    });
  };

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isVid = file.type.startsWith('video/');
    stopCameraStream();
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setCapturedMedia({
        url: result,
        type: isVid ? 'video' : 'image',
      });
    };
    reader.readAsDataURL(file);
  };

  const handleSendMedia = async () => {
    if (!capturedMedia) return;
    playPopSound();

    if (selectedDestination === 'status') {
      await postMoment(
        capturedMedia.url,
        caption.trim() || (capturedMedia.type === 'video' ? 'Video status 📹' : 'Photo status 📷'),
        'high',
        undefined,
        capturedMedia.type
      );
      showToast('Status Posted', 'Your media was published to My Status for 24h', 'success');
    } else {
      const conv = conversations.find((c) => c.id === selectedConvId) || conversations[0];
      if (conv) {
        setActiveConversationId(conv.id);
        await sendMessage(
          caption.trim() ? caption.trim() : (capturedMedia.type === 'video' ? '📹 Video' : '📷 Photo'),
          capturedMedia.type,
          capturedMedia.url,
          undefined,
          undefined,
          undefined,
          undefined,
          {
            conversationId: conv.id,
            isViewOnce: isViewOnceMedia,
            isViewed: false,
            viewOnceOpened: false,
          }
        );
        showToast(
          isViewOnceMedia ? 'View-Once Sent' : 'Media Sent',
          isViewOnceMedia ? `Sent view-once ${capturedMedia.type} (hidden preview after view)` : `Sent ${capturedMedia.type} to chat`,
          'success'
        );
      } else {
        showToast('Status Posted', 'Sent as status update', 'success');
      }
    }

    handleClose();
  };

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between select-none animate-in fade-in duration-200">
      {/* Hidden file upload input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleFilePicked}
      />

      {/* Camera Live Viewfinder / Captured Media Review */}
      {!capturedMedia ? (
        <div className="relative flex-1 flex flex-col justify-between overflow-hidden bg-slate-950">
          {/* Top Bar Controls */}
          <div className="z-20 p-4 flex items-center justify-between text-white bg-gradient-to-b from-black/60 to-transparent">
            <button
              onClick={() => {
                playClickSound();
                handleClose();
              }}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors cursor-pointer"
              title="Close camera"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Flash Toggle */}
            <button
              onClick={() => {
                playClickSound();
                setFlash((prev) => (prev === 'off' ? 'on' : prev === 'on' ? 'auto' : 'off'));
              }}
              className="px-3 py-1.5 rounded-full bg-black/40 hover:bg-black/60 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              {flash === 'off' ? (
                <ZapOff className="w-4 h-4 text-slate-400" />
              ) : (
                <Zap className="w-4 h-4 text-amber-300" />
              )}
              <span className="uppercase text-[10px]">{flash}</span>
            </button>

            {/* Flip Camera */}
            <button
              onClick={() => {
                playClickSound();
                setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
              }}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors cursor-pointer"
              title="Flip camera"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {/* Viewfinder Video Feed */}
          <div className="absolute inset-0 flex items-center justify-center">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />
            {/* Viewfinder simulated reticle */}
            <div className="absolute inset-x-8 inset-y-24 border border-white/20 rounded-3xl pointer-events-none flex flex-col justify-between p-4">
              <div className="flex justify-between">
                <div className="w-4 h-4 border-t-2 border-l-2 border-white/80 rounded-tl-sm" />
                <div className="w-4 h-4 border-t-2 border-r-2 border-white/80 rounded-tr-sm" />
              </div>
              {isRecording && (
                <div className="self-center flex items-center gap-2 bg-rose-600/90 px-3 py-1 rounded-full text-white text-xs font-bold animate-pulse">
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
                  <span>REC {formatTimer(recordingSeconds)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <div className="w-4 h-4 border-b-2 border-l-2 border-white/80 rounded-bl-sm" />
                <div className="w-4 h-4 border-b-2 border-r-2 border-white/80 rounded-br-sm" />
              </div>
            </div>
          </div>

          {/* Bottom Camera Controls */}
          <div className="z-20 p-5 bg-gradient-to-t from-black/80 via-black/40 to-transparent space-y-4">
            {/* Mode Switcher: Photo / Video */}
            <div className="flex justify-center gap-6 text-xs font-bold">
              <button
                onClick={() => {
                  playClickSound();
                  setMode('photo');
                }}
                className={`transition-colors cursor-pointer ${
                  mode === 'photo' ? 'text-[#25D366] underline underline-offset-4' : 'text-slate-400'
                }`}
              >
                PHOTO
              </button>
              <button
                onClick={() => {
                  playClickSound();
                  setMode('video');
                }}
                className={`transition-colors cursor-pointer ${
                  mode === 'video' ? 'text-[#25D366] underline underline-offset-4' : 'text-slate-400'
                }`}
              >
                VIDEO
              </button>
            </div>

            {/* Shutter Bar */}
            <div className="flex items-center justify-around">
              {/* Gallery upload */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-12 h-12 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white cursor-pointer transition-transform hover:scale-105 active:scale-95"
                title="Choose from device gallery"
              >
                <ImageIcon className="w-5 h-5" />
              </button>

              {/* Shutter Button */}
              {mode === 'photo' ? (
                <button
                  onClick={handleCapturePhoto}
                  className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center p-1 cursor-pointer active:scale-95 transition-transform"
                >
                  <div className="w-full h-full rounded-full bg-white hover:bg-slate-200 transition-colors shadow-lg" />
                </button>
              ) : (
                <button
                  onClick={isRecording ? handleStopRecording : handleStartRecording}
                  className="w-20 h-20 rounded-full border-4 border-rose-500 flex items-center justify-center p-1 cursor-pointer active:scale-95 transition-transform"
                >
                  <div
                    className={`rounded-full bg-rose-500 transition-all ${
                      isRecording ? 'w-8 h-8 rounded-md' : 'w-full h-full'
                    }`}
                  />
                </button>
              )}

              {/* Flip camera */}
              <button
                onClick={() => {
                  playClickSound();
                  setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
                }}
                className="w-12 h-12 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white cursor-pointer transition-transform hover:scale-105 active:scale-95"
                title="Flip Camera"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Review & Caption Screen */
        <div className="relative flex-1 flex flex-col justify-between bg-black text-white">
          {/* Top Bar */}
          <div className="z-20 p-4 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent">
            <button
              onClick={() => {
                playClickSound();
                setCapturedMedia(null);
              }}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors cursor-pointer"
              title="Retake"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Review {capturedMedia.type}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = capturedMedia.url;
                  link.download = `splender_${Date.now()}.${capturedMedia.type === 'video' ? 'mp4' : 'jpg'}`;
                  link.click();
                  showToast('Media Saved', 'Saved to your device storage', 'success');
                }}
                className="p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors cursor-pointer"
                title="Save to device"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  playClickSound();
                  handleClose();
                }}
                className="p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors cursor-pointer"
                title="Close camera"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Media Preview */}
          <div className="flex-1 flex items-center justify-center overflow-hidden p-2">
            {capturedMedia.type === 'image' ? (
              <img
                src={capturedMedia.url}
                alt="Captured"
                className="max-h-full max-w-full rounded-2xl object-contain shadow-2xl"
              />
            ) : (
              <video
                src={capturedMedia.url}
                controls
                autoPlay
                loop
                className="max-h-full max-w-full rounded-2xl object-contain shadow-2xl"
              />
            )}
          </div>

          {/* Bottom Destination & Caption Panel */}
          <div className="z-20 p-4 bg-gradient-to-t from-black via-black/80 to-transparent space-y-3">
            {/* Destination Selector: My Status vs Send to Chat */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedDestination('status')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedDestination === 'status'
                    ? 'bg-[#25D366] text-[#111B21]'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                My Status (24h)
              </button>
              <button
                onClick={() => setSelectedDestination('chat')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedDestination === 'chat'
                    ? 'bg-[#25D366] text-[#111B21]'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                Send to Chat
              </button>
            </div>

            {/* Conversation picker if destination is chat */}
            {selectedDestination === 'chat' && conversations.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {conversations.map((conv) => {
                  const otherUid = conv.participants.find((p) => p !== firebaseUser?.uid);
                  const name = conv.isGroup
                    ? conv.groupName || 'Group'
                    : conv.participantNames?.[otherUid || ''] || 'Direct Chat';
                  const isSelected = selectedConvId === conv.id;
                  return (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConvId(conv.id)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-white text-black font-bold'
                          : 'bg-white/10 text-white hover:bg-white/20'
                      }`}
                    >
                      {name}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Caption Input, View-Once Toggle, and Send FAB */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Add a caption..."
                className="flex-1 px-4 py-3 rounded-full bg-white/20 backdrop-blur-md text-white placeholder:text-white/60 text-xs outline-none border border-white/20 focus:border-[#25D366]"
              />

              {/* View-Once Toggle Button ("1") for chat delivery */}
              {selectedDestination === 'chat' && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    const next = !isViewOnceMedia;
                    setIsViewOnceMedia(next);
                    showToast(
                      'View-Once Mode',
                      next ? 'Photo/video will self-destruct after viewing (hidden preview)' : 'View-once disabled',
                      'info'
                    );
                  }}
                  className={`w-11 h-11 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-all cursor-pointer shrink-0 ${
                    isViewOnceMedia
                      ? 'bg-emerald-500 text-white shadow-lg ring-2 ring-emerald-300 scale-105'
                      : 'bg-white/15 hover:bg-white/25 text-white border border-white/20'
                  }`}
                  title="Toggle View-Once (photo/video self-destructs after opening)"
                >
                  1
                </button>
              )}

              <button
                onClick={handleSendMedia}
                className="w-12 h-12 rounded-full bg-[#25D366] text-[#111B21] flex items-center justify-center hover:scale-105 active:scale-95 transition-transform cursor-pointer shadow-xl"
                title="Send"
              >
                <Send className="w-5 h-5 ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
