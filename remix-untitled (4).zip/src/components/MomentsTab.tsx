import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Plus,
  Heart,
  MessageCircle,
  Eye,
  Camera,
  X,
  Share2,
  Film,
  Check,
  Radio,
  Tv,
  Send,
  BarChart2,
  UserPlus,
  UserCheck,
  RefreshCw,
  Compass,
  Smile,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import {
  processMediaWithQuality,
  MEDIA_QUALITY_OPTIONS,
  MediaQuality,
} from '../lib/compression';
import { uploadMediaToStorage, createDeterministicAvatarDataUri } from '../lib/firebase';
import { sound, playClickSound, triggerHeartHaptic } from '../lib/sound';
import { Moment, MomentComment, BroadcastChannel } from '../types';

type FeedTabMode = 'feed' | 'channels' | 'ar_camera';

interface ARFilter {
  id: string;
  name: string;
  badge: string;
  color: string;
  accent: string;
}

const AR_FILTERS: ARFilter[] = [
  { id: 'cyber_neon', name: 'Cyber Neon', badge: '⚡ AR', color: '#00FF88', accent: 'cyan' },
  { id: 'golden_halo', name: 'Golden Halo', badge: '👑 AR', color: '#FFD700', accent: 'amber' },
  { id: 'purple_aurora', name: 'Purple Aurora', badge: '✨ AR', color: '#9B51E0', accent: 'purple' },
  { id: 'retro_vhs', name: 'Retro VHS 1999', badge: '📼 AR', color: '#FF416C', accent: 'rose' },
  { id: 'star_sparkle', name: 'Star Sparkle', badge: '🌟 AR', color: '#00E5FF', accent: 'sky' },
];

export const MomentsTab: React.FC = () => {
  const {
    moments,
    setViewingStoryId,
    postMoment,
    toggleLikeMoment,
    voteMomentPoll,
    addMomentComment,
    firebaseUser,
    currentUserProfile,
    mediaQuality,
    showToast,
  } = useChat();

  const [activeTabMode, setActiveTabMode] = useState<FeedTabMode>('feed');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [caption, setCaption] = useState('');
  const [isPermanent, setIsPermanent] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [momentQuality, setMomentQuality] = useState<MediaQuality>(() => mediaQuality || 'high');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Poll Creation State
  const [hasPoll, setHasPoll] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOption1, setPollOption1] = useState('Yes, absolutely! 🔥');
  const [pollOption2, setPollOption2] = useState('Maybe next time 🤔');

  // Interactive Poll Voting State (Local and optimistic)
  const [pollVotes, setPollVotes] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('splender_poll_votes');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Comments Bottom Sheet State
  const [activeCommentMoment, setActiveCommentMoment] = useState<Moment | null>(null);
  const [commentInput, setCommentInput] = useState('');
  const [commentsMap, setCommentsMap] = useState<Record<string, MomentComment[]>>(() => {
    try {
      const saved = localStorage.getItem('splender_moment_comments');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Broadcaster Channels State
  const [channels, setChannels] = useState<BroadcastChannel[]>([
    {
      id: 'channel_splender_core',
      name: 'Splender Core Updates',
      description: 'Official release channel for mobile engineering, zero-overhead protocols & security patches.',
      avatar: createDeterministicAvatarDataUri('Splender Core', '#0F766E'),
      creatorUid: 'splender_system',
      creatorName: 'Splender Architect',
      subscriberUids: ['user_pioneer_1', 'user_pioneer_2'],
      lastUpdate: 'Version 2.4 Mobile Device Edition is now live across all sovereign nodes.',
      timestamp: Date.now() - 3600000 * 2,
      isVerified: true,
    },
    {
      id: 'channel_devsecops',
      name: 'Quantum DevSecOps Hub',
      description: 'Hardened Firebase rules, sub-100ms transport telemetry, and distributed P2P topologies.',
      avatar: createDeterministicAvatarDataUri('Quantum Hub', '#4338CA'),
      creatorUid: 'devsecops_lead',
      creatorName: 'Security Sentinel',
      subscriberUids: ['user_pioneer_1'],
      lastUpdate: 'Phase 2 Cloud Firestore multi-role authorization passed with zero unauthenticated leaks.',
      timestamp: Date.now() - 3600000 * 6,
      isVerified: true,
    },
    {
      id: 'channel_mobile_ui',
      name: 'Human-Centric UI/UX',
      description: 'Design constitutions, zero-noise tactile feedback, and fluid 60 FPS mobile aesthetics.',
      avatar: createDeterministicAvatarDataUri('Aura Studio', '#9333EA'),
      creatorUid: 'ui_architect',
      creatorName: 'Aura Studio',
      subscriberUids: [],
      lastUpdate: 'Instagram-inspired double-tap quick heart gestures integrated without ticking background noise.',
      timestamp: Date.now() - 3600000 * 12,
      isVerified: true,
    },
  ]);

  // AR Camera Engine State
  const [selectedARFilter, setSelectedARFilter] = useState<string>('cyber_neon');
  const [capturedARFrame, setCapturedARFrame] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    if (mediaQuality) {
      setMomentQuality(mediaQuality);
    }
  }, [mediaQuality]);

  // Start AR Camera stream when AR tab is selected
  useEffect(() => {
    if (activeTabMode === 'ar_camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [activeTabMode, cameraFacing]);

  const startCamera = async () => {
    try {
      stopCamera();
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showToast('Camera Not Supported', 'Camera access is unavailable on this browser.', 'warning');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: cameraFacing, width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      cameraStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setIsCameraActive(true);
      startARLoop();
    } catch (err) {
      console.warn('Camera access denied or unavailable:', err);
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (cameraStreamRef.current) {
      try {
        cameraStreamRef.current.getTracks().forEach((track) => {
          track.stop();
          track.enabled = false;
        });
      } catch (e) {
        console.warn('Error stopping camera stream track in MomentsTab:', e);
      }
      cameraStreamRef.current = null;
    }
    if (videoRef.current) {
      try {
        const srcObj = videoRef.current.srcObject;
        if (srcObj && 'getTracks' in srcObj && typeof (srcObj as any).getTracks === 'function') {
          (srcObj as MediaStream).getTracks().forEach((track) => {
            track.stop();
            track.enabled = false;
          });
        }
      } catch (e) {
        console.warn('Error stopping videoRef stream in MomentsTab:', e);
      }
      videoRef.current.srcObject = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setIsCameraActive(false);
  };

  const startARLoop = () => {
    const renderFrame = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video && canvas && video.readyState >= 2) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          canvas.width = video.videoWidth || 480;
          canvas.height = video.videoHeight || 640;
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          // Draw active AR filter accents
          drawAROverlays(ctx, canvas.width, canvas.height, selectedARFilter);
        }
      }
      animationFrameRef.current = requestAnimationFrame(renderFrame);
    };
    animationFrameRef.current = requestAnimationFrame(renderFrame);
  };

  const drawAROverlays = (ctx: CanvasRenderingContext2D, w: number, h: number, filterId: string) => {
    const time = Date.now() * 0.003;
    if (filterId === 'cyber_neon') {
      // Cyber neon framing & crosshairs
      ctx.strokeStyle = '#00FF88';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#00FF88';
      ctx.shadowBlur = 12;

      // Corner brackets
      const size = 36;
      ctx.beginPath();
      ctx.moveTo(20, 20 + size); ctx.lineTo(20, 20); ctx.lineTo(20 + size, 20);
      ctx.moveTo(w - 20 - size, 20); ctx.lineTo(w - 20, 20); ctx.lineTo(w - 20, 20 + size);
      ctx.moveTo(20, h - 20 - size); ctx.lineTo(20, h - 20); ctx.lineTo(20 + size, h - 20);
      ctx.moveTo(w - 20 - size, h - 20); ctx.lineTo(w - 20, h - 20); ctx.lineTo(w - 20, h - 20 - size);
      ctx.stroke();

      // Cyber HUD Center Ring
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 40 + Math.sin(time) * 4, 0, Math.PI * 2);
      ctx.stroke();
    } else if (filterId === 'golden_halo') {
      // Radiant golden crown halo
      ctx.save();
      ctx.strokeStyle = '#FFD700';
      ctx.lineWidth = 4;
      ctx.shadowColor = '#FFA500';
      ctx.shadowBlur = 16;
      ctx.beginPath();
      ctx.ellipse(w / 2, h * 0.28, 70, 22, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    } else if (filterId === 'purple_aurora') {
      // Purple prism aura tint
      ctx.fillStyle = 'rgba(155, 81, 224, 0.16)';
      ctx.fillRect(0, 0, w, h);
    } else if (filterId === 'retro_vhs') {
      // Retro scanlines & stamp
      ctx.fillStyle = 'rgba(255, 65, 108, 0.08)';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '14px monospace';
      ctx.fillText('REC ● 1999-SP', 24, 36);
    } else if (filterId === 'star_sparkle') {
      // Twinkling stars
      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 6; i++) {
        const x = (w * 0.2 + (i * 110 + Math.sin(time + i) * 20)) % w;
        const y = (h * 0.2 + (i * 90 + Math.cos(time + i) * 20)) % h;
        ctx.beginPath();
        ctx.arc(x, y, 3 + (i % 3), 0, Math.PI * 2);
        ctx.fill();
      }
    }
  };

  const buildOptionalPollPayload = (): Moment['poll'] | undefined => {
    if (!hasPoll) return undefined;
    const q = pollQuestion.trim() || 'Love this capture?';
    const opt1 = pollOption1.trim() || 'Yes, absolutely! 🔥';
    const opt2 = pollOption2.trim() || 'Maybe next time 🤔';
    return {
      question: q,
      options: [
        { text: opt1, votes: [] },
        { text: opt2, votes: [] },
      ],
    };
  };

  const handleCaptureARSnapshot = () => {
    playClickSound();
    const canvas = canvasRef.current;
    let dataUrl = '';
    if (canvas && canvas.width > 0 && canvas.height > 0) {
      dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    } else {
      const offscreen = document.createElement('canvas');
      offscreen.width = 480;
      offscreen.height = 640;
      const ctx = offscreen.getContext('2d');
      if (ctx) {
        const grad = ctx.createLinearGradient(0, 0, 480, 640);
        grad.addColorStop(0, '#0F172A');
        grad.addColorStop(1, '#312E81');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 480, 640);
        drawAROverlays(ctx, 480, 640, selectedARFilter);
        dataUrl = offscreen.toDataURL('image/jpeg', 0.85);
      }
    }
    setCapturedARFrame(dataUrl || null);
    setIsCreateOpen(true);
    setCaption(`AR Filter [${AR_FILTERS.find((f) => f.id === selectedARFilter)?.name || 'Custom'}] ✨`);
    showToast('AR Frame Captured', 'Ready to publish to Stories & Feed!', 'success');
  };

  const handlePublishCapturedAR = async () => {
    if (!capturedARFrame) return;
    try {
      setIsUploading(true);
      playClickSound();
      const uploadResult = await uploadMediaToStorage(
        'moments',
        firebaseUser?.uid || 'feed',
        'images',
        momentQuality,
        capturedARFrame
      );
      sound.playGlassSend();
      await postMoment(
        uploadResult.url,
        caption.trim() || 'AR Moment ✨',
        momentQuality,
        undefined,
        'image',
        {
          poll: buildOptionalPollPayload(),
          isPermanentFeed: isPermanent,
          arFilter: selectedARFilter,
        }
      );
      setCapturedARFrame(null);
      setCaption('');
      setHasPoll(false);
      setPollQuestion('');
      setIsCreateOpen(false);
      setActiveTabMode('feed');
    } catch (err: any) {
      console.error(err);
      showToast('AR Publish Failed', err.message, 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleVotePoll = (momentId: string, optionIndex: number) => {
    triggerHeartHaptic();
    const current = { ...pollVotes, [momentId]: optionIndex };
    setPollVotes(current);
    try {
      localStorage.setItem('splender_poll_votes', JSON.stringify(current));
    } catch {}
    void voteMomentPoll(momentId, optionIndex);
    showToast('Vote Recorded', 'Your peer reaction was synced.', 'success');
  };

  const handleAddComment = (momentId: string) => {
    const cleanText = commentInput.trim();
    if (!cleanText || !currentUserProfile) return;
    playClickSound();
    const newComment: MomentComment = {
      id: `comment_${Date.now()}`,
      momentId,
      userUid: currentUserProfile.uid,
      userName: currentUserProfile.displayName,
      userAvatar: currentUserProfile.avatar,
      text: cleanText,
      createdAt: Date.now(),
    };
    const updated = {
      ...commentsMap,
      [momentId]: [...(commentsMap[momentId] || []), newComment],
    };
    setCommentsMap(updated);
    try {
      localStorage.setItem('splender_moment_comments', JSON.stringify(updated));
    } catch {}
    void addMomentComment(momentId, cleanText);
    setCommentInput('');
    showToast('Comment Posted', undefined, 'success');
  };

  const handleToggleChannelSubscribe = (channelId: string) => {
    if (!firebaseUser) return;
    playClickSound();
    setChannels((prev) =>
      prev.map((c) => {
        if (c.id === channelId) {
          const isSubbed = c.subscriberUids.includes(firebaseUser.uid);
          const nextSubs = isSubbed
            ? c.subscriberUids.filter((u) => u !== firebaseUser.uid)
            : [...c.subscriberUids, firebaseUser.uid];
          showToast(
            isSubbed ? 'Unsubscribed' : 'Subscribed!',
            isSubbed ? `Left ${c.name}` : `Receiving broadcasts from ${c.name}`,
            'info'
          );
          return { ...c, subscriberUids: nextSubs };
        }
        return c;
      })
    );
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      playClickSound();
      const isVideo = file.type.startsWith('video/');
      showToast(
        isVideo ? 'Encoding Video' : 'Compressing Media',
        `Preparing for ${momentQuality.toUpperCase()} profile...`,
        'info'
      );

      const processed = await processMediaWithQuality(file, momentQuality);
      const categoryType = isVideo ? 'videos' : 'images';
      const uploadResult = await uploadMediaToStorage(
        'moments',
        firebaseUser?.uid || 'feed',
        categoryType,
        momentQuality,
        processed.dataUrl
      );

      sound.playGlassSend();
      await postMoment(
        uploadResult.url,
        caption.trim() || (isVideo ? 'Video Moment' : 'Ephemeral Moment'),
        momentQuality,
        processed.thumbnailUrl,
        processed.type,
        {
          poll: buildOptionalPollPayload(),
          isPermanentFeed: isPermanent,
        }
      );
      setCapturedARFrame(null);
      setCaption('');
      setHasPoll(false);
      setPollQuestion('');
      setIsCreateOpen(false);
      showToast('Live on Feed', `Shared in ${momentQuality.toUpperCase()} quality`, 'success');
    } catch (err: any) {
      console.error(err);
      showToast('Upload Failed', err.message, 'error');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const formatStoryTime = (timestamp: number) => {
    const minutes = Math.floor((Date.now() - timestamp) / (1000 * 60));
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  return (
    <div
      data-testid="stories-feed-container"
      className="flex-1 flex flex-col overflow-hidden bg-[#EFEAD8] dark:bg-[#0F0F14] text-[#2B2533] dark:text-gray-100 relative select-none"
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        onChange={handleFileSelected}
        className="hidden"
      />

      {/* Floating 3D Navigation Header & Mode Segment */}
      <div className="px-3 pt-2 pb-1.5 shrink-0 z-20 space-y-2">
        <div className="glass-3d-panel rounded-2xl px-4 py-2 flex items-center justify-between shadow-sm">
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-black tracking-tight text-[#2B2533]">Stories & Feed</h1>
              <Sparkles className="w-4 h-4 text-[#7C5C9B]" />
            </div>
            <p className="text-[10px] text-[#6B6275]">Ephemeral Moments, Broadcaster Channels & AR</p>
          </div>

          <button
            onClick={() => {
              playClickSound();
              setIsCreateOpen(true);
            }}
            className="px-3 py-1.5 rounded-xl glass-purple-glow text-white flex items-center gap-1.5 text-xs font-bold shadow-md cursor-pointer elastic-tap"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Create</span>
          </button>
        </div>

        {/* 3-Way Segment Selector: Stories & Feed | Channels | AR Camera */}
        <div className="p-1 rounded-2xl glass-pod-ivory flex items-center border border-white/80 shadow-xs">
          <button
            onClick={() => {
              playClickSound();
              setActiveTabMode('feed');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTabMode === 'feed'
                ? 'glass-purple-glow text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Feed & Stories</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setActiveTabMode('channels');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTabMode === 'channels'
                ? 'glass-purple-glow text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Channels</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setActiveTabMode('ar_camera');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTabMode === 'ar_camera'
                ? 'glass-purple-glow text-white shadow-xs'
                : 'text-[#6B6275] hover:text-[#2B2533]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AR Camera</span>
          </button>
        </div>
      </div>

      {/* VIEWPORT MODE 1: STORIES & FEED */}
      {activeTabMode === 'feed' && (
        <div className="flex-1 overflow-y-auto px-3 py-1 space-y-3.5 no-scrollbar pb-24">
          {moments.length === 0 ? (
            <div className="py-20 text-center text-[#6B6275] text-xs">
              <div className="w-14 h-14 rounded-3xl glass-pod-ivory flex items-center justify-center mx-auto mb-3 shadow-md">
                <Sparkles className="w-7 h-7 text-[#7C5C9B]" />
              </div>
              <p className="font-bold text-[#2B2533] text-sm">No active moments</p>
              <p className="text-[11px] text-[#6B6275] mt-1">
                Be the first to share an ephemeral moment or tap AR Camera to shoot with 3D filters.
              </p>
            </div>
          ) : (
            moments.map((moment) => {
              const hasLiked = firebaseUser ? moment.likes.includes(firebaseUser.uid) : false;
              const isVideo = moment.mediaType === 'video' || moment.mediaUrl.endsWith('.mp4') || moment.mediaUrl.includes('/videos/');
              const activePoll = moment.poll || {
                question: 'Love this capture?',
                options: [
                  { text: '🔥 Love it!', votes: [] },
                  { text: '⚡️ Super cool', votes: [] },
                ],
              };
              const serverVoteIdx = firebaseUser
                ? activePoll.options.findIndex((o) => o.votes?.includes(firebaseUser.uid))
                : -1;
              const votedIndex = serverVoteIdx >= 0 ? serverVoteIdx : pollVotes[moment.id];
              const totalVotes = activePoll.options.reduce((sum, o) => sum + (o.votes?.length || 0), 0);
              const commentList =
                moment.comments && moment.comments.length > 0
                  ? moment.comments
                  : commentsMap[moment.id] || [];

              return (
                <div
                  key={moment.id}
                  className="rounded-3xl glass-3d-panel overflow-hidden shadow-lg border border-white/60 animate-in fade-in"
                >
                  {/* Author Header */}
                  <div className="p-3 flex items-center justify-between">
                    <div
                      onClick={() => {
                        playClickSound();
                        setViewingStoryId(moment.id);
                      }}
                      className="flex items-center gap-2.5 cursor-pointer group"
                    >
                      <div className="w-9 h-9 rounded-2xl overflow-hidden border-2 border-white shadow-sm">
                        <img
                          src={moment.ownerAvatar}
                          alt={moment.ownerName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-[#2B2533] group-hover:text-[#7C5C9B] transition-colors">
                          {moment.ownerName}
                        </p>
                        <p className="text-[10px] text-[#6B6275]">{formatStoryTime(moment.createdAt)}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {moment.mediaQuality && (
                        <span className="text-[9px] font-mono text-[#7C5C9B] font-bold">
                          {moment.mediaQuality.toUpperCase()}
                        </span>
                      )}
                      <span className="text-[10px] font-mono text-[#7C5C9B] font-semibold">
                        {moment.ownerSplenderId}
                      </span>
                    </div>
                  </div>

                  {/* Media Frame with Double-Tap to Like */}
                  <div
                    onDoubleClick={() => {
                      triggerHeartHaptic();
                      toggleLikeMoment(moment.id);
                      showToast('Liked Moment ❤️', undefined, 'info');
                    }}
                    onClick={() => {
                      playClickSound();
                      setViewingStoryId(moment.id);
                    }}
                    className="relative aspect-4/3 bg-[#E5DFCC] cursor-pointer overflow-hidden group"
                  >
                    {isVideo ? (
                      <video
                        src={moment.mediaUrl}
                        controls
                        playsInline
                        preload="metadata"
                        poster={moment.thumbnailUrl}
                        className="w-full h-full object-cover"
                        onClick={(e) => e.stopPropagation()}
                      />
                    ) : (
                      <div className="relative w-full h-full">
                        {moment.thumbnailUrl && (
                          <img
                            src={moment.thumbnailUrl}
                            alt="Preview blur"
                            className="absolute inset-0 w-full h-full object-cover filter blur-md scale-110 opacity-70"
                          />
                        )}
                        <img
                          src={moment.mediaUrl}
                          alt="Moment"
                          loading="lazy"
                          className="relative w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                        />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#2B2533]/60 via-transparent to-transparent pointer-events-none" />

                    <div className="absolute bottom-3 left-3 right-3 pointer-events-none">
                      <p className="text-xs text-white font-medium drop-shadow-md">
                        {moment.caption}
                      </p>
                    </div>
                  </div>

                  {/* Interactive Poll Component */}
                  <div className="p-3 border-t border-white/40 bg-white/30 space-y-2">
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#2B2533]">
                      <BarChart2 className="w-3.5 h-3.5 text-[#7C5C9B]" />
                      <span>Community Poll: {activePoll.question}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {activePoll.options.slice(0, 2).map((opt, optIdx) => {
                        const optVotes = opt.votes?.length || (votedIndex === optIdx ? 1 : 0);
                        const pct =
                          totalVotes > 0
                            ? Math.round(((opt.votes?.length || 0) / totalVotes) * 100)
                            : votedIndex === optIdx
                            ? 100
                            : 0;
                        return (
                          <button
                            key={optIdx}
                            onClick={() => handleVotePoll(moment.id, optIdx)}
                            className={`p-2 rounded-xl text-left border transition-all text-xs font-semibold cursor-pointer ${
                              votedIndex === optIdx
                                ? 'bg-[#7C5C9B] text-white border-[#7C5C9B] shadow-xs'
                                : 'bg-white/60 text-[#2B2533] border-white hover:bg-white'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className="truncate">{opt.text}</span>
                              {votedIndex !== undefined && (
                                <span className="font-mono text-[10px] shrink-0">{pct}% ({optVotes})</span>
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Action Bar & Reply comments trigger */}
                  <div className="p-3 flex items-center justify-between border-t border-white/40 bg-white/20">
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => {
                          triggerHeartHaptic();
                          toggleLikeMoment(moment.id);
                        }}
                        className={`flex items-center gap-1.5 text-xs font-bold cursor-pointer transition-colors elastic-tap ${
                          hasLiked ? 'text-[#A63A3A]' : 'text-[#6B6275] hover:text-[#A63A3A]'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${hasLiked ? 'fill-[#A63A3A]' : ''}`} />
                        <span>{moment.likes.length}</span>
                      </button>

                      <button
                        onClick={() => {
                          playClickSound();
                          setActiveCommentMoment(moment);
                        }}
                        className="flex items-center gap-1.5 text-xs text-[#6B6275] hover:text-[#7C5C9B] transition-colors cursor-pointer elastic-tap font-semibold"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>{commentList.length > 0 ? `${commentList.length} Comments` : 'Comment'}</span>
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        playClickSound();
                        showToast('Moment Link Copied', `splender://moment/${moment.id}`, 'info');
                      }}
                      className="text-[#6B6275] hover:text-[#2B2533] transition-colors cursor-pointer elastic-tap"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* VIEWPORT MODE 2: BROADCASTER CHANNELS */}
      {activeTabMode === 'channels' && (
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-3 no-scrollbar pb-24">
          <div className="p-3.5 rounded-2xl glass-pod-ivory border border-white/80 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-[#7C5C9B]/15 text-[#7C5C9B] flex items-center justify-center font-bold">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-[#2B2533]">Broadcaster Network</h3>
                <p className="text-[10px] text-[#6B6275]">High-throughput 1-to-Many verified streams</p>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold text-[#7C5C9B] bg-[#7C5C9B]/10 px-2 py-0.5 rounded-full">
              LIVE
            </span>
          </div>

          {channels.map((chan) => {
            const isSubscribed = firebaseUser ? chan.subscriberUids.includes(firebaseUser.uid) : false;
            return (
              <div
                key={chan.id}
                className="p-4 rounded-3xl glass-3d-panel border border-white/60 shadow-sm space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={chan.avatar}
                      alt={chan.name}
                      className="w-11 h-11 rounded-2xl object-cover border-2 border-white shadow-xs"
                    />
                    <div>
                      <div className="flex items-center gap-1">
                        <h4 className="text-xs font-black text-[#2B2533]">{chan.name}</h4>
                        {chan.isVerified && <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />}
                      </div>
                      <p className="text-[10px] text-[#6B6275]">{chan.subscriberUids.length + 142} Subscribers</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggleChannelSubscribe(chan.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                      isSubscribed
                        ? 'bg-white/80 text-[#2B2533] border border-white'
                        : 'glass-purple-glow text-white'
                    }`}
                  >
                    {isSubscribed ? <UserCheck className="w-3.5 h-3.5 text-emerald-600" /> : <UserPlus className="w-3.5 h-3.5" />}
                    <span>{isSubscribed ? 'Following' : 'Subscribe'}</span>
                  </button>
                </div>

                <p className="text-xs text-[#2B2533] leading-relaxed">
                  {chan.description}
                </p>

                {/* Latest Broadcast Message Card */}
                <div className="p-3 rounded-2xl bg-white/50 border border-white/70 space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#6B6275]">
                    <span className="font-bold text-[#7C5C9B]">LATEST BROADCAST</span>
                    <span>{formatStoryTime(chan.timestamp)}</span>
                  </div>
                  <p className="text-xs text-[#2B2533] font-medium leading-snug">
                    "{chan.lastUpdate}"
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEWPORT MODE 3: AR CAMERA ENGINE */}
      {activeTabMode === 'ar_camera' && (
        <div className="flex-1 flex flex-col relative overflow-hidden bg-black pb-20">
          <video ref={videoRef} playsInline muted className="hidden" />
          <canvas ref={canvasRef} className="w-full h-full object-cover" />

          {/* AR Filter Selection Carousel */}
          <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between">
            <div className="flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 text-white text-[10px] font-mono">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>AR ENGINE 60 FPS</span>
            </div>

            <button
              onClick={() => {
                playClickSound();
                setCameraFacing((prev) => (prev === 'user' ? 'environment' : 'user'));
              }}
              className="p-2 rounded-full bg-black/50 text-white backdrop-blur-md border border-white/20 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {/* Bottom AR Filter Pill Row & Shutter */}
          <div className="absolute bottom-6 left-0 right-0 z-30 flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar max-w-full px-4">
              {AR_FILTERS.map((f) => {
                const isSelected = selectedARFilter === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => {
                      playClickSound();
                      setSelectedARFilter(f.id);
                    }}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer border ${
                      isSelected
                        ? 'bg-white text-black border-white shadow-lg scale-105'
                        : 'bg-black/60 text-white border-white/30 backdrop-blur-md'
                    }`}
                  >
                    <span>{f.badge}</span>
                  </button>
                );
              })}
            </div>

            {/* Shutter Capture Button */}
            <button
              onClick={handleCaptureARSnapshot}
              className="w-16 h-16 rounded-full border-4 border-white p-1 flex items-center justify-center cursor-pointer active:scale-90 transition-transform shadow-2xl"
            >
              <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
                <Camera className="w-6 h-6 text-black" />
              </div>
            </button>
          </div>
        </div>
      )}

      {/* CREATE MOMENT / POST MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 bg-[#2B2533]/50 backdrop-blur-md flex flex-col justify-end">
          <div className="glass-3d-panel rounded-t-[32px] p-5 max-h-[92%] flex flex-col shadow-2xl bg-[#EFEAD8]/95 overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-bold text-[#2B2533]">Create Moment / Post</h3>
                <p className="text-xs text-[#6B6275]">Publish photo, video or AR capture to feed</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setIsCreateOpen(false);
                }}
                className="p-1 rounded-full text-[#6B6275] hover:text-[#2B2533] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quality Selector */}
            <div className="mb-3 space-y-1.5">
              <label className="text-[11px] font-bold text-[#6B6275] uppercase tracking-wider block">
                Encoding Quality Profile
              </label>
              <div className="grid grid-cols-2 gap-2">
                {MEDIA_QUALITY_OPTIONS.map((opt) => {
                  const isSelected = momentQuality === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setMomentQuality(opt.id);
                      }}
                      className={`p-2 rounded-xl text-left transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-white/90 border-[#7C5C9B] shadow-sm rainbow-glass-border'
                          : 'bg-white/40 border-white/60 hover:bg-white/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[11px] font-bold ${isSelected ? 'text-[#7C5C9B]' : 'text-[#2B2533]'}`}>
                          {opt.label.split(' ')[0]}
                        </span>
                        {isSelected && <Check className="w-3 h-3 text-[#7C5C9B] stroke-[3]" />}
                      </div>
                      <p className="text-[9px] text-[#6B6275] mt-0.5 truncate">{opt.imageSpec}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Caption Area */}
            <div className="mb-3">
              <label className="text-[11px] font-bold text-[#6B6275] uppercase tracking-wider mb-1 block">
                Caption or Thought
              </label>
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                rows={2}
                placeholder="Write a caption or commentary..."
                className="w-full glass-input-3d rounded-2xl p-3 text-xs text-[#2B2533] placeholder-[#6B6275] focus:outline-none focus:ring-1 focus:ring-[#7C5C9B] resize-none"
              />
            </div>

            {/* Attach Interactive Poll Toggle */}
            <div className="mb-4 p-3 rounded-2xl bg-white/40 border border-white/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#2B2533] flex items-center gap-1.5">
                  <BarChart2 className="w-4 h-4 text-[#7C5C9B]" />
                  <span>Attach Interactive Poll</span>
                </span>
                <input
                  type="checkbox"
                  checked={hasPoll}
                  onChange={(e) => setHasPoll(e.target.checked)}
                  className="w-4 h-4 accent-[#7C5C9B] rounded cursor-pointer"
                />
              </div>

              {hasPoll && (
                <div className="space-y-2 pt-1 text-xs">
                  <input
                    type="text"
                    value={pollQuestion}
                    onChange={(e) => setPollQuestion(e.target.value)}
                    placeholder="Poll Question (e.g. Which vibe do you prefer?)"
                    className="w-full px-3 py-1.5 rounded-xl bg-white/80 border border-white text-xs text-[#2B2533] focus:outline-none"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={pollOption1}
                      onChange={(e) => setPollOption1(e.target.value)}
                      placeholder="Option 1"
                      className="px-2.5 py-1.5 rounded-xl bg-white/80 border border-white text-xs text-[#2B2533] focus:outline-none"
                    />
                    <input
                      type="text"
                      value={pollOption2}
                      onChange={(e) => setPollOption2(e.target.value)}
                      placeholder="Option 2"
                      className="px-2.5 py-1.5 rounded-xl bg-white/80 border border-white text-xs text-[#2B2533] focus:outline-none"
                    />
                  </div>
                </div>
              )}
            </div>

            {capturedARFrame && (
              <div className="mb-3 rounded-2xl overflow-hidden border border-white/70 bg-black/80 relative">
                <img
                  src={capturedARFrame}
                  alt="Captured AR Frame"
                  className="w-full h-36 object-cover"
                />
                <button
                  type="button"
                  onClick={() => setCapturedARFrame(null)}
                  className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <div className="space-y-2">
              {capturedARFrame && (
                <button
                  type="button"
                  onClick={handlePublishCapturedAR}
                  disabled={isUploading}
                  className="w-full py-3 rounded-2xl bg-[#0F766E] text-white text-xs font-bold shadow-lg cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 elastic-tap"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isUploading ? 'Publishing AR Capture...' : 'Publish Captured AR Moment'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  fileInputRef.current?.click();
                }}
                disabled={isUploading}
                className="w-full py-3 rounded-2xl glass-purple-glow text-white text-xs font-bold shadow-lg cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 elastic-tap"
              >
                <Camera className="w-4 h-4" />
                <span>{isUploading ? 'Encoding & Publishing...' : `Select Media & Publish (${momentQuality.toUpperCase()})`}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COMMENTS BOTTOM SHEET */}
      {activeCommentMoment && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-[#EFEAD8] rounded-t-[32px] p-5 max-h-[70%] flex flex-col shadow-2xl border-t border-white/80">
            <div className="flex items-center justify-between pb-3 border-b border-black/5">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#7C5C9B]" />
                <h3 className="text-sm font-bold text-[#2B2533]">Comments & Replies</h3>
              </div>
              <button
                onClick={() => setActiveCommentMoment(null)}
                className="p-1 rounded-full text-[#6B6275] hover:text-[#2B2533] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Comments Stream */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 no-scrollbar">
              {(() => {
                const liveMoment = moments.find((m) => m.id === activeCommentMoment.id);
                const mergedComments =
                  liveMoment?.comments && liveMoment.comments.length > 0
                    ? liveMoment.comments
                    : commentsMap[activeCommentMoment.id] || [];
                return mergedComments.length === 0 ? (
                  <p className="text-center text-xs text-[#6B6275] py-6">
                    No comments yet. Be the first to spark the conversation! ✨
                  </p>
                ) : (
                  mergedComments.map((c) => (
                    <div key={c.id} className="flex items-start gap-2.5 bg-white/50 p-2.5 rounded-2xl border border-white/70">
                      <img src={c.userAvatar} alt={c.userName} className="w-7 h-7 rounded-xl object-cover" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-[#2B2533]">{c.userName}</span>
                          <span className="text-[9px] text-[#6B6275]">{formatStoryTime(c.createdAt)}</span>
                        </div>
                        <p className="text-xs text-[#2B2533] mt-0.5">{c.text}</p>
                      </div>
                    </div>
                  ))
                );
              })()}
            </div>

            {/* Quick Emoji Strip */}
            <div className="flex items-center justify-around py-1 border-t border-black/5 text-lg">
              {['❤️', '🔥', '👏', '⚡️', '🙌', '💯'].map((em) => (
                <button
                  key={em}
                  onClick={() => {
                    setCommentInput((prev) => prev + em);
                  }}
                  className="hover:scale-125 transition-transform cursor-pointer"
                >
                  {em}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddComment(activeCommentMoment.id);
                }}
                placeholder="Add a comment..."
                className="flex-1 bg-white/80 rounded-xl px-3 py-2 text-xs text-[#2B2533] focus:outline-none border border-white"
              />
              <button
                onClick={() => handleAddComment(activeCommentMoment.id)}
                className="p-2 rounded-xl glass-purple-glow text-white shadow-xs cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
