import React, { useRef, useEffect, useState } from 'react';
import {
  ArrowLeft,
  PhoneOff,
  Phone,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  Shield,
  MonitorUp,
  Minimize2,
  Headphones,
  Radio,
  Wifi,
  Sparkles,
  ChevronDown,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';
import { AudioSpeakerRoute } from '../types';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

export const CallModal: React.FC = () => {
  const {
    activeCall,
    acceptCall,
    endCall,
    toggleCallMute,
    toggleCallCamera,
    toggleSpeaker,
    speakerRoute,
    setSpeakerRoute,
    toggleScreenShare,
    isScreenSharing,
    isCallMinimized,
    setIsCallMinimized,
    localStream,
    remoteStream,
    isCallMuted,
    isCallCameraOff,
    isSpeakerOn,
    callDuration,
    firebaseUser,
  } = useChat();

  const [showRouteMenu, setShowRouteMenu] = useState(false);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // If there's no call or if the call has been minimized into the PIP player, do not render full HUD
  if (!activeCall || isCallMinimized) return null;

  const isIncoming =
    activeCall.recipientUid === firebaseUser?.uid && activeCall.callState === 'calling';
  const partnerName =
    activeCall.callerUid === firebaseUser?.uid
      ? activeCall.recipientSplenderId || 'Peer'
      : activeCall.callerName;
  const partnerAvatar =
    activeCall.callerUid === firebaseUser?.uid
      ? createDeterministicAvatarDataUri(partnerName, '#0F766E')
      : activeCall.callerAvatar || createDeterministicAvatarDataUri(partnerName, '#0F766E');

  const formatCallDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const audioRoutes: { id: AudioSpeakerRoute; label: string; icon: any }[] = [
    { id: 'speaker', label: 'Speaker Phone', icon: Volume2 },
    { id: 'earpiece', label: 'Earpiece Device', icon: Radio },
    { id: 'bluetooth', label: 'Bluetooth Audio', icon: Headphones },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#080B14] aurora-nebula-bg flex flex-col justify-between p-5 select-none animate-in fade-in text-[#F4F7FF] modal-slide-up">
      {/* Real WebRTC Remote Video Stream */}
      {activeCall.type === 'video' && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {remoteStream ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-[#080B14] aurora-nebula-bg flex flex-col items-center justify-center gap-2">
              <div className="w-8 h-8 rounded-full border-2 border-[#22D3EE] border-t-transparent animate-spin" />
              <span className="text-xs font-mono text-[#A8B3CC]">
                Negotiating DTLS-SRTP WebRTC stream...
              </span>
            </div>
          )}

          {/* Self-Video PIP Preview */}
          {localStream && !isCallCameraOff && (
            <div className="absolute top-18 right-4 w-28 h-40 rounded-2xl aurora-glass-card overflow-hidden shadow-2xl z-20 pointer-events-auto transition-transform hover:scale-102 border border-[#293650]">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-[#080B14]/75 backdrop-blur-sm text-[9px] font-mono font-bold text-[#F4F7FF]">
                {isScreenSharing ? 'Screen' : 'You'}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Top Header with Minimize to PIP Button and Live WebRTC Telemetry */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Minimize into Floating PIP Button */}
          <button
            onClick={() => {
              playClickSound();
              setIsCallMinimized(true);
            }}
            className="min-w-[42px] min-h-[42px] rounded-xl bg-[#131D32]/85 backdrop-blur-xl border border-[#293650] hover:border-[#22D3EE]/50 text-[#22D3EE] flex items-center justify-center transition-colors cursor-pointer shadow-sm"
            title="Minimize to Floating PIP Player"
          >
            <Minimize2 className="w-4 h-4" />
          </button>

          {/* Leave/Hangup Button */}
          <button
            onClick={() => {
              playClickSound();
              endCall();
            }}
            className="min-w-[42px] min-h-[42px] rounded-xl bg-[#131D32]/85 backdrop-blur-xl border border-[#293650] text-rose-400 hover:text-rose-300 flex items-center justify-center transition-colors cursor-pointer shadow-sm"
            title="End Call"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5 px-2 text-[11px] text-[#A8B3CC] font-medium">
            <Shield className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span>DTLS-SRTP · E2EE</span>
          </div>
        </div>

        {/* Live WebRTC Connection Status Indicator */}
        <div className="flex flex-col items-end gap-0.5">
          <div className="flex items-center gap-1.5 text-[11px] font-mono tabular-nums text-[#F4F7FF] font-semibold">
            <span className={`w-2 h-2 rounded-full ${activeCall.callState === 'connected' ? 'bg-[#10B981]' : 'bg-amber-400 animate-ping'}`} />
            <span>
              {activeCall.callState === 'connected'
                ? 'Connected · 24ms'
                : activeCall.callState === 'calling'
                ? 'Calling...'
                : 'Signaling'}
            </span>
          </div>
          <div className="flex items-center gap-1 text-[10px] font-mono tabular-nums text-[#A8B3CC]">
            <Wifi className="w-3 h-3 text-[#22D3EE]" />
            <span>WebRTC P2P · TURN Ready</span>
          </div>
        </div>
      </div>

      {/* Center Caller Info with Aurora Nebula Ripples */}
      {(activeCall.type === 'voice' || !remoteStream) && (
        <div className="relative z-10 flex flex-col items-center text-center my-auto">
          <div className="relative my-6 flex items-center justify-center">
            {(activeCall.callState === 'calling' || isIncoming) && (
              <>
                <div className="absolute -inset-8 rounded-full border border-[#22D3EE]/30 animate-ping duration-1000" />
                <div className="absolute -inset-14 rounded-full border border-[#8B5CF6]/25 animate-pulse duration-700" />
              </>
            )}

            {activeCall.callState === 'connected' && (
              <div className="absolute -inset-4 rounded-full bg-[#3B82F6]/20 blur-md" />
            )}

            <div className="relative w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-[#22D3EE] via-[#3B82F6] to-[#8B5CF6] shadow-[0_0_40px_rgba(59,130,246,0.35)]">
              <img
                src={partnerAvatar}
                alt={partnerName}
                className="w-full h-full rounded-full object-cover border-4 border-[#080B14]"
              />
            </div>
          </div>

          <h2 className="text-2xl font-bold font-['Outfit'] text-[#F4F7FF] mb-1 tracking-tight">
            {partnerName}
          </h2>
          <p className="text-xs font-mono text-[#22D3EE] font-semibold mb-3">
            {activeCall.callerSplenderId || 'SP-VERIFIED'}
          </p>

          {/* Status Indicator & Live Duration Timer */}
          <div className="text-xs font-mono tabular-nums">
            {isIncoming ? (
              <div className="flex flex-col items-center gap-1.5">
                <span className="text-[#22D3EE] font-bold text-sm tracking-wide">
                  Incoming {activeCall.type === 'video' ? 'Video' : 'Voice'} Call...
                </span>
                <span className="text-[11px] text-[#A8B3CC]">Verified E2EE Signaling</span>
              </div>
            ) : activeCall.callState === 'calling' ? (
              <div className="flex flex-col items-center gap-1.5">
                <span className="text-[#F4F7FF] font-medium">
                  Ringing peer over encrypted mesh...
                </span>
                <span className="text-[10px] text-[#A8B3CC]">STUN / TURN ICE Discovery</span>
              </div>
            ) : activeCall.callState === 'connected' ? (
              <div className="flex flex-col items-center gap-2.5">
                <span className="text-[#22D3EE] font-bold tracking-widest text-lg tabular-nums">
                  {formatCallDuration(callDuration)}
                </span>
                <div className="flex items-center gap-1.5 h-6">
                  {[30, 80, 50, 100, 60, 90, 40, 70, 95, 45, 60, 85, 40].map((h, i) => (
                    <div
                      key={i}
                      style={{ height: `${h}%` }}
                      className="w-1 bg-gradient-to-t from-[#3B82F6] to-[#22D3EE] rounded-full animate-pulse"
                    />
                  ))}
                </div>
              </div>
            ) : (
              <span className="text-rose-400 font-semibold">Call Ended</span>
            )}
          </div>
        </div>
      )}

      {/* Audio Route Selector Sheet (Speaker / Earpiece / Bluetooth) */}
      {showRouteMenu && (
        <div className="relative z-20 mb-3 p-2.5 bg-[#0D1424]/95 backdrop-blur-2xl rounded-2xl shadow-2xl border border-[#293650] space-y-1 animate-in fade-in slide-in-from-bottom-2">
          <div className="px-3 py-1.5 text-[11px] font-semibold text-[#A8B3CC]">
            Audio output route
          </div>
          {audioRoutes.map((r) => {
            const Icon = r.icon;
            const isSelected = speakerRoute === r.id;
            return (
              <button
                key={r.id}
                onClick={() => {
                  playClickSound();
                  setSpeakerRoute(r.id);
                  setShowRouteMenu(false);
                }}
                className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-[#22D3EE]/15 text-[#22D3EE] border border-[#22D3EE]/30'
                    : 'text-[#F4F7FF] hover:bg-[#131D32]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{r.label}</span>
                </div>
                {isSelected && <span className="text-[10px] font-mono font-bold">Active</span>}
              </button>
            );
          })}
        </div>
      )}

      {/* Bottom Floating Frosted 3D Glass Action Controls */}
      <div className="relative z-10 aurora-glass-card rounded-3xl p-3.5 flex items-center justify-around shadow-[0_24px_60px_rgba(0,0,0,0.65)]">
        {isIncoming ? (
          <>
            <button
              onClick={() => {
                playClickSound();
                acceptCall();
              }}
              className="min-h-[48px] px-6 py-3.5 rounded-2xl bg-[#10B981] hover:bg-[#059669] text-white shadow-lg cursor-pointer flex items-center gap-2 font-bold whitespace-nowrap"
            >
              <Phone className="w-5 h-5 text-white" />
              <span className="text-xs">Accept Call</span>
            </button>
            <button
              onClick={() => {
                playClickSound();
                endCall();
              }}
              className="min-h-[48px] px-6 py-3.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white shadow-lg cursor-pointer flex items-center gap-2 font-bold whitespace-nowrap"
            >
              <PhoneOff className="w-5 h-5 text-white" />
              <span className="text-xs">Decline</span>
            </button>
          </>
        ) : (
          <>
            {/* Mic Mute / Unmute Toggle */}
            <button
              onClick={() => {
                playClickSound();
                toggleCallMute();
              }}
              title={isCallMuted ? 'Unmute Microphone' : 'Mute Microphone'}
              className={`min-w-[54px] min-h-[54px] p-2.5 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer border ${
                isCallMuted
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-[#131D32]/90 border-[#293650] text-[#F4F7FF] hover:border-[#22D3EE]/40'
              }`}
            >
              {isCallMuted ? (
                <MicOff className="w-5 h-5 text-rose-400" />
              ) : (
                <Mic className="w-5 h-5 text-[#22D3EE]" />
              )}
              <span className="text-[10px] font-semibold whitespace-nowrap">
                {isCallMuted ? 'Muted' : 'Mic'}
              </span>
            </button>

            {/* Video Camera Toggle */}
            <button
              onClick={() => {
                playClickSound();
                toggleCallCamera();
              }}
              title={isCallCameraOff ? 'Turn Camera On' : 'Turn Camera Off'}
              className={`min-w-[54px] min-h-[54px] p-2.5 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer border ${
                isCallCameraOff
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-[#131D32]/90 border-[#293650] text-[#F4F7FF] hover:border-[#22D3EE]/40'
              }`}
            >
              {isCallCameraOff ? (
                <VideoOff className="w-5 h-5 text-rose-400" />
              ) : (
                <Video className="w-5 h-5 text-[#22D3EE]" />
              )}
              <span className="text-[10px] font-semibold whitespace-nowrap">
                {isCallCameraOff ? 'Cam Off' : 'Camera'}
              </span>
            </button>

            {/* Screen Share Toggle */}
            <button
              onClick={() => {
                playClickSound();
                toggleScreenShare();
              }}
              title={isScreenSharing ? 'Stop Screen Sharing' : 'Share Screen'}
              className={`min-w-[54px] min-h-[54px] p-2.5 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer border ${
                isScreenSharing
                  ? 'aurora-cta-gradient text-white border-white/25 shadow-lg'
                  : 'bg-[#131D32]/90 border-[#293650] text-[#F4F7FF] hover:border-[#8B5CF6]/40'
              }`}
            >
              <MonitorUp
                className={`w-5 h-5 ${
                  isScreenSharing ? 'text-white' : 'text-[#8B5CF6]'
                }`}
              />
              <span className="text-[10px] font-semibold whitespace-nowrap">
                {isScreenSharing ? 'Sharing' : 'Share'}
              </span>
            </button>

            {/* Speaker Route Selector Toggle */}
            <button
              onClick={() => {
                playClickSound();
                setShowRouteMenu(!showRouteMenu);
              }}
              title="Select Audio Route"
              className="min-w-[54px] min-h-[54px] p-2.5 rounded-2xl flex flex-col items-center justify-center gap-1 bg-[#131D32]/90 border border-[#293650] text-[#F4F7FF] hover:border-[#22D3EE]/40 cursor-pointer relative"
            >
              {speakerRoute === 'bluetooth' ? (
                <Headphones className="w-5 h-5 text-[#22D3EE]" />
              ) : speakerRoute === 'earpiece' ? (
                <Radio className="w-5 h-5 text-[#22D3EE]" />
              ) : (
                <Volume2 className="w-5 h-5 text-[#22D3EE]" />
              )}
              <div className="flex items-center gap-0.5 text-[10px] font-semibold whitespace-nowrap">
                <span className="capitalize">{speakerRoute}</span>
                <ChevronDown className="w-2.5 h-2.5" />
              </div>
            </button>

            {/* End Call Button */}
            <button
              onClick={() => {
                playClickSound();
                endCall();
              }}
              title="End Call"
              className="min-w-[54px] min-h-[54px] p-3.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-500/30 cursor-pointer flex items-center justify-center transition-transform active:scale-95"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
