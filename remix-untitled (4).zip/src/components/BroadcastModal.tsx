import React, { useState } from 'react';
import {
  X,
  Radio,
  Check,
  Send,
  Users,
  Image as ImageIcon,
  Sparkles,
  Info,
  CheckSquare,
  Square,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound } from '../lib/sound';

interface BroadcastModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BroadcastModal: React.FC<BroadcastModalProps> = ({ isOpen, onClose }) => {
  const { contacts, sendBroadcastMessage, showToast } = useChat();
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [mediaUrlInput, setMediaUrlInput] = useState('');
  const [showMediaInput, setShowMediaInput] = useState(false);
  const [isSending, setIsSending] = useState(false);

  if (!isOpen) return null;

  const acceptedContacts = contacts.filter((c) => c.state === 'accepted');

  const handleSelectAll = () => {
    playClickSound();
    if (selectedParticipants.length === acceptedContacts.length) {
      setSelectedParticipants([]);
    } else {
      setSelectedParticipants(acceptedContacts.map((c) => c.targetUid));
    }
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) {
      showToast('Message Required', 'Please enter a message to broadcast', 'warning');
      return;
    }
    if (selectedParticipants.length === 0) {
      showToast('Select Recipients', 'Choose at least 1 contact for this broadcast', 'warning');
      return;
    }

    setIsSending(true);
    playClickSound();

    try {
      await sendBroadcastMessage(
        selectedParticipants,
        broadcastMessage.trim(),
        mediaUrlInput.trim() || undefined
      );
      onClose();
      setBroadcastMessage('');
      setMediaUrlInput('');
      setSelectedParticipants([]);
    } catch {
      showToast('Broadcast Failed', 'Could not dispatch broadcast', 'error');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in select-none">
      <form
        onSubmit={handleSendBroadcast}
        className="w-full max-w-sm rounded-3xl bg-[#FFFFFF] dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 p-5 shadow-2xl modal-slide-up space-y-4 text-[#111B21] dark:text-[#E9EDEF]"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-[#008069] dark:text-[#25D366]" />
            <div>
              <h3 className="text-sm font-bold">Broadcast Message</h3>
              <span className="text-[10px] text-slate-400 font-mono block">
                Deliver to multiple recipients independently
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 text-[11px] text-emerald-800 dark:text-emerald-300 flex items-start gap-2">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
          <span>
            Recipients receive your broadcast as individual 1-on-1 private messages without seeing each other.
          </span>
        </div>

        {/* Recipients Picker with Select All */}
        <div>
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 mb-1.5">
            <span>Recipients ({selectedParticipants.length})</span>
            <button
              type="button"
              onClick={handleSelectAll}
              className="text-[#008069] dark:text-[#25D366] text-[11px] hover:underline cursor-pointer font-semibold"
            >
              {selectedParticipants.length === acceptedContacts.length ? 'Clear All' : 'Select All'}
            </button>
          </div>

          <div className="max-h-40 overflow-y-auto no-scrollbar space-y-1 border border-slate-100 dark:border-slate-800 rounded-xl p-1 bg-slate-50/50 dark:bg-slate-900/40">
            {acceptedContacts.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">No verified contacts available</p>
            ) : (
              acceptedContacts.map((c) => {
                const isSelected = selectedParticipants.includes(c.targetUid);
                return (
                  <div
                    key={c.targetUid}
                    onClick={() => {
                      setSelectedParticipants((prev) =>
                        prev.includes(c.targetUid)
                          ? prev.filter((id) => id !== c.targetUid)
                          : [...prev, c.targetUid]
                      );
                    }}
                    className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                      isSelected
                        ? 'border-[#008069] bg-[#E7FCE8]/50 dark:bg-[#103629]/50'
                        : 'border-transparent hover:bg-slate-100/50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <img src={c.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold truncate">{c.displayName}</p>
                        <p className="text-[9px] text-slate-400 font-mono truncate">{c.splenderId}</p>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        isSelected ? 'border-[#008069] bg-[#008069]' : 'border-slate-400'
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Message Composition Input */}
        <div>
          <label className="text-xs font-bold text-slate-500 mb-1 block">Broadcast Text</label>
          <textarea
            value={broadcastMessage}
            onChange={(e) => setBroadcastMessage(e.target.value)}
            placeholder="Type message to broadcast to all recipients..."
            rows={3}
            required
            className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 focus:border-[#008069] resize-none"
          />
        </div>

        {/* Optional Media Attachment */}
        <div>
          <button
            type="button"
            onClick={() => setShowMediaInput(!showMediaInput)}
            className="text-[11px] font-semibold text-[#008069] dark:text-[#25D366] flex items-center gap-1.5 cursor-pointer"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>{showMediaInput ? 'Hide Image Link' : '+ Attach Image Link'}</span>
          </button>

          {showMediaInput && (
            <input
              type="url"
              value={mediaUrlInput}
              onChange={(e) => setMediaUrlInput(e.target.value)}
              placeholder="https://example.com/image.jpg"
              className="w-full mt-1.5 px-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 focus:border-[#008069]"
            />
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!broadcastMessage.trim() || selectedParticipants.length === 0 || isSending}
          className="w-full py-2.5 rounded-xl bg-[#008069] hover:bg-[#00705c] dark:bg-[#25D366] dark:hover:bg-[#20bd5a] text-white dark:text-[#111B21] font-bold text-xs disabled:opacity-40 transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-md"
        >
          {isSending ? (
            <>
              <div className="w-3.5 h-3.5 rounded-full border-2 border-white dark:border-black border-t-transparent animate-spin" />
              <span>Dispatching Messages...</span>
            </>
          ) : (
            <>
              <Send className="w-3.5 h-3.5" />
              <span>Send Broadcast ({selectedParticipants.length})</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
