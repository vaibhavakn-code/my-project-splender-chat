import React from 'react';
import { useChat } from '../context/ChatContext';
import { Message } from '../types';
import { RichMarkdownRenderer } from './RichMarkdownRenderer';
import { HapticsService } from '../services/HapticsService';

interface MessageBubbleProps {
  message: Message;
  isOutgoing?: boolean;
  highlightQuery?: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isOutgoing = false,
  highlightQuery,
}) => {
  const { copyToClipboard, copiedId } = useChat();
  const isCopied = copiedId === message.text;

  return (
    <div
      className={`relative group p-3 rounded-2xl spring-bubble my-2 max-w-[85%] ${
        isOutgoing ? 'glass-bubble-me ml-auto' : 'glass-bubble-peer'
      }`}
    >
      {message.text && (
        <RichMarkdownRenderer
          text={message.text}
          isOutgoing={isOutgoing}
          highlightQuery={highlightQuery}
          fontSizePx={13}
        />
      )}

      {/* Single-Click Copy Action Bar */}
      <div
        className={`flex items-center justify-between mt-1.5 pt-1 border-t text-xs font-mono tabular-nums ${
          isOutgoing
            ? 'border-white/15 text-white/80'
            : 'border-slate-200/70 dark:border-[#293650] text-slate-500 dark:text-[#A8B3CC]'
        }`}
      >
        <span>
          {typeof message.timestamp === 'number'
            ? new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            : message.timestamp}
        </span>
        <button
          type="button"
          onClick={() => {
            void HapticsService.tapLight();
            if (message.text) copyToClipboard(message.text);
          }}
          className={`flex items-center gap-1 px-2 py-0.5 rounded-md transition-colors text-[11px] font-medium cursor-pointer whitespace-nowrap ${
            isOutgoing
              ? 'bg-white/15 hover:bg-white/25 text-white'
              : 'bg-slate-100 dark:bg-[#0D1424] hover:bg-slate-200 dark:hover:bg-[#192642] text-slate-700 dark:text-[#F4F7FF]'
          }`}
          title="Single click to copy text"
        >
          {isCopied ? (
            <span className="text-[#10B981] dark:text-[#22D3EE] font-semibold">Copied</span>
          ) : (
            <span>Copy</span>
          )}
        </button>
      </div>
    </div>
  );
};
