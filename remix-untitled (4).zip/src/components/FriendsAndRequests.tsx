import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Check,
  X,
  Phone,
  MessageSquare,
  QrCode,
  UserCheck,
  Settings,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { UserProfile } from '../types';
import { sound } from '../lib/sound';

export const FriendsAndRequests: React.FC = () => {
  const {
    contacts,
    acceptContactRequest,
    declineContactRequest,
    searchUserBySplenderOrUsername,
    sendContactRequest,
    startDirectConversation,
    startCall,
    setViewingUserId,
    setIsQrScannerOpen,
    setIsSettingsModalOpen,
    showToast,
  } = useChat();

  const [segment, setSegment] = useState<'friends' | 'requests'>('friends');
  const [searchQuery, setSearchQuery] = useState('');
  const [addInput, setAddInput] = useState('');
  const [isSearchingUser, setIsSearchingUser] = useState(false);
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const acceptedFriends = contacts.filter((c) => c.state === 'accepted');
  const incomingRequests = contacts.filter((c) => c.state === 'pending' && c.isIncoming);

  const filteredFriends = acceptedFriends.filter((f) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      f.displayName.toLowerCase().includes(q) ||
      f.username.toLowerCase().includes(q) ||
      f.splenderId.toLowerCase().includes(q)
    );
  });

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addInput.trim()) return;
    sound.triggerInteraction();
    setIsSearchingUser(true);
    setFoundUser(null);
    try {
      const user = await searchUserBySplenderOrUsername(addInput.trim());
      if (user) {
        setFoundUser(user);
      } else {
        showToast('Peer Not Found', 'No user found matching this Splender ID or @username', 'warning');
      }
    } finally {
      setIsSearchingUser(false);
    }
  };

  const handleSendInvite = async () => {
    if (!foundUser) return;
    sound.playGlassSend();
    await sendContactRequest(foundUser);
    setFoundUser(null);
    setAddInput('');
    setShowAddForm(false);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#080B14] aurora-nebula-bg text-[#F4F7FF] relative">
      {/* Header Toolbar */}
      <div className="px-3.5 pt-2.5 pb-1.5 shrink-0 z-20">
        <div className="aurora-glass-card rounded-2xl px-4 py-2.5 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-base font-semibold tracking-tight font-['Outfit'] text-[#F4F7FF] truncate">
              Contacts
            </h1>
            <p className="text-xs text-[#A8B3CC] truncate">
              Verified P2P Directory · {acceptedFriends.length} Peers
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                sound.triggerInteraction();
                setIsSettingsModalOpen(true);
              }}
              title="Settings"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF] hover:border-[#22D3EE]/50 transition-colors cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                sound.triggerInteraction();
                setIsQrScannerOpen(true);
              }}
              title="Scan Peer QR"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-[#131D32] border border-[#293650] text-[#22D3EE] hover:border-[#22D3EE]/50 transition-colors cursor-pointer"
            >
              <QrCode className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                sound.triggerInteraction();
                setShowAddForm(!showAddForm);
              }}
              className="min-h-[40px] px-3.5 py-2 rounded-xl aurora-cta-gradient text-white transition-transform active:scale-[0.98] cursor-pointer flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap shrink-0"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add Contact Search Accordion */}
      {showAddForm && (
        <div className="px-3.5 pb-2 animate-in fade-in shrink-0 z-20">
          <div className="aurora-glass-card rounded-2xl p-4 space-y-3">
            <form onSubmit={handleSearchSubmit}>
              <p className="text-xs font-semibold text-[#F4F7FF] mb-0.5">Find Peer</p>
              <p className="text-xs text-[#A8B3CC] mb-2.5">
                Enter exact Splender ID (e.g. SP-492817) or @username. No phonebook contacts uploaded.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={addInput}
                  onChange={(e) => setAddInput(e.target.value)}
                  placeholder="SP-XXXXXX or @username"
                  className="flex-1 bg-[#080B14] border border-[#293650] rounded-xl px-3.5 py-2 text-xs text-[#F4F7FF] placeholder-[#A8B3CC]/60 focus:outline-none focus:border-[#22D3EE] font-mono"
                />
                <button
                  type="submit"
                  disabled={isSearchingUser}
                  className="px-4 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  {isSearchingUser ? 'Searching...' : 'Search'}
                </button>
              </div>
            </form>

            {/* Search Result Card */}
            {foundUser && (
              <div className="p-3 rounded-2xl bg-[#131D32] border border-[#22D3EE]/40 flex items-center justify-between gap-3 animate-in zoom-in-95">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={foundUser.avatar}
                    alt={foundUser.displayName}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-[#293650]"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-[#F4F7FF] truncate">{foundUser.displayName}</p>
                    <p className="text-[11px] font-mono tabular-nums text-[#22D3EE] truncate">
                      {foundUser.splenderId} · @{foundUser.username}
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleSendInvite}
                  className="px-3.5 py-2 rounded-xl aurora-cta-gradient text-white font-semibold text-xs cursor-pointer whitespace-nowrap shrink-0"
                >
                  Send Request
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Interactive Segment Control */}
      <div className="px-3.5 py-1.5 shrink-0">
        <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0D1424] border border-[#293650]">
          <button
            onClick={() => {
              sound.triggerInteraction();
              setSegment('friends');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap ${
              segment === 'friends'
                ? 'bg-[#131D32] text-[#F4F7FF] border border-[#293650]'
                : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span className="tabular-nums">Contacts ({acceptedFriends.length})</span>
          </button>

          <button
            onClick={() => {
              sound.triggerInteraction();
              setSegment('requests');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap ${
              segment === 'requests'
                ? 'bg-[#131D32] text-[#F4F7FF] border border-[#293650]'
                : 'text-[#A8B3CC] hover:text-[#F4F7FF]'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-[#8B5CF6]" />
            <span className="tabular-nums">
              Requests{incomingRequests.length > 0 ? ` (${incomingRequests.length})` : ''}
            </span>
          </button>
        </div>
      </div>

      {/* Search Bar for Existing Contacts */}
      {segment === 'friends' && (
        <div className="px-3.5 py-1 shrink-0">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-[#A8B3CC] absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter contacts by name or Splender ID..."
              className="w-full bg-[#0D1424] border border-[#293650] rounded-xl pl-9 pr-3 py-2 text-xs text-[#F4F7FF] placeholder-[#A8B3CC]/65 focus:outline-none focus:border-[#22D3EE]"
            />
          </div>
        </div>
      )}

      {/* Contacts & Requests List */}
      <div className="flex-1 overflow-y-auto px-3.5 py-2 space-y-2 no-scrollbar">
        {segment === 'friends' ? (
          filteredFriends.length === 0 ? (
            <div className="text-center py-12 text-[#A8B3CC] text-xs">
              No contacts found. Tap Add above to discover peers by Splender ID or @username.
            </div>
          ) : (
            filteredFriends.map((friend) => (
              <div
                key={friend.targetUid}
                className="p-3 rounded-2xl bg-[#0D1424]/90 border border-[#293650] hover:border-[#8B5CF6]/50 flex items-center justify-between gap-3 transition-colors"
              >
                <div
                  onClick={() => {
                    sound.triggerInteraction();
                    setViewingUserId(friend.targetUid);
                  }}
                  className="flex items-center gap-3 cursor-pointer min-w-0 flex-1"
                >
                  <div className="p-[1.5px] rounded-full bg-gradient-to-tr from-[#22D3EE]/70 to-[#8B5CF6]/70 shrink-0">
                    <img
                      src={friend.avatar}
                      alt={friend.displayName}
                      referrerPolicy="no-referrer"
                      className="w-11 h-11 rounded-full object-cover border border-[#080B14]"
                    />
                  </div>

                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[#F4F7FF] truncate">
                      {friend.displayName}
                    </p>
                    <p className="text-xs font-mono tabular-nums text-[#22D3EE] truncate">
                      {friend.splenderId}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      sound.triggerInteraction();
                      startDirectConversation({
                        uid: friend.targetUid,
                        splenderId: friend.splenderId,
                        displayName: friend.displayName,
                        avatar: friend.avatar,
                      });
                    }}
                    title="Send Message"
                    className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl aurora-cta-gradient text-white transition-transform active:scale-95 cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      sound.triggerInteraction();
                      startCall(friend.targetUid, friend.displayName, friend.avatar, 'voice');
                    }}
                    title="Voice Call"
                    className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-[#131D32] border border-[#293650] text-[#22D3EE] hover:border-[#22D3EE]/60 transition-colors cursor-pointer"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )
        ) : incomingRequests.length === 0 ? (
          <div className="text-center py-16 text-[#A8B3CC] text-xs">
            <UserCheck className="w-8 h-8 mx-auto mb-2.5 text-[#8B5CF6]" />
            <p className="font-semibold text-[#F4F7FF] text-sm">No pending connection requests</p>
            <p className="text-xs text-[#A8B3CC] mt-1">
              Share your Splender ID or QR code with peers to connect securely.
            </p>
          </div>
        ) : (
          incomingRequests.map((req) => (
            <div
              key={req.targetUid}
              className="p-4 rounded-2xl bg-[#0D1424]/95 border border-[#293650] space-y-3"
            >
              <div className="flex items-center gap-3">
                <img
                  src={req.avatar}
                  alt={req.displayName}
                  referrerPolicy="no-referrer"
                  className="w-11 h-11 rounded-full object-cover border border-[#293650]"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[#F4F7FF] truncate">{req.displayName}</p>
                  <p className="text-xs font-mono tabular-nums text-[#22D3EE]">{req.splenderId}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => {
                    sound.playGlassSend();
                    acceptContactRequest(req);
                  }}
                  className="flex-1 min-h-[40px] py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" /> Accept
                </button>
                <button
                  onClick={() => {
                    sound.triggerInteraction();
                    declineContactRequest(req);
                  }}
                  className="flex-1 min-h-[40px] py-2 rounded-xl bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF] text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" /> Decline
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
