import React, { useState, useEffect } from 'react';
import {
  HardDrive,
  X,
  Trash2,
  CheckCircle2,
  Play,
  Pause,
  Upload,
  ArrowRight,
  ShieldCheck,
  Zap,
  RefreshCw,
  FolderOpen,
  PieChart,
  FileCode,
  Sparkles,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

interface P2PTransferItem {
  id: string;
  name: string;
  sizeGB: number;
  progressPercent: number;
  speedMBs: number;
  status: 'transferring' | 'paused' | 'completed' | 'verifying';
  peer: string;
  checksum: string;
}

export const P2PStorageCleanupModal: React.FC = () => {
  const {
    isP2PStorageDashboardOpen,
    setIsP2PStorageDashboardOpen,
    storageBreakdown,
    cleanStorageCategory,
    conversations,
    showToast,
  } = useChat();

  const [activeTab, setActiveTab] = useState<'transfers' | 'insights' | 'cleanup' | 'chats'>('transfers');

  // Simulated & active 1GB+ P2P transfers
  const [transfers, setTransfers] = useState<P2PTransferItem[]>([
    {
      id: 'xfer_1gb_01',
      name: 'Quantum_Dataset_Encrypted_Archive.iso',
      sizeGB: 1.85,
      progressPercent: 78,
      speedMBs: 16.4,
      status: 'transferring',
      peer: 'Sophia Vance (Peer Node #4)',
      checksum: 'sha256:7f8a9e...2a1b',
    },
    {
      id: 'xfer_1gb_02',
      name: 'Splender_ColdStorage_Backup_2026.tar.gz',
      sizeGB: 2.45,
      progressPercent: 100,
      speedMBs: 0,
      status: 'completed',
      peer: 'Alex Walker (P2P Mesh)',
      checksum: 'sha256:3d9c8b...e901',
    },
    {
      id: 'xfer_1gb_03',
      name: 'Cinematic_ProRes_Master_4K.mov',
      sizeGB: 1.28,
      progressPercent: 42,
      speedMBs: 18.2,
      status: 'transferring',
      peer: 'Marcus Chen',
      checksum: 'sha256:1a2b3c...4d5e',
    },
  ]);

  // Live progress simulation for active transfers
  useEffect(() => {
    if (!isP2PStorageDashboardOpen) return;

    const interval = setInterval(() => {
      setTransfers((prev) =>
        prev.map((item) => {
          if (item.status === 'transferring') {
            const nextPercent = Math.min(100, item.progressPercent + 1);
            const isFinished = nextPercent >= 100;
            return {
              ...item,
              progressPercent: nextPercent,
              status: isFinished ? 'completed' : 'transferring',
              speedMBs: isFinished ? 0 : Number((14 + Math.random() * 5).toFixed(1)),
            };
          }
          return item;
        })
      );
    }, 1200);

    return () => clearInterval(interval);
  }, [isP2PStorageDashboardOpen]);

  if (!isP2PStorageDashboardOpen) return null;

  const togglePause = (id: string) => {
    playClickSound();
    setTransfers((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextStatus = t.status === 'transferring' ? 'paused' : 'transferring';
          return {
            ...t,
            status: nextStatus,
            speedMBs: nextStatus === 'paused' ? 0 : 15.5,
          };
        }
        return t;
      })
    );
  };

  const removeTransfer = (id: string) => {
    playPopSound();
    setTransfers((prev) => prev.filter((t) => t.id !== id));
    showToast('Transfer Removed', 'Transfer session removed from active queue', 'info');
  };

  const addSimulated1GBTransfer = () => {
    playPopSound();
    const newId = `xfer_${Date.now()}`;
    const newItem: P2PTransferItem = {
      id: newId,
      name: `HighSpeed_Dataset_Slice_${Math.floor(Math.random() * 900 + 100)}.bundle`,
      sizeGB: Number((1.1 + Math.random() * 1.5).toFixed(2)),
      progressPercent: 5,
      speedMBs: 19.2,
      status: 'transferring',
      peer: 'Active Direct P2P Channel',
      checksum: `sha256:${Math.random().toString(36).substring(2, 10)}...`,
    };
    setTransfers([newItem, ...transfers]);
    showToast('1GB+ P2P Transfer Started', `${newItem.name} (${newItem.sizeGB} GB)`, 'success');
  };

  const totalUsedGB = (storageBreakdown.totalUsed / 1024).toFixed(2);
  const totalFreeGB = (storageBreakdown.totalFree / 1024).toFixed(2);
  const capacityGB = (65536 / 1024).toFixed(0);
  const usedPercent = Math.min(100, Math.round((storageBreakdown.totalUsed / 65536) * 100));

  return (
    <div
      onClick={() => setIsP2PStorageDashboardOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-4 bg-black/75 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-3xl bg-white dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden modal-slide-up text-slate-800 dark:text-slate-100"
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-600 text-white shrink-0">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-white/20">
                <HardDrive className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-sm font-black tracking-tight leading-tight">
                  P2P Storage & Cleanup
                </h3>
                <p className="text-[11px] text-white/80 font-medium">
                  1GB+ WebRTC chunked pipeline & storage insights
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                playClickSound();
                setIsP2PStorageDashboardOpen(false);
              }}
              className="p-1.5 rounded-full hover:bg-white/20 text-white/90 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Storage Meter Bar in Header */}
          <div className="pt-1 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-white/95">{totalUsedGB} GB Used</span>
              <span className="text-white/80">{totalFreeGB} GB Free / {capacityGB} GB</span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/20 overflow-hidden shadow-inner">
              <div
                style={{ width: `${usedPercent}%` }}
                className="h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full transition-all duration-500"
              />
            </div>
          </div>
        </div>

        {/* Tab Selector Segment */}
        <div className="px-3 pt-2.5 pb-1 flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 shrink-0 bg-slate-50 dark:bg-slate-900/40 text-xs overflow-x-auto no-scrollbar">
          {[
            { id: 'transfers', label: '1GB+ Transfers', count: transfers.length },
            { id: 'insights', label: 'Storage Insights' },
            { id: 'cleanup', label: 'Cleanup Panel' },
            { id: 'chats', label: 'Per-Chat Storage' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playClickSound();
                setActiveTab(tab.id as any);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4 no-scrollbar">
          {/* TAB 1: 1GB+ P2P File Transfers */}
          {activeTab === 'transfers' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    Active 1GB+ WebRTC Transfers
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Direct browser-to-browser P2P chunking (64KB packets)
                  </p>
                </div>
                <button
                  onClick={addSimulated1GBTransfer}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Send 1GB+ File</span>
                </button>
              </div>

              {transfers.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
                  <HardDrive className="w-8 h-8 mx-auto text-slate-400" />
                  <p className="text-xs font-bold">No active P2P transfers</p>
                  <p className="text-[11px] text-slate-500">
                    Send large files (1GB+) directly to any peer with zero cloud storage limits.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {transfers.map((item) => {
                    const transferredGB = ((item.sizeGB * item.progressPercent) / 100).toFixed(2);
                    return (
                      <div
                        key={item.id}
                        className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-2.5 transition-all"
                      >
                        {/* Title & Status */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-xs font-bold truncate text-slate-900 dark:text-slate-100">
                              {item.name}
                            </p>
                            <div className="flex items-center gap-2 text-[10px] text-slate-500 dark:text-slate-400 pt-0.5">
                              <span>Peer: {item.peer}</span>
                              <span>•</span>
                              <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                                {item.status === 'completed'
                                  ? 'Verified'
                                  : item.status === 'paused'
                                  ? 'Paused'
                                  : `${item.speedMBs} MB/s`}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {item.status !== 'completed' && (
                              <button
                                onClick={() => togglePause(item.id)}
                                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                                title={item.status === 'paused' ? 'Resume transfer' : 'Pause transfer'}
                              >
                                {item.status === 'paused' ? (
                                  <Play className="w-3.5 h-3.5" />
                                ) : (
                                  <Pause className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                            <button
                              onClick={() => removeTransfer(item.id)}
                              className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                              title="Cancel & delete transfer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Progress Bar & Numerical Gauge */}
                        <div className="space-y-1">
                          <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                            <div
                              style={{ width: `${item.progressPercent}%` }}
                              className={`h-full rounded-full transition-all duration-300 ${
                                item.status === 'completed'
                                  ? 'bg-emerald-500'
                                  : item.status === 'paused'
                                  ? 'bg-amber-400'
                                  : 'bg-gradient-to-r from-blue-500 to-indigo-600'
                              }`}
                            />
                          </div>

                          <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400">
                            <span>
                              {transferredGB} GB / {item.sizeGB} GB ({item.progressPercent}%)
                            </span>
                            <span className="flex items-center gap-1 text-[9px]">
                              <ShieldCheck className="w-3 h-3 text-emerald-500" />
                              <span>{item.checksum}</span>
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Storage Insights */}
          {activeTab === 'insights' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <PieChart className="w-4 h-4 text-indigo-500" />
                  <span>Partition Footprint Breakdown</span>
                </h4>

                <div className="space-y-2 text-xs">
                  {/* Category 1: 1GB+ P2P Large Transfers */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700 dark:text-slate-200">
                        📦 1GB+ P2P Large Files
                      </span>
                      <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                        {(storageBreakdown.files / 1024).toFixed(2)} GB
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div
                        style={{ width: `${(storageBreakdown.files / storageBreakdown.totalUsed) * 100}%` }}
                        className="h-full bg-blue-500 rounded-full"
                      />
                    </div>
                  </div>

                  {/* Category 2: Media (Images & Videos) */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700 dark:text-slate-200">
                        🎬 Photos & Video Media
                      </span>
                      <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                        {(storageBreakdown.media / 1024).toFixed(2)} GB
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div
                        style={{ width: `${(storageBreakdown.media / storageBreakdown.totalUsed) * 100}%` }}
                        className="h-full bg-indigo-500 rounded-full"
                      />
                    </div>
                  </div>

                  {/* Category 3: Audio & Voice Notes */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700 dark:text-slate-200">
                        🎙️ Voice Notes & Audio
                      </span>
                      <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                        {storageBreakdown.audio} MB
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div
                        style={{ width: `${(storageBreakdown.audio / storageBreakdown.totalUsed) * 100}%` }}
                        className="h-full bg-amber-500 rounded-full"
                      />
                    </div>
                  </div>

                  {/* Category 4: Cache & Temp Chunks */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700 dark:text-slate-200">
                        ⚡ WebRTC Slices & Cache
                      </span>
                      <span className="font-mono font-bold text-rose-500">
                        {storageBreakdown.cache} MB
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div
                        style={{ width: `${(storageBreakdown.cache / storageBreakdown.totalUsed) * 100}%` }}
                        className="h-full bg-rose-500 rounded-full"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Security & Zero Cloud Footprint Card */}
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 space-y-1.5 text-xs">
                <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>Zero-Knowledge Local Storage</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  All 1GB+ files and multimedia blobs are stored client-side in encrypted IndexedDB partitions. No metadata or unencrypted payload leaves your local hardware.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: Cleanup Panel */}
          {activeTab === 'cleanup' && (
            <div className="space-y-3">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Reclaim local drive space with one-tap modular garbage collection.
              </p>

              {/* Action 1: Clean Cache */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3 shadow-xs">
                <div>
                  <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    Purge Temporary WebRTC Blobs
                  </h5>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Frees temporary file slices & preview thumbnails ({storageBreakdown.cache} MB)
                  </p>
                </div>
                <button
                  onClick={() => {
                    playPopSound();
                    cleanStorageCategory('cache');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer transition-colors shrink-0"
                >
                  Clean
                </button>
              </div>

              {/* Action 2: Purge Voice Notes */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3 shadow-xs">
                <div>
                  <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    Clear Audio Notes Cache
                  </h5>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Reclaims cached voice notes ({storageBreakdown.audio} MB)
                  </p>
                </div>
                <button
                  onClick={() => {
                    playPopSound();
                    cleanStorageCategory('audio');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer transition-colors shrink-0"
                >
                  Clean
                </button>
              </div>

              {/* Action 3: Purge 1GB+ Completed Transfers */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3 shadow-xs">
                <div>
                  <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    Prune 1GB+ Downloaded Files
                  </h5>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Clears completed P2P download checkpoints (~1.12 GB)
                  </p>
                </div>
                <button
                  onClick={() => {
                    playPopSound();
                    cleanStorageCategory('p2p');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer transition-colors shrink-0"
                >
                  Prune
                </button>
              </div>

              {/* Action 4: Deep Clean All */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-500/10 via-amber-500/10 to-purple-500/10 border border-rose-500/20 space-y-2 mt-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-rose-600 dark:text-rose-400">
                      Deep Clean Entire System Cache
                    </h5>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Reclaims up to 3.5+ GB of temporary caches & unneeded blobs
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    playPopSound();
                    cleanStorageCategory('all');
                  }}
                  className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-98"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Execute Deep Storage Cleanup</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: Per-Chat Storage */}
          {activeTab === 'chats' && (
            <div className="space-y-2.5">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Storage allocated per conversation thread:
              </p>

              {conversations.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">No chat records found</p>
              ) : (
                conversations.map((conv, idx) => {
                  const estMB = (idx + 1) * 340 + 80;
                  const convTitle =
                    conv.groupName ||
                    (conv.participantNames ? Object.values(conv.participantNames)[0] : null) ||
                    `Conversation #${idx + 1}`;
                  const convAvatar =
                    conv.groupAvatar ||
                    (conv.participantAvatars ? Object.values(conv.participantAvatars)[0] : null) ||
                    createDeterministicAvatarDataUri(convTitle, '#0F766E');

                  return (
                    <div
                      key={conv.id}
                      className="p-3 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={convAvatar}
                          alt={convTitle}
                          className="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                        />
                        <div className="min-w-0">
                          <p className="font-bold truncate text-slate-900 dark:text-slate-100">
                            {convTitle}
                          </p>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                            {estMB > 1024 ? `${(estMB / 1024).toFixed(2)} GB` : `${estMB} MB`} allocated
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          playPopSound();
                          showToast('Chat Storage Cleaned', `Freed ${estMB} MB for ${convTitle}`, 'success');
                        }}
                        className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-rose-500 hover:text-white transition-colors cursor-pointer shrink-0"
                      >
                        Wipe Media
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 flex justify-end shrink-0">
          <button
            onClick={() => {
              playClickSound();
              setIsP2PStorageDashboardOpen(false);
            }}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
          >
            Close Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
