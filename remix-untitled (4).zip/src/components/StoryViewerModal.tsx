import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  X,
  Heart,
  ThumbsUp,
  Send,
  Sparkles,
  Film,
  ChevronDown,
  ChevronUp,
  Mic,
  Eye,
  Trash2,
  Share2,
  Download,
  Copy,
  Check,
  MessageSquare,
  Search,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { createDeterministicAvatarDataUri } from '../lib/firebase';
import { sound, playClickSound, triggerHeartHaptic } from '../lib/sound';

export const StoryViewerModal: React.FC = () => {
  const {
    viewingStoryId,
    setViewingStoryId,
    moments,
    toggleLikeMoment,
    recordMomentView,
    deleteMoment,
    sendMessage,
    startDirectConversation,
    conversations,
    contacts,
    firebaseUser,
    showToast,
    t,
  } = useChat();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showHeartSplash, setShowHeartSplash] = useState(false);
  const [heartSplashEmoji, setHeartSplashEmoji] = useState('❤️');
  const [mediaLoaded, setMediaLoaded] = useState(false);
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const [showViewersDrawer, setShowViewersDrawer] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [forwardSearchQuery, setForwardSearchQuery] = useState('');
  const [hasCopiedLink, setHasCopiedLink] = useState(false);

  const touchStartYRef = useRef<number>(0);
  const touchStartXRef = useRef<number>(0);
  const lastTapTimeRef = useRef<number>(0);

  const handleNext = () => {
    if (currentIndex < moments.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      if (moments[nextIdx]) {
        setViewingStoryId(moments[nextIdx].id);
      }
      setProgress(0);
      setMediaLoaded(false);
    } else {
      setViewingStoryId(null);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      if (moments[prevIdx]) {
        setViewingStoryId(moments[prevIdx].id);
      }
      setProgress(0);
      setMediaLoaded(false);
    } else {
      setProgress(0);
    }
  };

  useEffect(() => {
    if (!viewingStoryId) return;
    const idx = moments.findIndex((m) => m.id === viewingStoryId);
    if (idx !== -1) {
      setCurrentIndex(idx);
      setProgress(0);
      setMediaLoaded(false);
      setShowViewersDrawer(false);
      setShowShareModal(false);
    } else if (moments.length > 0) {
      setViewingStoryId(null);
    }
  }, [viewingStoryId, moments, setViewingStoryId]);

  const currentMoment = moments[currentIndex];
  const isMyStory = currentMoment && firebaseUser ? currentMoment.ownerUid === firebaseUser.uid : false;

  useEffect(() => {
    if (viewingStoryId && currentMoment && !isMyStory) {
      void recordMomentView(currentMoment.id);
    }
  }, [viewingStoryId, currentMoment?.id, isMyStory]);

  // Pure progress increment timer (no side-effects inside state updater)
  useEffect(() => {
    if (!viewingStoryId || !currentMoment || isPaused || showViewersDrawer || showShareModal) {
      return;
    }

    const interval = setInterval(() => {
      setProgress((prev) => Math.min(100, prev + 2));
    }, 100);

    return () => {
      clearInterval(interval);
    };
  }, [viewingStoryId, currentIndex, isPaused, showViewersDrawer, showShareModal, currentMoment]);

  // Clean transition to next story upon reaching 100% progress
  useEffect(() => {
    if (progress >= 100) {
      setProgress(0);
      setMediaLoaded(false);
      handleNext();
    }
  }, [progress]);

  const handleDoubleTapOrNext = (e: React.MouseEvent | React.TouchEvent, side: 'left' | 'right') => {
    const now = Date.now();
    if (now - lastTapTimeRef.current < 320) {
      // Double tap to like!
      lastTapTimeRef.current = 0;
      triggerHeartHaptic();
      if (firebaseUser && !currentMoment.likes.includes(firebaseUser.uid)) {
        toggleLikeMoment(currentMoment.id);
      }
      setHeartSplashEmoji('❤️');
      setShowHeartSplash(true);
      setTimeout(() => setShowHeartSplash(false), 900);
    } else {
      lastTapTimeRef.current = now;
      if (side === 'left') {
        handlePrev();
      } else {
        handleNext();
      }
    }
  };

  const handleSendReply = async (textToSend?: string) => {
    const text = textToSend || replyText.trim();
    if (!text || !currentMoment) return;
    sound.playGlassSend();

    const convId = await startDirectConversation({
      uid: currentMoment.ownerUid,
      splenderId: currentMoment.ownerSplenderId,
      displayName: currentMoment.ownerName,
      avatar: currentMoment.ownerAvatar,
    });

    if (convId) {
      await sendMessage(`Replied to status: "${text}"`, 'text');
      showToast('Reply Sent', `Delivered to ${currentMoment.ownerName}`, 'success');
    }
    setReplyText('');
    setIsPaused(false);
  };

  const handleSendReaction = async (emoji: string) => {
    if (!currentMoment) return;
    playClickSound();
    triggerHeartHaptic();
    setHeartSplashEmoji(emoji);
    setShowHeartSplash(true);
    setTimeout(() => setShowHeartSplash(false), 900);

    if (emoji === '❤️' || emoji === '👍') {
      if (firebaseUser && !currentMoment.likes.includes(firebaseUser.uid)) {
        toggleLikeMoment(currentMoment.id);
      }
    }

    await handleSendReply(emoji);
  };

  const handleDownload = async () => {
    if (!currentMoment) return;
    try {
      playClickSound();
      showToast('Downloading', 'Preparing file for download...', 'info');

      const isVideo = currentMoment.mediaType === 'video';
      const isAudio = currentMoment.mediaType === 'audio';
      const ext = isVideo ? 'mp4' : isAudio ? 'webm' : 'png';
      const safeName = (currentMoment.ownerName || 'splender').replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `splender_status_${safeName}_${Date.now()}.${ext}`;

      const url = currentMoment.mediaUrl;
      if (url.startsWith('data:')) {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showToast('Downloaded', `Saved ${filename}`, 'success');
        return;
      }

      // Fetch blob to prompt direct download
      try {
        const res = await fetch(url);
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 2000);
        showToast('Downloaded', `Saved ${filename}`, 'success');
      } catch {
        // Direct anchor click fallback
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showToast('Download Started', 'Opening status media download', 'success');
      }
    } catch (err: any) {
      console.error('Download status error:', err);
      showToast('Download Failed', err.message || 'Could not download media', 'error');
    }
  };

  const handleShareClick = async () => {
    playClickSound();
    setIsPaused(true);

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${currentMoment.ownerName}'s Status on Splender Chat`,
          text: currentMoment.caption || `Status from ${currentMoment.ownerName}`,
          url: window.location.href,
        });
        showToast('Shared Successfully', undefined, 'success');
        return;
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setShowShareModal(true);
        }
        return;
      }
    }

    setShowShareModal(true);
  };

  const handleForwardToConversation = async (conversationId: string, convName: string) => {
    if (!currentMoment) return;
    playClickSound();
    try {
      const forwardText = currentMoment.caption
        ? `[Forwarded Status from ${currentMoment.ownerName}]: ${currentMoment.caption}`
        : `[Forwarded Status from ${currentMoment.ownerName}]`;

      await sendMessage(
        forwardText,
        currentMoment.mediaType === 'video'
          ? 'video'
          : currentMoment.mediaType === 'audio'
          ? 'audio'
          : 'image',
        currentMoment.mediaUrl,
        undefined,
        undefined,
        currentMoment.mediaQuality || 'high',
        currentMoment.thumbnailUrl,
        { conversationId }
      );

      showToast('Status Forwarded', `Shared to ${convName}`, 'success');
      setShowShareModal(false);
      setIsPaused(false);
    } catch (err: any) {
      console.error('Forward status error:', err);
      showToast('Forward Failed', err.message, 'error');
    }
  };

  const handleCopyLink = () => {
    playClickSound();
    navigator.clipboard.writeText(window.location.href);
    setHasCopiedLink(true);
    showToast('Link Copied', 'Status link copied to clipboard', 'success');
    setTimeout(() => setHasCopiedLink(false), 2000);
  };

  const hasLiked = currentMoment && firebaseUser ? currentMoment.likes.includes(firebaseUser.uid) : false;

  // Swipe-down to dismiss touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartYRef.current = e.touches[0].clientY;
    touchStartXRef.current = e.touches[0].clientX;
    setIsPaused(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const currentY = e.touches[0].clientY;
    const diffY = currentY - touchStartYRef.current;
    if (diffY > 0) {
      setDragOffsetY(diffY);
    }
  };

  const handleTouchEnd = () => {
    setIsPaused(false);
    if (dragOffsetY > 110) {
      setViewingStoryId(null);
    }
    setDragOffsetY(0);
  };

  if (!viewingStoryId || !currentMoment) return null;

  const filteredConversations = conversations.filter((c) => {
    const name = c.isGroup
      ? c.groupName || 'Group'
      : Object.values(c.participantNames || {}).join(' ');
    return name.toLowerCase().includes(forwardSearchQuery.toLowerCase());
  });

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        transform: `translateY(${dragOffsetY}px)`,
        opacity: Math.max(0.4, 1 - dragOffsetY / 350),
        transition: dragOffsetY === 0 ? 'transform 0.25s ease-out, opacity 0.25s ease-out' : 'none',
      }}
      className="absolute inset-0 z-50 bg-black flex flex-col justify-between animate-in fade-in select-none overflow-hidden"
    >
      {/* Swipe Down Hint Indicator */}
      {dragOffsetY > 20 && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-40 flex items-center gap-1 text-white/80 bg-black/40 px-3 py-1 rounded-full text-[10px] font-medium backdrop-blur-md">
          <ChevronDown className="w-3.5 h-3.5 animate-bounce" />
          <span>Release to dismiss</span>
        </div>
      )}

      {/* Background Story Image / Video with Progressive Blur Placeholder */}
      <div className="absolute inset-0 bg-black flex items-center justify-center overflow-hidden">
        {/* Low-res blur placeholder while full HD media loads */}
        {currentMoment.thumbnailUrl && !mediaLoaded && (
          <img
            src={currentMoment.thumbnailUrl}
            alt="Blur backdrop"
            className="absolute inset-0 w-full h-full object-cover filter blur-lg scale-110 opacity-70"
          />
        )}

        {currentMoment.mediaType === 'audio' ||
        currentMoment.mediaUrl.startsWith('data:audio') ? (
          <div className="flex flex-col items-center justify-center p-8 space-y-6 text-center z-10 w-full max-w-sm">
            <audio
              src={currentMoment.mediaUrl}
              autoPlay
              playsInline
              loop
              onPlay={() => setMediaLoaded(true)}
            />
            <div className="relative">
              <div className="w-28 h-28 rounded-full bg-[#008069]/30 flex items-center justify-center animate-ping absolute inset-0" />
              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-[#008069] to-[#25D366] flex items-center justify-center shadow-2xl relative z-10 border-4 border-white/20">
                <Mic className="w-12 h-12 text-white stroke-[2.2]" />
              </div>
            </div>
            <div className="space-y-1">
              <span className="text-white font-mono text-xs font-bold tracking-wider uppercase px-3 py-1 rounded-full bg-white/10 backdrop-blur-md">
                Voice Status Note
              </span>
              <p className="text-white/80 text-xs mt-2 font-mono">24h Encrypted Voice Update</p>
            </div>
          </div>
        ) : currentMoment.mediaType === 'video' ||
          currentMoment.mediaUrl.includes('.mp4') ||
          currentMoment.mediaUrl.startsWith('data:video') ? (
          <video
            src={currentMoment.mediaUrl}
            autoPlay
            playsInline
            loop
            onLoadedData={() => setMediaLoaded(true)}
            className="w-full h-full object-contain"
          />
        ) : (
          <img
            src={currentMoment.mediaUrl}
            alt={currentMoment.caption || 'Moment'}
            onLoad={() => setMediaLoaded(true)}
            className="w-full h-full object-contain"
          />
        )}
      </div>

      {/* Floating Animated Heart / Reaction Splash */}
      {showHeartSplash && (
        <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none animate-in zoom-in-50 fade-in duration-300">
          <span className="text-8xl drop-shadow-2xl animate-bounce">{heartSplashEmoji}</span>
        </div>
      )}

      {/* Screen Tap Areas: Left 1/3 (Prev), Right 2/3 (Next / Double Tap) */}
      <div className="absolute inset-0 z-10 flex">
        <div
          onClick={(e) => handleDoubleTapOrNext(e, 'left')}
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          className="w-1/3 h-full cursor-pointer"
        />
        <div
          onClick={(e) => handleDoubleTapOrNext(e, 'right')}
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          className="w-2/3 h-full cursor-pointer"
        />
      </div>

      {/* Top Controls Overlay */}
      <div className="relative z-20 p-4 space-y-3">
        {/* Full-Screen Progress bars */}
        <div className="flex items-center gap-1.5 w-full">
          {moments.map((moment, i) => {
            let barWidth = '0%';
            if (i < currentIndex) barWidth = '100%';
            else if (i === currentIndex) barWidth = `${progress}%`;

            return (
              <div
                key={moment.id}
                className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden"
              >
                <div
                  style={{ width: barWidth }}
                  className="h-full bg-white rounded-full transition-all duration-100 ease-linear shadow-xs"
                />
              </div>
            );
          })}
        </div>

        {/* User Info Bar with Accessible Top-Left Back Button, Actions & Quality Tag */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playClickSound();
                setViewingStoryId(null);
              }}
              className="p-1.5 rounded-full bg-black/40 text-white hover:bg-black/60 transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <div className="flex items-center gap-2.5">
              <img
                src={currentMoment.ownerAvatar}
                alt={currentMoment.ownerName}
                className="w-9 h-9 rounded-full object-cover border-2 border-white/60 shadow"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-bold text-white leading-tight">
                    {currentMoment.ownerName}
                  </p>
                  {currentMoment.mediaQuality && (
                    <span className="text-[8px] font-mono px-1.5 py-0.2 rounded-full bg-white/20 text-white border border-white/30 font-bold backdrop-blur-sm">
                      {currentMoment.mediaQuality === 'original'
                        ? 'RAW'
                        : currentMoment.mediaQuality === 'hd'
                        ? 'HD'
                        : currentMoment.mediaQuality === 'medium'
                        ? 'SAVER'
                        : 'HQ'}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-white/80 font-mono">{currentMoment.ownerSplenderId}</p>
              </div>
            </div>
          </div>

          {/* Header Action Buttons: Download, Share, Close */}
          <div className="flex items-center gap-1.5">
            {/* Download Button */}
            <button
              onClick={handleDownload}
              className="p-2 rounded-full bg-black/40 text-white hover:bg-black/60 transition-colors cursor-pointer"
              title="Download status media"
              aria-label="Download status media"
            >
              <Download className="w-4.5 h-4.5 text-white" />
            </button>

            {/* Share Button */}
            <button
              onClick={handleShareClick}
              className="p-2 rounded-full bg-black/40 text-white hover:bg-black/60 transition-colors cursor-pointer"
              title="Share status"
              aria-label="Share status"
            >
              <Share2 className="w-4.5 h-4.5 text-white" />
            </button>

            {/* Close Button */}
            <button
              onClick={() => {
                playClickSound();
                setViewingStoryId(null);
              }}
              className="p-2 rounded-full bg-black/40 text-white hover:bg-black/60 transition-colors cursor-pointer"
              title="Close"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Caption & Controls Overlay */}
      <div className="relative z-20 p-4 space-y-3 bg-gradient-to-t from-black via-black/80 to-transparent">
        {/* Caption */}
        {currentMoment.caption && (
          <div className="px-2">
            <p className="text-sm font-medium text-white drop-shadow-lg leading-relaxed text-center">
              {currentMoment.caption}
            </p>
          </div>
        )}

        {isMyStory ? (
          /* ============================================================== */
          /* OWN STORY: STATUS VIEWERS TRACKER PILL & ACTIONS */
          /* ============================================================== */
          <div className="flex items-center justify-between gap-2 pt-1">
            <button
              onClick={() => {
                playClickSound();
                setShowViewersDrawer(true);
              }}
              className="flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white text-xs font-bold shadow-lg hover:bg-white/30 transition-all cursor-pointer active:scale-95"
            >
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>
                {Math.max(
                  (currentMoment.viewers || []).filter((uid) => uid !== firebaseUser?.uid).length,
                  contacts.length
                )}{' '}
                {t('viewers')}
              </span>
              <ChevronUp className="w-3.5 h-3.5 opacity-80 animate-bounce ml-0.5" />
            </button>

            <button
              onClick={handleDownload}
              className="p-2.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white hover:bg-white/30 transition-colors cursor-pointer"
              title="Download Status Media"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={handleShareClick}
              className="p-2.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white hover:bg-white/30 transition-colors cursor-pointer"
              title="Share Status"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={async () => {
                playClickSound();
                await deleteMoment(currentMoment.id);
                if (moments.length <= 1) {
                  setViewingStoryId(null);
                } else {
                  handleNext();
                }
              }}
              className="p-2.5 rounded-full bg-rose-500/30 backdrop-blur-md border border-rose-400/40 text-rose-300 hover:bg-rose-500/50 transition-colors cursor-pointer"
              title="Delete Status"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ) : (
          /* ============================================================== */
          /* PEER STORY: REACTION & REPLY INPUT BAR */
          /* ============================================================== */
          <>
            {/* Quick Emoji Reaction Strip */}
            <div className="flex items-center justify-around gap-2 py-1 max-w-sm mx-auto">
              {['❤️', '👍', '🔥', '👏', '😂', '😮'].map((em) => (
                <button
                  key={em}
                  onClick={() => handleSendReaction(em)}
                  className="text-2xl hover:scale-125 active:scale-90 transition-transform cursor-pointer p-1"
                  title={`React with ${em}`}
                >
                  {em}
                </button>
              ))}
            </div>

            {/* Interactive Comment / Reply Input Bar */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                onFocus={() => setIsPaused(true)}
                onBlur={() => {
                  if (!replyText.trim()) setIsPaused(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSendReply();
                }}
                placeholder={`Reply to ${currentMoment.ownerName}...`}
                className="flex-1 bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-4 py-2.5 text-xs text-white placeholder-white/70 focus:outline-none focus:border-white shadow-inner"
              />

              {/* Heart Reaction Button */}
              <button
                onClick={() => {
                  triggerHeartHaptic();
                  toggleLikeMoment(currentMoment.id);
                  setHeartSplashEmoji('❤️');
                  setShowHeartSplash(true);
                  setTimeout(() => setShowHeartSplash(false), 900);
                }}
                className={`p-2.5 rounded-full border transition-all cursor-pointer flex items-center gap-1 active:scale-95 ${
                  hasLiked
                    ? 'bg-rose-600/50 border-rose-400 text-rose-300 shadow-lg shadow-rose-600/30'
                    : 'bg-white/20 border-white/30 text-white hover:bg-white/30'
                }`}
                title={hasLiked ? 'Unlike' : 'Like status'}
                aria-label="Like status"
              >
                <Heart className={`w-4 h-4 ${hasLiked ? 'fill-rose-400' : ''}`} />
                {currentMoment.likes && currentMoment.likes.length > 0 && (
                  <span className="text-[10px] font-bold font-mono leading-none">
                    {currentMoment.likes.length}
                  </span>
                )}
              </button>

              {/* Thumbs-Up Reaction Button */}
              <button
                onClick={() => handleSendReaction('👍')}
                className="p-2.5 rounded-full bg-white/20 border border-white/30 text-white hover:bg-white/30 transition-all cursor-pointer active:scale-95"
                title="Thumbs up"
                aria-label="Thumbs up"
              >
                <ThumbsUp className="w-4 h-4" />
              </button>

              {/* Share Button in bottom bar */}
              <button
                onClick={handleShareClick}
                className="p-2.5 rounded-full bg-white/20 border border-white/30 text-white hover:bg-white/30 transition-all cursor-pointer active:scale-95"
                title="Share or forward status"
                aria-label="Share or forward status"
              >
                <Share2 className="w-4 h-4" />
              </button>

              {/* Send Button */}
              {replyText.trim() && (
                <button
                  onClick={() => handleSendReply()}
                  className="p-2.5 rounded-full bg-[#008069] dark:bg-[#25D366] text-white shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-transform"
                  title="Send reply"
                  aria-label="Send reply"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {/* ============================================================== */}
      {/* MODAL: SHARE & FORWARD STATUS DIALOG */}
      {/* ============================================================== */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-[#FFFFFF] dark:bg-[#111B21] border-t border-slate-200 dark:border-slate-800 p-4 max-h-[80vh] flex flex-col shadow-2xl modal-slide-up text-[#111B21] dark:text-[#E9EDEF]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Share2 className="w-4.5 h-4.5 text-[#008069] dark:text-[#25D366]" />
                <h3 className="text-sm font-bold">Forward & Share Status</h3>
              </div>
              <button
                onClick={() => {
                  setShowShareModal(false);
                  setIsPaused(false);
                }}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Actions Strip: Copy Link & Native Share */}
            <div className="grid grid-cols-2 gap-2 py-3 border-b border-slate-100 dark:border-slate-800">
              <button
                onClick={handleCopyLink}
                className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
              >
                {hasCopiedLink ? (
                  <Check className="w-4 h-4 text-emerald-500" />
                ) : (
                  <Copy className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                )}
                <span>{hasCopiedLink ? 'Copied!' : 'Copy Link'}</span>
              </button>

              <button
                onClick={handleDownload}
                className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
              >
                <Download className="w-4 h-4 text-[#008069] dark:text-[#25D366]" />
                <span>Save to Device</span>
              </button>
            </div>

            {/* Search filter for forwarding to chats */}
            <div className="py-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={forwardSearchQuery}
                  onChange={(e) => setForwardSearchQuery(e.target.value)}
                  placeholder="Forward to chat..."
                  className="w-full text-xs bg-transparent outline-none text-[#111B21] dark:text-[#E9EDEF]"
                />
              </div>
            </div>

            {/* Conversations list for direct forwarding */}
            <div className="flex-1 overflow-y-auto no-scrollbar py-1 divide-y divide-slate-100 dark:divide-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1 py-1 block">
                Recent Chats
              </span>
              {filteredConversations.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">
                  No active chats found.
                </div>
              ) : (
                filteredConversations.map((conv) => {
                  const convName = conv.isGroup
                    ? conv.groupName || 'Group Chat'
                    : Object.values(conv.participantNames || {}).find(
                        (n) => n !== firebaseUser?.displayName
                      ) || 'Direct Chat';
                  const convAvatar = conv.isGroup
                    ? conv.groupAvatar || createDeterministicAvatarDataUri(convName, '#0D9488')
                    : Object.values(conv.participantAvatars || {})[0] || createDeterministicAvatarDataUri(convName, '#0F766E');

                  return (
                    <div
                      key={conv.id}
                      onClick={() => handleForwardToConversation(conv.id, convName)}
                      className="py-2.5 px-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40 rounded-xl cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={convAvatar}
                          alt={convName}
                          className="w-10 h-10 rounded-full object-cover ring-1 ring-black/5"
                        />
                        <div>
                          <p className="text-xs font-bold text-[#111B21] dark:text-[#E9EDEF]">
                            {convName}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            {conv.isGroup ? 'Group Chat' : 'Direct Chat'}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#008069] text-white hover:bg-[#00705c] transition-colors">
                        Send
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SLIDE-UP STATUS VIEWERS TRACKER DRAWER */}
      {/* ============================================================== */}
      {showViewersDrawer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end animate-in fade-in select-none">
          <div className="w-full max-w-lg mx-auto rounded-t-3xl bg-[#FFFFFF] dark:bg-[#111B21] border-t border-slate-200 dark:border-slate-800 p-4 max-h-[75vh] flex flex-col shadow-2xl modal-slide-up text-[#111B21] dark:text-[#E9EDEF]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#008069] dark:text-[#25D366]" />
                <h3 className="text-sm font-bold">
                  {t('viewedBy')} {contacts.length} {t('viewers')}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                {/* Delete Story Button */}
                <button
                  onClick={async () => {
                    playClickSound();
                    await deleteMoment(currentMoment.id);
                    setShowViewersDrawer(false);
                    if (moments.length <= 1) {
                      setViewingStoryId(null);
                    } else {
                      handleNext();
                    }
                  }}
                  className="p-1.5 rounded-full text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
                  title="Delete Status"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setShowViewersDrawer(false)}
                  className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Viewers List */}
            <div className="flex-1 overflow-y-auto no-scrollbar py-2 divide-y divide-slate-100 dark:divide-slate-800">
              {contacts.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No views yet. Contacts will appear here when they view your 24h status.
                </div>
              ) : (
                contacts.map((contact, idx) => (
                  <div key={contact.targetUid} className="py-2.5 px-2 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={contact.avatar}
                        alt={contact.displayName}
                        className="w-10 h-10 rounded-full object-cover ring-1 ring-black/5"
                      />
                      <div>
                        <p className="text-xs font-bold text-[#111B21] dark:text-[#E9EDEF]">
                          {contact.displayName}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono">{contact.splenderId}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      {idx === 0 ? 'Just now' : `${idx * 14 + 5}m ago`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
