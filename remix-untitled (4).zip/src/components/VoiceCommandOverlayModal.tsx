import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  X,
  Languages,
  Sparkles,
  Command,
  CheckCircle2,
  Volume2,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';

export const VoiceCommandOverlayModal: React.FC = () => {
  const {
    isVoiceCommandOverlayOpen,
    setIsVoiceCommandOverlayOpen,
    setActiveTab,
    setActiveConversationId,
    setIsSettingsModalOpen,
    toggleDarkMode,
    cleanStorageCategory,
    showToast,
  } = useChat();

  const [isListening, setIsListening] = useState(true);
  const [lang, setLang] = useState<'mr-IN' | 'en-US'>('mr-IN');
  const [transcript, setTranscript] = useState('');
  const [recognizedCommand, setRecognizedCommand] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!isVoiceCommandOverlayOpen) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      return;
    }

    setTranscript('');
    setRecognizedCommand(null);

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      try {
        const recognition = new SpeechRec();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = lang;

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const text = event.results[current][0].transcript;
          setTranscript(text);

          if (event.results[current].isFinal) {
            handleProcessCommand(text);
          }
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
        recognitionRef.current = recognition;
        setIsListening(true);
      } catch {
        setIsListening(false);
      }
    } else {
      setIsListening(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
    };
  }, [isVoiceCommandOverlayOpen, lang]);

  if (!isVoiceCommandOverlayOpen) return null;

  const handleProcessCommand = (spoken: string) => {
    const s = spoken.toLowerCase().trim();

    // Marathi and English Voice Command Lexicon
    if (s.includes('नवीन') || s.includes('new chat') || s.includes('गप्पा') || s.includes('chat')) {
      setRecognizedCommand('स्विच करत आहे: गप्पा (Chats)');
      playPopSound();
      setTimeout(() => {
        setActiveTab('chats');
        setIsVoiceCommandOverlayOpen(false);
        showToast('Voice Command', 'गप्पा टॅब उघडला (Chats Tab)', 'success');
      }, 700);
    } else if (s.includes('कॉल') || s.includes('call') || s.includes('calls')) {
      setRecognizedCommand('स्विच करत आहे: कॉल्स (Calls)');
      playPopSound();
      setTimeout(() => {
        setActiveTab('calls');
        setIsVoiceCommandOverlayOpen(false);
        showToast('Voice Command', 'कॉल्स टॅब उघडला (Calls Tab)', 'success');
      }, 700);
    } else if (s.includes('डार्क') || s.includes('dark') || s.includes('लाईट') || s.includes('light') || s.includes('थीम') || s.includes('theme')) {
      setRecognizedCommand('थीम बदलत आहे (Toggling Theme)');
      playPopSound();
      setTimeout(() => {
        toggleDarkMode();
        setIsVoiceCommandOverlayOpen(false);
        showToast('Voice Command', 'थीम टॉगल केली (Theme Toggled)', 'success');
      }, 700);
    } else if (s.includes('साफ') || s.includes('clean') || s.includes('कॅशे') || s.includes('cache')) {
      setRecognizedCommand('कॅशे साफ करत आहे (Cleaning Cache)');
      playPopSound();
      setTimeout(() => {
        cleanStorageCategory('cache');
        setIsVoiceCommandOverlayOpen(false);
      }, 700);
    } else if (s.includes('सेटिंग') || s.includes('settings')) {
      setRecognizedCommand('सेटिंग्ज उघडत आहे (Opening Settings)');
      playPopSound();
      setTimeout(() => {
        setIsSettingsModalOpen(true);
        setIsVoiceCommandOverlayOpen(false);
        showToast('Voice Command', 'सेटिंग्ज उघडल्या (Settings Opened)', 'success');
      }, 700);
    } else if (s.includes('मागे') || s.includes('back')) {
      setRecognizedCommand('मागे जात आहे (Navigating Back)');
      playPopSound();
      setTimeout(() => {
        setActiveConversationId(null);
        setIsVoiceCommandOverlayOpen(false);
      }, 700);
    } else {
      setRecognizedCommand(`आदेश: "${spoken}"`);
    }
  };

  return (
    <div
      onClick={() => setIsVoiceCommandOverlayOpen(false)}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden modal-slide-up text-slate-800 dark:text-slate-100 flex flex-col p-5 space-y-4 text-center"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-teal-500" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              Voice Command Control
            </h3>
          </div>
          <div className="flex items-center gap-2">
            {/* Language toggle: Marathi / English */}
            <button
              onClick={() => {
                playClickSound();
                setLang((prev) => (prev === 'mr-IN' ? 'en-US' : 'mr-IN'));
              }}
              className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold border border-teal-500/20 cursor-pointer"
            >
              {lang === 'mr-IN' ? 'मराठी' : 'EN'}
            </button>
            <button
              onClick={() => {
                playClickSound();
                setIsVoiceCommandOverlayOpen(false);
              }}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pulsing Mic Wave Animation */}
        <div className="py-4 flex flex-col items-center justify-center">
          <div className="relative">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
              isListening
                ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-white shadow-xl shadow-teal-500/30 scale-105 animate-pulse'
                : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
            }`}>
              <Mic className="w-8 h-8" />
            </div>
            {isListening && (
              <div className="absolute inset-0 rounded-full border-2 border-teal-400 animate-ping pointer-events-none" />
            )}
          </div>
          <p className="mt-3 text-xs font-bold text-slate-800 dark:text-slate-200">
            {isListening ? 'ऐकत आहे... (Listening...)' : 'टॅप करून बोला (Tap to Speak)'}
          </p>
        </div>

        {/* Live Recognized Speech Transcript */}
        <div className="min-h-12 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-xs">
          <p className="italic text-slate-600 dark:text-slate-300">
            {transcript ? `"${transcript}"` : lang === 'mr-IN' ? 'उदा. "कॉल", "नवीन चॅट", "डार्क मोड", "कॅशे साफ करा"' : 'e.g. "Calls", "New Chat", "Dark Mode", "Clean Cache"'}
          </p>
          {recognizedCommand && (
            <p className="mt-1 font-bold text-teal-600 dark:text-teal-400 font-mono text-[11px]">
              ✓ {recognizedCommand}
            </p>
          )}
        </div>

        {/* Quick Sample Voice Command Chips */}
        <div className="space-y-1.5 text-left pt-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            जलद आज्ञा (Quick Commands):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { label: 'नवीन चॅट (Chats)', cmd: 'नवीन चॅट' },
              { label: 'कॉल करा (Calls)', cmd: 'कॉल' },
              { label: 'डार्क मोड (Dark Mode)', cmd: 'डार्क मोड' },
              { label: 'कॅशे साफ करा (Clean)', cmd: 'कॅशे साफ करा' },
              { label: 'सेटिंग्ज (Settings)', cmd: 'सेटिंग्ज' },
            ].map((item) => (
              <button
                key={item.cmd}
                onClick={() => {
                  setTranscript(item.cmd);
                  handleProcessCommand(item.cmd);
                }}
                className="px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-teal-50 dark:bg-slate-800 dark:hover:bg-teal-950/40 text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 text-[11px] font-medium border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
