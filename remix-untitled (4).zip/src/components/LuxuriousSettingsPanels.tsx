import React from 'react';
import {
  Palette,
  Shield,
  Lock,
  EyeOff,
  Bot,
  Sparkles,
  Network,
  Wifi,
  HardDrive,
  Trash2,
  Languages,
  Type,
  Mic,
  Smartphone,
  Check,
  Cpu,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { LUXURY_THEMES } from '../lib/themeEngine';
import { ThemeMode } from '../types';
import { playClickSound, playPopSound } from '../lib/sound';

export const ThemeSelectorPanel: React.FC = () => {
  const {
    theme,
    setTheme,
    adaptiveThemeSync,
    setAdaptiveThemeSync,
    preferredDarkAccent,
    setPreferredDarkAccent,
    preferredLightAccent,
    setPreferredLightAccent,
    darkMode,
    toggleDarkMode,
  } = useChat();

  const luxuryThemeKeys: ThemeMode[] = [
    'indigo_dawn',
    'midnight_oled',
    'cyber_indigo',
    'teal_dusk',
    'emerald_luxury',
    'emerald',
    'dark_amber',
    'apricot_bloom',
    'rose_quartz',
  ];

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/15 border border-[#8B5CF6]/30 text-[#22D3EE] flex items-center justify-center shrink-0">
            <Palette className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF] truncate">
              Aurora Nebula Theme System
            </h4>
            <p className="text-xs text-[#A8B3CC] truncate">
              9 coordinated CSS-variable palettes with smooth transitions
            </p>
          </div>
        </div>
        <span className="text-xs font-mono tabular-nums text-[#22D3EE] font-medium whitespace-nowrap shrink-0">
          9 Palettes
        </span>
      </div>

      {/* Adaptive Dark & Light Accent Sync Card */}
      <div className="p-3.5 rounded-2xl bg-[#0D1424] border border-[#293650] space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#8B5CF6] shrink-0" />
              <h5 className="text-xs font-semibold text-[#F4F7FF] truncate">
                Adaptive System Sync
              </h5>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Automatically switch accents when device appearance changes
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setAdaptiveThemeSync(!adaptiveThemeSync);
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              adaptiveThemeSync ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                adaptiveThemeSync ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {adaptiveThemeSync && (
          <div className="space-y-2.5 pt-2.5 border-t border-[#293650]/70 text-xs">
            {/* Preferred Dark Accent */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-[#A8B3CC]">
                System Dark Accent
              </span>
              <div className="flex items-center gap-1.5">
                {(['indigo_dawn', 'teal_dusk'] as const).map((accentKey) => (
                  <button
                    key={accentKey}
                    onClick={() => {
                      playPopSound();
                      setPreferredDarkAccent(accentKey);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      preferredDarkAccent === accentKey
                        ? 'bg-[#8B5CF6] text-white border-[#8B5CF6]'
                        : 'bg-[#131D32] border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                    }`}
                  >
                    {accentKey === 'indigo_dawn' ? 'Indigo Dawn' : 'Teal Dusk'}
                  </button>
                ))}
              </div>
            </div>

            {/* Preferred Light Accent */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-[#A8B3CC]">
                System Light Accent
              </span>
              <div className="flex items-center gap-1.5">
                {(['apricot_bloom', 'rose_quartz'] as const).map((accentKey) => (
                  <button
                    key={accentKey}
                    onClick={() => {
                      playPopSound();
                      setPreferredLightAccent(accentKey);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      preferredLightAccent === accentKey
                        ? 'bg-[#3B82F6] text-white border-[#3B82F6]'
                        : 'bg-[#131D32] border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                    }`}
                  >
                    {accentKey === 'apricot_bloom' ? 'Apricot Bloom' : 'Rose Quartz'}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulate Toggle Button */}
            <div className="pt-1 flex items-center justify-between text-xs text-[#A8B3CC]">
              <span>
                Current State: <strong className="text-[#F4F7FF]">{darkMode ? 'Dark Mode' : 'Light Mode'}</strong>
              </span>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  toggleDarkMode();
                }}
                className="px-2.5 py-1 rounded-lg bg-[#131D32] border border-[#293650] hover:border-[#22D3EE]/60 text-[#F4F7FF] font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Toggle Mode
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Grid of all 9 coordinated themes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {luxuryThemeKeys.map((key) => {
          const cfg = LUXURY_THEMES[key];
          if (!cfg) return null;
          const isSelected = theme === key;

          return (
            <div
              key={key}
              onClick={() => {
                playPopSound();
                setTheme(key);
              }}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between group overflow-hidden ${
                isSelected
                  ? 'border-[#22D3EE] ring-1 ring-[#22D3EE]/35 bg-[#0D1424]'
                  : 'border-[#293650] bg-[#0D1424]/70 hover:border-[#8B5CF6]/55 hover:bg-[#0D1424]'
              }`}
            >
              {/* Header with Title and Unboxed Active State */}
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div
                    className="w-4 h-4 rounded-full border border-white/20 shrink-0"
                    style={{ backgroundColor: cfg.primary }}
                  />
                  <span className="text-xs font-semibold text-[#F4F7FF] truncate">
                    {cfg.name}
                  </span>
                </div>
                {isSelected ? (
                  <span className="flex items-center gap-1 text-xs font-semibold text-[#22D3EE] whitespace-nowrap shrink-0">
                    <Check className="w-3.5 h-3.5" /> Active
                  </span>
                ) : (
                  <span className="text-xs text-[#A8B3CC] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shrink-0">
                    Apply
                  </span>
                )}
              </div>

              <p className="text-xs text-[#A8B3CC] line-clamp-1 mb-2.5">
                {cfg.tagline}
              </p>

              {/* Color Swatches Breakdown */}
              <div className="pt-2 border-t border-[#293650]/60 flex items-center justify-between text-[11px] font-mono tabular-nums text-[#A8B3CC]">
                <div className="flex items-center gap-1.5">
                  <span
                    className="w-3 h-3 rounded-sm border border-white/15 inline-block"
                    style={{ backgroundColor: cfg.primary }}
                    title={`Primary: ${cfg.primary}`}
                  />
                  <span>{cfg.primary}</span>
                  <span aria-hidden="true">·</span>
                  <span
                    className="w-3 h-3 rounded-sm border border-white/15 inline-block"
                    style={{ backgroundColor: cfg.accent }}
                    title={`Accent: ${cfg.accent}`}
                  />
                  <span>{cfg.accent}</span>
                </div>

                <div className="flex items-center gap-1">
                  <span
                    className="w-3 h-3 rounded-sm border border-white/15 inline-block"
                    style={{ backgroundColor: cfg.surface }}
                    title={`Surface: ${cfg.surface}`}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Wallpaper Engine Quick Launch Card */}
      <div
        onClick={() => {
          playClickSound();
          const evt = new CustomEvent('open_wallpaper_engine');
          window.dispatchEvent(evt);
        }}
        className="p-3.5 rounded-2xl bg-[#0D1424] border border-[#293650] hover:border-[#22D3EE]/50 flex items-center justify-between gap-3 cursor-pointer transition-colors group"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#06B6D4] via-[#3B82F6] to-[#8B5CF6] text-white flex items-center justify-center shrink-0">
            <Palette className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h5 className="text-xs font-semibold text-[#F4F7FF] truncate">
              Custom Wallpaper Engine
            </h5>
            <p className="text-xs text-[#A8B3CC] truncate mt-0.5">
              Aurora Nebula mesh, dark gradients, or custom backgrounds
            </p>
          </div>
        </div>
        <button
          type="button"
          className="px-3.5 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          Customize
        </button>
      </div>
    </div>
  );
};

export const NetworkCallLinksPanel: React.FC = () => {
  const {
    disappearingMode,
    setDisappearingMode,
    linkExpiryDuration,
    setLinkExpiryDuration,
    showToast,
  } = useChat();

  const handleToggleDisappearing = () => {
    playClickSound();
    const next = !disappearingMode;
    setDisappearingMode(next);
    showToast(
      'Disappearing Mode',
      next ? 'New messages and call links will auto-expire' : 'Disappearing mode disabled',
      'info'
    );
  };

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-[#22D3EE]/15 border border-[#22D3EE]/30 text-[#22D3EE] flex items-center justify-center shrink-0">
          <Network className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Network & Call Links</h4>
          <p className="text-xs text-[#A8B3CC]">
            Ephemeral parameters, link expiration & WebRTC call tunneling
          </p>
        </div>
      </div>

      <div className="space-y-3 pt-1">
        {/* Toggle 1: Disappearing Mode */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Disappearing Mode
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Auto-wipe call links and transient messages once expired
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleDisappearing}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              disappearingMode ? 'bg-[#22D3EE]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                disappearingMode ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Slider: Link Expiry duration */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-[#F4F7FF]">
              Link Expiry Duration
            </span>
            <span className="font-mono tabular-nums font-semibold text-[#22D3EE]">
              {linkExpiryDuration} {linkExpiryDuration === 1 ? 'Hour' : 'Hours'}
            </span>
          </div>

          <input
            type="range"
            min="1"
            max="72"
            step="1"
            value={linkExpiryDuration}
            onChange={(e) => setLinkExpiryDuration(Number(e.target.value))}
            className="w-full accent-[#22D3EE] cursor-pointer"
          />

          <div className="flex justify-between text-[11px] text-[#A8B3CC] font-mono tabular-nums">
            <span>1h</span>
            <span>24h Default</span>
            <span>72h</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AccountSecurityPanel: React.FC = () => {
  const {
    lockChatThread,
    setLockChatThread,
    snapshotGuard,
    setSnapshotGuard,
    screenShareLock,
    setScreenShareLock,
    autoLockTimer,
    setAutoLockTimer,
    setIsE2eeHealthModalOpen,
    setIsOfflineQueueModalOpen,
    showToast,
  } = useChat();

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-[#10B981] flex items-center justify-center shrink-0">
          <Shield className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Account & Security</h4>
          <p className="text-xs text-[#A8B3CC]">
            Hardware biometric locks & screenshot isolation
          </p>
        </div>
      </div>

      <div className="space-y-2.5 pt-1">
        {/* Toggle 1: Lock Chat Thread */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
              <p className="text-xs font-semibold text-[#F4F7FF]">
                Lock Chat Thread
              </p>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Require PIN or fingerprint before opening active conversation
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !lockChatThread;
              setLockChatThread(next);
              showToast('Lock Chat Thread', next ? 'Thread lock enabled' : 'Thread lock disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              lockChatThread ? 'bg-[#10B981]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                lockChatThread ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Toggle 2: Snapshot Guard */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <EyeOff className="w-3.5 h-3.5 text-[#F472B6] shrink-0" />
              <p className="text-xs font-semibold text-[#F4F7FF]">
                Snapshot Guard
              </p>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Block screenshots and mask viewport during backgrounding
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !snapshotGuard;
              setSnapshotGuard(next);
              showToast('Snapshot Guard', next ? 'Screenshot prevention active' : 'Snapshot guard disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              snapshotGuard ? 'bg-[#10B981]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                snapshotGuard ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Toggle 3: Screen Share Lock */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-[#3B82F6] shrink-0" />
              <p className="text-xs font-semibold text-[#F4F7FF]">
                Screen Share Lock
              </p>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Obscure chat texts and media preview when broadcasting screen
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !screenShareLock;
              setScreenShareLock(next);
              showToast('Screen Share Lock', next ? 'Content hidden during screenshare' : 'Screenshare lock disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              screenShareLock ? 'bg-[#10B981]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                screenShareLock ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Biometric Auto-Lock Timer Control */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-[#22D3EE]" />
              <span className="text-xs font-semibold text-[#F4F7FF]">
                Biometric Auto-Lock Timer
              </span>
            </div>
            <span className="text-xs font-mono tabular-nums font-semibold text-[#22D3EE]">
              {autoLockTimer === 'disabled' ? 'Disabled' : autoLockTimer === 'immediate' ? 'Instant' : autoLockTimer}
            </span>
          </div>
          <p className="text-xs text-[#A8B3CC]">
            Automatically prompt fingerprint or PIN when idle or switching apps
          </p>
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            {[
              { id: 'immediate', label: 'Instant' },
              { id: '1m', label: '1 Min' },
              { id: '5m', label: '5 Mins' },
              { id: '15m', label: '15 Mins' },
              { id: '30m', label: '30 Mins' },
              { id: 'disabled', label: 'Never' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  setAutoLockTimer(opt.id as any);
                }}
                className={`py-2 px-2 rounded-xl text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  autoLockTimer === opt.id
                    ? 'bg-[#8B5CF6] text-white border border-[#8B5CF6]'
                    : 'bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Launchers: E2EE Health & Offline Queue */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setIsE2eeHealthModalOpen(true);
            }}
            className="p-3 rounded-xl bg-[#0D1424] hover:bg-[#080B14] border border-[#293650] hover:border-[#10B981]/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 text-[#10B981] font-semibold text-xs mb-0.5">
              <Shield className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Live E2EE Suite</span>
            </div>
            <p className="text-[11px] text-[#A8B3CC] truncate">
              Session health & cipher
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setIsOfflineQueueModalOpen(true);
            }}
            className="p-3 rounded-xl bg-[#0D1424] hover:bg-[#080B14] border border-[#293650] hover:border-[#22D3EE]/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 text-[#22D3EE] font-semibold text-xs mb-0.5">
              <HardDrive className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Offline Outbox</span>
            </div>
            <p className="text-[11px] text-[#A8B3CC] truncate">
              Manage queued messages
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};

export const AiFeaturesPanel: React.FC = () => {
  const {
    smartThreadSummaries,
    setSmartThreadSummaries,
    autoQuickReplies,
    setAutoQuickReplies,
    contextSuperEngine,
    setContextSuperEngine,
    showToast,
  } = useChat();

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#3B82F6]/15 border border-[#3B82F6]/30 text-[#3B82F6] flex items-center justify-center shrink-0">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Smart Assistance</h4>
            <p className="text-xs text-[#A8B3CC]">
              Optional thread summaries & contextual reply suggestions
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2.5 pt-1">
        {/* Control 1: Smart Thread Summaries */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Smart Thread Summaries
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Generate concise catch-ups for unread conversations
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !smartThreadSummaries;
              setSmartThreadSummaries(next);
              showToast('Smart Summaries', next ? 'Thread catch-up enabled' : 'Disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              smartThreadSummaries ? 'bg-[#3B82F6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                smartThreadSummaries ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Control 2: Auto Quick Replies */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Auto Quick Replies
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Suggest quick reply actions above the message composer
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !autoQuickReplies;
              setAutoQuickReplies(next);
              showToast('Auto Quick Replies', next ? 'Quick replies active' : 'Disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              autoQuickReplies ? 'bg-[#3B82F6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                autoQuickReplies ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Control 3: Context Super-Engine */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-[#8B5CF6] shrink-0" />
              <p className="text-xs font-semibold text-[#F4F7FF]">
                Contextual Reminders
              </p>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Local intent detection for follow-up reminders
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !contextSuperEngine;
              setContextSuperEngine(next);
              showToast('Contextual Reminders', next ? 'Enabled' : 'Disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              contextSuperEngine ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                contextSuperEngine ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export const ConnectivityPrivacyPanel: React.FC = () => {
  const {
    vpnStatus,
    setVpnStatus,
    lockScreenShield,
    setLockScreenShield,
    showToast,
  } = useChat();

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/15 border border-[#8B5CF6]/30 text-[#8B5CF6] flex items-center justify-center shrink-0">
          <Wifi className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Connectivity & Privacy</h4>
          <p className="text-xs text-[#A8B3CC]">
            Relay IP masking & lock screen notification privacy
          </p>
        </div>
      </div>

      <div className="space-y-2.5 pt-1">
        {/* Toggle 1: VPN Status */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Relay Tunnel · {vpnStatus ? 'Connected' : 'Direct'}
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              {vpnStatus
                ? 'Routing WebRTC media via TURN relay · Peer IP masked'
                : 'Direct peer-to-peer ICE path · Low latency'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !vpnStatus;
              setVpnStatus(next);
              showToast('Relay Tunnel', next ? 'Encrypted TURN relay active' : 'Direct P2P connection', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              vpnStatus ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                vpnStatus ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Toggle 2: Lock Screen Shield */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Lock Screen Shield
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Hide sender name and message previews on lock screen banners
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !lockScreenShield;
              setLockScreenShield(next);
              showToast('Lock Screen Shield', next ? 'Notification previews hidden' : 'Standard banners', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              lockScreenShield ? 'bg-[#8B5CF6]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                lockScreenShield ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export const MediaStorageEnginePanel: React.FC = () => {
  const { storageBreakdown, cleanStorageCache, setIsP2PStorageDashboardOpen } = useChat();

  const [smartAutoCleanup, setSmartAutoCleanup] = React.useState<boolean>(() => {
    try {
      return localStorage.getItem('splender_smart_auto_cleanup') !== 'false';
    } catch {
      return true;
    }
  });

  const [autoCleanupPeriod, setAutoCleanupPeriod] = React.useState<string>(() => {
    try {
      return localStorage.getItem('splender_auto_cleanup_period') || '30days';
    } catch {
      return '30days';
    }
  });

  const totalUsedMB = storageBreakdown.totalUsed;
  const totalFreeMB = storageBreakdown.totalFree;
  const totalCapacityMB = Math.max(1, totalUsedMB + totalFreeMB);

  const filesPct = (storageBreakdown.files / totalCapacityMB) * 100;
  const mediaPct = (storageBreakdown.media / totalCapacityMB) * 100;
  const audioPct = (storageBreakdown.audio / totalCapacityMB) * 100;
  const cachePct = (storageBreakdown.cache / totalCapacityMB) * 100;

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-[#22D3EE]/15 border border-[#22D3EE]/30 text-[#22D3EE] flex items-center justify-center shrink-0">
            <HardDrive className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Media & Storage Engine</h4>
            <p className="text-xs text-[#A8B3CC] truncate">
              Encrypted chunk cache inspection & storage management
            </p>
          </div>
        </div>

        {/* Action Buttons: P2P Cleanup Dashboard + Quick Cache Clean */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              playClickSound();
              setIsP2PStorageDashboardOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0D1424] border border-[#293650] hover:border-[#22D3EE]/60 text-[#22D3EE] text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap shrink-0"
            title="Open P2P Storage Dashboard"
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>P2P Storage</span>
          </button>

          <button
            onClick={() => {
              playPopSound();
              cleanStorageCache();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F472B6]/15 border border-[#F472B6]/35 hover:bg-[#F472B6]/25 text-[#F472B6] text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap shrink-0"
            title="Clean temporary cache"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clean Cache</span>
          </button>
        </div>
      </div>

      {/* Storage Breakdown Chart Widget */}
      <div className="p-4 rounded-xl bg-[#0D1424] border border-[#293650] space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs text-[#A8B3CC] block">
              Used Storage
            </span>
            <span className="text-base font-bold text-[#F4F7FF] font-mono tabular-nums">
              {(totalUsedMB / 1024).toFixed(2)} GB
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs text-[#A8B3CC] block">
              Free Available
            </span>
            <span className="text-base font-bold text-[#10B981] font-mono tabular-nums">
              {(totalFreeMB / 1024).toFixed(2)} GB
            </span>
          </div>
        </div>

        {/* Multi-segment Colored Bar Chart */}
        <div className="w-full h-2.5 rounded-full bg-[#080B14] border border-[#293650] overflow-hidden flex">
          <div
            style={{ width: `${mediaPct}%` }}
            className="bg-[#8B5CF6] h-full transition-all duration-300"
            title={`Media: ${storageBreakdown.media} MB`}
          />
          <div
            style={{ width: `${filesPct}%` }}
            className="bg-[#22D3EE] h-full transition-all duration-300"
            title={`Documents & Files: ${storageBreakdown.files} MB`}
          />
          <div
            style={{ width: `${audioPct}%` }}
            className="bg-[#3B82F6] h-full transition-all duration-300"
            title={`Audio: ${storageBreakdown.audio} MB`}
          />
          <div
            style={{ width: `${cachePct}%` }}
            className="bg-[#F472B6] h-full transition-all duration-300"
            title={`Cache: ${storageBreakdown.cache} MB`}
          />
        </div>

        {/* Legend Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#8B5CF6] shrink-0" />
            <div className="truncate">
              <span className="text-[#A8B3CC] block text-[11px]">Media</span>
              <span className="font-semibold text-[#F4F7FF] font-mono tabular-nums">
                {storageBreakdown.media} MB
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#22D3EE] shrink-0" />
            <div className="truncate">
              <span className="text-[#A8B3CC] block text-[11px]">Files</span>
              <span className="font-semibold text-[#F4F7FF] font-mono tabular-nums">
                {storageBreakdown.files} MB
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#3B82F6] shrink-0" />
            <div className="truncate">
              <span className="text-[#A8B3CC] block text-[11px]">Audio</span>
              <span className="font-semibold text-[#F4F7FF] font-mono tabular-nums">
                {storageBreakdown.audio} MB
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#F472B6] shrink-0" />
            <div className="truncate">
              <span className="text-[#A8B3CC] block text-[11px]">Cache</span>
              <span className="font-semibold text-[#F4F7FF] font-mono tabular-nums">
                {storageBreakdown.cache} MB
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Smart Auto-Cleanup Feature */}
      <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <span className="text-xs font-semibold text-[#F4F7FF] block">
              Smart Auto-Cleanup
            </span>
            <span className="text-xs text-[#A8B3CC] block mt-0.5">
              Automatically purge expired voice caches & temporary chunks
            </span>
          </div>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSmartAutoCleanup((prev) => {
                const next = !prev;
                localStorage.setItem('splender_smart_auto_cleanup', String(next));
                return next;
              });
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              smartAutoCleanup ? 'bg-[#10B981]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                smartAutoCleanup ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {smartAutoCleanup && (
          <div className="space-y-2.5 pt-2.5 border-t border-[#293650]/70">
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="text-[#A8B3CC]">Cache Retention</span>
              <div className="flex items-center gap-1.5">
                {[
                  { id: '7days', label: '7 Days' },
                  { id: '30days', label: '30 Days' },
                  { id: '90days', label: '90 Days' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      playClickSound();
                      setAutoCleanupPeriod(item.id);
                      localStorage.setItem('splender_auto_cleanup_period', item.id);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      autoCleanupPeriod === item.id
                        ? 'bg-[#10B981] text-white'
                        : 'bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-[#A8B3CC]">
              <span className="flex items-center gap-1 text-[#10B981] font-medium">
                <Check className="w-3.5 h-3.5" /> Background cleanup active
              </span>
              <button
                type="button"
                onClick={() => {
                  playPopSound();
                  cleanStorageCache();
                }}
                className="text-[#22D3EE] hover:underline font-semibold cursor-pointer whitespace-nowrap shrink-0"
              >
                Run Cleanup Now
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const LanguageAccessibilityPanel: React.FC = () => {
  const {
    language,
    setLanguage,
    fontSize,
    setFontSize,
    realtimeTranslation,
    setRealtimeTranslation,
    voiceCommandControl,
    setVoiceCommandControl,
    showToast,
  } = useChat();

  return (
    <div className="rounded-2xl p-4 bg-[#131D32]/90 border border-[#293650] space-y-4 text-[#F4F7FF]">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-[#22D3EE]/15 border border-[#22D3EE]/30 text-[#22D3EE] flex items-center justify-center shrink-0">
          <Languages className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-sm font-semibold font-['Outfit'] text-[#F4F7FF]">Language & Accessibility</h4>
          <p className="text-xs text-[#A8B3CC]">
            Interface locale, dynamic font scaling & voice dictation
          </p>
        </div>
      </div>

      <div className="space-y-3 pt-1">
        {/* Quick Language Switcher */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] space-y-2.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-[#F4F7FF]">
              Interface Language
            </label>
            <span className="text-xs font-semibold text-[#22D3EE]">
              {language === 'mr' ? 'मराठी' : language === 'hi' ? 'हिंदी' : language === 'en' ? 'English' : language === 'es' ? 'Español' : language === 'fr' ? 'Français' : 'Deutsch'}
            </span>
          </div>

          <div className="grid grid-cols-6 gap-1.5 pt-0.5">
            {[
              { id: 'mr' as const, label: 'MR', name: 'मराठी' },
              { id: 'hi' as const, label: 'HI', name: 'हिंदी' },
              { id: 'en' as const, label: 'EN', name: 'English' },
              { id: 'es' as const, label: 'ES', name: 'Español' },
              { id: 'fr' as const, label: 'FR', name: 'Français' },
              { id: 'de' as const, label: 'DE', name: 'Deutsch' },
            ].map((item) => {
              const isSelected = language === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setLanguage(item.id);
                    showToast('Language Changed', `Switched to ${item.name}`, 'info');
                  }}
                  className={`py-1.5 rounded-lg text-xs font-semibold font-mono transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-[#8B5CF6] text-white'
                      : 'bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                  }`}
                  title={item.name}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <select
            value={language}
            onChange={(e) => {
              playClickSound();
              setLanguage(e.target.value as any);
              showToast('Language Changed', `Interface set to ${e.target.value.toUpperCase()}`, 'info');
            }}
            className="w-full p-2.5 rounded-xl border border-[#293650] bg-[#080B14] text-[#F4F7FF] font-medium text-xs outline-none focus:border-[#22D3EE] cursor-pointer mt-1"
          >
            <option value="mr">मराठी (Marathi - Default)</option>
            <option value="hi">हिंदी (Hindi)</option>
            <option value="en">English (Global)</option>
            <option value="es">Español (Spanish)</option>
            <option value="fr">Français (French)</option>
            <option value="de">Deutsch (German)</option>
          </select>
        </div>

        {/* Font Size adjustment slider */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-[#22D3EE]" />
              <span className="font-semibold text-[#F4F7FF]">
                Dynamic Font Size
              </span>
            </div>
            <span className="font-mono tabular-nums font-semibold text-[#22D3EE]">
              {fontSize}px
            </span>
          </div>

          <input
            type="range"
            min="12"
            max="24"
            step="1"
            value={fontSize}
            onChange={(e) => setFontSize(Number(e.target.value))}
            className="w-full accent-[#22D3EE] cursor-pointer"
          />

          <div className="flex justify-between text-[11px] text-[#A8B3CC] font-mono tabular-nums">
            <span>12px</span>
            <span>15px</span>
            <span>18px</span>
            <span>24px</span>
          </div>

          {/* Live Text Preview Box */}
          <div className="mt-2 p-2.5 rounded-xl bg-[#080B14] border border-[#293650] text-center">
            <p style={{ fontSize: `${fontSize}px` }} className="font-medium text-[#F4F7FF] leading-snug">
              सुंदर आणि सुरक्षित चॅट · Preview font scale
            </p>
          </div>
        </div>

        {/* Toggle 1: Real-time Translation */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#F4F7FF]">
              Real-time Translation
            </p>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Translate incoming messages into your preferred language
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !realtimeTranslation;
              setRealtimeTranslation(next);
              showToast('Real-time Translation', next ? 'Live translation active' : 'Disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              realtimeTranslation ? 'bg-[#22D3EE]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                realtimeTranslation ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Toggle 2: Voice Command Control */}
        <div className="p-3.5 rounded-xl bg-[#0D1424] border border-[#293650] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <Mic className="w-3.5 h-3.5 text-[#22D3EE] shrink-0" />
              <p className="text-xs font-semibold text-[#F4F7FF]">
                Voice Dictation Control
              </p>
            </div>
            <p className="text-xs text-[#A8B3CC] mt-0.5">
              Hands-free voice-to-text dictation assistance
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              const next = !voiceCommandControl;
              setVoiceCommandControl(next);
              showToast('Voice Dictation', next ? 'Voice dictation active' : 'Disabled', 'info');
            }}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              voiceCommandControl ? 'bg-[#22D3EE]' : 'bg-[#293650]'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                voiceCommandControl ? 'left-5.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
