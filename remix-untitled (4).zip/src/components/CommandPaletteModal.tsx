import React, { useState, useEffect } from 'react';
import {
  Search,
  Sparkles,
  Lock,
  Battery,
  Palette,
  MessageSquare,
  Users,
  Briefcase,
  GraduationCap,
  X,
  Star,
  Check,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';
import { ThemeMode, ChatCategory } from '../types';
import { createDeterministicAvatarDataUri } from '../lib/firebase';

export const CommandPaletteModal: React.FC = () => {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    theme,
    setTheme,
    activeCategory,
    setActiveCategory,
    batterySaver,
    setBatterySaver,
    setActiveConversationId,
    conversations,
  } = useChat();

  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && commandPaletteOpen) {
        setCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [commandPaletteOpen, setCommandPaletteOpen]);

  if (!commandPaletteOpen) return null;

  const themes: { id: ThemeMode; name: string; color: string; desc: string }[] = [
    { id: 'indigo_dawn', name: 'Indigo Dawn', color: '#2A2438', desc: 'Obsidian Twilight & Slate (Luxury)' },
    { id: 'apricot_bloom', name: 'Apricot Bloom', color: '#E27D60', desc: 'Warm Terracotta Sunset & Silk (Luxury)' },
    { id: 'teal_dusk', name: 'Teal Dusk', color: '#005F73', desc: 'Oceanic Cyan & Mint Frost (Luxury)' },
    { id: 'rose_quartz', name: 'Rose Quartz', color: '#8D5B4C', desc: 'Artisan Rosewood & Soft Cream (Luxury)' },
    { id: 'emerald', name: 'Emerald WhatsApp', color: '#008069', desc: 'Classic Flagship Green' },
    { id: 'midnight_oled', name: 'Midnight OLED', color: '#000000', desc: 'Pure Pitch AMOLED' },
    { id: 'emerald_luxury', name: 'Emerald Luxury', color: '#064e3b', desc: 'Deep Royal Emerald & Gold' },
    { id: 'cyber_indigo', name: 'Cyber Indigo', color: '#4F46E5', desc: 'Electric Indigo & Neon' },
  ];

  const categories: { id: ChatCategory; name: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'all', name: 'All Chats', icon: MessageSquare },
    { id: 'personal', name: 'Personal', icon: Users },
    { id: 'work', name: 'Work', icon: Briefcase },
    { id: 'college', name: 'College', icon: GraduationCap },
    { id: 'unread', name: 'Unread Only', icon: Star },
  ];

  return (
    <div
      onClick={() => setCommandPaletteOpen(false)}
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/60 backdrop-blur-md animate-in fade-in select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-3xl bg-white dark:bg-[#111B21] border border-slate-200 dark:border-slate-800 shadow-2xl modal-spring overflow-hidden text-[#111B21] dark:text-[#E9EDEF]"
      >
        {/* Search Input Bar */}
        <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-emerald-500 shrink-0" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, theme, category or conversation..."
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400 font-medium"
          />
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono rounded bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
            ESC
          </kbd>
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="max-h-[60vh] overflow-y-auto no-scrollbar p-3 space-y-4 text-xs">
          {/* Quick AI & Actions */}
          <div className="space-y-1">
            <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Quick Actions</p>
            <button
              onClick={() => {
                playPopSound();
                setActiveConversationId('splender_ai_assistant');
                setCommandPaletteOpen(false);
              }}
              className="w-full p-2.5 rounded-2xl flex items-center justify-between hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-colors cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold">Splender AI Assistant</p>
                  <p className="text-[10px] text-slate-400">Summaries, instant neural replies & translations</p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">Open</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setBatterySaver(!batterySaver);
              }}
              className="w-full p-2.5 rounded-2xl flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <Battery className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold">Toggle Battery Saver Mode</p>
                  <p className="text-[10px] text-slate-400">Reduces UI micro-animations and saves power</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${batterySaver ? 'bg-amber-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                {batterySaver ? 'Active' : 'Off'}
              </span>
            </button>
          </div>

          {/* Elite Visual Themes */}
          <div className="space-y-1">
            <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Elite Themes</p>
            <div className="grid grid-cols-2 gap-2">
              {themes.map((th) => (
                <button
                  key={th.id}
                  onClick={() => {
                    playClickSound();
                    setTheme(th.id);
                  }}
                  className={`p-2.5 rounded-2xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                    theme === th.id
                      ? 'border-emerald-500 bg-emerald-50/20 dark:bg-emerald-950/20 ring-2 ring-emerald-500/30'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-5 h-5 rounded-full border border-white/20 shadow-xs shrink-0"
                      style={{ backgroundColor: th.color }}
                    />
                    <div>
                      <p className="font-bold text-[11px] leading-tight">{th.name}</p>
                      <p className="text-[9px] text-slate-400">{th.desc}</p>
                    </div>
                  </div>
                  {theme === th.id && <Check className="w-4 h-4 text-emerald-500 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Category Filters */}
          <div className="space-y-1">
            <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Chat Categories</p>
            <div className="grid grid-cols-3 gap-1.5">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = activeCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      playClickSound();
                      setActiveCategory(cat.id);
                      setCommandPaletteOpen(false);
                    }}
                    className={`p-2 rounded-xl flex items-center gap-2 transition-colors cursor-pointer text-left ${
                      isSelected
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-[11px] truncate">{cat.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Matching Conversations */}
          {query.trim() && (
            <div className="space-y-1 pt-1 border-t border-slate-100 dark:border-slate-800">
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Matching Chats</p>
              {conversations
                .filter((c) => (c.groupName || Object.values(c.participantNames || {}).join(' ')).toLowerCase().includes(query.toLowerCase()))
                .slice(0, 5)
                .map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => {
                      playPopSound();
                      setActiveConversationId(conv.id);
                      setCommandPaletteOpen(false);
                    }}
                    className="w-full p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-3 text-left cursor-pointer"
                  >
                    <img
                      src={conv.groupAvatar || createDeterministicAvatarDataUri(conv.groupName || 'Chat', '#0F766E')}
                      alt=""
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="font-semibold text-xs truncate">
                      {conv.groupName || 'Chat'}
                    </span>
                  </button>
                ))}
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
          <span>Splender Command Palette</span>
          <span>Tip: Press Cmd+K anywhere to launch</span>
        </div>
      </div>
    </div>
  );
};
