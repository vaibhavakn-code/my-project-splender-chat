import React, { useState, useRef, useEffect } from 'react';
import {
  Palette,
  X,
  Check,
  Upload,
  Image as ImageIcon,
  Eye,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { playClickSound, playPopSound } from '../lib/sound';

export interface WallpaperPreset {
  id: string;
  name: string;
  category: 'gradient' | 'pattern' | 'artistic';
  description: string;
  style: React.CSSProperties;
  thumbnailStyle: React.CSSProperties;
}

export const LUXURY_WALLPAPERS: WallpaperPreset[] = [
  {
    id: 'aurora_nebula',
    name: 'Aurora Nebula Deep Space',
    category: 'gradient',
    description: 'Obsidian night with subtle violet, cyan, and cosmic blue radial light',
    style: {
      backgroundColor: '#080B14',
      backgroundImage:
        'radial-gradient(circle at 18% 12%, rgba(139, 92, 246, 0.16), transparent 44%), radial-gradient(circle at 84% 18%, rgba(34, 211, 238, 0.13), transparent 42%), radial-gradient(circle at 50% 88%, rgba(59, 130, 246, 0.12), transparent 48%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #080B14 0%, #1E1B4B 55%, #083344 100%)',
    },
  },
  {
    id: 'imperial_velvet',
    name: 'Imperial Velvet',
    category: 'gradient',
    description: 'Deep royal twilight purple, indigo and obsidian noir',
    style: {
      background: 'linear-gradient(135deg, #1e1b4b 0%, #311042 50%, #0f172a 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #1e1b4b 0%, #311042 50%, #0f172a 100%)',
    },
  },
  {
    id: 'aquatic_teal',
    name: 'Aquatic Teal Dusk',
    category: 'gradient',
    description: 'Oceanic deep cyan, aquatic luminescence and marine abyss',
    style: {
      background: 'linear-gradient(135deg, #005F73 0%, #0a3d47 50%, #021f26 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #005F73 0%, #0a3d47 50%, #021f26 100%)',
    },
  },
  {
    id: 'cyber_amethyst',
    name: 'Cyber Amethyst',
    category: 'gradient',
    description: 'Electric violet twilight and deep starry graphite',
    style: {
      background: 'linear-gradient(135deg, #4c1d95 0%, #2e1065 50%, #080B14 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #4c1d95 0%, #2e1065 50%, #080B14 100%)',
    },
  },
  {
    id: 'emerald_imperial',
    name: 'Emerald Imperial Veil',
    category: 'gradient',
    description: 'Deep sovereign emerald forest and obsidian glow',
    style: {
      background: 'linear-gradient(135deg, #064e3b 0%, #022c22 50%, #011812 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #064e3b 0%, #022c22 50%, #011812 100%)',
    },
  },
  {
    id: 'golden_amber',
    name: 'Golden Amber Radiance',
    category: 'gradient',
    description: 'Warm cognac, terracotta glow and gilded amber',
    style: {
      background: 'linear-gradient(135deg, #7c2d12 0%, #b45309 50%, #451a03 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #7c2d12 0%, #b45309 50%, #451a03 100%)',
    },
  },
  {
    id: 'rose_quartz_blush',
    name: 'Rose Quartz Dusk',
    category: 'gradient',
    description: 'Artisan rosewood, magenta dusk and quartz dust',
    style: {
      background: 'linear-gradient(135deg, #4c1d3d 0%, #831843 50%, #190b18 100%)',
    },
    thumbnailStyle: {
      background: 'linear-gradient(135deg, #4c1d3d 0%, #831843 50%, #190b18 100%)',
    },
  },
  {
    id: 'carbon_hex_matrix',
    name: 'Carbon Hex Matrix',
    category: 'pattern',
    description: 'Precision micro-dot geometry on Obsidian Night',
    style: {
      backgroundColor: '#080B14',
      backgroundImage: `radial-gradient(circle, rgba(255,255,255,0.07) 1px, transparent 1px), radial-gradient(circle, rgba(34,211,238,0.07) 1px, #080B14 1px)`,
      backgroundSize: '18px 18px',
      backgroundPosition: '0 0, 9px 9px',
    },
    thumbnailStyle: {
      backgroundColor: '#080B14',
      backgroundImage: `radial-gradient(circle, rgba(34,211,238,0.2) 1px, transparent 1px)`,
      backgroundSize: '8px 8px',
    },
  },
  {
    id: 'isometric_blueprint',
    name: 'Deep Space Grid',
    category: 'pattern',
    description: 'Minimal architectural grid on Obsidian Night',
    style: {
      backgroundColor: '#080B14',
      backgroundImage: `linear-gradient(to right, rgba(41,54,80,0.35) 1px, transparent 1px), linear-gradient(to bottom, rgba(41,54,80,0.35) 1px, transparent 1px)`,
      backgroundSize: '24px 24px',
    },
    thumbnailStyle: {
      backgroundColor: '#080B14',
      backgroundImage: `linear-gradient(to right, rgba(41,54,80,0.6) 1px, transparent 1px), linear-gradient(to bottom, rgba(41,54,80,0.6) 1px, transparent 1px)`,
      backgroundSize: '10px 10px',
    },
  },
  {
    id: 'constellation_stars',
    name: 'Constellation Field',
    category: 'pattern',
    description: 'Subtle celestial stars and quiet nebula luminescence',
    style: {
      backgroundColor: '#080B14',
      backgroundImage: `radial-gradient(1.5px 1.5px at 20px 30px, rgba(244,247,255,0.7), rgba(0,0,0,0)), radial-gradient(2px 2px at 40px 70px, rgba(34,211,238,0.65), rgba(0,0,0,0)), radial-gradient(1.5px 1.5px at 90px 40px, rgba(139,92,246,0.7), rgba(0,0,0,0))`,
      backgroundSize: '120px 120px',
    },
    thumbnailStyle: {
      backgroundColor: '#080B14',
      backgroundImage: `radial-gradient(1.5px 1.5px at 10px 15px, #F4F7FF, transparent), radial-gradient(1.5px 1.5px at 25px 30px, #22D3EE, transparent)`,
      backgroundSize: '40px 40px',
    },
  },
  {
    id: 'midnight_oled_pure',
    name: 'Midnight OLED Pitch Black',
    category: 'pattern',
    description: 'Zero power AMOLED #000000 true black canvas',
    style: {
      backgroundColor: '#000000',
    },
    thumbnailStyle: {
      backgroundColor: '#000000',
    },
  },
];

interface WallpaperEngineModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversationId?: string | null;
}

export const WallpaperEngineModal: React.FC<WallpaperEngineModalProps> = ({
  isOpen,
  onClose,
  conversationId = null,
}) => {
  const { showToast } = useChat();

  const [activeCategory, setActiveCategory] = useState<'all' | 'gradient' | 'pattern' | 'custom'>('all');
  const [selectedPresetId, setSelectedPresetId] = useState<string>(() => {
    return (
      (conversationId && localStorage.getItem(`splender_wallpaper_${conversationId}`)) ||
      localStorage.getItem('splender_global_wallpaper') ||
      'aurora_nebula'
    );
  });

  const [customImageUrl, setCustomImageUrl] = useState<string>(() => {
    return (
      (conversationId && localStorage.getItem(`splender_wallpaper_url_${conversationId}`)) ||
      localStorage.getItem('splender_global_wallpaper_url') ||
      ''
    );
  });

  const [overlayDim, setOverlayDim] = useState<number>(() => {
    const saved = localStorage.getItem('splender_wallpaper_dim');
    return saved !== null ? Number(saved) : 20;
  });

  const [blurAmount, setBlurAmount] = useState<number>(() => {
    const saved = localStorage.getItem('splender_wallpaper_blur');
    return saved !== null ? Number(saved) : 0;
  });

  const [urlInput, setUrlInput] = useState('');
  const [applyGlobally, setApplyGlobally] = useState<boolean>(!conversationId);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const curPreset =
        (conversationId && localStorage.getItem(`splender_wallpaper_${conversationId}`)) ||
        localStorage.getItem('splender_global_wallpaper') ||
        'aurora_nebula';
      const curUrl =
        (conversationId && localStorage.getItem(`splender_wallpaper_url_${conversationId}`)) ||
        localStorage.getItem('splender_global_wallpaper_url') ||
        '';
      setSelectedPresetId(curPreset);
      setCustomImageUrl(curUrl);
      if (curUrl) setUrlInput(curUrl);
    }
  }, [isOpen, conversationId]);

  if (!isOpen) return null;

  const currentPreset = LUXURY_WALLPAPERS.find((p) => p.id === selectedPresetId);

  const getPreviewWallpaperStyle = (): React.CSSProperties => {
    if (customImageUrl) {
      return {
        backgroundImage: `url(${customImageUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      };
    }
    return currentPreset?.style || LUXURY_WALLPAPERS[0].style;
  };

  const handleApplyPreset = (presetId: string) => {
    playClickSound();
    setSelectedPresetId(presetId);
    setCustomImageUrl('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Invalid File', 'Please select a valid image file', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setCustomImageUrl(result);
      setSelectedPresetId('custom_upload');
      playPopSound();
      showToast('Image Loaded', 'Custom background photo ready to preview and save', 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleApplyCustomUrl = () => {
    const trimmed = urlInput.trim();
    if (!trimmed) {
      showToast('URL Required', 'Please enter a valid image web link', 'warning');
      return;
    }
    playClickSound();
    setCustomImageUrl(trimmed);
    setSelectedPresetId('custom_url');
    showToast('Image URL Applied', 'Previewing custom web background', 'info');
  };

  const handleSaveAndApply = () => {
    playPopSound();

    localStorage.setItem('splender_wallpaper_dim', String(overlayDim));
    localStorage.setItem('splender_wallpaper_blur', String(blurAmount));

    if (applyGlobally || !conversationId) {
      localStorage.setItem('splender_global_wallpaper', selectedPresetId);
      localStorage.setItem('splender_global_wallpaper_url', customImageUrl);
      showToast('Wallpaper Saved Globally', 'Applied across all chat rooms', 'success');
    } else {
      localStorage.setItem(`splender_wallpaper_${conversationId}`, selectedPresetId);
      localStorage.setItem(`splender_wallpaper_url_${conversationId}`, customImageUrl);
      showToast('Chat Wallpaper Applied', 'Customized for this conversation', 'success');
    }

    onClose();
  };

  const handleResetToDefault = () => {
    playClickSound();
    setSelectedPresetId('aurora_nebula');
    setCustomImageUrl('');
    setUrlInput('');
    setOverlayDim(20);
    setBlurAmount(0);

    if (conversationId) {
      localStorage.removeItem(`splender_wallpaper_${conversationId}`);
      localStorage.removeItem(`splender_wallpaper_url_${conversationId}`);
    }
    localStorage.setItem('splender_global_wallpaper', 'aurora_nebula');
    localStorage.removeItem('splender_global_wallpaper_url');
    showToast('Reset Complete', 'Restored Aurora Nebula default wallpaper', 'info');
  };

  const filteredPresets = LUXURY_WALLPAPERS.filter((p) => {
    if (activeCategory === 'all') return true;
    return p.category === activeCategory;
  });

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-60 bg-[#080B14]/82 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 select-none animate-in fade-in duration-200"
    >
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#0D1424] border-t sm:border border-[#293650] rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-[0_24px_64px_rgba(0,0,0,0.75)] modal-slide-up text-[#F4F7FF] overflow-hidden"
      >
        <div className="w-10 h-1 bg-[#293650] rounded-full mx-auto mt-2.5 sm:hidden shrink-0" />

        {/* Header Bar */}
        <div className="px-4 py-3 flex items-center justify-between bg-[#080B14]/88 backdrop-blur-xl text-[#F4F7FF] border-b border-[#293650] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/15 border border-[#8B5CF6]/30 flex items-center justify-center text-[#22D3EE]">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold font-['Outfit'] leading-tight">Custom Wallpaper Engine</h3>
              <p className="text-xs text-[#A8B3CC]">
                Aurora Nebula mesh, dark gradients & custom photos
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl hover:bg-[#131D32] text-[#A8B3CC] hover:text-[#F4F7FF] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* Live Preview Card */}
          <div className="rounded-2xl border border-[#293650] overflow-hidden bg-[#131D32]/80">
            <div className="px-3.5 py-2.5 bg-[#080B14]/70 border-b border-[#293650] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-[#22D3EE]" />
                <span className="text-xs font-semibold text-[#A8B3CC]">
                  Live Chat Room Preview
                </span>
              </div>
              <span className="text-xs font-mono text-[#22D3EE] font-medium">
                {customImageUrl ? 'Custom Image' : currentPreset?.name || 'Selected'}
              </span>
            </div>

            {/* Simulated Chat Room Surface */}
            <div
              className="relative p-4 h-44 flex flex-col justify-between overflow-hidden transition-all duration-300"
              style={getPreviewWallpaperStyle()}
            >
              <div
                className="absolute inset-0 pointer-events-none transition-all duration-200"
                style={{
                  backgroundColor: `rgba(8, 11, 20, ${overlayDim / 100})`,
                  backdropFilter: blurAmount > 0 ? `blur(${blurAmount}px)` : 'none',
                }}
              />

              {/* Sample Incoming Message */}
              <div className="relative z-10 self-start max-w-[75%] rounded-2xl p-2.5 glass-bubble-peer text-xs">
                <p className="font-semibold text-[11px] text-[#22D3EE] mb-0.5">
                  Elena Rostova
                </p>
                <p className="text-xs leading-snug text-[#F4F7FF]">
                  Aurora Nebula glass bubbles stay crisp across every backdrop.
                </p>
                <span className="block text-[10px] text-[#A8B3CC] text-right mt-1 font-mono tabular-nums">
                  10:42 AM
                </span>
              </div>

              {/* Sample Outgoing Message */}
              <div className="relative z-10 self-end max-w-[75%] rounded-2xl p-2.5 glass-bubble-me text-white text-xs">
                <p className="text-xs leading-snug">
                  End-to-end encrypted P2P session verified.
                </p>
                <div className="flex items-center justify-end gap-1 mt-1 text-[10px] text-white/80 font-mono tabular-nums">
                  <span>10:43 AM</span>
                  <span className="text-[#22D3EE] font-bold">✓✓</span>
                </div>
              </div>
            </div>

            {/* Readability Controls: Dim Overlay & Blur */}
            <div className="p-3.5 bg-[#0D1424] border-t border-[#293650] grid grid-cols-2 gap-3 text-xs">
              <div>
                <div className="flex items-center justify-between text-xs font-medium text-[#A8B3CC] mb-1.5">
                  <span>Dim Overlay</span>
                  <span className="font-mono tabular-nums font-semibold text-[#22D3EE]">{overlayDim}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  step="5"
                  value={overlayDim}
                  onChange={(e) => setOverlayDim(Number(e.target.value))}
                  className="w-full accent-[#22D3EE] cursor-pointer h-1.5 bg-[#080B14] rounded-lg"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-medium text-[#A8B3CC] mb-1.5">
                  <span>Soft Blur</span>
                  <span className="font-mono tabular-nums font-semibold text-[#22D3EE]">{blurAmount}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  step="1"
                  value={blurAmount}
                  onChange={(e) => setBlurAmount(Number(e.target.value))}
                  className="w-full accent-[#8B5CF6] cursor-pointer h-1.5 bg-[#080B14] rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {[
              { id: 'all' as const, label: 'All Styles' },
              { id: 'gradient' as const, label: 'Aurora Gradients' },
              { id: 'pattern' as const, label: 'Minimalist Dark' },
              { id: 'custom' as const, label: 'Upload / URL' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  playClickSound();
                  setActiveCategory(tab.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  activeCategory === tab.id
                    ? 'bg-[#8B5CF6] text-white'
                    : 'bg-[#131D32] border border-[#293650] text-[#A8B3CC] hover:text-[#F4F7FF]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Custom Image Upload & URL Section */}
          {(activeCategory === 'custom' || activeCategory === 'all') && (
            <div className="p-3.5 rounded-2xl border border-dashed border-[#22D3EE]/45 bg-[#131D32]/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#22D3EE]">
                  <ImageIcon className="w-4 h-4" />
                  <span>Custom Background Image</span>
                </div>
                <span className="text-xs text-[#A8B3CC]">PNG · JPG · WebP</span>
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 px-3 rounded-xl aurora-cta-gradient text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload from Device</span>
              </button>

              <div className="flex items-center gap-1.5">
                <input
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="Or enter image URL (https://...)"
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-[#080B14] border border-[#293650] text-[#F4F7FF] outline-none focus:border-[#22D3EE]"
                />
                <button
                  type="button"
                  onClick={handleApplyCustomUrl}
                  disabled={!urlInput.trim()}
                  className="px-3.5 py-2 rounded-xl bg-[#131D32] border border-[#293650] hover:border-[#22D3EE]/50 text-[#F4F7FF] text-xs font-semibold disabled:opacity-40 cursor-pointer whitespace-nowrap shrink-0"
                >
                  Apply
                </button>
              </div>
            </div>
          )}

          {/* Curated Preset Grid */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-[#A8B3CC] tabular-nums">
              Curated Wallpapers ({filteredPresets.length})
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredPresets.map((preset) => {
                const isSelected = selectedPresetId === preset.id && !customImageUrl;
                return (
                  <div
                    key={preset.id}
                    onClick={() => handleApplyPreset(preset.id)}
                    className={`p-3 rounded-2xl border transition-colors cursor-pointer flex items-center gap-3 ${
                      isSelected
                        ? 'border-[#22D3EE] ring-1 ring-[#22D3EE]/35 bg-[#131D32]'
                        : 'border-[#293650] bg-[#131D32]/65 hover:border-[#8B5CF6]/50'
                    }`}
                  >
                    <div
                      className="w-12 h-12 rounded-xl border border-white/15 shrink-0 overflow-hidden"
                      style={preset.thumbnailStyle}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-[#F4F7FF] truncate">
                          {preset.name}
                        </p>
                        {isSelected && (
                          <Check className="w-4 h-4 text-[#22D3EE] shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-[#A8B3CC] line-clamp-1 mt-0.5">
                        {preset.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 border-t border-[#293650] bg-[#080B14]/88 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            {conversationId && (
              <label className="flex items-center gap-1.5 text-xs font-medium cursor-pointer text-[#A8B3CC]">
                <input
                  type="checkbox"
                  checked={applyGlobally}
                  onChange={(e) => setApplyGlobally(e.target.checked)}
                  className="rounded accent-[#8B5CF6]"
                />
                <span>Set for all chats</span>
              </label>
            )}
            <button
              type="button"
              onClick={handleResetToDefault}
              className="text-xs font-semibold text-[#A8B3CC] hover:text-[#F472B6] cursor-pointer transition-colors whitespace-nowrap"
            >
              Reset Default
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl bg-[#131D32] border border-[#293650] text-[#F4F7FF] text-xs font-semibold cursor-pointer hover:bg-[#0D1424] whitespace-nowrap"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveAndApply}
              className="px-4 py-2 rounded-xl aurora-cta-gradient text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
            >
              Apply Wallpaper
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
