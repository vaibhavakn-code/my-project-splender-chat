// src/hooks/useOfflineChat.ts
import { useState, useEffect, useCallback, useRef } from 'react';
import { PadmavyuhaProtocol } from '../lib/padmavyuhaProtocol';
import { SanjivaniResilience, ResilientMessageItem } from '../lib/sanjivaniResilience';
import { CryptoService } from '../services/CryptoService';
import { SyncService } from '../services/SyncService';
import { auth } from '../lib/firebase';

export type PendingChatMessage = ResilientMessageItem;

export function useOfflineChat(roomId: string) {
  const sanjivani = useRef(SanjivaniResilience.getInstance()).current;

  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [pendingCount, setPendingCount] = useState<number>(0);
  const [circuitState, setCircuitState] = useState<string>('CLOSED');

  const syncQueue = useCallback(async () => {
    if (typeof window === 'undefined') return;

    try {
      const msgs = await sanjivani.getPending(roomId);
      setPendingCount(msgs.length);

      const canSync = navigator.onLine && sanjivani.canExecuteNetworkRequest();

      if (canSync && msgs.length > 0) {
        const senderUid = auth.currentUser?.uid || 'client_local';
        for (const msg of msgs) {
          try {
            const targetRoom = msg.roomId || roomId;
            const { envelope, ratchetStep } = await CryptoService.sealConversationPayload(
              targetRoom,
              undefined,
              { text: msg.content }
            );
            const syncRes = await SyncService.syncOutgoingMessage({
              idempotencyKey: msg.id,
              conversationId: targetRoom,
              senderUid,
              sealedMessagePayload: {
                id: msg.id,
                conversationId: targetRoom,
                senderUid,
                text: '[Encrypted]',
                type: 'text',
                encryptedEnvelope: envelope,
                ratchetStep,
                isEncrypted: true,
                encryptionProtocol: 'DOUBLE_RATCHET_V3',
                transportMode: 'e2ee_relay',
                createdAt: msg.timestamp,
                timestamp: msg.timestamp,
                status: 'sent',
              },
            });

            if (syncRes.status === 'synced' || syncRes.status === 'queued') {
              await sanjivani.remove(msg.id);
              sanjivani.recordSuccess();
            }
          } catch (e) {
            sanjivani.recordFailure();
            await new Promise((resolve) =>
              setTimeout(resolve, sanjivani.computeBackoffDelay(msg.retryCount))
            );
            console.debug('Sanjivani offline sync deferred:', e);
            break;
          }
        }

        const remaining = await sanjivani.getPending(roomId);
        setPendingCount(remaining.length);
      }

      const telemetry = sanjivani.getTelemetry(msgs.length);
      setCircuitState(telemetry.circuitState);
    } catch (err) {
      console.debug('useOfflineChat sync error:', err);
    }
  }, [roomId, sanjivani]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOnline = () => {
      setIsOnline(true);
      sanjivani.recordSuccess();
      syncQueue();
    };

    const handleOffline = () => {
      setIsOnline(false);
      sanjivani.recordFailure();
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    syncQueue();

    // Periodic self-healing sweep every 30 seconds
    const healInterval = setInterval(() => {
      sanjivani.selfHealQueue().then(() => syncQueue());
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(healInterval);
    };
  }, [syncQueue, sanjivani]);

  const sendMessage = async (content: string, senderUid: string = 'client_local') => {
    const rawContent = (content || '').trim();
    if (!rawContent) return;

    // Padmavyuha Protocol Security & Validation Layer
    const inspection = PadmavyuhaProtocol.inspectAndArm(
      rawContent,
      senderUid,
      roomId
    );

    const safeContent = inspection.sanitizedText;
    const msgId = inspection.idempotencyHash || `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    const item = await sanjivani.enqueue({
      id: msgId,
      roomId,
      content: safeContent,
      timestamp: Date.now(),
    });

    await syncQueue();
    return item;
  };

  return {
    isOnline,
    pendingCount,
    circuitState,
    sendMessage,
    syncQueue,
  };
}
