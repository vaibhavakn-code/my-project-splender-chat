/**
 * Splender Chat — Consolidated Network & Real-Time Connection Manager (`src/services/ConnectionManager.ts`)
 *
 * Prevents duplicate Firestore `onSnapshot` listeners, memory leaks, and mobile battery drain by:
 * 1. Multiplexing subscriptions via reference-counted channels (`room_messages`, `room_meta`, `online_peers`).
 * 2. Coalescing & throttling outgoing typing indicators (1.8s throttle + 3.0s auto-expire) and read receipts.
 * 3. Hibernating non-essential presence listeners when the mobile app stays backgrounded (`visibilityState === 'hidden'`)
 *    beyond a 25-second grace window, and transparently re-attaching upon foreground return.
 */

import {
  db,
  doc,
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  updateDoc,
} from '../lib/firebase';
import { Conversation, Message, UserProfile } from '../types';

export interface RoomRealtimeMeta {
  conversationId: string;
  typingUids: string[];
  unreadCountForMe: number;
  updatedAt: number;
}

export interface ConnectionDiagnostics {
  activeFirestoreListeners: number;
  activeChannels: string[];
  totalSubscribers: number;
  isHibernated: boolean;
  eventsDispatched: number;
}

type UnsubscribeFn = () => void;

interface MultiplexedChannel<TPayload> {
  key: string;
  subscribers: Set<(payload: TPayload) => void>;
  lastPayload?: TPayload;
  hasEmitted: boolean;
  firestoreUnsub: UnsubscribeFn | null;
  startFactory: () => UnsubscribeFn;
  pausableInBackground: boolean;
}

const TYPING_THROTTLE_MS = 1800;
const TYPING_AUTO_CLEAR_MS = 3000;
const BACKGROUND_HIBERNATE_DELAY_MS = 25_000;

export class RealtimeConnectionManager {
  private static instance: RealtimeConnectionManager | null = null;

  private channels = new Map<string, MultiplexedChannel<any>>();
  private typingLastSentAt = new Map<string, number>();
  private typingAutoClearTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private readReceiptDebounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private hibernateTimer: ReturnType<typeof setTimeout> | null = null;
  private isHibernated = false;
  private eventsDispatched = 0;
  private lifecycleAttached = false;

  private constructor() {
    this.attachVisibilityLifecycle();
  }

  public static getInstance(): RealtimeConnectionManager {
    if (!RealtimeConnectionManager.instance) {
      RealtimeConnectionManager.instance = new RealtimeConnectionManager();
    }
    return RealtimeConnectionManager.instance;
  }

  private attachVisibilityLifecycle(): void {
    if (this.lifecycleAttached || typeof document === 'undefined') return;
    this.lifecycleAttached = true;

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        if (this.hibernateTimer) clearTimeout(this.hibernateTimer);
        this.hibernateTimer = setTimeout(() => {
          this.enterBackgroundHibernation();
        }, BACKGROUND_HIBERNATE_DELAY_MS);
      } else {
        if (this.hibernateTimer) {
          clearTimeout(this.hibernateTimer);
          this.hibernateTimer = null;
        }
        this.resumeFromHibernation();
      }
    });
  }

  /**
   * Pauses background-pausable listeners (e.g., global online peer presence & typing watchers)
   * when app is in background to eliminate radio wakeups & battery drain on Android.
   */
  public enterBackgroundHibernation(): void {
    if (this.isHibernated) return;
    this.isHibernated = true;

    for (const channel of this.channels.values()) {
      if (channel.pausableInBackground && channel.firestoreUnsub) {
        channel.firestoreUnsub();
        channel.firestoreUnsub = null;
      }
    }
  }

  /**
   * Resumes any paused channels that still have active UI subscribers when returning to foreground.
   */
  public resumeFromHibernation(): void {
    if (!this.isHibernated) return;
    this.isHibernated = false;

    for (const channel of this.channels.values()) {
      if (channel.subscribers.size > 0 && !channel.firestoreUnsub) {
        channel.firestoreUnsub = channel.startFactory();
      }
    }
  }

  private retainChannel<TPayload>(
    key: string,
    pausableInBackground: boolean,
    createFirestoreStream: (emit: (payload: TPayload) => void) => UnsubscribeFn,
    subscriber: (payload: TPayload) => void
  ): UnsubscribeFn {
    let channel = this.channels.get(key) as MultiplexedChannel<TPayload> | undefined;

    if (!channel) {
      const emit = (payload: TPayload) => {
        const current = this.channels.get(key) as MultiplexedChannel<TPayload> | undefined;
        if (!current) return;
        current.lastPayload = payload;
        current.hasEmitted = true;
        this.eventsDispatched += 1;
        current.subscribers.forEach((cb) => {
          try {
            cb(payload);
          } catch (err) {
            console.debug(`ConnectionManager subscriber error on [${key}]:`, err);
          }
        });
      };

      const startFactory = () => createFirestoreStream(emit);
      channel = {
        key,
        subscribers: new Set(),
        hasEmitted: false,
        firestoreUnsub: this.isHibernated && pausableInBackground ? null : startFactory(),
        startFactory,
        pausableInBackground,
      };
      this.channels.set(key, channel);
    }

    channel.subscribers.add(subscriber);

    // Replay latest cached snapshot immediately to new subscriber without extra network roundtrip
    if (channel.hasEmitted && channel.lastPayload !== undefined) {
      try {
        subscriber(channel.lastPayload);
      } catch {
        // Ignore subscriber replay error
      }
    }

    let released = false;
    return () => {
      if (released) return;
      released = true;

      const active = this.channels.get(key) as MultiplexedChannel<TPayload> | undefined;
      if (!active) return;

      active.subscribers.delete(subscriber);
      if (active.subscribers.size === 0) {
        if (active.firestoreUnsub) {
          active.firestoreUnsub();
          active.firestoreUnsub = null;
        }
        this.channels.delete(key);
      }
    };
  }

  // ===========================================================================
  // 1. CONSOLIDATED CHAT ROOM MESSAGES STREAM
  // ===========================================================================

  public subscribeToRoomMessages(
    conversationId: string,
    onMessages: (rawMessages: Message[]) => void,
    maxLimit = 45
  ): UnsubscribeFn {
    if (
      !conversationId ||
      conversationId === 'conv_demo_starter' ||
      conversationId === 'splender_ai_assistant' ||
      conversationId.startsWith('p2p_')
    ) {
      onMessages([]);
      return () => {};
    }

    const channelKey = `room_messages:${conversationId}:${maxLimit}`;
    return this.retainChannel<Message[]>(
      channelKey,
      false,
      (emit) => {
        const msgQuery = query(
          collection(db, 'conversations', conversationId, 'messages'),
          orderBy('timestamp', 'asc'),
          limit(maxLimit)
        );
        return onSnapshot(
          msgQuery,
          (snapshot) => {
            const docs: Message[] = [];
            snapshot.forEach((d) => {
              const data = d.data();
              docs.push({
                id: d.id,
                senderId: data.senderId || data.senderUid || '',
                ...data,
                isViewOnce: Boolean(data.isViewOnce),
                isViewed: Boolean(data.isViewed || data.viewOnceOpened),
                viewOnceOpened: Boolean(data.viewOnceOpened || data.isViewed),
              } as Message);
            });
            emit(docs);
          },
          (err) => {
            console.debug(`Room messages listener notice [${conversationId}]:`, err);
          }
        );
      },
      onMessages
    );
  }

  // ===========================================================================
  // 2. CONSOLIDATED ROOM TYPING INDICATORS & READ RECEIPT STATE
  // ===========================================================================

  public subscribeToRoomMeta(
    conversationId: string,
    myUid: string,
    onMeta: (meta: RoomRealtimeMeta) => void
  ): UnsubscribeFn {
    if (
      !conversationId ||
      !myUid ||
      conversationId === 'conv_demo_starter' ||
      conversationId === 'splender_ai_assistant' ||
      conversationId.startsWith('p2p_')
    ) {
      return () => {};
    }

    const channelKey = `room_meta:${conversationId}`;
    return this.retainChannel<Conversation | null>(
      channelKey,
      true,
      (emit) => {
        const convRef = doc(db, 'conversations', conversationId);
        return onSnapshot(
          convRef,
          (snap) => {
            if (!snap.exists()) {
              emit(null);
              return;
            }
            emit({ id: snap.id, ...snap.data() } as Conversation);
          },
          (err) => {
            console.debug(`Room meta listener notice [${conversationId}]:`, err);
          }
        );
      },
      (conv) => {
        if (!conv) return;
        const typingMap = conv.typing || {};
        const typingUids = Object.entries(typingMap)
          .filter(([uid, active]) => active === true && uid !== myUid)
          .map(([uid]) => uid);

        onMeta({
          conversationId,
          typingUids,
          unreadCountForMe: conv.unreadCounts?.[myUid] || 0,
          updatedAt: conv.updatedAt || Date.now(),
        });
      }
    );
  }

  /**
   * Throttled & auto-expiring typing indicator emitter.
   * Suppresses redundant Firestore writes while typing continuously.
   */
  public async emitTypingIndicator(
    conversationId: string,
    myUid: string,
    isTyping: boolean
  ): Promise<void> {
    if (
      !conversationId ||
      !myUid ||
      conversationId === 'conv_demo_starter' ||
      conversationId === 'splender_ai_assistant' ||
      conversationId.startsWith('p2p_')
    ) {
      return;
    }

    const timerKey = `${conversationId}:${myUid}`;
    const existingClear = this.typingAutoClearTimers.get(timerKey);
    if (existingClear) {
      clearTimeout(existingClear);
      this.typingAutoClearTimers.delete(timerKey);
    }

    const now = Date.now();
    const lastSent = this.typingLastSentAt.get(timerKey) || 0;

    if (isTyping && now - lastSent < TYPING_THROTTLE_MS) {
      // Still schedule auto-clear without sending another write over the wire
      this.scheduleTypingAutoClear(conversationId, myUid, timerKey);
      return;
    }

    this.typingLastSentAt.set(timerKey, isTyping ? now : 0);

    try {
      await updateDoc(doc(db, 'conversations', conversationId), {
        [`typing.${myUid}`]: isTyping,
      });
    } catch {
      // Non-fatal when offline or conversation initializing
    }

    if (isTyping) {
      this.scheduleTypingAutoClear(conversationId, myUid, timerKey);
    }
  }

  private scheduleTypingAutoClear(conversationId: string, myUid: string, timerKey: string): void {
    const timer = setTimeout(async () => {
      this.typingAutoClearTimers.delete(timerKey);
      this.typingLastSentAt.delete(timerKey);
      try {
        await updateDoc(doc(db, 'conversations', conversationId), {
          [`typing.${myUid}`]: false,
        });
      } catch {
        // Ignore clear error when offline
      }
    }, TYPING_AUTO_CLEAR_MS);

    this.typingAutoClearTimers.set(timerKey, timer);
  }

  /**
   * Coalesces read-receipt resets per conversation so rapid message bursts produce a single write.
   */
  public markConversationReadCoalesced(conversationId: string, myUid: string): void {
    if (
      !conversationId ||
      !myUid ||
      conversationId === 'conv_demo_starter' ||
      conversationId === 'splender_ai_assistant' ||
      conversationId.startsWith('p2p_')
    ) {
      return;
    }

    const key = `${conversationId}:${myUid}`;
    if (this.readReceiptDebounceTimers.has(key)) {
      return;
    }

    const timer = setTimeout(async () => {
      this.readReceiptDebounceTimers.delete(key);
      try {
        await updateDoc(doc(db, 'conversations', conversationId), {
          [`unreadCounts.${myUid}`]: 0,
        });
      } catch {
        // Non-fatal
      }
    }, 350);

    this.readReceiptDebounceTimers.set(key, timer);
  }

  // ===========================================================================
  // 3. ONLINE PEER PRESENCE MULTIPLEXER (FIRESTORE RULE-COMPLIANT)
  // ===========================================================================

  /**
   * Subscribes to online peers using the exact Firestore rule-authorized query
   * `where('status', '==', 'online')`. Shared across all UI consumers and automatically
   * hibernated when the app is backgrounded on mobile.
   */
  public subscribeToOnlinePeers(
    onOnlinePeers: (peers: UserProfile[]) => void,
    maxPeers = 35
  ): UnsubscribeFn {
    const channelKey = `online_peers:${maxPeers}`;
    return this.retainChannel<UserProfile[]>(
      channelKey,
      true,
      (emit) => {
        const onlineQuery = query(
          collection(db, 'users'),
          where('status', '==', 'online'),
          limit(maxPeers)
        );
        return onSnapshot(
          onlineQuery,
          (snap) => {
            const peers: UserProfile[] = [];
            snap.forEach((d) => {
              peers.push({ ...(d.data() as UserProfile), uid: d.id });
            });
            emit(peers);
          },
          (err) => {
            console.debug('Online presence listener notice:', err);
          }
        );
      },
      onOnlinePeers
    );
  }

  /**
   * Custom channel multiplexer for deterministic unit/integration testing & WebRTC room buses.
   */
  public subscribeCustomChannel<TPayload>(
    channelKey: string,
    pausableInBackground: boolean,
    streamFactory: (emit: (payload: TPayload) => void) => UnsubscribeFn,
    subscriber: (payload: TPayload) => void
  ): UnsubscribeFn {
    return this.retainChannel(channelKey, pausableInBackground, streamFactory, subscriber);
  }

  /**
   * Tears down all active listeners, timers, and channels cleanly (e.g., on sign-out).
   */
  public teardownAll(): void {
    for (const channel of this.channels.values()) {
      if (channel.firestoreUnsub) {
        channel.firestoreUnsub();
        channel.firestoreUnsub = null;
      }
      channel.subscribers.clear();
    }
    this.channels.clear();

    for (const timer of this.typingAutoClearTimers.values()) clearTimeout(timer);
    this.typingAutoClearTimers.clear();
    this.typingLastSentAt.clear();

    for (const timer of this.readReceiptDebounceTimers.values()) clearTimeout(timer);
    this.readReceiptDebounceTimers.clear();

    if (this.hibernateTimer) {
      clearTimeout(this.hibernateTimer);
      this.hibernateTimer = null;
    }
    this.isHibernated = false;
  }

  public getDiagnostics(): ConnectionDiagnostics {
    let activeFirestoreListeners = 0;
    let totalSubscribers = 0;
    const activeChannels: string[] = [];

    for (const [key, ch] of this.channels.entries()) {
      activeChannels.push(key);
      totalSubscribers += ch.subscribers.size;
      if (ch.firestoreUnsub) {
        activeFirestoreListeners += 1;
      }
    }

    return {
      activeFirestoreListeners,
      activeChannels,
      totalSubscribers,
      isHibernated: this.isHibernated,
      eventsDispatched: this.eventsDispatched,
    };
  }
}

export const ConnectionManager = RealtimeConnectionManager.getInstance();
export default ConnectionManager;
