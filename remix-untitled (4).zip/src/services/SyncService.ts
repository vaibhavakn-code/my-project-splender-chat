/**
 * Splender Chat — Unified Offline-First Transactional Sync Engine (`src/services/SyncService.ts`)
 *
 * Combines IndexedDB (`idb`) and Firebase Firestore into a single transactional sync queue.
 * - Offline Queueing: Outgoing E2EE messages, PII-sanitized profile updates, and RSA-OAEP
 *   public encryption keys persist atomically inside IndexedDB when offline or on transient failure.
 * - Zero-Plaintext Enforcement: Validates every outgoing message via `CryptoService.assertZeroPlaintextMessage`
 *   before queueing or dispatching to Firestore.
 * - Auto-Resume Flushing: Single-flight mutex queue processor triggered automatically on
 *   `window` `'online'`, foreground `'visibilitychange'`, Firestore stream reconnect, or manual trigger.
 */

import { openDB, DBSchema, IDBPDatabase } from 'idb';
import {
  db as firestoreDb,
  doc,
  collection,
  setDoc,
  updateDoc,
  writeBatch,
  sanitizeForFirestore,
  FirestoreStreamResilience,
} from '../lib/firebase';
import { CryptoService } from './CryptoService';
import { SplenderNativeBridge } from '../lib/nativeBridge';
import { HapticsService } from './HapticsService';

export type SyncOperationType =
  | 'OUTGOING_MESSAGE'
  | 'PROFILE_UPDATE'
  | 'ENCRYPTION_KEY_PUBLISH';

export interface SyncQueueRecord {
  id: string;
  idempotencyKey: string;
  operationType: SyncOperationType;
  uid: string;
  conversationId?: string;
  payload: Record<string, unknown>;
  conversationSummaryPatch?: Record<string, unknown>;
  createdAt: number;
  retryCount: number;
  nextAttemptAt: number;
  lastError?: string;
  status: 'queued' | 'processing' | 'failed';
}

export interface SyncEngineStats {
  queuedCount: number;
  failedCount: number;
  isFlushing: boolean;
  isOnline: boolean;
  lastSyncedAt: number | null;
}

interface SplenderSyncDB extends DBSchema {
  sync_queue: {
    key: string;
    value: SyncQueueRecord;
    indexes: {
      'by-created': number;
      'by-type': SyncOperationType;
      'by-idempotency': string;
    };
  };
  cached_profiles: {
    key: string;
    value: {
      uid: string;
      profile: Record<string, unknown>;
      updatedAt: number;
    };
  };
  published_keys: {
    key: string;
    value: {
      uid: string;
      publicKeySpkiBase64: string;
      fingerprintHex: string;
      syncedToServer: boolean;
      updatedAt: number;
    };
  };
}

const SYNC_DB_NAME = 'splender_unified_sync_v1';
const SYNC_DB_VERSION = 1;
const MAX_RETRY_ATTEMPTS = 8;

type SyncStatsListener = (stats: SyncEngineStats) => void;
export type CustomFlushTransport = (record: SyncQueueRecord) => Promise<void>;

function stripDisallowedPublicUserFields(raw: Record<string, unknown>): Record<string, unknown> {
  const clone = { ...raw };
  // Enforce `/firestore.rules` `hasNoPiiOrPrivilegeFields` on `/users/{uid}`
  delete clone.email;
  delete clone.phone;
  delete clone.isAdmin;
  delete clone.role;
  return clone;
}

export class UnifiedSyncService {
  private static instance: UnifiedSyncService | null = null;
  private dbPromise: Promise<IDBPDatabase<SplenderSyncDB>> | null = null;
  private isFlushing = false;
  private activeFlushPromise: Promise<{ flushedCount: number; remainingCount: number }> | null = null;
  private lastSyncedAt: number | null = null;
  private listeners = new Set<SyncStatsListener>();
  private autoResumeAttached = false;
  private onlineHandler: (() => void) | null = null;
  private offlineHandler: (() => void) | null = null;
  private visibilityHandler: (() => void) | null = null;
  private firestoreReconnectUnsub: (() => void) | null = null;
  private customTransport: CustomFlushTransport | null = null;
  private simulatedOffline: boolean | null = null;

  private constructor() {}

  public static getInstance(): UnifiedSyncService {
    if (!UnifiedSyncService.instance) {
      UnifiedSyncService.instance = new UnifiedSyncService();
    }
    return UnifiedSyncService.instance;
  }

  private getDb(): Promise<IDBPDatabase<SplenderSyncDB>> {
    if (!this.dbPromise) {
      this.dbPromise = openDB<SplenderSyncDB>(SYNC_DB_NAME, SYNC_DB_VERSION, {
        upgrade(db) {
          if (!db.objectStoreNames.contains('sync_queue')) {
            const queueStore = db.createObjectStore('sync_queue', { keyPath: 'id' });
            queueStore.createIndex('by-created', 'createdAt');
            queueStore.createIndex('by-type', 'operationType');
            queueStore.createIndex('by-idempotency', 'idempotencyKey', { unique: true });
          }
          if (!db.objectStoreNames.contains('cached_profiles')) {
            db.createObjectStore('cached_profiles', { keyPath: 'uid' });
          }
          if (!db.objectStoreNames.contains('published_keys')) {
            db.createObjectStore('published_keys', { keyPath: 'uid' });
          }
        },
      });
    }
    return this.dbPromise;
  }

  public isNetworkOnline(): boolean {
    if (this.simulatedOffline !== null) {
      return !this.simulatedOffline;
    }
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return false;
    }
    if (!this.customTransport && FirestoreStreamResilience.isStreamPausedOrOffline()) {
      return false;
    }
    return true;
  }

  /**
   * Deterministic offline simulation hook for integration testing & Airplane Mode diagnostics.
   */
  public setSimulatedOffline(offline: boolean | null): void {
    this.simulatedOffline = offline;
    void this.emitStats();
    if (offline === false) {
      void this.flushQueue();
    }
  }

  /**
   * Optional custom transport hook (defaults to live Firebase Firestore atomic batch/doc writes).
   */
  public setCustomTransport(transport: CustomFlushTransport | null): void {
    this.customTransport = transport;
  }

  public subscribeStats(listener: SyncStatsListener): () => void {
    this.listeners.add(listener);
    void this.getStats().then((stats) => listener(stats));
    return () => {
      this.listeners.delete(listener);
    };
  }

  public async getStats(): Promise<SyncEngineStats> {
    const db = await this.getDb();
    const all = await db.getAll('sync_queue');
    const queuedCount = all.filter((r) => r.status !== 'failed').length;
    const failedCount = all.filter((r) => r.status === 'failed').length;

    return {
      queuedCount,
      failedCount,
      isFlushing: this.isFlushing,
      isOnline: this.isNetworkOnline(),
      lastSyncedAt: this.lastSyncedAt,
    };
  }

  private async emitStats(): Promise<void> {
    if (this.listeners.size === 0) return;
    const stats = await this.getStats();
    this.listeners.forEach((cb) => {
      try {
        cb(stats);
      } catch {
        // Ignore subscriber error
      }
    });
  }

  // ===========================================================================
  // TRANSACTIONAL ENQUEUE & IMMEDIATE-OR-DEFERRED OPERATIONS
  // ===========================================================================

  /**
   * Queues or dispatches an E2EE-sealed outgoing message (`text: '[Encrypted]'` + `encryptedEnvelope`).
   * Uses a single IndexedDB readwrite transaction to guarantee idempotency and zero data loss.
   */
  public async syncOutgoingMessage(params: {
    idempotencyKey: string;
    conversationId: string;
    senderUid: string;
    sealedMessagePayload: Record<string, unknown>;
    conversationSummaryPatch?: Record<string, unknown>;
  }): Promise<{ status: 'synced' | 'queued'; queueId: string }> {
    const {
      idempotencyKey,
      conversationId,
      senderUid,
      sealedMessagePayload,
      conversationSummaryPatch,
    } = params;

    // Enforce zero-plaintext policy before persisting anywhere outside RAM
    CryptoService.assertZeroPlaintextMessage(sealedMessagePayload);

    const db = await this.getDb();
    const queueId = `msg_${idempotencyKey}`;

    const record: SyncQueueRecord = {
      id: queueId,
      idempotencyKey,
      operationType: 'OUTGOING_MESSAGE',
      uid: senderUid,
      conversationId,
      payload: sanitizeForFirestore(sealedMessagePayload),
      conversationSummaryPatch: conversationSummaryPatch
        ? sanitizeForFirestore(conversationSummaryPatch)
        : undefined,
      createdAt: Date.now(),
      retryCount: 0,
      nextAttemptAt: Date.now(),
      status: 'queued',
    };

    // Transactional upsert into IndexedDB first (Write-Ahead Log pattern)
    const tx = db.transaction('sync_queue', 'readwrite');
    const existing = await tx.store.index('by-idempotency').get(idempotencyKey);
    if (!existing) {
      await tx.store.put(record);
    }
    await tx.done;
    await this.emitStats();

    if (!this.isNetworkOnline()) {
      void SplenderNativeBridge.scheduleOutboxSync();
      return { status: 'queued', queueId };
    }

    try {
      await this.executeRecordOnFirestore(record);
      await db.delete('sync_queue', queueId);
      this.lastSyncedAt = Date.now();
      await this.emitStats();
      return { status: 'synced', queueId };
    } catch (err: any) {
      await this.markRecordRetry(queueId, err?.message || 'Transient network write error');
      void SplenderNativeBridge.scheduleOutboxSync();
      return { status: 'queued', queueId };
    }
  }

  /**
   * Queues or dispatches a PII-clean `/users/{uid}` profile update, caching locally in IndexedDB.
   */
  public async syncProfileUpdate(
    uid: string,
    updates: Record<string, unknown>
  ): Promise<{ status: 'synced' | 'queued'; queueId: string }> {
    const cleanUpdates = sanitizeForFirestore({
      ...stripDisallowedPublicUserFields(updates),
      updatedAt: Date.now(),
    });

    const db = await this.getDb();
    // Coalesce pending profile updates for the same UID inside a single IndexedDB transaction
    const queueId = `profile_${uid}`;
    const tx = db.transaction(['sync_queue', 'cached_profiles'], 'readwrite');
    const prevQueued = await tx.objectStore('sync_queue').get(queueId);
    const mergedPayload = prevQueued
      ? { ...prevQueued.payload, ...cleanUpdates }
      : cleanUpdates;

    const record: SyncQueueRecord = {
      id: queueId,
      idempotencyKey: `profile_idem_${uid}`,
      operationType: 'PROFILE_UPDATE',
      uid,
      payload: mergedPayload,
      createdAt: prevQueued?.createdAt ?? Date.now(),
      retryCount: 0,
      nextAttemptAt: Date.now(),
      status: 'queued',
    };

    await tx.objectStore('sync_queue').put(record);
    const cachedProfile = await tx.objectStore('cached_profiles').get(uid);
    await tx.objectStore('cached_profiles').put({
      uid,
      profile: { ...(cachedProfile?.profile || {}), ...mergedPayload },
      updatedAt: Date.now(),
    });
    await tx.done;
    await this.emitStats();

    if (!this.isNetworkOnline()) {
      return { status: 'queued', queueId };
    }

    try {
      await this.executeRecordOnFirestore(record);
      await db.delete('sync_queue', queueId);
      this.lastSyncedAt = Date.now();
      await this.emitStats();
      return { status: 'synced', queueId };
    } catch (err: any) {
      await this.markRecordRetry(queueId, err?.message || 'Profile sync deferred');
      return { status: 'queued', queueId };
    }
  }

  /**
   * Publishes or queues this device's RSA-OAEP SPKI Base64 public key (`users/{uid}.publicKey`).
   */
  public async syncEncryptionPublicKey(
    uid: string,
    publicKeySpkiBase64: string,
    fingerprintHex: string
  ): Promise<{ status: 'synced' | 'queued'; queueId: string }> {
    if (!publicKeySpkiBase64 || publicKeySpkiBase64.length > 4096) {
      throw new Error('Invalid publicKey length for Firestore rules (must be 1..4096 chars)');
    }

    const db = await this.getDb();
    const existingPublished = await db.get('published_keys', uid);
    if (
      existingPublished?.syncedToServer &&
      existingPublished.publicKeySpkiBase64 === publicKeySpkiBase64 &&
      this.isNetworkOnline()
    ) {
      return { status: 'synced', queueId: `key_${uid}` };
    }

    const queueId = `key_${uid}`;
    const record: SyncQueueRecord = {
      id: queueId,
      idempotencyKey: `key_idem_${uid}_${fingerprintHex.slice(0, 16)}`,
      operationType: 'ENCRYPTION_KEY_PUBLISH',
      uid,
      payload: {
        publicKey: publicKeySpkiBase64,
        updatedAt: Date.now(),
      },
      createdAt: Date.now(),
      retryCount: 0,
      nextAttemptAt: Date.now(),
      status: 'queued',
    };

    const tx = db.transaction(['sync_queue', 'published_keys'], 'readwrite');
    await tx.objectStore('sync_queue').put(record);
    await tx.objectStore('published_keys').put({
      uid,
      publicKeySpkiBase64,
      fingerprintHex,
      syncedToServer: false,
      updatedAt: Date.now(),
    });
    await tx.done;
    await this.emitStats();

    if (!this.isNetworkOnline()) {
      return { status: 'queued', queueId };
    }

    try {
      await this.executeRecordOnFirestore(record);
      const confirmTx = db.transaction(['sync_queue', 'published_keys'], 'readwrite');
      await confirmTx.objectStore('sync_queue').delete(queueId);
      await confirmTx.objectStore('published_keys').put({
        uid,
        publicKeySpkiBase64,
        fingerprintHex,
        syncedToServer: true,
        updatedAt: Date.now(),
      });
      await confirmTx.done;
      this.lastSyncedAt = Date.now();
      await this.emitStats();
      return { status: 'synced', queueId };
    } catch (err: any) {
      await this.markRecordRetry(queueId, err?.message || 'Key publish deferred');
      return { status: 'queued', queueId };
    }
  }

  // ===========================================================================
  // ATOMIC FIRESTORE DISPATCH & AUTO-RESUME QUEUE FLUSHER
  // ===========================================================================

  private async executeRecordOnFirestore(record: SyncQueueRecord): Promise<void> {
    if (this.customTransport) {
      await this.customTransport(record);
      return;
    }

    switch (record.operationType) {
      case 'OUTGOING_MESSAGE': {
        if (!record.conversationId) {
          throw new Error('Missing conversationId on OUTGOING_MESSAGE sync record');
        }
        CryptoService.assertZeroPlaintextMessage(record.payload);

        const batch = writeBatch(firestoreDb);
        const msgRef = doc(
          collection(firestoreDb, 'conversations', record.conversationId, 'messages'),
          record.idempotencyKey
        );
        batch.set(msgRef, sanitizeForFirestore(record.payload));

        if (record.conversationSummaryPatch) {
          const convRef = doc(firestoreDb, 'conversations', record.conversationId);
          batch.update(convRef, sanitizeForFirestore(record.conversationSummaryPatch));
        }

        await batch.commit();
        return;
      }

      case 'PROFILE_UPDATE': {
        const userRef = doc(firestoreDb, 'users', record.uid);
        const clean = stripDisallowedPublicUserFields(record.payload);
        await updateDoc(userRef, sanitizeForFirestore(clean));
        return;
      }

      case 'ENCRYPTION_KEY_PUBLISH': {
        const userRef = doc(firestoreDb, 'users', record.uid);
        try {
          await updateDoc(
            userRef,
            sanitizeForFirestore({
              publicKey: record.payload.publicKey,
              updatedAt: Date.now(),
            })
          );
        } catch {
          // If document hasn't settled yet, merge safely without PII fields
          await setDoc(
            userRef,
            sanitizeForFirestore({
              uid: record.uid,
              publicKey: record.payload.publicKey,
              updatedAt: Date.now(),
            }),
            { merge: true }
          );
        }
        return;
      }
    }
  }

  private async markRecordRetry(id: string, errorMsg: string): Promise<void> {
    const db = await this.getDb();
    const rec = await db.get('sync_queue', id);
    if (!rec) return;

    const nextRetry = rec.retryCount + 1;
    const backoffMs = Math.min(30_000, 500 * Math.pow(2, nextRetry));
    rec.retryCount = nextRetry;
    rec.lastError = errorMsg;
    rec.nextAttemptAt = Date.now() + backoffMs;
    rec.status = nextRetry >= MAX_RETRY_ATTEMPTS ? 'failed' : 'queued';
    await db.put('sync_queue', rec);
    await this.emitStats();
  }

  /**
   * Flushes all queued operations in chronological (`createdAt`) order once connectivity resumes.
   * Protected by a single-flight mutex to prevent duplicate concurrent flushes.
   */
  public async flushQueue(forceIgnoreBackoff = true): Promise<{
    flushedCount: number;
    remainingCount: number;
  }> {
    if (this.activeFlushPromise) {
      return this.activeFlushPromise;
    }

    if (!this.isNetworkOnline()) {
      const stats = await this.getStats();
      return { flushedCount: 0, remainingCount: stats.queuedCount };
    }

    this.activeFlushPromise = (async () => {
      this.isFlushing = true;
      await this.emitStats();

      let flushedCount = 0;
      try {
        const db = await this.getDb();
        const ordered = await db.getAllFromIndex('sync_queue', 'by-created');
        const now = Date.now();

        for (const item of ordered) {
          if (!this.isNetworkOnline()) break;
          if (item.status === 'failed' && !forceIgnoreBackoff) continue;
          if (!forceIgnoreBackoff && item.nextAttemptAt > now) continue;

          try {
            await this.executeRecordOnFirestore(item);
            await db.delete('sync_queue', item.id);
            if (item.operationType === 'ENCRYPTION_KEY_PUBLISH') {
              const pub = await db.get('published_keys', item.uid);
              if (pub) {
                await db.put('published_keys', {
                  ...pub,
                  syncedToServer: true,
                  updatedAt: Date.now(),
                });
              }
            }
            flushedCount += 1;
          } catch (err: any) {
            await this.markRecordRetry(item.id, err?.message || 'Flush retry error');
          }
        }

        if (flushedCount > 0) {
          this.lastSyncedAt = Date.now();
          void HapticsService.notificationSuccess();
        }
      } finally {
        this.isFlushing = false;
        this.activeFlushPromise = null;
        await this.emitStats();
      }

      const finalStats = await this.getStats();
      return { flushedCount, remainingCount: finalStats.queuedCount };
    })();

    return this.activeFlushPromise;
  }

  public async getQueuedItems(): Promise<SyncQueueRecord[]> {
    const db = await this.getDb();
    return db.getAllFromIndex('sync_queue', 'by-created');
  }

  public async clearQueue(): Promise<void> {
    const db = await this.getDb();
    await db.clear('sync_queue');
    await this.emitStats();
  }

  /**
   * Attaches automatic connectivity, app-foreground, & Firestore stream reconnect listeners to flush queued records.
   */
  public startAutoResumeListener(onFlushed?: (flushedCount: number) => void): () => void {
    if (typeof window === 'undefined') return () => {};

    if (!this.autoResumeAttached) {
      this.autoResumeAttached = true;

      this.onlineHandler = () => {
        void this.emitStats();
        void this.flushQueue(true).then((res) => {
          if (res.flushedCount > 0 && onFlushed) {
            onFlushed(res.flushedCount);
          }
        });
      };

      this.offlineHandler = () => {
        void this.emitStats();
      };

      this.visibilityHandler = () => {
        if (typeof document !== 'undefined' && document.visibilityState === 'visible' && this.isNetworkOnline()) {
          void this.flushQueue(false).then((res) => {
            if (res.flushedCount > 0 && onFlushed) {
              onFlushed(res.flushedCount);
            }
          });
        }
      };

      this.firestoreReconnectUnsub = FirestoreStreamResilience.onReconnect(() => {
        void this.emitStats();
        void this.flushQueue(true).then((res) => {
          if (res.flushedCount > 0 && onFlushed) {
            onFlushed(res.flushedCount);
          }
        });
      });

      window.addEventListener('online', this.onlineHandler);
      window.addEventListener('offline', this.offlineHandler);
      if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', this.visibilityHandler);
      }

      // Trigger an initial flush check on startup if online
      if (this.isNetworkOnline()) {
        void this.flushQueue(false).then((res) => {
          if (res.flushedCount > 0 && onFlushed) {
            onFlushed(res.flushedCount);
          }
        });
      }
    }

    return () => this.stopAutoResumeListener();
  }

  public stopAutoResumeListener(): void {
    if (!this.autoResumeAttached || typeof window === 'undefined') return;
    if (this.onlineHandler) {
      window.removeEventListener('online', this.onlineHandler);
      this.onlineHandler = null;
    }
    if (this.offlineHandler) {
      window.removeEventListener('offline', this.offlineHandler);
      this.offlineHandler = null;
    }
    if (this.visibilityHandler && typeof document !== 'undefined') {
      document.removeEventListener('visibilitychange', this.visibilityHandler);
      this.visibilityHandler = null;
    }
    if (this.firestoreReconnectUnsub) {
      this.firestoreReconnectUnsub();
      this.firestoreReconnectUnsub = null;
    }
    this.autoResumeAttached = false;
  }
}

export const SyncService = UnifiedSyncService.getInstance();
export default SyncService;
