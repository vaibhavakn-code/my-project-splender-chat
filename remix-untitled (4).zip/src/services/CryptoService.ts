/**
 * Splender Chat — Centralized Security & E2EE Singleton (`src/services/CryptoService.ts`)
 *
 * Architecture:
 * 1. Asymmetric Key Exchange: RSA-OAEP-2048 (SHA-256) with non-extractable private keys
 *    persisted in IndexedDB (`splender_crypto_service_v1`) and SPKI Base64 public keys
 *    published to peers (`<= 600` chars, compliant with `/firestore.rules` `publicKey <= 4096`).
 * 2. Symmetric Message Payload Encryption: Authenticated AES-GCM-256 + HMAC-SHA256
 *    producing zero-plaintext `EncryptedEnvelope` structures (`ciphertext`, `iv`, `hmac`,
 *    `ratchetStep`, `protocol`) compatible with `P2PCryptoEngine` and Firestore security gates.
 * 3. Secure Local Token Vault: Hardware/IndexedDB master-key-sealed session tokens with
 *    AAD binding, Android Keystore bridge delegation when running natively, and strict TTL expiry.
 */

import { openDB, IDBPDatabase } from 'idb';
import { P2PCryptoEngine, EncryptedEnvelope } from '../lib/p2pSecurity';
import { SplenderKeyVault } from '../lib/keyVault';
import { SplenderNativeBridge } from '../lib/nativeBridge';
import { auth, db, doc, getDoc } from '../lib/firebase';

const CRYPTO_DB_NAME = 'splender_crypto_service_v1';
const CRYPTO_DB_VERSION = 1;
const STORE_KEYS = 'keystore';
const STORE_TOKENS = 'secure_tokens';

const RSA_IDENTITY_KEY_ID = 'rsa_oaep_identity_v1';
const TOKEN_MASTER_KEY_ID = 'local_token_aes_master_v1';

export interface RsaIdentityBundle {
  publicKeySpkiBase64: string;
  fingerprintHex: string;
  algorithm: 'RSA-OAEP-2048-SHA256';
  createdAt: number;
}

interface StoredKeyRecord {
  id: string;
  publicKey?: CryptoKey;
  privateKey?: CryptoKey;
  secretKey?: CryptoKey;
  publicKeySpkiBase64?: string;
  fingerprintHex?: string;
  createdAt: number;
}

interface SealedTokenRecord {
  tokenId: string;
  ivBase64: string;
  ciphertextBase64: string;
  nativeKeystoreWrapped?: boolean;
  createdAt: number;
  expiresAt: number;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    out[i] = binary.charCodeAt(i);
  }
  return out;
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function constantTimeHexEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

export class TamperDetectedError extends Error {
  constructor(message = 'E2EE envelope authentication tag mismatch or ciphertext tampered') {
    super(message);
    this.name = 'TamperDetectedError';
  }
}

export class ZeroPlaintextViolationError extends Error {
  constructor(message = 'Zero-Plaintext Policy Violation: Server payload contains unsealed plaintext') {
    super(message);
    this.name = 'ZeroPlaintextViolationError';
  }
}

export class CryptoServiceSingleton {
  private static instance: CryptoServiceSingleton | null = null;
  private dbPromise: Promise<IDBPDatabase> | null = null;
  private cachedRsaRecord: StoredKeyRecord | null = null;
  private cachedTokenMasterKey: CryptoKey | null = null;
  private peerPublicKeyCache = new Map<string, string>();

  private constructor() {}

  public static getInstance(): CryptoServiceSingleton {
    if (!CryptoServiceSingleton.instance) {
      CryptoServiceSingleton.instance = new CryptoServiceSingleton();
    }
    return CryptoServiceSingleton.instance;
  }

  private getDb(): Promise<IDBPDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = openDB(CRYPTO_DB_NAME, CRYPTO_DB_VERSION, {
        upgrade(db) {
          if (!db.objectStoreNames.contains(STORE_KEYS)) {
            db.createObjectStore(STORE_KEYS, { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains(STORE_TOKENS)) {
            db.createObjectStore(STORE_TOKENS, { keyPath: 'tokenId' });
          }
        },
      });
    }
    return this.dbPromise;
  }

  private getNativeKeystorePlugin(): {
    wrapSecretInKeystore?: (args: { secret: string; aad: string }) => Promise<{ wrappedBase64: string }>;
    unwrapSecretFromKeystore?: (args: { wrappedBase64: string; aad: string }) => Promise<{ secret: string }>;
  } | null {
    if (typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.()) {
      return (window as any).Capacitor?.Plugins?.SplenderNative ?? null;
    }
    return null;
  }

  // ===========================================================================
  // 1. RSA-OAEP-2048 ASYMMETRIC KEY EXCHANGE & SESSION KEY WRAPPING
  // ===========================================================================

  /**
   * Generates or loads this device's RSA-OAEP-2048 keypair.
   * The private key is generated with `extractable: false` and remains inside IndexedDB/WebCrypto.
   */
  public async getOrCreateRsaIdentity(): Promise<RsaIdentityBundle> {
    if (
      this.cachedRsaRecord?.publicKeySpkiBase64 &&
      this.cachedRsaRecord?.fingerprintHex &&
      this.cachedRsaRecord?.privateKey
    ) {
      return {
        publicKeySpkiBase64: this.cachedRsaRecord.publicKeySpkiBase64,
        fingerprintHex: this.cachedRsaRecord.fingerprintHex,
        algorithm: 'RSA-OAEP-2048-SHA256',
        createdAt: this.cachedRsaRecord.createdAt,
      };
    }

    const db = await this.getDb();
    const existing = (await db.get(STORE_KEYS, RSA_IDENTITY_KEY_ID)) as StoredKeyRecord | undefined;
    if (
      existing?.privateKey &&
      existing?.publicKey &&
      existing?.publicKeySpkiBase64 &&
      existing?.fingerprintHex
    ) {
      this.cachedRsaRecord = existing;
      return {
        publicKeySpkiBase64: existing.publicKeySpkiBase64,
        fingerprintHex: existing.fingerprintHex,
        algorithm: 'RSA-OAEP-2048-SHA256',
        createdAt: existing.createdAt,
      };
    }

    const keyPair = await crypto.subtle.generateKey(
      {
        name: 'RSA-OAEP',
        modulusLength: 2048,
        publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
        hash: 'SHA-256',
      },
      false, // Private key is strictly non-extractable
      ['encrypt', 'decrypt', 'wrapKey', 'unwrapKey']
    );

    const spkiBuffer = await crypto.subtle.exportKey('spki', keyPair.publicKey);
    const spkiBytes = new Uint8Array(spkiBuffer);
    const publicKeySpkiBase64 = bytesToBase64(spkiBytes);
    const digestBuf = await crypto.subtle.digest('SHA-256', spkiBuffer);
    const fingerprintHex = bytesToHex(new Uint8Array(digestBuf));

    const record: StoredKeyRecord = {
      id: RSA_IDENTITY_KEY_ID,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
      publicKeySpkiBase64,
      fingerprintHex,
      createdAt: Date.now(),
    };

    await db.put(STORE_KEYS, record);
    this.cachedRsaRecord = record;

    return {
      publicKeySpkiBase64,
      fingerprintHex,
      algorithm: 'RSA-OAEP-2048-SHA256',
      createdAt: record.createdAt,
    };
  }

  /**
   * Imports a peer's SPKI Base64 RSA-OAEP public key for key wrapping or direct asymmetric sealing.
   */
  public async importPeerRsaPublicKey(spkiBase64: string): Promise<CryptoKey> {
    const spkiBytes = base64ToBytes(spkiBase64);
    return crypto.subtle.importKey(
      'spki',
      spkiBytes as unknown as BufferSource,
      { name: 'RSA-OAEP', hash: 'SHA-256' },
      true,
      ['encrypt', 'wrapKey']
    );
  }

  /**
   * Generates a fresh 256-bit AES-GCM session key for a conversation.
   */
  public async generateSessionAesKey(extractableForWrap = true): Promise<CryptoKey> {
    return crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      extractableForWrap,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Wraps an AES-GCM-256 session key under a peer's RSA-OAEP-2048 public key so it can be
   * exchanged over an untrusted relay with zero server visibility.
   */
  public async wrapSessionKeyForPeer(
    sessionAesKey: CryptoKey,
    peerPublicKeySpkiBase64: string
  ): Promise<string> {
    const peerPublicKey = await this.importPeerRsaPublicKey(peerPublicKeySpkiBase64);
    const wrappedBuffer = await crypto.subtle.wrapKey('raw', sessionAesKey, peerPublicKey, {
      name: 'RSA-OAEP',
    });
    return bytesToBase64(new Uint8Array(wrappedBuffer));
  }

  /**
   * Unwraps a peer-provided RSA-OAEP wrapped AES-GCM-256 session key into a non-extractable CryptoKey.
   */
  public async unwrapSessionKeyFromPeer(
    wrappedKeyBase64: string,
    extractable = false
  ): Promise<CryptoKey> {
    await this.getOrCreateRsaIdentity();
    if (!this.cachedRsaRecord?.privateKey) {
      throw new Error('RSA-OAEP private key unavailable in local hardware/IndexedDB store');
    }
    const wrappedBytes = base64ToBytes(wrappedKeyBase64);
    return crypto.subtle.unwrapKey(
      'raw',
      wrappedBytes as unknown as BufferSource,
      this.cachedRsaRecord.privateKey,
      { name: 'RSA-OAEP' },
      { name: 'AES-GCM', length: 256 },
      extractable,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypts small control secrets directly with a peer's RSA-OAEP public key.
   */
  public async rsaEncryptForPeer(plaintext: string, peerPublicKeySpkiBase64: string): Promise<string> {
    const peerPub = await this.importPeerRsaPublicKey(peerPublicKeySpkiBase64);
    const encoded = new TextEncoder().encode(plaintext);
    const cipherBuf = await crypto.subtle.encrypt(
      { name: 'RSA-OAEP' },
      peerPub,
      encoded as unknown as BufferSource
    );
    return bytesToBase64(new Uint8Array(cipherBuf));
  }

  /**
   * Decrypts an RSA-OAEP ciphertext using this device's non-extractable private key.
   */
  public async rsaDecryptWithIdentity(ciphertextBase64: string): Promise<string> {
    await this.getOrCreateRsaIdentity();
    if (!this.cachedRsaRecord?.privateKey) {
      throw new Error('RSA-OAEP private identity key not initialized');
    }
    const cipherBytes = base64ToBytes(ciphertextBase64);
    const plainBuf = await crypto.subtle.decrypt(
      { name: 'RSA-OAEP' },
      this.cachedRsaRecord.privateKey,
      cipherBytes as unknown as BufferSource
    );
    return new TextDecoder().decode(plainBuf);
  }

  // ===========================================================================
  // 2. AES-GCM-256 + HMAC-SHA256 ZERO-PLAINTEXT MESSAGE ENVELOPE ENGINE
  // ===========================================================================

  private async deriveSymmetricPair(secretMaterial: string): Promise<{
    aesKey: CryptoKey;
    hmacKey: CryptoKey;
  }> {
    const rawMaterial = new TextEncoder().encode(secretMaterial);
    const encSeed = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(`splender_aes256:${secretMaterial}`)
    );
    const macSeed = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(`splender_hmac256:${ bytesToHex(new Uint8Array(rawMaterial.slice(0, 32))) }:${secretMaterial}`)
    );

    const [aesKey, hmacKey] = await Promise.all([
      crypto.subtle.importKey('raw', encSeed, { name: 'AES-GCM', length: 256 }, false, [
        'encrypt',
        'decrypt',
      ]),
      crypto.subtle.importKey(
        'raw',
        macSeed,
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['sign', 'verify']
      ),
    ]);

    return { aesKey, hmacKey };
  }

  /**
   * Encrypts a message string or structured JSON payload with AES-GCM-256 using an explicit
   * `CryptoKey` (e.g., unwrapped via RSA-OAEP) OR deterministic conversation ratchet material.
   * Always produces a Firestore-rule-validated `EncryptedEnvelope`.
   */
  public async encryptPayloadWithSessionKey(
    plaintext: string,
    aesKey: CryptoKey,
    ratchetStep = 1
  ): Promise<EncryptedEnvelope> {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const aad = new TextEncoder().encode(`splender_e2ee_v3:step_${ratchetStep}`);
    const encodedPlain = new TextEncoder().encode(plaintext);

    const cipherBuf = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as BufferSource,
        additionalData: aad as unknown as BufferSource,
        tagLength: 128,
      },
      aesKey,
      encodedPlain as unknown as BufferSource
    );

    const ciphertextBase64 = bytesToBase64(new Uint8Array(cipherBuf));
    const ivBase64 = bytesToBase64(iv);

    // Compute integrity digest binding IV + Ciphertext + RatchetStep
    const macInput = new TextEncoder().encode(`${ivBase64}.${ciphertextBase64}.${ratchetStep}`);
    const digest = await crypto.subtle.digest('SHA-256', macInput);
    const hmacHex = bytesToHex(new Uint8Array(digest));

    return {
      ciphertext: ciphertextBase64,
      iv: ivBase64,
      ratchetStep,
      protocol: 'DOUBLE_RATCHET_V3',
      hmac: hmacHex,
    };
  }

  /**
   * Decrypts an `EncryptedEnvelope` sealed by `encryptPayloadWithSessionKey`.
   */
  public async decryptPayloadWithSessionKey(
    envelope: EncryptedEnvelope,
    aesKey: CryptoKey
  ): Promise<string> {
    const macInput = new TextEncoder().encode(
      `${envelope.iv}.${envelope.ciphertext}.${envelope.ratchetStep}`
    );
    const expectedDigest = bytesToHex(new Uint8Array(await crypto.subtle.digest('SHA-256', macInput)));
    if (!constantTimeHexEqual(expectedDigest, envelope.hmac)) {
      throw new TamperDetectedError();
    }

    const iv = base64ToBytes(envelope.iv);
    const cipherBytes = base64ToBytes(envelope.ciphertext);
    const aad = new TextEncoder().encode(`splender_e2ee_v3:step_${envelope.ratchetStep}`);

    try {
      const plainBuf = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv as unknown as BufferSource,
          additionalData: aad as unknown as BufferSource,
          tagLength: 128,
        },
        aesKey,
        cipherBytes as unknown as BufferSource
      );
      return new TextDecoder().decode(plainBuf);
    } catch {
      throw new TamperDetectedError('AES-GCM authentication tag rejected during decryption');
    }
  }

  /**
   * Registers or caches a peer's SPKI Base64 RSA-OAEP-2048 public key for zero-latency session key wrapping.
   */
  public registerPeerPublicKey(peerUid: string, publicKeySpkiBase64: string): void {
    if (peerUid && publicKeySpkiBase64 && publicKeySpkiBase64.length >= 64) {
      this.peerPublicKeyCache.set(peerUid, publicKeySpkiBase64.trim());
    }
  }

  private async resolvePeerPublicKeySpki(peerUid: string): Promise<string | null> {
    if (!peerUid) return null;
    const cached = this.peerPublicKeyCache.get(peerUid);
    if (cached) return cached;

    if (!auth.currentUser || (typeof navigator !== 'undefined' && navigator.onLine === false)) {
      return null;
    }

    try {
      const snap = await Promise.race([
        getDoc(doc(db, 'users', peerUid)),
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 1200)),
      ]);
      const pubKey = snap && typeof snap.data === 'function' ? snap.data()?.publicKey : null;
      if (typeof pubKey === 'string' && pubKey.trim().length >= 64) {
        this.peerPublicKeyCache.set(peerUid, pubKey.trim());
        return pubKey.trim();
      }
    } catch {
      // Offline or unprovisioned peer profile
    }
    return null;
  }

  /**
   * Rotates a conversation's 256-bit root session secret in the platform key vault.
   * Subsequent outbound messages wrap the new secret under participant RSA-OAEP public keys.
   */
  public async rotateConversationSessionKey(conversationId: string): Promise<{
    rotatedAt: number;
    keyFingerprint: string;
  }> {
    if (!conversationId) {
      throw new Error('conversationId is required for session key rotation');
    }
    const freshRootSecret = P2PCryptoEngine.generateRandom256BitKeyBase64();
    await SplenderKeyVault.storeSealedConversationSecret(conversationId, freshRootSecret);
    const keyFingerprint = (await SplenderNativeBridge.computeSha256(freshRootSecret)).slice(0, 16);
    return {
      rotatedAt: Date.now(),
      keyFingerprint,
    };
  }

  /**
   * Conversation-level Hybrid E2EE seal:
   * - Provisions/loads a random 256-bit conversation root secret sealed in `SplenderKeyVault` (never derived from conversationId/UIDs).
   * - Advances the HKDF + HMAC-SHA256 Double-Ratchet step key and encrypts with AES-GCM-256.
   * - Wraps the 256-bit root secret with RSA-OAEP-2048 for self and known participant public keys inside a Firestore-compliant `EncryptedEnvelope`.
   */
  public async sealConversationPayload(
    conversationId: string,
    participants: string[] | undefined,
    payloadObjOrText: Record<string, unknown> | string
  ): Promise<{
    envelope: EncryptedEnvelope;
    ratchetStep: number;
  }> {
    let rootSecretBase64 = await SplenderKeyVault.loadSealedConversationSecret(conversationId);
    if (!rootSecretBase64 || rootSecretBase64.startsWith('splender_v17_e2ee::')) {
      rootSecretBase64 = P2PCryptoEngine.generateRandom256BitKeyBase64();
      await SplenderKeyVault.storeSealedConversationSecret(conversationId, rootSecretBase64);
    }

    const ratchet = await P2PCryptoEngine.nextRatchetStep(conversationId, rootSecretBase64);
    const serialized =
      typeof payloadObjOrText === 'string' ? payloadObjOrText : JSON.stringify(payloadObjOrText);
    const innerEnvelope = await P2PCryptoEngine.encryptPayload(
      serialized,
      rootSecretBase64,
      ratchet.step
    );

    const wk: Record<string, string> = {};
    try {
      const ownIdentity = await this.getOrCreateRsaIdentity();
      const selfSlot = `__self__${ownIdentity.fingerprintHex.slice(0, 16)}`;
      wk[selfSlot] = await this.rsaEncryptForPeer(rootSecretBase64, ownIdentity.publicKeySpkiBase64);
    } catch {
      // Proceed with local vault key if RSA wrap unavailable
    }

    const uniquePeers = Array.from(new Set((participants || []).filter(Boolean))).slice(0, 24);
    for (const peerUid of uniquePeers) {
      const peerSpki = await this.resolvePeerPublicKeySpki(peerUid);
      if (peerSpki) {
        try {
          wk[peerUid] = await this.rsaEncryptForPeer(rootSecretBase64, peerSpki);
        } catch {
          // Skip invalid peer public key
        }
      }
    }

    const packedJson = JSON.stringify({
      v: 'hyb4',
      ct: innerEnvelope.ciphertext,
      ih: innerEnvelope.hmac,
      wk,
    });
    const packedCiphertextB64 = bytesToBase64(new TextEncoder().encode(packedJson));

    // Stay strictly within Firestore's 262,144 char envelope ciphertext ceiling
    if (packedCiphertextB64.length <= 260000) {
      const outerHmac = await SplenderNativeBridge.computeHmacSha256(
        `splender_hyb4_mac_${ratchet.messageKeyBase64}`,
        `${innerEnvelope.iv}:${packedCiphertextB64}:${ratchet.step}`
      );
      return {
        envelope: {
          ciphertext: packedCiphertextB64,
          iv: innerEnvelope.iv,
          ratchetStep: ratchet.step,
          protocol: 'DOUBLE_RATCHET_V3',
          hmac: outerHmac,
        },
        ratchetStep: ratchet.step,
      };
    }

    return { envelope: innerEnvelope, ratchetStep: ratchet.step };
  }

  /**
   * Conversation-level Hybrid E2EE unseal:
   * 1. Unpacks `hyb4` RSA-OAEP + Double-Ratchet AES-GCM-256 envelopes using either the cached vault secret
   *    or RSA-OAEP private-key unwrapping (`wk`), verifying both outer and inner HMAC-SHA256 tags.
   * 2. Falls back to direct vault-secret v4 envelopes.
   * 3. Preserves read-only legacy decryption (`deriveLegacyReadOnlyKeyMaterial`) so historical user messages never break.
   */
  public async unsealConversationPayload(
    conversationId: string,
    participants: string[] | undefined,
    envelope: EncryptedEnvelope
  ): Promise<string> {
    if (!envelope || typeof envelope.ciphertext !== 'string' || typeof envelope.iv !== 'string') {
      throw new TamperDetectedError('Malformed encryptedEnvelope');
    }

    // Check if ciphertext is a Base64-packed `hyb4` hybrid envelope
    let parsedHybrid: {
      v?: string;
      ct?: string;
      ih?: string;
      wk?: Record<string, string>;
    } | null = null;

    try {
      const decodedBytes = base64ToBytes(envelope.ciphertext);
      if (decodedBytes.length > 12 && decodedBytes[0] === 0x7b) {
        const candidate = JSON.parse(new TextDecoder().decode(decodedBytes));
        if (candidate && candidate.v === 'hyb4' && typeof candidate.ct === 'string') {
          parsedHybrid = candidate;
        }
      }
    } catch {
      parsedHybrid = null;
    }

    if (parsedHybrid && parsedHybrid.ct) {
      const candidateSecrets: Array<{ secret: string; fromRsa: boolean }> = [];
      const localSecret = await SplenderKeyVault.loadSealedConversationSecret(conversationId);
      if (localSecret && !localSecret.startsWith('splender_v17_e2ee::')) {
        candidateSecrets.push({ secret: localSecret, fromRsa: false });
      }

      if (parsedHybrid.wk && typeof parsedHybrid.wk === 'object') {
        const currentUid = auth.currentUser?.uid;
        const orderedSlots: string[] = [];
        if (currentUid && typeof parsedHybrid.wk[currentUid] === 'string') {
          orderedSlots.push(parsedHybrid.wk[currentUid]);
        }
        for (const [slotKey, wrappedVal] of Object.entries(parsedHybrid.wk)) {
          if (slotKey !== currentUid && typeof wrappedVal === 'string') {
            orderedSlots.push(wrappedVal);
          }
        }
        for (const wrapped of orderedSlots) {
          try {
            const unwrapped = await this.rsaDecryptWithIdentity(wrapped);
            if (
              unwrapped &&
              !unwrapped.startsWith('splender_v17_e2ee::') &&
              !candidateSecrets.some((c) => c.secret === unwrapped)
            ) {
              candidateSecrets.push({ secret: unwrapped, fromRsa: true });
            }
          } catch {
            // Slot encrypted for a different participant's RSA public key
          }
        }
      }

      for (const candidate of candidateSecrets) {
        try {
          const step = typeof envelope.ratchetStep === 'number' ? envelope.ratchetStep : 1;
          const stepKeyB64 = await P2PCryptoEngine.deriveStepMessageKeyBase64(candidate.secret, step);
          const expectedOuterHmac = await SplenderNativeBridge.computeHmacSha256(
            `splender_hyb4_mac_${stepKeyB64}`,
            `${envelope.iv}:${envelope.ciphertext}:${step}`
          );
          if (!constantTimeHexEqual(expectedOuterHmac, envelope.hmac)) {
            continue;
          }

          const innerEnv: EncryptedEnvelope = {
            ciphertext: parsedHybrid.ct,
            iv: envelope.iv,
            ratchetStep: step,
            protocol: envelope.protocol,
            hmac: typeof parsedHybrid.ih === 'string' ? parsedHybrid.ih : envelope.hmac,
          };
          const plaintext = await P2PCryptoEngine.decryptPayload(innerEnv, candidate.secret);
          if (candidate.fromRsa) {
            await SplenderKeyVault.storeSealedConversationSecret(conversationId, candidate.secret);
          }
          return plaintext;
        } catch {
          // Try next candidate key
        }
      }

      throw new TamperDetectedError('Unable to authenticate or unwrap hybrid E2EE conversation envelope');
    }

    // Non-hyb4 v4 vault secret path
    const vaultSecret = await SplenderKeyVault.loadSealedConversationSecret(conversationId);
    if (vaultSecret && !vaultSecret.startsWith('splender_v17_e2ee::')) {
      try {
        return await P2PCryptoEngine.decryptPayload(envelope, vaultSecret);
      } catch {
        // Fall through to legacy read-only check for historical messages in the same thread
      }
    }

    // Read-only legacy envelope fallback so pre-upgrade chat history remains readable
    const legacyKeyWithPeers = P2PCryptoEngine.deriveLegacyReadOnlyKeyMaterial(
      conversationId,
      participants
    );
    try {
      return await P2PCryptoEngine.decryptPayload(envelope, legacyKeyWithPeers);
    } catch {
      if (participants && participants.length > 0) {
        const legacyKeyIdOnly = P2PCryptoEngine.deriveLegacyReadOnlyKeyMaterial(conversationId);
        return await P2PCryptoEngine.decryptPayload(envelope, legacyKeyIdOnly);
      }
      throw new TamperDetectedError('E2EE envelope authentication or decryption failed');
    }
  }

  /**
   * Strict Zero-Plaintext Server Gate: verifies outgoing Firestore message payloads never leak
   * plaintext `text` or sensitive metadata outside `encryptedEnvelope`.
   */
  public assertZeroPlaintextMessage(payload: Record<string, unknown>): void {
    const msgType = payload.type;
    if (msgType === 'system') return;

    if (payload.text !== '[Encrypted]') {
      throw new ZeroPlaintextViolationError(
        `Outgoing message text must be '[Encrypted]', received '${String(payload.text).slice(0, 24)}'`
      );
    }

    const env = payload.encryptedEnvelope as Record<string, unknown> | undefined;
    if (
      !env ||
      typeof env.ciphertext !== 'string' ||
      env.ciphertext.length === 0 ||
      typeof env.iv !== 'string' ||
      typeof env.hmac !== 'string'
    ) {
      throw new ZeroPlaintextViolationError(
        'Outgoing message is missing a valid AES-GCM encryptedEnvelope'
      );
    }
  }

  // ===========================================================================
  // 3. SECURE LOCAL SESSION TOKEN VAULT (NON-EXTRACTABLE AES-GCM / KEYSTORE)
  // ===========================================================================

  private async getOrCreateTokenMasterKey(): Promise<CryptoKey> {
    if (this.cachedTokenMasterKey) return this.cachedTokenMasterKey;

    const db = await this.getDb();
    const existing = (await db.get(STORE_KEYS, TOKEN_MASTER_KEY_ID)) as StoredKeyRecord | undefined;
    if (existing?.secretKey) {
      this.cachedTokenMasterKey = existing.secretKey;
      return existing.secretKey;
    }

    const masterKey = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false, // Non-extractable hardware/browser keystore key
      ['encrypt', 'decrypt']
    );

    await db.put(STORE_KEYS, {
      id: TOKEN_MASTER_KEY_ID,
      secretKey: masterKey,
      createdAt: Date.now(),
    } satisfies StoredKeyRecord);

    this.cachedTokenMasterKey = masterKey;
    return masterKey;
  }

  /**
   * Seals and stores a sensitive session/refresh token inside IndexedDB (and Android Keystore when native).
   * Never writes plaintext tokens to `localStorage` or `sessionStorage`.
   */
  public async storeSecureToken(
    tokenId: string,
    rawToken: string,
    ttlMs: number = 7 * 24 * 60 * 60 * 1000
  ): Promise<void> {
    if (!tokenId || !rawToken) {
      throw new Error('tokenId and rawToken are required');
    }

    const db = await this.getDb();
    const now = Date.now();
    const expiresAt = now + Math.max(1000, ttlMs);
    const nativePlugin = this.getNativeKeystorePlugin();

    if (nativePlugin?.wrapSecretInKeystore) {
      try {
        const res = await nativePlugin.wrapSecretInKeystore({
          secret: rawToken,
          aad: `splender_token:${tokenId}`,
        });
        if (res?.wrappedBase64) {
          await db.put(STORE_TOKENS, {
            tokenId,
            ivBase64: 'keystore_managed',
            ciphertextBase64: res.wrappedBase64,
            nativeKeystoreWrapped: true,
            createdAt: now,
            expiresAt,
          } satisfies SealedTokenRecord);
          return;
        }
      } catch {
        // Fallback cleanly to non-extractable WebCrypto AES-GCM-256
      }
    }

    const masterKey = await this.getOrCreateTokenMasterKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const aad = new TextEncoder().encode(`splender_token_aad:${tokenId}`);
    const cipherBuf = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as BufferSource,
        additionalData: aad as unknown as BufferSource,
        tagLength: 128,
      },
      masterKey,
      new TextEncoder().encode(rawToken) as unknown as BufferSource
    );

    await db.put(STORE_TOKENS, {
      tokenId,
      ivBase64: bytesToBase64(iv),
      ciphertextBase64: bytesToBase64(new Uint8Array(cipherBuf)),
      nativeKeystoreWrapped: false,
      createdAt: now,
      expiresAt,
    } satisfies SealedTokenRecord);
  }

  /**
   * Unseals a previously stored session token if and only if its TTL has not expired
   * and its AES-GCM authentication tag + AAD match.
   */
  public async retrieveSecureToken(tokenId: string): Promise<string | null> {
    const db = await this.getDb();
    const record = (await db.get(STORE_TOKENS, tokenId)) as SealedTokenRecord | undefined;
    if (!record) return null;

    if (Date.now() > record.expiresAt) {
      await db.delete(STORE_TOKENS, tokenId);
      return null;
    }

    if (record.nativeKeystoreWrapped) {
      const nativePlugin = this.getNativeKeystorePlugin();
      if (!nativePlugin?.unwrapSecretFromKeystore) return null;
      try {
        const res = await nativePlugin.unwrapSecretFromKeystore({
          wrappedBase64: record.ciphertextBase64,
          aad: `splender_token:${tokenId}`,
        });
        return res?.secret ?? null;
      } catch {
        return null;
      }
    }

    try {
      const masterKey = await this.getOrCreateTokenMasterKey();
      const iv = base64ToBytes(record.ivBase64);
      const cipherBytes = base64ToBytes(record.ciphertextBase64);
      const aad = new TextEncoder().encode(`splender_token_aad:${tokenId}`);
      const plainBuf = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv as unknown as BufferSource,
          additionalData: aad as unknown as BufferSource,
          tagLength: 128,
        },
        masterKey,
        cipherBytes as unknown as BufferSource
      );
      return new TextDecoder().decode(plainBuf);
    } catch {
      return null;
    }
  }

  public async revokeSecureToken(tokenId: string): Promise<void> {
    const db = await this.getDb();
    await db.delete(STORE_TOKENS, tokenId);
  }

  public async clearAllTokens(): Promise<void> {
    const db = await this.getDb();
    await db.clear(STORE_TOKENS);
  }

  // Expose utility helpers for deterministic interoperability
  public readonly deriveSymmetricPairForTest = this.deriveSymmetricPair.bind(this);
}

export const CryptoService = CryptoServiceSingleton.getInstance();
export default CryptoService;
