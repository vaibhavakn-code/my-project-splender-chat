/**
 * Splender Chat — Tactile Haptics Engine (`src/services/HapticsService.ts`)
 *
 * Wraps `@capacitor/haptics` for native Android 17 (API 37) actuator feedback
 * with automatic capability detection, duplicate-tap debounce, user preference
 * persistence (`splender_haptics_enabled`), and graceful Web Vibration API fallback.
 */

import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';

class HapticsEngine {
  private static instance: HapticsEngine | null = null;
  private lastPulseAt = 0;
  private readonly minIntervalMs = 35;

  private constructor() {}

  public static getInstance(): HapticsEngine {
    if (!HapticsEngine.instance) {
      HapticsEngine.instance = new HapticsEngine();
    }
    return HapticsEngine.instance;
  }

  public isEnabled(): boolean {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_haptics_enabled') !== 'false';
  }

  public setEnabled(enabled: boolean): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_haptics_enabled', String(enabled));
    }
  }

  private isNativeCapacitor(): boolean {
    return Boolean(
      typeof window !== 'undefined' &&
        (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.()
    );
  }

  private shouldThrottle(): boolean {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    if (now - this.lastPulseAt < this.minIntervalMs) {
      return true;
    }
    this.lastPulseAt = now;
    return false;
  }

  private webVibrateFallback(pattern: number | number[]): void {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Browser frame or battery saver disallowed vibration
      }
    }
  }

  /**
   * Subtle crisp tap for standard buttons, navigation tabs, and copy actions.
   */
  public async tapLight(): Promise<void> {
    if (!this.isEnabled() || this.shouldThrottle()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.impact({ style: ImpactStyle.Light });
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback(6);
  }

  /**
   * Distinct medium tactile thud when dispatching an E2EE message or attachment.
   */
  public async messageSent(): Promise<void> {
    if (!this.isEnabled() || this.shouldThrottle()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.impact({ style: ImpactStyle.Medium });
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback([10, 24, 14]);
  }

  /**
   * Selection tick for theme switching, sliders, and segmented pickers.
   */
  public async selectionChanged(): Promise<void> {
    if (!this.isEnabled() || this.shouldThrottle()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.selectionChanged();
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback(8);
  }

  /**
   * Double-pulse heart/emoji reaction feedback.
   */
  public async reactionPulse(): Promise<void> {
    if (!this.isEnabled()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.impact({ style: ImpactStyle.Light });
        setTimeout(() => {
          void Haptics.impact({ style: ImpactStyle.Medium }).catch(() => {});
        }, 55);
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback([18, 38, 18]);
  }

  /**
   * Biometric unlock, sync completion, or key verification success notification.
   */
  public async notificationSuccess(): Promise<void> {
    if (!this.isEnabled()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.notification({ type: NotificationType.Success });
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback([12, 30, 20]);
  }

  /**
   * Security warning or PIN mismatch tactile alert.
   */
  public async notificationError(): Promise<void> {
    if (!this.isEnabled()) return;
    if (this.isNativeCapacitor()) {
      try {
        await Haptics.notification({ type: NotificationType.Error });
        return;
      } catch {
        // Fallback to navigator.vibrate
      }
    }
    this.webVibrateFallback([30, 45, 30, 45, 40]);
  }
}

export const HapticsService = HapticsEngine.getInstance();
export default HapticsService;
