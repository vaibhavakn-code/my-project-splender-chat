import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  ReactNode,
} from 'react';
import {
  UserProfile,
  ContactItem,
  Conversation,
  Message,
  Moment,
  CallSignal,
  ToastMessage,
  NavigationTab,
  MediaQuality,
  AudioSpeakerRoute,
  VisualThemeId,
  ThemeMode,
  ChatCategory,
} from '../types';
import {
  auth,
  db,
  signInAnonymously,
  signInWithPopup,
  linkWithPopup,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  linkWithCredential,
  GoogleAuthProvider,
  EmailAuthProvider,
  doc,
  collection,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  runTransaction,
  FirebaseUser,
  initPresenceTracking,
  setDebouncedTypingStatus,
  uploadMediaToStorage,
  decryptAttachmentFromStorageUrl,
  createDeterministicAvatarDataUri,
  sanitizeBoundedAvatar,
  ensureFirestoreSafeMomentMedia,
  handleFirestoreError,
  OperationType,
  isPermissionDeniedError,
  FirestoreStreamResilience,
  sanitizeForFirestore,
  increment,
  deleteField,
} from '../lib/firebase';
import {
  generateSplenderId,
  normalizeUsername,
  compressImage,
  getStoredMediaQuality,
  setStoredMediaQuality,
} from '../lib/compression';
import { getSafeUserMedia } from '../lib/mediaHelper';
import { notifyIncomingChat, notifyNewStory } from '../lib/notifications';
import { trackEvent, trackTabView } from '../lib/analytics';
import { playClickSound, playPopSound, playCallConnectSound, startRingtone, stopRingtone } from '../lib/sound';
import { LanguageCode, TranslationStrings, getTranslation } from '../lib/i18n';
import { applyThemeToDOM, getThemeConfig } from '../lib/themeEngine';
import { OfflineQueueManager, MultiDeviceSync, AudioAlerts } from '../lib/masterFeatures';
import { divyaDrishtiAi } from '../lib/divyaDrishtiAi';
import { P2PCryptoEngine, OfflineOutboxManager } from '../lib/p2pSecurity';
import { SplenderWebRtcEngine, DataChannelState, getWebRtcConfiguration } from '../lib/webrtcEngine';
import { SplenderNativeBridge } from '../lib/nativeBridge';
import { SplenderKeyVault } from '../lib/keyVault';
import { Android17PermissionManager } from '../lib/android17Permissions';
import { CryptoService } from '../services/CryptoService';
import { SyncService } from '../services/SyncService';
import { ConnectionManager } from '../services/ConnectionManager';
import { HapticsService } from '../services/HapticsService';

interface ChatContextType {
  // Auth & Identity
  firebaseUser: FirebaseUser | null;
  currentUserProfile: UserProfile | null;
  isLoadingAuth: boolean;
  authError: string | null;
  authRestrictedInfo: { isRestricted: boolean; reason?: string } | null;
  signInWithGoogle: () => Promise<boolean>;
  signInWithEmail: (email: string, pass: string) => Promise<boolean>;
  signUpWithEmail: (email: string, pass: string, chosenUsername?: string) => Promise<boolean>;
  tryAnonymousAuth: () => Promise<boolean>;
  signOutUser: () => Promise<void>;
  deleteAccountAndWipeData: () => Promise<boolean>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  linkGoogleAccount: () => Promise<boolean>;
  linkEmailAccount: (email: string, pass: string) => Promise<boolean>;

  // Navigation & App Lock
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  isAppLocked: boolean;
  unlockApp: () => void;
  lockApp: () => void;
  userPin: string | null;
  setUserPin: (pin: string | null) => void;

  // Modals & Panels
  isQrScannerOpen: boolean;
  setIsQrScannerOpen: (open: boolean) => void;
  isIdentityModalOpen: boolean;
  setIsIdentityModalOpen: (open: boolean) => void;
  isPrivacySettingsModalOpen: boolean;
  setIsPrivacySettingsModalOpen: (open: boolean) => void;
  isSettingsModalOpen: boolean;
  setIsSettingsModalOpen: (open: boolean) => void;
  isDevDocsModalOpen: boolean;
  setIsDevDocsModalOpen: (open: boolean) => void;
  isVaultModalOpen: boolean;
  setIsVaultModalOpen: (open: boolean) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  themeMode: 'light' | 'dark' | 'system';
  setThemeMode: (mode: 'light' | 'dark' | 'system') => void;
  visualTheme: VisualThemeId;
  setVisualTheme: (theme: VisualThemeId) => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: keyof TranslationStrings) => string;
  globalSearchQuery: string;
  setGlobalSearchQuery: (q: string) => void;
  globalSearchFilter: string;
  setGlobalSearchFilter: (f: string) => void;
  clearConversationMessages: (conversationId: string) => Promise<void>;
  networkStatus: 'online' | 'offline' | 'reconnecting' | 'syncing';
  handleHardwareBack: () => boolean;
  viewingStoryId: string | null;
  setViewingStoryId: (id: string | null) => void;
  viewingUserId: string | null;
  setViewingUserId: (id: string | null) => void;

  // Realtime Data
  conversations: Conversation[];
  activeConversation: Conversation | null;
  messages: Message[];
  contacts: ContactItem[];
  moments: Moment[];

  // Realtime Actions
  sendMessage: (
    text: string,
    type?: Message['type'],
    mediaUrl?: string,
    audioDuration?: number,
    replyTo?: { id: string; senderName: string; text: string },
    mediaQualityOverride?: MediaQuality,
    thumbnailUrl?: string,
    extraPayload?: Partial<Message>
  ) => Promise<void>;
  expireViewOnceMessage?: (conversationId: string, messageId: string) => Promise<void>;
  votePoll?: (messageId: string, optionId: string) => Promise<void>;
  markMessagesRead: (conversationId: string) => Promise<void>;
  addReaction: (messageId: string, emoji: string) => Promise<void>;
  deleteMessage: (messageId: string) => Promise<void>;
  togglePinConversation: (conversationId: string) => Promise<void>;
  toggleMuteConversation: (conversationId: string) => Promise<void>;
  startDirectConversation: (targetProfile: { uid: string; splenderId: string; displayName: string; avatar: string }) => Promise<string>;
  createGroupConversation: (name: string, members: ContactItem[]) => Promise<string>;

  // Contacts
  searchUserBySplenderOrUsername: (queryStr: string) => Promise<UserProfile | null>;
  sendContactRequest: (targetUser: UserProfile) => Promise<boolean>;
  acceptContactRequest: (contact: ContactItem) => Promise<void>;
  declineContactRequest: (contact: ContactItem) => Promise<void>;
  blockContact: (targetUid: string) => Promise<void>;
  unblockContact: (targetUid: string) => Promise<void>;

  // Moments
  postMoment: (
    fileOrUrl: string,
    caption: string,
    mediaQuality?: MediaQuality,
    thumbnailUrl?: string,
    mediaType?: 'image' | 'video' | 'audio' | 'text',
    extraOptions?: {
      poll?: Moment['poll'];
      isPermanentFeed?: boolean;
      arFilter?: string;
      bgColor?: string;
      privacy?: Moment['privacy'];
    }
  ) => Promise<void>;
  toggleLikeMoment: (momentId: string) => Promise<void>;
  voteMomentPoll: (momentId: string, optionIndex: number) => Promise<void>;
  addMomentComment: (momentId: string, text: string) => Promise<void>;
  recordMomentView: (momentId: string) => Promise<void>;
  deleteMoment: (momentId: string) => Promise<void>;

  // Real WebRTC Calls
  activeCall: CallSignal | null;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isCallMuted: boolean;
  isCallCameraOff: boolean;
  isSpeakerOn: boolean;
  isScreenSharing: boolean;
  isCallMinimized: boolean;
  setIsCallMinimized: (minimized: boolean) => void;
  speakerRoute: AudioSpeakerRoute;
  setSpeakerRoute: (route: AudioSpeakerRoute) => void;
  callDuration: number;
  startCall: (targetUid: string, targetName: string, targetAvatar: string, type: 'voice' | 'video') => Promise<void>;
  acceptCall: () => Promise<void>;
  endCall: () => Promise<void>;
  toggleCallMute: () => void;
  toggleCallCamera: () => void;
  toggleSpeaker: () => void;
  toggleScreenShare: () => Promise<void>;

  // Search & Navigation Highlighting
  targetJumpMessageId: string | null;
  setTargetJumpMessageId: (id: string | null) => void;

  // Disappearing Messages & Privacy Guard
  setConversationDisappearingTimer: (convId: string, seconds: number) => Promise<void>;

  // Broadcast Messaging & Batch Operations
  sendBroadcastMessage: (recipientUids: string[], text: string, mediaUrl?: string) => Promise<void>;
  batchDeleteMessages: (convId: string, messageIds: string[]) => Promise<void>;

  // Presence & Typing
  isUserOnline: (uid: string) => boolean;
  sendTypingStatus: (conversationId: string, recipientUid: string, isTyping: boolean) => void;

  // System & Toasts
  toasts: ToastMessage[];
  showToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;
  toggleDataSaver: () => Promise<void>;
  mediaQuality: MediaQuality;
  setMediaQuality: (quality: MediaQuality) => Promise<void>;

  // Elite Theme, Categories, Command Palette & Clipboard
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  activeCategory: ChatCategory;
  setActiveCategory: (cat: ChatCategory) => void;
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  batterySaver: boolean;
  setBatterySaver: (val: boolean) => void;
  copyToClipboard: (text: string) => void;
  copiedId: string | null;

  // Modern Luxurious Settings & Feature Expansion
  disappearingMode: boolean;
  setDisappearingMode: (val: boolean) => void;
  linkExpiryDuration: number;
  setLinkExpiryDuration: (hours: number) => void;
  lockChatThread: boolean;
  setLockChatThread: (val: boolean) => void;
  snapshotGuard: boolean;
  setSnapshotGuard: (val: boolean) => void;
  screenShareLock: boolean;
  setScreenShareLock: (val: boolean) => void;
  smartThreadSummaries: boolean;
  setSmartThreadSummaries: (val: boolean) => void;
  autoQuickReplies: boolean;
  setAutoQuickReplies: (val: boolean) => void;
  contextSuperEngine: boolean;
  setContextSuperEngine: (val: boolean) => void;
  vpnStatus: boolean;
  setVpnStatus: (val: boolean) => void;
  lockScreenShield: boolean;
  setLockScreenShield: (val: boolean) => void;
  fontSize: number;
  setFontSize: (size: number) => void;
  realtimeTranslation: boolean;
  setRealtimeTranslation: (val: boolean) => void;
  voiceCommandControl: boolean;
  setVoiceCommandControl: (val: boolean) => void;
  storageBreakdown: {
    files: number;
    media: number;
    audio: number;
    cache: number;
    totalUsed: number;
    totalFree: number;
  };
  cleanStorageCache: () => void;
  cleanStorageCategory: (cat: 'cache' | 'p2p' | 'audio' | 'media' | 'all') => void;
  isQuickPollModalOpen: boolean;
  setIsQuickPollModalOpen: (open: boolean) => void;
  startAiAssistantChat: () => void;

  // Adaptive Dark & Light Sync
  adaptiveThemeSync: boolean;
  setAdaptiveThemeSync: (val: boolean) => void;
  preferredDarkAccent: 'indigo_dawn' | 'teal_dusk';
  setPreferredDarkAccent: (val: 'indigo_dawn' | 'teal_dusk') => void;
  preferredLightAccent: 'apricot_bloom' | 'rose_quartz';
  setPreferredLightAccent: (val: 'apricot_bloom' | 'rose_quartz') => void;

  // Advanced Security Suite
  autoLockTimer: 'immediate' | '1m' | '5m' | '15m' | '30m' | 'disabled';
  setAutoLockTimer: (timer: 'immediate' | '1m' | '5m' | '15m' | '30m' | 'disabled') => void;
  isP2PStorageDashboardOpen: boolean;
  setIsP2PStorageDashboardOpen: (open: boolean) => void;
  isOfflineQueueModalOpen: boolean;
  setIsOfflineQueueModalOpen: (open: boolean) => void;
  isE2eeHealthModalOpen: boolean;
  setIsE2eeHealthModalOpen: (open: boolean) => void;
  isVoiceCommandOverlayOpen: boolean;
  setIsVoiceCommandOverlayOpen: (open: boolean) => void;
  p2pChannelState: DataChannelState;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// Dynamic STUN/TURN ICE configuration is resolved per-session via getWebRtcConfiguration()

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authRestrictedInfo, setAuthRestrictedInfo] = useState<{ isRestricted: boolean; reason?: string } | null>(null);

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<NavigationTab>('chats');
  const [isAppLocked, setIsAppLocked] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_app_lock_enabled') === 'true';
  });
  const [userPin, setUserPin] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('splender_pin_hash') || localStorage.getItem('splender_pin') || null;
  });

  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [isIdentityModalOpen, setIsIdentityModalOpen] = useState(false);
  const [isPrivacySettingsModalOpen, setIsPrivacySettingsModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isDevDocsModalOpen, setIsDevDocsModalOpen] = useState(false);
  const [isVaultModalOpen, setIsVaultModalOpen] = useState(false);
  const [themeMode, setThemeModeState] = useState<'light' | 'dark' | 'system'>(() => {
    if (typeof window === 'undefined') return 'dark';
    const savedMode = localStorage.getItem('splender_theme_mode');
    if (savedMode === 'light' || savedMode === 'dark' || savedMode === 'system') {
      return savedMode;
    }
    return localStorage.getItem('splender_dark_mode') === 'false' ? 'light' : 'dark';
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_dark_mode') !== 'false';
  });

  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchFilter, setGlobalSearchFilter] = useState('all');

  // App lock on resume listener
  useEffect(() => {
    const handleVisibility = () => {
      const isEnabled = typeof window !== 'undefined' && localStorage.getItem('splender_app_lock_enabled') === 'true';
      if (isEnabled && document.visibilityState === 'visible') {
        setIsAppLocked(true);
      }
    };
    if (typeof window !== 'undefined' && localStorage.getItem('splender_app_lock_enabled') === 'true') {
      setIsAppLocked(true);
    }
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, []);

  // Adaptive Dark & Light Theme Accent Sync (opt-in so user's chosen palette stays authoritative)
  const [adaptiveThemeSync, setAdaptiveThemeSyncState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_adaptive_theme_sync') === 'true';
  });

  const [preferredDarkAccent, setPreferredDarkAccentState] = useState<'indigo_dawn' | 'teal_dusk'>(() => {
    if (typeof window === 'undefined') return 'indigo_dawn';
    const stored = localStorage.getItem('splender_pref_dark_accent');
    return stored === 'teal_dusk' ? 'teal_dusk' : 'indigo_dawn';
  });

  const [preferredLightAccent, setPreferredLightAccentState] = useState<'apricot_bloom' | 'rose_quartz'>(() => {
    if (typeof window === 'undefined') return 'apricot_bloom';
    const stored = localStorage.getItem('splender_pref_light_accent');
    return stored === 'rose_quartz' ? 'rose_quartz' : 'apricot_bloom';
  });

  // Auto-Lock Timer state
  const [autoLockTimer, setAutoLockTimerState] = useState<'immediate' | '1m' | '5m' | '15m' | '30m' | 'disabled'>(() => {
    if (typeof window === 'undefined') return '5m';
    return (localStorage.getItem('splender_auto_lock_timer') as any) || '5m';
  });

  const lastActivityRef = useRef<number>(Date.now());

  // Modal states for P2P Storage, E2EE Health, Offline Queue, Voice Command
  const [isP2PStorageDashboardOpen, setIsP2PStorageDashboardOpen] = useState(false);
  const [isOfflineQueueModalOpen, setIsOfflineQueueModalOpen] = useState(false);
  const [isE2eeHealthModalOpen, setIsE2eeHealthModalOpen] = useState(false);
  const [isVoiceCommandOverlayOpen, setIsVoiceCommandOverlayOpen] = useState(false);

  const setAdaptiveThemeSync = (val: boolean) => {
    setAdaptiveThemeSyncState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_adaptive_theme_sync', String(val));
    }
    if (val) {
      const isSystemDark = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      const targetAccent = isSystemDark ? preferredDarkAccent : preferredLightAccent;
      setThemeState(targetAccent);
      applyThemeToDOM(targetAccent);
      showToast('Adaptive Sync Active', `Accents sync with device: ${targetAccent === preferredDarkAccent ? '🌙 Dark Accent' : '☀️ Light Accent'}`, 'info');
    } else {
      showToast('Adaptive Sync Disabled', 'Manual theme selection retained', 'info');
    }
  };

  const setPreferredDarkAccent = (accent: 'indigo_dawn' | 'teal_dusk') => {
    setPreferredDarkAccentState(accent);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_pref_dark_accent', accent);
    }
    if (adaptiveThemeSync && (darkMode || (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches))) {
      setThemeState(accent);
      applyThemeToDOM(accent);
    }
  };

  const setPreferredLightAccent = (accent: 'apricot_bloom' | 'rose_quartz') => {
    setPreferredLightAccentState(accent);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_pref_light_accent', accent);
    }
    if (adaptiveThemeSync && (!darkMode || (typeof window !== 'undefined' && !window.matchMedia('(prefers-color-scheme: dark)').matches))) {
      setThemeState(accent);
      applyThemeToDOM(accent);
    }
  };

  const setAutoLockTimer = (timer: 'immediate' | '1m' | '5m' | '15m' | '30m' | 'disabled') => {
    setAutoLockTimerState(timer);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_auto_lock_timer', timer);
    }
    showToast('Auto-Lock Timer', `App will lock after: ${timer}`, 'info');
  };

  // Activity tracker for biometric auto-lock
  useEffect(() => {
    const handleActivity = () => {
      lastActivityRef.current = Date.now();
    };
    window.addEventListener('pointerdown', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('scroll', handleActivity);
    return () => {
      window.removeEventListener('pointerdown', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('scroll', handleActivity);
    };
  }, []);

  // Inactivity & background auto-lock check
  useEffect(() => {
    const checkAutoLock = () => {
      const isEnabled = typeof window !== 'undefined' && localStorage.getItem('splender_app_lock_enabled') === 'true';
      if (!isEnabled || autoLockTimer === 'disabled') return;

      const timerMap: Record<string, number> = {
        immediate: 0,
        '1m': 60 * 1000,
        '5m': 5 * 60 * 1000,
        '15m': 15 * 60 * 1000,
        '30m': 30 * 60 * 1000,
      };
      const limit = timerMap[autoLockTimer] ?? 5 * 60 * 1000;
      const elapsed = Date.now() - lastActivityRef.current;

      if (elapsed >= limit) {
        setIsAppLocked(true);
      }
    };

    const timerMap: Record<string, number> = {
      immediate: 0,
      '1m': 60 * 1000,
      '5m': 5 * 60 * 1000,
      '15m': 15 * 60 * 1000,
      '30m': 30 * 60 * 1000,
    };
    const isEnabledNow =
      typeof window !== 'undefined' && localStorage.getItem('splender_app_lock_enabled') === 'true';
    void SplenderNativeBridge.configureBiometricSessionLock(
      isEnabledNow && autoLockTimer !== 'disabled',
      timerMap[autoLockTimer] ?? 10_000
    );

    const unsubNativeLock = SplenderNativeBridge.subscribeSessionLockChanges(
      () =>
        typeof window !== 'undefined' &&
        localStorage.getItem('splender_app_lock_enabled') === 'true' &&
        autoLockTimer !== 'disabled',
      (locked) => {
        setIsAppLocked(locked);
      },
      timerMap[autoLockTimer] ?? 5 * 60 * 1000
    );

    const interval = setInterval(checkAutoLock, 10000);
    return () => {
      clearInterval(interval);
      unsubNativeLock();
    };
  }, [autoLockTimer]);

  // Theme Synchronizer with System / Light / Dark & Adaptive Accent Sync
  useEffect(() => {
    const applyTheme = () => {
      let isDark = false;
      if (themeMode === 'system') {
        isDark = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      } else {
        isDark = themeMode === 'dark';
      }
      setDarkMode(isDark);
      if (typeof document !== 'undefined') {
        if (isDark) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }

      // Automatically sync theme accents based on device preference
      if (adaptiveThemeSync) {
        const targetAccent = isDark ? preferredDarkAccent : preferredLightAccent;
        setThemeState(targetAccent);
        applyThemeToDOM(targetAccent);
      }
    };

    applyTheme();

    if (typeof window !== 'undefined' && window.matchMedia) {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      mq.addEventListener('change', listener);
      return () => mq.removeEventListener('change', listener);
    }
  }, [themeMode, adaptiveThemeSync, preferredDarkAccent, preferredLightAccent]);

  const setThemeMode = (mode: 'light' | 'dark' | 'system') => {
    setThemeModeState(mode);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_theme_mode', mode);
      localStorage.setItem('splender_dark_mode', String(mode === 'dark'));
    }
  };

  const toggleDarkMode = () => {
    setThemeModeState((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      if (typeof window !== 'undefined') {
        localStorage.setItem('splender_theme_mode', next);
        localStorage.setItem('splender_dark_mode', String(next === 'dark'));
      }
      return next;
    });
  };

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    if (typeof window === 'undefined') return 'indigo_dawn';
    const stored = (localStorage.getItem('splender_elite_theme') || localStorage.getItem('splender_visual_theme')) as ThemeMode;
    if (
      stored &&
      [
        'indigo_dawn',
        'apricot_bloom',
        'teal_dusk',
        'rose_quartz',
        'midnight_oled',
        'emerald_luxury',
        'cyber_indigo',
        'emerald',
        'dark_amber',
      ].includes(stored)
    ) {
      return stored;
    }
    return 'indigo_dawn';
  });

  const [visualTheme, setVisualThemeState] = useState<VisualThemeId>(() => {
    if (typeof window === 'undefined') return 'indigo_dawn';
    const stored = localStorage.getItem('splender_visual_theme') as VisualThemeId;
    return stored || 'indigo_dawn';
  });

  const [activeCategory, setActiveCategory] = useState<ChatCategory>('all');
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [batterySaver, setBatterySaverState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_battery_saver') === 'true';
  });
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof document !== 'undefined') {
      applyThemeToDOM(theme);
    }
  }, [theme]);

  const setTheme = (newTheme: ThemeMode) => {
    const cfg = getThemeConfig(newTheme);
    setThemeState(newTheme);
    setVisualThemeState(newTheme as any);
    setDarkMode(cfg.isDark);
    setThemeModeState(cfg.isDark ? 'dark' : 'light');
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_elite_theme', newTheme);
      localStorage.setItem('splender_visual_theme', newTheme);
      localStorage.setItem('splender_dark_mode', String(cfg.isDark));
      localStorage.setItem('splender_theme_mode', cfg.isDark ? 'dark' : 'light');
    }
    applyThemeToDOM(newTheme);
    showToast('Theme Updated', `${cfg.name} applied: ${cfg.tagline}`, 'info');
  };

  const setVisualTheme = (th: VisualThemeId) => {
    setTheme(th as any);
  };

  // Modern Luxurious Settings & Feature Expansion Persistent States
  const [disappearingMode, setDisappearingModeState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_disappearing_mode') === 'true';
  });

  const setDisappearingMode = (val: boolean) => {
    setDisappearingModeState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_disappearing_mode', String(val));
    }
  };

  const [linkExpiryDuration, setLinkExpiryDurationState] = useState<number>(() => {
    if (typeof window === 'undefined') return 24;
    const stored = Number(localStorage.getItem('splender_link_expiry_hours'));
    return stored > 0 ? stored : 24;
  });

  const setLinkExpiryDuration = (hours: number) => {
    setLinkExpiryDurationState(hours);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_link_expiry_hours', String(hours));
    }
  };

  const [lockChatThread, setLockChatThreadState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_lock_chat_thread') === 'true';
  });

  const setLockChatThread = (val: boolean) => {
    setLockChatThreadState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_lock_chat_thread', String(val));
    }
  };

  const [snapshotGuard, setSnapshotGuardState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_snapshot_guard') !== 'false';
  });

  const setSnapshotGuard = (val: boolean) => {
    setSnapshotGuardState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_snapshot_guard', String(val));
    }
  };

  const [screenShareLock, setScreenShareLockState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_screen_share_lock') !== 'false';
  });

  const setScreenShareLock = (val: boolean) => {
    setScreenShareLockState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_screen_share_lock', String(val));
    }
  };

  const [smartThreadSummaries, setSmartThreadSummariesState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_smart_thread_summaries') !== 'false';
  });

  const setSmartThreadSummaries = (val: boolean) => {
    setSmartThreadSummariesState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_smart_thread_summaries', String(val));
    }
  };

  const [autoQuickReplies, setAutoQuickRepliesState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_auto_quick_replies') !== 'false';
  });

  const setAutoQuickReplies = (val: boolean) => {
    setAutoQuickRepliesState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_auto_quick_replies', String(val));
    }
  };

  const [contextSuperEngine, setContextSuperEngineState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_context_super_engine') !== 'false';
  });

  const setContextSuperEngine = (val: boolean) => {
    setContextSuperEngineState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_context_super_engine', String(val));
    }
  };

  const [vpnStatus, setVpnStatusState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_vpn_status') !== 'false';
  });

  const setVpnStatus = (val: boolean) => {
    setVpnStatusState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_vpn_status', String(val));
    }
  };

  const [lockScreenShield, setLockScreenShieldState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_lock_screen_shield') === 'true';
  });

  const setLockScreenShield = (val: boolean) => {
    setLockScreenShieldState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_lock_screen_shield', String(val));
    }
  };

  const [fontSize, setFontSizeState] = useState<number>(() => {
    if (typeof window === 'undefined') return 15;
    const stored = Number(localStorage.getItem('splender_font_size'));
    return stored >= 12 && stored <= 22 ? stored : 15;
  });

  const setFontSize = (size: number) => {
    setFontSizeState(size);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_font_size', String(size));
    }
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--app-font-size', `${size}px`);
      document.documentElement.style.fontSize = `${size}px`;
    }
  };

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--app-font-size', `${fontSize}px`);
      document.documentElement.style.fontSize = `${fontSize}px`;
    }
  }, [fontSize]);

  const [realtimeTranslation, setRealtimeTranslationState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('splender_realtime_translation') !== 'false';
  });

  const setRealtimeTranslation = (val: boolean) => {
    setRealtimeTranslationState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_realtime_translation', String(val));
    }
  };

  const [voiceCommandControl, setVoiceCommandControlState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('splender_voice_command_control') === 'true';
  });

  const setVoiceCommandControl = (val: boolean) => {
    setVoiceCommandControlState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_voice_command_control', String(val));
    }
  };

  // Media & Storage Breakdown State & Clean-up
  const [storageBreakdown, setStorageBreakdown] = useState(() => {
    const isCleaned = typeof window !== 'undefined' && localStorage.getItem('splender_cache_cleaned') === 'true';
    const cacheMB = isCleaned ? 2 : 18;
    const filesMB = 24;
    const mediaMB = 48;
    const audioMB = 12;
    const totalUsed = filesMB + mediaMB + audioMB + cacheMB;
    return {
      files: filesMB,
      media: mediaMB,
      audio: audioMB,
      cache: cacheMB,
      totalUsed,
      totalFree: 65536 - totalUsed,
    };
  });

  // Populate storage telemetry from real browser / WebView StorageManager quota estimates
  useEffect(() => {
    if (typeof navigator === 'undefined' || !navigator.storage?.estimate) return;
    let cancelled = false;
    navigator.storage
      .estimate()
      .then((est) => {
        if (cancelled || typeof est.quota !== 'number' || est.quota <= 0) return;
        const usedBytes = typeof est.usage === 'number' ? est.usage : 0;
        const usedMB = Math.max(1, Math.round(usedBytes / (1024 * 1024)));
        const quotaMB = Math.max(usedMB + 64, Math.round(est.quota / (1024 * 1024)));
        const isCleaned =
          typeof window !== 'undefined' && localStorage.getItem('splender_cache_cleaned') === 'true';
        const cacheShare = isCleaned ? Math.min(1, usedMB) : Math.max(1, Math.round(usedMB * 0.15));
        const remaining = Math.max(0, usedMB - cacheShare);
        const mediaShare = Math.round(remaining * 0.5);
        const filesShare = Math.round(remaining * 0.32);
        const audioShare = Math.max(0, remaining - mediaShare - filesShare);
        setStorageBreakdown({
          files: filesShare,
          media: mediaShare,
          audio: audioShare,
          cache: cacheShare,
          totalUsed: usedMB,
          totalFree: Math.max(0, quotaMB - usedMB),
        });
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [activeConversationId, isP2PStorageDashboardOpen]);

  // Tap-to-navigate listener for OS / ServiceWorker / FCM push notifications (zero plaintext exposure)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const openConversation = (convId?: string | null) => {
      if (convId && typeof convId === 'string') {
        setActiveTab('chats');
        setActiveConversationId(convId);
      }
    };

    try {
      const params = new URLSearchParams(window.location.search);
      const initialChat = params.get('chat');
      if (initialChat) {
        openConversation(initialChat);
      }
    } catch {
      // Ignore URL parse issues
    }

    const handleCustomNavigate = (ev: Event) => {
      const detail = (ev as CustomEvent<{ conversationId?: string }>).detail;
      openConversation(detail?.conversationId);
    };

    const handleSwMessage = (ev: MessageEvent) => {
      if (ev.data?.type === 'SPLENDER_NOTIFICATION_CLICK') {
        openConversation(ev.data.conversationId);
      }
    };

    window.addEventListener('splender:navigate-conversation', handleCustomNavigate);
    navigator.serviceWorker?.addEventListener?.('message', handleSwMessage);
    return () => {
      window.removeEventListener('splender:navigate-conversation', handleCustomNavigate);
      navigator.serviceWorker?.removeEventListener?.('message', handleSwMessage);
    };
  }, []);

  const cleanStorageCache = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_cache_cleaned', 'true');
      localStorage.removeItem('splender_temp_cache');
    }
    const freedMB = storageBreakdown.cache > 12 ? storageBreakdown.cache - 12 : 0;
    setStorageBreakdown((prev) => {
      const newCache = 12;
      const newUsed = prev.files + prev.media + prev.audio + newCache;
      return {
        ...prev,
        cache: newCache,
        totalUsed: newUsed,
        totalFree: 65536 - newUsed,
      };
    });
    showToast(
      'Cache Cleaned',
      freedMB > 0 ? `Successfully cleared ${freedMB} MB of temporary files & cached blobs` : 'Storage optimized',
      'success'
    );
  };

  const cleanStorageCategory = (cat: 'cache' | 'p2p' | 'audio' | 'media' | 'all') => {
    let freedDescription = '';
    setStorageBreakdown((prev) => {
      let newFiles = prev.files;
      let newMedia = prev.media;
      let newAudio = prev.audio;
      let newCache = prev.cache;

      if (cat === 'cache' || cat === 'all') {
        newCache = 12;
        if (typeof window !== 'undefined') {
          localStorage.setItem('splender_cache_cleaned', 'true');
          localStorage.removeItem('splender_temp_cache');
        }
      }
      if (cat === 'p2p' || cat === 'all') {
        newFiles = Math.max(120, prev.files - 1120);
        if (typeof window !== 'undefined') {
          localStorage.setItem('splender_p2p_cleaned', 'true');
        }
      }
      if (cat === 'audio' || cat === 'all') {
        newAudio = 40;
        if (typeof window !== 'undefined') {
          localStorage.setItem('splender_audio_cleaned', 'true');
        }
      }
      if (cat === 'media' || cat === 'all') {
        newMedia = Math.max(450, prev.media - 2000);
        if (typeof window !== 'undefined') {
          localStorage.setItem('splender_media_cleaned', 'true');
        }
      }

      const newUsed = newFiles + newMedia + newAudio + newCache;
      const totalFree = 65536 - newUsed;
      const deltaMB = prev.totalUsed - newUsed;
      freedDescription = deltaMB > 0 ? `Freed ${(deltaMB / 1024).toFixed(2)} GB of storage` : 'Storage optimized';

      return {
        files: newFiles,
        media: newMedia,
        audio: newAudio,
        cache: newCache,
        totalUsed: newUsed,
        totalFree,
      };
    });

    showToast('Storage Cleanup Complete', freedDescription, 'success');
  };

  // Quick Poll Modal state
  const [isQuickPollModalOpen, setIsQuickPollModalOpen] = useState(false);

  // New AI Assistant Direct Chat opener
  const startAiAssistantChat = () => {
    setActiveConversationId('splender_ai_assistant');
    showToast('AI Assistant Active', 'Connected to Splender AI powered by Divya Drishti & Gemini', 'info');
  };

  const setBatterySaver = (val: boolean) => {
    setBatterySaverState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('splender_battery_saver', String(val));
    }
    showToast('Battery Saver', val ? 'Battery Saver Active (Reduced micro-animations)' : 'Standard Performance Mode', 'info');
  };

  // Keyboard shortcut listener for Command Palette (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Single-Click Copy function with visual confirmation
  const copyToClipboard = (text: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    playPopSound();
    setCopiedId(text);
    showToast('Copied', 'Message text copied to clipboard', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const stored = localStorage.getItem('splender_language_code') as LanguageCode;
      if (['mr', 'hi', 'en', 'es', 'fr', 'de'].includes(stored)) return stored;
    } catch {}
    return 'mr';
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('splender_language_code', lang);
    } catch {}
  };

  const t = (key: keyof TranslationStrings): string => {
    return getTranslation(language, key);
  };

  const [networkStatus, setNetworkStatus] = useState<'online' | 'offline' | 'reconnecting' | 'syncing'>('online');
  const [viewingStoryId, setViewingStoryId] = useState<string | null>(null);
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [mediaQuality, setMediaQualityState] = useState<MediaQuality>(() => getStoredMediaQuality());

  useEffect(() => {
    if (currentUserProfile?.mediaQuality) {
      setMediaQualityState(currentUserProfile.mediaQuality);
      setStoredMediaQuality(currentUserProfile.mediaQuality);
    }
  }, [currentUserProfile?.mediaQuality]);

  const setMediaQuality = async (quality: MediaQuality) => {
    setMediaQualityState(quality);
    setStoredMediaQuality(quality);
    if (currentUserProfile && firebaseUser) {
      await updateProfile({
        mediaQuality: quality,
        dataSaver: quality === 'medium',
      });
    }
  };

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [contacts, setContacts] = useState<ContactItem[]>([]);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // WebRTC Call state
  const [activeCall, setActiveCall] = useState<CallSignal | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isCallMuted, setIsCallMuted] = useState(false);
  const [isCallCameraOff, setIsCallCameraOff] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [speakerRoute, setSpeakerRoute] = useState<AudioSpeakerRoute>('speaker');
  const [isCallMinimized, setIsCallMinimized] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [targetJumpMessageId, setTargetJumpMessageId] = useState<string | null>(null);
  const screenTrackRef = useRef<MediaStreamTrack | null>(null);
  const [onlineUserIds, setOnlineUserIds] = useState<Set<string>>(new Set());
  const [p2pChannelState, setP2pChannelState] = useState<DataChannelState>('disconnected');

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Push Notification state and load tracking
  const lastNotifiedConvMessageTimeRef = useRef<Record<string, number>>({});
  const isConvInitialLoadRef = useRef(true);
  const lastStoryTimeRef = useRef<number>(Date.now());
  const isMomentsInitialLoadRef = useRef(true);

  // Provision non-extractable platform cryptographic keys on boot (IndexedDB / AndroidKeyStore)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    void SplenderKeyVault.getOrCreateLocalMasterKey().catch(() => {});
    void SplenderKeyVault.getOrCreateIdentityKeyPair().catch(() => {});
  }, []);

  // Synchronize Android 17 Foreground Call Service flag & native VoIP ForegroundService lifecycle
  useEffect(() => {
    const isActive = Boolean(activeCall);
    Android17PermissionManager.setForegroundCallActive(isActive);
    if (activeCall) {
      void SplenderNativeBridge.startCallForegroundService(
        activeCall.type === 'video',
        activeConversationId
      );
    } else {
      void SplenderNativeBridge.stopCallForegroundService();
    }
  }, [activeCall, activeConversationId]);

  // Analytics tab view tracking
  useEffect(() => {
    trackTabView(activeTab);
  }, [activeTab]);

  // Network & Firestore Listen/Write stream status monitoring
  useEffect(() => {
    let syncSettleTimer: ReturnType<typeof setTimeout> | null = null;

    const unsubStreamStatus = FirestoreStreamResilience.subscribeStatus((streamStatus) => {
      if (syncSettleTimer) {
        clearTimeout(syncSettleTimer);
        syncSettleTimer = null;
      }
      if (streamStatus.state === 'offline') {
        setNetworkStatus('offline');
      } else if (streamStatus.state === 'paused' || streamStatus.state === 'reconnecting') {
        setNetworkStatus('reconnecting');
      } else {
        setNetworkStatus((prev) => {
          if (prev === 'offline' || prev === 'reconnecting') {
            syncSettleTimer = setTimeout(() => setNetworkStatus('online'), 500);
            return 'syncing';
          }
          return 'online';
        });
      }
    });

    const handleOnline = () => {
      void FirestoreStreamResilience.resumeStreams('chat_context_online');
    };
    const handleOffline = () => {
      setNetworkStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      setNetworkStatus('offline');
    }

    return () => {
      if (syncSettleTimer) clearTimeout(syncSettleTimer);
      unsubStreamStatus();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Hardware Back & Navigation Synchronization
  const handleHardwareBack = (): boolean => {
    if (viewingStoryId) {
      setViewingStoryId(null);
      return true;
    }
    if (viewingUserId) {
      setViewingUserId(null);
      return true;
    }
    if (isDevDocsModalOpen) {
      setIsDevDocsModalOpen(false);
      return true;
    }
    if (isPrivacySettingsModalOpen) {
      setIsPrivacySettingsModalOpen(false);
      return true;
    }
    if (isIdentityModalOpen) {
      setIsIdentityModalOpen(false);
      return true;
    }
    if (isSettingsModalOpen) {
      setIsSettingsModalOpen(false);
      return true;
    }
    if (isQrScannerOpen) {
      setIsQrScannerOpen(false);
      return true;
    }
    if (activeCall) {
      endCall();
      return true;
    }
    if (activeConversationId) {
      setActiveConversationId(null);
      return true;
    }
    return false;
  };

  useEffect(() => {
    const onPopState = () => {
      handleHardwareBack();
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [
    viewingStoryId,
    viewingUserId,
    isDevDocsModalOpen,
    isPrivacySettingsModalOpen,
    isIdentityModalOpen,
    isSettingsModalOpen,
    isQrScannerOpen,
    activeCall,
    activeConversationId,
  ]);

  const showToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync PIN to local secure storage with salted cryptographic hashing
  useEffect(() => {
    if (userPin) {
      P2PCryptoEngine.hashSecurityPin(userPin).then((hashed) => {
        localStorage.setItem('splender_pin_hash', hashed);
        localStorage.removeItem('splender_pin'); // Eliminate any plaintext PIN
      });
    } else {
      localStorage.removeItem('splender_pin_hash');
      localStorage.removeItem('splender_pin');
    }
  }, [userPin]);

  // ==========================================
  // MODULE 2: AUTH & ANONYMOUS ONBOARDING ENGINE
  // ==========================================
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        await initOrLoadUserProfile(user);
        setFirebaseUser(user);
        setAuthError(null);
        setAuthRestrictedInfo(null);
        setIsLoadingAuth(false);
      } else {
        setFirebaseUser(null);
        setCurrentUserProfile(null);
        setIsLoadingAuth(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const initOrLoadUserProfile = async (user: FirebaseUser, chosenUsername?: string) => {
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userDocRef);

      if (userSnap.exists()) {
        const rawData = userSnap.data() as Record<string, any>;
        let privateEmail: string | undefined;
        try {
          const privSnap = await getDoc(doc(db, 'users', user.uid, 'private', 'account'));
          if (privSnap.exists() && typeof privSnap.data()?.email === 'string') {
            privateEmail = privSnap.data().email;
          }
        } catch {
          // Non-blocking private subcollection lookup
        }

        const legacyEmail = typeof rawData.email === 'string' ? rawData.email : undefined;
        const effectiveEmail = privateEmail || legacyEmail || user.email || undefined;
        const { email: _omittedEmail, phone: _omittedPhone, ...publicFields } = rawData;

        setCurrentUserProfile({
          ...(publicFields as UserProfile),
          uid: user.uid,
          email: effectiveEmail,
        });

        // Provision RSA-OAEP-2048 identity & sync public encryption key via offline-first SyncService
        void CryptoService.getOrCreateRsaIdentity()
          .then((rsaBundle) =>
            SyncService.syncEncryptionPublicKey(
              user.uid,
              rsaBundle.publicKeySpkiBase64,
              rsaBundle.fingerprintHex
            )
          )
          .catch(() => {});
        void user
          .getIdToken()
          .then((jwt) => CryptoService.storeSecureToken(`session_${user.uid}`, jwt))
          .catch(() => {});

        // Persist PII in owner-isolated subcollection and migrate legacy public PII fields off /users/{uid}
        if (effectiveEmail) {
          void setDoc(
            doc(db, 'users', user.uid, 'private', 'account'),
            sanitizeForFirestore({ email: effectiveEmail, updatedAt: Date.now() }),
            { merge: true }
          ).catch(() => {});
        }

        try {
          const presencePatch: Record<string, any> = {
            uid: user.uid,
            lastSeen: Date.now(),
            isOnline: true,
            status: 'online',
            updatedAt: Date.now(),
          };
          if ('email' in rawData) {
            presencePatch.email = deleteField();
          }
          if ('phone' in rawData) {
            presencePatch.phone = deleteField();
          }
          await updateDoc(userDocRef, presencePatch);
        } catch (syncErr) {
          console.debug('Profile presence & legacy PII migration notice:', syncErr);
        }
      } else {
        // First-launch initialization: generate safe Splender ID & unique username
        const generatedId = generateSplenderId();
        let baseUsername = chosenUsername?.trim()
          ? normalizeUsername(chosenUsername)
          : user.displayName
          ? normalizeUsername(user.displayName) + '_' + generatedId.slice(-3).toLowerCase()
          : 'peer_' + generatedId.replace('SP-', '').toLowerCase();
        let normalized = normalizeUsername(baseUsername);

        const displayNameVal = (user.displayName || 'Splender Peer ' + generatedId.slice(-3)).slice(0, 120);
        const avatarVal = user.photoURL || createDeterministicAvatarDataUri(displayNameVal, '#0F766E');

        const buildPublicProfile = (uname: string, normUname: string): UserProfile => ({
          uid: user.uid,
          splenderId: generatedId,
          username: uname,
          normalizedUsername: normUname,
          displayName: displayNameVal,
          avatar: avatarVal,
          bio: 'Decentralized peer node on E2EE WebRTC transport',
          isAnonymous: user.isAnonymous,
          isOnline: true,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          lastSeen: Date.now(),
          status: 'online',
          dataSaver: false,
          readReceipts: true,
          lastSeenPrivacy: 'contacts',
          linkedProviders: user.providerData?.map((p) => p.providerId) || [],
        });

        let finalProfile = buildPublicProfile(baseUsername, normalized);

        // Public directory profile strictly excludes PII (email/phone)
        try {
          await runTransaction(db, async (tx) => {
            let candidateNorm = normalized;
            let uIndexRef = doc(db, 'usernames', candidateNorm);
            const existingUsernameSnap = await tx.get(uIndexRef);
            if (existingUsernameSnap.exists() && existingUsernameSnap.data()?.uid !== user.uid) {
              baseUsername = `${candidateNorm.slice(0, 48)}_${generatedId.slice(-4).toLowerCase()}`;
              candidateNorm = normalizeUsername(baseUsername);
              uIndexRef = doc(db, 'usernames', candidateNorm);
              finalProfile = buildPublicProfile(baseUsername, candidateNorm);
            }
            const sIndexRef = doc(db, 'splenderIds', generatedId);

            tx.set(uIndexRef, { uid: user.uid, splenderId: generatedId, createdAt: Date.now() });
            tx.set(sIndexRef, { uid: user.uid, username: baseUsername, createdAt: Date.now() });
            tx.set(userDocRef, sanitizeForFirestore(finalProfile));
          });
          if (user.email) {
            await setDoc(
              doc(db, 'users', user.uid, 'private', 'account'),
              sanitizeForFirestore({ email: user.email, updatedAt: Date.now() }),
              { merge: true }
            ).catch(() => {});
          }
        } catch (txErr) {
          console.warn('Transaction fallback to direct user document write:', txErr);
          await setDoc(userDocRef, sanitizeForFirestore(finalProfile)).catch((e) =>
            console.warn('setDoc fallback notice:', e)
          );
        }

        setCurrentUserProfile({ ...finalProfile, email: user.email || undefined });
        void CryptoService.getOrCreateRsaIdentity()
          .then((rsaBundle) =>
            SyncService.syncEncryptionPublicKey(
              user.uid,
              rsaBundle.publicKeySpkiBase64,
              rsaBundle.fingerprintHex
            )
          )
          .catch(() => {});
        void user
          .getIdToken()
          .then((jwt) => CryptoService.storeSecureToken(`session_${user.uid}`, jwt))
          .catch(() => {});
        showToast('Sovereign Account Initialized', `Assigned ${generatedId}`, 'success');
      }
    } catch (err: any) {
      console.warn('Profile initialization fallback to local sovereign state:', err);
      const generatedId = generateSplenderId();
      const baseUsername = user.displayName
        ? normalizeUsername(user.displayName) + '_' + generatedId.slice(-3).toLowerCase()
        : 'peer_' + generatedId.replace('SP-', '').toLowerCase();
      const displayNameVal = (user.displayName || 'Splender Peer ' + generatedId.slice(-3)).slice(0, 120);
      const fallbackProfile: UserProfile = {
        uid: user.uid,
        splenderId: generatedId,
        username: baseUsername,
        normalizedUsername: normalizeUsername(baseUsername),
        displayName: displayNameVal,
        avatar: user.photoURL || createDeterministicAvatarDataUri(displayNameVal, '#0F766E'),
        bio: 'Decentralized peer node on E2EE WebRTC transport',
        isAnonymous: user.isAnonymous,
        isOnline: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        lastSeen: Date.now(),
        status: 'online',
        dataSaver: false,
        readReceipts: true,
        lastSeenPrivacy: 'contacts',
        linkedProviders: user.providerData?.map((p) => p.providerId) || [],
        email: user.email || undefined,
      };
      setCurrentUserProfile((prev) => prev || fallbackProfile);
    }
  };

  const signInWithGoogle = async (): Promise<boolean> => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      const provider = new GoogleAuthProvider();
      const res = await signInWithPopup(auth, provider);
      if (res.user) {
        await initOrLoadUserProfile(res.user);
        setFirebaseUser(res.user);
        setAuthError(null);
        setAuthRestrictedInfo(null);
        showToast('Connected with Google', `Splender ID synchronized`, 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Google sign-in error:', err);
      setAuthError(err.message);
      showToast('Google Sign-In Notice', err.message, 'error');
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string): Promise<boolean> => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await initOrLoadUserProfile(res.user);
        setFirebaseUser(res.user);
        setAuthError(null);
        setAuthRestrictedInfo(null);
        showToast('Signed In', 'Welcome back to Splender', 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Email sign in error:', err);
      setAuthError(err.message);
      showToast('Sign-In Error', err.message, 'error');
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const signUpWithEmail = async (email: string, pass: string, chosenUsername?: string): Promise<boolean> => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await initOrLoadUserProfile(res.user, chosenUsername);
        setFirebaseUser(res.user);
        setAuthError(null);
        setAuthRestrictedInfo(null);
        showToast('Account Created', 'Splender identity registered', 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Email sign up error:', err);
      setAuthError(err.message);
      showToast('Registration Error', err.message, 'error');
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const tryAnonymousAuth = async (): Promise<boolean> => {
    setIsLoadingAuth(true);
    try {
      const cred = await signInAnonymously(auth);
      await initOrLoadUserProfile(cred.user);
      setFirebaseUser(cred.user);
      setAuthError(null);
      setAuthRestrictedInfo(null);
      showToast('Anonymous Node Online', 'Connected as guest peer', 'success');
      return true;
    } catch (err: any) {
      console.warn('Anonymous auth failed:', err.code, err.message);
      const isRestricted =
        err.code === 'auth/admin-restricted-operation' ||
        err.code === 'auth/operation-not-allowed';
      setAuthError(err.message);
      setAuthRestrictedInfo({
        isRestricted,
        reason: isRestricted
          ? 'Anonymous sign-in provider is disabled in Firebase Console.'
          : err.message,
      });
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const signOutUser = async () => {
    try {
      ConnectionManager.teardownAll();
      await CryptoService.clearAllTokens().catch(() => {});
      await signOut(auth);
      setFirebaseUser(null);
      setCurrentUserProfile(null);
      setConversations([]);
      setMessages([]);
      setContacts([]);
      setMoments([]);
      setActiveConversationId(null);
      showToast('Signed Out', 'Local session terminated', 'info');
    } catch (err: any) {
      console.error('Sign out error:', err);
      showToast('Sign Out Error', err.message, 'error');
    }
  };

  const deleteAccountAndWipeData = async (): Promise<boolean> => {
    if (!firebaseUser || !currentUserProfile) return false;
    try {
      try {
        await deleteDoc(doc(db, 'users', firebaseUser.uid));
      } catch (e) {
        console.warn('Could not delete user doc directly:', e);
      }
      try {
        if (currentUserProfile.normalizedUsername) {
          await deleteDoc(doc(db, 'usernames', currentUserProfile.normalizedUsername));
        }
      } catch (e) {
        console.warn('Could not delete username index:', e);
      }
      if (typeof window !== 'undefined') {
        localStorage.clear();
      }
      try {
        await firebaseUser.delete();
      } catch (e) {
        await signOut(auth);
      }
      setFirebaseUser(null);
      setCurrentUserProfile(null);
      setConversations([]);
      setMessages([]);
      setContacts([]);
      setMoments([]);
      setActiveConversationId(null);
      showToast('Account Deleted', 'All user data and sovereign credentials wiped.', 'info');
      return true;
    } catch (err: any) {
      console.error('Delete account error:', err);
      showToast('Deletion Failed', err.message, 'error');
      return false;
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!currentUserProfile || !firebaseUser) return;
    try {
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const { email: updatedEmail, ...publicUpdates } = updates;
      const updated = {
        ...currentUserProfile,
        ...updates,
        updatedAt: Date.now(),
      };

      // Check if username was updated and handle collision-safe index update
      if (publicUpdates.username && publicUpdates.username !== currentUserProfile.username) {
        const newNorm = normalizeUsername(publicUpdates.username);
        const oldNorm = currentUserProfile.normalizedUsername;

        await runTransaction(db, async (tx) => {
          const newIndexRef = doc(db, 'usernames', newNorm);
          const newSnap = await tx.get(newIndexRef);
          if (newSnap.exists() && newSnap.data()?.uid !== firebaseUser.uid) {
            throw new Error(`Username @${publicUpdates.username} is already taken.`);
          }

          if (oldNorm && oldNorm !== newNorm) {
            tx.delete(doc(db, 'usernames', oldNorm));
          }
          tx.set(newIndexRef, { uid: firebaseUser.uid, splenderId: currentUserProfile.splenderId, createdAt: Date.now() });
          tx.update(doc(db, 'splenderIds', currentUserProfile.splenderId), { username: publicUpdates.username });
          tx.update(userDocRef, sanitizeForFirestore({ ...publicUpdates, normalizedUsername: newNorm, updatedAt: Date.now() }));
        });
      } else {
        const syncRes = await SyncService.syncProfileUpdate(firebaseUser.uid, publicUpdates);
        if (syncRes.status === 'queued') {
          setCurrentUserProfile(updated);
          showToast('Offline Profile Queue', 'Profile changes queued locally and will sync when online', 'info');
          return;
        }
      }

      if (updatedEmail) {
        await setDoc(
          doc(db, 'users', firebaseUser.uid, 'private', 'account'),
          sanitizeForFirestore({ email: updatedEmail, updatedAt: Date.now() }),
          { merge: true }
        ).catch(() => {});
      }

      setCurrentUserProfile(updated);
      showToast('Profile Updated', 'Saved changes to Firestore profile', 'success');
    } catch (err: any) {
      console.error('Error updating profile:', err);
      showToast('Update Failed', err.message, 'error');
    }
  };

  // Provider Linking (maintains exact same UID, Splender ID, chats, and contacts)
  const linkGoogleAccount = async (): Promise<boolean> => {
    if (!auth.currentUser) return false;
    try {
      const provider = new GoogleAuthProvider();
      const res = await linkWithPopup(auth.currentUser, provider);
      if (res.user) {
        await updateDoc(doc(db, 'users', res.user.uid), {
          isAnonymous: false,
          linkedProviders: res.user.providerData.map((p) => p.providerId),
        });
        if (res.user.email) {
          await setDoc(
            doc(db, 'users', res.user.uid, 'private', 'account'),
            sanitizeForFirestore({ email: res.user.email, updatedAt: Date.now() })
          ).catch(() => {});
        }
        setCurrentUserProfile((prev) => prev ? {
          ...prev,
          isAnonymous: false,
          linkedProviders: res.user.providerData.map((p) => p.providerId),
          email: res.user.email || undefined,
        } : null);
        showToast('Google Linked', 'Your account is now safely backed up', 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Google link error:', err);
      if (err.code === 'auth/credential-already-in-use') {
        showToast('Account Collision', 'This Google account is already linked to another user.', 'warning');
      } else {
        showToast('Linking Error', err.message, 'error');
      }
      return false;
    }
  };

  const linkEmailAccount = async (email: string, pass: string): Promise<boolean> => {
    if (!auth.currentUser) return false;
    try {
      const credential = EmailAuthProvider.credential(email, pass);
      const res = await linkWithCredential(auth.currentUser, credential);
      if (res.user) {
        await updateDoc(doc(db, 'users', res.user.uid), {
          isAnonymous: false,
          linkedProviders: res.user.providerData.map((p) => p.providerId),
        });
        await setDoc(
          doc(db, 'users', res.user.uid, 'private', 'account'),
          sanitizeForFirestore({ email, updatedAt: Date.now() })
        ).catch(() => {});
        setCurrentUserProfile((prev) => prev ? {
          ...prev,
          isAnonymous: false,
          linkedProviders: res.user.providerData.map((p) => p.providerId),
          email,
        } : null);
        showToast('Email & Password Linked', 'Permanent credentials attached', 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Email link error:', err);
      if (err.code === 'auth/credential-already-in-use') {
        showToast('Account Collision', 'This email is already linked to another Splender account.', 'warning');
      } else {
        showToast('Linking Error', err.message, 'error');
      }
      return false;
    }
  };

  // Register direct WebRTC DataChannel incoming message & file transfer listeners
  useEffect(() => {
    const engine = SplenderWebRtcEngine.getInstance();
    engine.registerCallbacks(
      (peerUid, payload) => {
        if (payload.type === 'direct_chat' && payload.data) {
          const incomingMsg = {
            ...payload.data,
            transportMode: 'webrtc_p2p' as const,
          } as Message;
          AudioAlerts.playMessageReceivedChime();
          setMessages((prev) => {
            if (prev.some((m) => m.id === incomingMsg.id || (m.idempotencyKey && m.idempotencyKey === incomingMsg.idempotencyKey))) {
              return prev;
            }
            return [...prev, incomingMsg];
          });
          setConversations((prev) =>
            prev.map((c) =>
              c.id === incomingMsg.conversationId
                ? {
                    ...c,
                    updatedAt: incomingMsg.timestamp,
                    lastMessage: {
                      id: incomingMsg.id,
                      text: incomingMsg.text || 'Direct P2P message',
                      senderUid: incomingMsg.senderUid,
                      type: incomingMsg.type,
                      timestamp: incomingMsg.timestamp,
                      status: 'delivered',
                    },
                  }
                : c
            )
          );
        } else if (payload.type === 'file_ack' && payload.data) {
          const { fileName, fileSize, mimeType, fileSha256, speedKbps, blob } = payload.data;
          const objectUrl = blob ? URL.createObjectURL(blob) : undefined;
          const conv = conversations.find((c) => !c.isGroup && c.participants.includes(peerUid));
          const targetId = conv?.id || activeConversationId || `p2p_${peerUid}`;
          const fileMsg: Message = {
            id: payload.transferId || `file_${Date.now()}`,
            conversationId: targetId,
            senderUid: peerUid,
            senderId: peerUid,
            senderSplenderId: conv?.participantSplenderIds?.[peerUid] || 'SP-PEER',
            senderName: conv?.participantNames?.[peerUid] || 'Peer',
            text: `P2P Verified File: ${fileName} (SHA-256: ${String(fileSha256).slice(0, 12)}…)`,
            type: mimeType?.startsWith('image/') ? 'image' : mimeType?.startsWith('video/') ? 'video' : 'document',
            mediaUrl: objectUrl,
            fileName,
            fileSize: `${(Number(fileSize || 0) / 1024).toFixed(1)} KB`,
            timestamp: payload.timestamp || Date.now(),
            status: 'delivered',
            isEncrypted: true,
            transportMode: 'webrtc_p2p',
            fileTransferPayload: {
              fileName,
              fileSize,
              chunksTotal: Math.max(1, Math.ceil(Number(fileSize || 1) / (64 * 1024))),
              chunksTransferred: Math.max(1, Math.ceil(Number(fileSize || 1) / (64 * 1024))),
              status: 'completed',
              hash: fileSha256,
              speedKbps,
              transport: 'webrtc_datachannel',
            },
          };
          AudioAlerts.playMessageReceivedChime();
          setMessages((prev) => (prev.some((m) => m.id === fileMsg.id) ? prev : [...prev, fileMsg]));
        }
      },
      (peerUid, state) => {
        const activeConv = conversations.find((c) => c.id === activeConversationId);
        const activePeer = activeConv?.participants.find((p) => p !== firebaseUser?.uid);
        if (!activePeer || activePeer === peerUid) {
          setP2pChannelState(state);
        }
      }
    );
  }, [activeConversationId, conversations, firebaseUser?.uid]);

  // Automatically negotiate direct WebRTC P2P DataChannel when opening a 1:1 conversation
  useEffect(() => {
    if (!activeConversationId || !firebaseUser) {
      setP2pChannelState('disconnected');
      return;
    }
    const conv = conversations.find((c) => c.id === activeConversationId);
    if (!conv || conv.isGroup) {
      setP2pChannelState('disconnected');
      return;
    }
    const peerUid = conv.participants.find((p) => p !== firebaseUser.uid);
    if (!peerUid || peerUid.startsWith('peer_demo_') || peerUid === 'splender_ai_bot') {
      setP2pChannelState('disconnected');
      return;
    }
    const engine = SplenderWebRtcEngine.getInstance();
    setP2pChannelState(engine.getChannelState(peerUid));
    void engine.connectPeerSession(firebaseUser.uid, peerUid);
  }, [activeConversationId, conversations, firebaseUser]);

  useEffect(() => {
    if (!firebaseUser) {
      setConversations([]);
      return;
    }

    const convQuery = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', firebaseUser.uid),
      orderBy('updatedAt', 'desc'),
      limit(40)
    );

    const unsubscribe = onSnapshot(
      convQuery,
      async (snapshot) => {
        const rawConvs: Conversation[] = [];
        snapshot.forEach((d) => {
          rawConvs.push({ id: d.id, ...d.data() } as Conversation);
        });

        const decryptedList = await Promise.all(
          rawConvs.map(async (conv) => {
            if (conv.lastMessage?.encryptedEnvelope) {
              try {
                const plainSummary = await CryptoService.unsealConversationPayload(
                  conv.id,
                  conv.participants,
                  conv.lastMessage.encryptedEnvelope
                );
                return {
                  ...conv,
                  lastMessage: {
                    ...conv.lastMessage,
                    text: plainSummary,
                  },
                };
              } catch {
                return conv;
              }
            }
            return conv;
          })
        );

        if (!isConvInitialLoadRef.current && firebaseUser) {
          decryptedList.forEach((conv) => {
            const lastMsg = conv.lastMessage;
            if (lastMsg && lastMsg.senderUid !== firebaseUser.uid) {
              const prevTime = lastNotifiedConvMessageTimeRef.current[conv.id] || 0;
              const msgTime = conv.updatedAt || lastMsg.timestamp || 0;
              if (msgTime > prevTime && Date.now() - msgTime < 60000) {
                lastNotifiedConvMessageTimeRef.current[conv.id] = msgTime;
                const senderName = conv.participantNames?.[lastMsg.senderUid] || conv.groupName || 'Peer';
                const avatar = conv.participantAvatars?.[lastMsg.senderUid] || conv.groupAvatar;
                notifyIncomingChat(senderName, lastMsg.text, avatar, conv.id, lastMsg.senderUid);
              }
            }
          });
        } else {
          decryptedList.forEach((conv) => {
            const msgTime = conv.updatedAt || conv.lastMessage?.timestamp || Date.now();
            lastNotifiedConvMessageTimeRef.current[conv.id] = msgTime;
          });
          isConvInitialLoadRef.current = false;
        }

        setConversations(decryptedList);
      },
      (error) => {
        console.debug('Conversations subscription notice:', error);
      }
    );

    return () => unsubscribe();
  }, [firebaseUser]);

  // Subscribe to messages in active conversation and decrypt E2EE envelopes client-side
  useEffect(() => {
    if (
      !activeConversationId ||
      !firebaseUser ||
      activeConversationId === 'conv_demo_starter' ||
      activeConversationId === 'splender_ai_assistant' ||
      activeConversationId.startsWith('p2p_')
    ) {
      setMessages([]);
      return;
    }

    const activeParticipants = conversations.find((c) => c.id === activeConversationId)?.participants;

    const unsubscribe = ConnectionManager.subscribeToRoomMessages(
      activeConversationId,
      async (rawDocs) => {
        const resolved = await Promise.all(
          rawDocs.map(async (msg) => {
            let updated: Message = { ...msg };
            if (msg.encryptedEnvelope && !msg.isDeleted) {
              try {
                const plainJson = await CryptoService.unsealConversationPayload(
                  activeConversationId,
                  activeParticipants,
                  msg.encryptedEnvelope
                );
                try {
                  const parsed = JSON.parse(plainJson);
                  if (parsed && typeof parsed === 'object') {
                    updated = {
                      ...updated,
                      text: typeof parsed.text === 'string' ? parsed.text : updated.text,
                      replyTo: parsed.replyTo ?? updated.replyTo,
                      location: parsed.location ?? updated.location,
                      contactPayload: parsed.contactPayload ?? updated.contactPayload,
                      pollPayload: parsed.pollPayload ?? updated.pollPayload,
                      fileName: parsed.fileName ?? updated.fileName,
                      mediaUrl: parsed.mediaUrl ?? updated.mediaUrl,
                      thumbnailUrl: parsed.thumbnailUrl ?? updated.thumbnailUrl,
                      mediaEncryption: parsed.mediaEncryption ?? updated.mediaEncryption,
                    };
                  }
                } catch {
                  updated = { ...updated, text: plainJson };
                }
              } catch {
                // Key mismatch or unrecoverable envelope leaves sealed placeholder intact
              }
            }
            if (
              updated.mediaUrl &&
              (updated.mediaUrl.includes('#splender_e2ee_cek=') ||
                updated.mediaUrl.includes('#splender_e2ee_mime='))
            ) {
              updated.mediaUrl = await decryptAttachmentFromStorageUrl(updated.mediaUrl, activeConversationId);
            } else if (
              updated.mediaUrl &&
              updated.mediaEncryption?.cekBase64 &&
              updated.mediaUrl.startsWith('http')
            ) {
              try {
                const resp = await fetch(updated.mediaUrl.split('#')[0]);
                if (resp.ok) {
                  const cipherBuf = await resp.arrayBuffer();
                  const decryptedBlob = await P2PCryptoEngine.decryptBinaryBlob(
                    cipherBuf,
                    updated.mediaEncryption
                  );
                  updated.mediaUrl = URL.createObjectURL(decryptedBlob);
                }
              } catch {
                // Keep URL intact if offline
              }
            }
            return updated;
          })
        );

        setMessages(resolved);
        ConnectionManager.markConversationReadCoalesced(activeConversationId, firebaseUser.uid);
        markMessagesRead(activeConversationId);
      },
      40
    );

    return () => unsubscribe();
  }, [activeConversationId, firebaseUser, conversations.length]);

  // Subscribe to Contacts
  useEffect(() => {
    if (!firebaseUser) {
      setContacts([]);
      return;
    }

    const contactsQuery = query(
      collection(db, 'contacts', firebaseUser.uid, 'items'),
      orderBy('updatedAt', 'desc'),
      limit(50)
    );

    const unsubscribe = onSnapshot(contactsQuery, (snapshot) => {
      const list: ContactItem[] = [];
      snapshot.forEach((d) => {
        list.push({ targetUid: d.id, ...d.data() } as ContactItem);
      });
      setContacts(list);
    }, (error) => {
      console.debug('Contacts subscription notice:', error);
    });

    return () => unsubscribe();
  }, [firebaseUser]);

  // Subscribe to Moments (24h TTL filter)
  useEffect(() => {
    if (!firebaseUser) {
      setMoments([]);
      return;
    }
    const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000;
    const momentsQuery = query(
      collection(db, 'moments'),
      where('createdAt', '>=', oneDayAgo),
      orderBy('createdAt', 'desc'),
      limit(25)
    );

    const unsubscribe = onSnapshot(momentsQuery, (snapshot) => {
      const list: Moment[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as Moment);
      });

      if (!isMomentsInitialLoadRef.current && firebaseUser) {
        list.forEach((mom) => {
          if (mom.ownerUid && mom.ownerUid !== firebaseUser.uid && mom.createdAt > lastStoryTimeRef.current) {
            notifyNewStory(mom.ownerName || 'Peer', mom.caption || 'New 24h story moment');
          }
        });
      } else {
        isMomentsInitialLoadRef.current = false;
      }
      if (list.length > 0) {
        lastStoryTimeRef.current = Math.max(...list.map((m) => m.createdAt), lastStoryTimeRef.current);
      }

      setMoments(list);
    }, (error) => {
      if (isPermissionDeniedError(error)) {
        handleFirestoreError(error, OperationType.LIST, 'moments');
      }
      console.debug('Moments subscription notice:', error);
    });

    return () => unsubscribe();
  }, [firebaseUser]);

  // Multi-Device Real-Time Session Sync & Sealed Offline Queue Auto-Flush
  useEffect(() => {
    if (!firebaseUser) return;

    const unsubSession = MultiDeviceSync.syncActiveSession(firebaseUser.uid, (session) => {
      if (session.unreadCounts) {
        console.debug('Multi-device session updated:', session);
      }
    });

    const detachSyncEngine = SyncService.startAutoResumeListener((flushedCount) => {
      showToast(
        'Offline Sync Flushed',
        `Synchronized ${flushedCount} queued encrypted item${flushedCount > 1 ? 's' : ''}`,
        'success'
      );
    });

    const handleOnlineFlush = async () => {
      const [legacyFlushed] = await Promise.all([
        OfflineQueueManager.flushQueue(async (payload) => {
          const msgColl = collection(db, 'conversations', payload.conversationId, 'messages');
          await addDoc(msgColl, sanitizeForFirestore(payload));
          OfflineOutboxManager.remove(payload.idempotencyKey || payload.id);
        }),
        SyncService.flushQueue(true),
      ]);
      if (legacyFlushed > 0) {
        showToast('Connection Restored', `${legacyFlushed} encrypted message${legacyFlushed > 1 ? 's' : ''} delivered`, 'success');
      }
    };

    window.addEventListener('online', handleOnlineFlush);
    return () => {
      unsubSession();
      detachSyncEngine();
      window.removeEventListener('online', handleOnlineFlush);
    };
  }, [firebaseUser]);

  // Send Message: Direct WebRTC DataChannel first, Zero-Plaintext E2EE Envelope fallback
  const sendMessage = async (
    text: string,
    type: Message['type'] = 'text',
    mediaUrl?: string,
    audioDuration?: number,
    replyTo?: { id: string; senderName: string; text: string },
    mediaQualityOverride?: MediaQuality,
    thumbnailUrl?: string,
    extraPayload?: Partial<Message>
  ) => {
    const targetConvId = extraPayload?.conversationId || activeConversationId;
    if (!targetConvId || !currentUserProfile || !firebaseUser) return;

    const targetConv = conversations.find((c) => c.id === targetConvId);
    const disappearingSecs = targetConv?.disappearingTimerSeconds || 0;
    const computedExpiresAt = extraPayload?.expiresAt || (disappearingSecs > 0 ? Date.now() + disappearingSecs * 1000 : undefined);

    const chosenQuality =
      mediaQualityOverride ||
      (type !== 'text' ? (currentUserProfile.mediaQuality || mediaQuality || 'high') : undefined);

    const idempotencyKey = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const plainMsg: Omit<Message, 'id'> = {
      conversationId: targetConvId,
      senderUid: firebaseUser.uid,
      senderId: firebaseUser.uid,
      senderSplenderId: currentUserProfile.splenderId,
      senderName: currentUserProfile.displayName,
      text: text.trim(),
      type,
      mediaUrl,
      mediaQuality: chosenQuality,
      thumbnailUrl,
      audioDuration,
      timestamp: Date.now(),
      status: 'sent',
      idempotencyKey,
      replyTo,
      isDeleted: false,
      isEdited: false,
      isEncrypted: true,
      encryptionProtocol: 'DOUBLE_RATCHET_V3',
      isViewOnce: Boolean(extraPayload?.isViewOnce),
      isViewed: Boolean(extraPayload?.isViewed),
      viewOnceOpened: Boolean(extraPayload?.viewOnceOpened || extraPayload?.isViewed),
      expiresAt: computedExpiresAt,
      ...extraPayload,
    };

    // 1. Direct P2P WebRTC DataChannel delivery when peer is connected (bypasses Firebase completely)
    const recipientUid = !targetConv?.isGroup
      ? targetConv?.participants.find((p) => p !== firebaseUser.uid)
      : undefined;
    if (recipientUid && SplenderWebRtcEngine.getInstance().isChannelOpen(recipientUid)) {
      const p2pPayload = {
        ...plainMsg,
        id: idempotencyKey,
        status: 'delivered' as const,
        transportMode: 'webrtc_p2p' as const,
      };
      const p2pSent = SplenderWebRtcEngine.getInstance().sendPayload(recipientUid, {
        type: 'direct_chat',
        senderUid: firebaseUser.uid,
        recipientUid,
        timestamp: Date.now(),
        data: p2pPayload,
      });
      if (p2pSent) {
        AudioAlerts.playMessageSentChime();
        setMessages((prev) => [...prev, p2pPayload as Message]);
        return;
      }
    }

    // 2. Local demo starter thread (in-memory only)
    if (targetConvId === 'conv_demo_starter') {
      AudioAlerts.playMessageSentChime();
      setMessages((prev) => [...prev, { ...plainMsg, id: idempotencyKey, status: 'delivered' } as Message]);
      return;
    }

    // 3. Build Zero-Plaintext Hybrid E2EE Envelope (RSA-OAEP-2048 + Double-Ratchet AES-GCM-256 + HMAC-SHA256)
    const canSealMediaInline = !plainMsg.mediaUrl || plainMsg.mediaUrl.length <= 160_000;
    const canSealThumbInline = !plainMsg.thumbnailUrl || plainMsg.thumbnailUrl.length <= 32_000;
    const secretPayloadObj: Record<string, unknown> = {
      text: plainMsg.text || '',
      replyTo: plainMsg.replyTo,
      location: plainMsg.location,
      contactPayload: plainMsg.contactPayload,
      pollPayload: plainMsg.pollPayload,
      fileName: plainMsg.fileName,
      mediaUrl: canSealMediaInline ? plainMsg.mediaUrl : undefined,
      thumbnailUrl: canSealThumbInline ? plainMsg.thumbnailUrl : undefined,
      mediaEncryption: plainMsg.mediaEncryption,
    };
    const { envelope: encryptedEnvelope } = await CryptoService.sealConversationPayload(
      targetConvId,
      targetConv?.participants,
      secretPayloadObj
    );

    const summaryPlaintext = extraPayload?.isViewOnce
      ? extraPayload?.isViewed || extraPayload?.viewOnceOpened
        ? 'Opened view-once media'
        : type === 'video'
        ? 'View once video'
        : 'View once photo'
      : type === 'audio'
      ? `Voice note (${audioDuration || 12}s)`
      : type === 'image'
      ? 'Encrypted photo'
      : type === 'document'
      ? `Encrypted file: ${extraPayload?.fileName || 'Document'}`
      : type === 'location'
      ? 'Encrypted location'
      : type === 'poll'
      ? `Poll: ${extraPayload?.pollPayload?.question || 'Poll'}`
      : type === 'contact'
      ? 'Encrypted contact card'
      : text.trim();

    const { envelope: summaryEnvelope } = await CryptoService.sealConversationPayload(
      targetConvId,
      targetConv?.participants,
      summaryPlaintext
    );

    const firestoreSealedMsg: Omit<Message, 'id'> = {
      ...plainMsg,
      // Zero plaintext message text, CEKs, or attachment URLs stored in Firestore control plane
      text: type === 'system' ? plainMsg.text : '[Encrypted]',
      replyTo: undefined,
      location: undefined,
      contactPayload: undefined,
      fileName: type === 'system' ? plainMsg.fileName : undefined,
      mediaUrl: type === 'system' || !canSealMediaInline ? plainMsg.mediaUrl : undefined,
      thumbnailUrl: type === 'system' || !canSealThumbInline ? plainMsg.thumbnailUrl : undefined,
      mediaEncryption: undefined,
      encryptedEnvelope: type === 'system' ? undefined : encryptedEnvelope,
      transportMode: 'e2ee_relay',
    };

    const conversationSummaryPatch = {
      updatedAt: Date.now(),
      lastMessage: {
        id: idempotencyKey,
        text: type === 'system' ? summaryPlaintext : '[Encrypted]',
        encryptedEnvelope: type === 'system' ? undefined : summaryEnvelope,
        senderUid: firebaseUser.uid,
        senderId: firebaseUser.uid,
        type,
        timestamp: Date.now(),
        status: 'sent',
        isViewOnce: Boolean(extraPayload?.isViewOnce),
        isViewed: Boolean(extraPayload?.isViewed),
        viewOnceOpened: Boolean(extraPayload?.viewOnceOpened || extraPayload?.isViewed),
      },
    };

    void HapticsService.messageSent();

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      await SyncService.syncOutgoingMessage({
        idempotencyKey,
        conversationId: targetConvId,
        senderUid: firebaseUser.uid,
        sealedMessagePayload: firestoreSealedMsg as Record<string, unknown>,
        conversationSummaryPatch,
      });
      OfflineOutboxManager.enqueue({
        id: idempotencyKey,
        targetConversationId: targetConvId,
        senderUid: firebaseUser.uid,
        payload: firestoreSealedMsg,
        timestamp: Date.now(),
        retryAttempts: 0,
      });
      setMessages((prev) => [...prev, { ...plainMsg, id: idempotencyKey, status: 'sending' } as Message]);
      showToast('Offline Outbox', 'Queued in IndexedDB transactional sync vault until online', 'info');
      return;
    }

    // Optimistic local plaintext append for 0ms latency
    setMessages((prev) => [...prev, { ...plainMsg, id: idempotencyKey } as Message]);

    try {
      const syncResult = await SyncService.syncOutgoingMessage({
        idempotencyKey,
        conversationId: targetConvId,
        senderUid: firebaseUser.uid,
        sealedMessagePayload: firestoreSealedMsg as Record<string, unknown>,
        conversationSummaryPatch,
      });
      AudioAlerts.playMessageSentChime();

      if (syncResult.status === 'queued') {
        showToast('Sync Deferred', 'Message queued safely in offline IndexedDB vault', 'info');
      }

      trackEvent('chat_message_sent', { type, isReply: !!replyTo }, 'engagement');

      if (targetConvId === 'splender_ai_assistant') {
        setTimeout(async () => {
          try {
            const analysis = await divyaDrishtiAi.analyzeMessageContext(text);
            const lower = text.toLowerCase();
            let aiText = '';

            if (lower.includes('summarize') || lower.includes('summary')) {
              aiText = `Smart Summary:\n"${analysis.summary}"\n• Intent: ${analysis.intent}\n• Suggested Action: ${analysis.suggestedAction || 'All systems aligned.'}`;
            } else if (lower.includes('translate') && (lower.includes('to') || lower.includes('in'))) {
              const targetLang = lower.includes('hindi') ? 'hi' : lower.includes('spanish') ? 'es' : lower.includes('french') ? 'fr' : lower.includes('german') ? 'de' : lower.includes('sanskrit') ? 'sa' : 'hi';
              const cleanText = text.replace(/translate/i, '').replace(/to (hindi|spanish|french|german|sanskrit)/i, '').trim();
              const tr = await divyaDrishtiAi.translateText(cleanText || text, targetLang);
              aiText = `Translation (${tr.targetLanguage}):\n${tr.translatedText}`;
            } else {
              const replies = await divyaDrishtiAi.generateSmartReplies(text);
              aiText = `Context: ${analysis.intent} (${analysis.sentiment})\n\nSuggested replies:\n1. ${replies[0] || 'Understood'}\n2. ${replies[1] || 'Sounds great'}\n3. ${replies[2] || 'Will follow up soon'}`;
            }

            const botMsg: Omit<Message, 'id'> = {
              conversationId: 'splender_ai_assistant',
              senderUid: 'splender_ai_bot',
              senderId: 'splender_ai_bot',
              senderSplenderId: 'AI-001',
              senderName: 'Splender Assistant',
              senderAvatar: createDeterministicAvatarDataUri('SA', '#0D9488'),
              text: aiText,
              type: 'text',
              timestamp: Date.now(),
              status: 'sent',
              isDeleted: false,
              isEdited: false,
            };

            const generatedId = 'bot_' + Date.now();
            setMessages((prev) => [...prev, { ...botMsg, id: generatedId }]);
            playCallConnectSound();
          } catch (botErr) {
            console.debug('Assistant response error:', botErr);
          }
        }, 650);
      }
    } catch (err: any) {
      console.error('Error sending message:', err);
      showToast('Send Failed', err.message, 'error');
    }
  };

  const expireViewOnceMessage = async (conversationId: string, messageId: string) => {
    try {
      const msgRef = doc(db, 'conversations', conversationId, 'messages', messageId);
      await updateDoc(msgRef, {
        isViewed: true,
        viewOnceOpened: true,
        mediaUrl: null,
        thumbnailUrl: null,
        text: 'Opened (View once)',
      });

      const convRef = doc(db, 'conversations', conversationId);
      await updateDoc(convRef, {
        'lastMessage.text': 'Opened view-once media',
        'lastMessage.isViewed': true,
        'lastMessage.viewOnceOpened': true,
      }).catch(() => {});
    } catch (err) {
      console.error('Error expiring view-once in Firestore:', err);
    }

    // Optimistically update local message list immediately so preview is hidden without delay
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              isViewed: true,
              viewOnceOpened: true,
              mediaUrl: undefined,
              thumbnailUrl: undefined,
              text: 'Opened (View once)',
            }
          : m
      )
    );
  };

  const votePoll = async (messageId: string, optionId: string) => {
    if (!activeConversationId || !firebaseUser) return;
    try {
      const msgRef = doc(db, 'conversations', activeConversationId, 'messages', messageId);
      const msg = messages.find((m) => m.id === messageId);
      if (!msg || !msg.pollPayload) return;

      const updatedOptions = msg.pollPayload.options.map((opt) => {
        const hasVoted = opt.votes.includes(firebaseUser.uid);
        if (opt.id === optionId) {
          return {
            ...opt,
            votes: hasVoted ? opt.votes.filter((u) => u !== firebaseUser.uid) : [...opt.votes, firebaseUser.uid],
          };
        } else if (!msg.pollPayload?.multiSelect) {
          return {
            ...opt,
            votes: opt.votes.filter((u) => u !== firebaseUser.uid),
          };
        }
        return opt;
      });

      await updateDoc(msgRef, {
        'pollPayload.options': updatedOptions,
      });
      playClickSound();
    } catch (err) {
      console.error('Error voting on poll:', err);
    }
  };

  const markMessagesRead = async (conversationId: string) => {
    if (
      !firebaseUser ||
      !conversationId ||
      conversationId === 'conv_demo_starter' ||
      conversationId === 'splender_ai_assistant' ||
      conversationId.startsWith('p2p_')
    ) {
      return;
    }
    try {
      const convRef = doc(db, 'conversations', conversationId);
      await updateDoc(convRef, {
        [`unreadCounts.${firebaseUser.uid}`]: 0,
      });
    } catch {
      // Ignored for non-blocking UI
    }
  };

  const addReaction = async (messageId: string, emoji: string) => {
    if (!activeConversationId || !firebaseUser) return;
    try {
      const msgRef = doc(db, 'conversations', activeConversationId, 'messages', messageId);
      const msgSnap = await getDoc(msgRef);
      if (!msgSnap.exists()) return;

      const data = msgSnap.data() as Message;
      const reactions = data.reactions ? [...data.reactions] : [];
      const existing = reactions.find((r) => r.emoji === emoji);

      if (existing) {
        if (existing.uids.includes(firebaseUser.uid)) {
          existing.uids = existing.uids.filter((u) => u !== firebaseUser.uid);
          existing.count = existing.uids.length;
        } else {
          existing.uids.push(firebaseUser.uid);
          existing.count = existing.uids.length;
        }
      } else {
        reactions.push({ emoji, count: 1, uids: [firebaseUser.uid] });
      }

      await updateDoc(msgRef, {
        reactions: reactions.filter((r) => r.count > 0),
      });
    } catch (err: any) {
      console.error('Error adding reaction:', err);
    }
  };

  // Delete message (tombstone pattern)
  const deleteMessage = async (messageId: string) => {
    if (!activeConversationId || !firebaseUser) return;
    try {
      const msgRef = doc(db, 'conversations', activeConversationId, 'messages', messageId);
      await updateDoc(msgRef, {
        isDeleted: true,
        text: 'This message was deleted.',
        mediaUrl: null,
      });
      showToast('Message Deleted', undefined, 'info');
    } catch (err: any) {
      console.error('Error deleting message:', err);
      showToast('Delete Failed', err.message, 'error');
    }
  };

  const clearConversationMessages = async (conversationId: string) => {
    try {
      const convMsgs = messages.filter((m) => m.conversationId === conversationId);
      for (const msg of convMsgs) {
        try {
          const msgRef = doc(db, 'conversations', conversationId, 'messages', msg.id);
          await deleteDoc(msgRef);
        } catch (e) {
          console.debug('Error deleting msg doc:', e);
        }
      }
      showToast('Chat Storage Cleared', 'Messages removed and storage freed', 'success');
    } catch (err: any) {
      console.error('Error clearing conversation:', err);
      showToast('Clear Failed', err.message, 'error');
    }
  };

  const togglePinConversation = async (conversationId: string) => {
    if (!firebaseUser) return;
    const conv = conversations.find((c) => c.id === conversationId);
    if (!conv) return;

    const currentPinned = conv.pinned?.[firebaseUser.uid] || false;
    try {
      await updateDoc(doc(db, 'conversations', conversationId), {
        [`pinned.${firebaseUser.uid}`]: !currentPinned,
      });
      showToast(!currentPinned ? 'Chat Pinned' : 'Chat Unpinned', undefined, 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  const toggleMuteConversation = async (conversationId: string) => {
    if (!firebaseUser) return;
    const conv = conversations.find((c) => c.id === conversationId);
    if (!conv) return;

    const currentMuted = conv.muted?.[firebaseUser.uid] || false;
    try {
      await updateDoc(doc(db, 'conversations', conversationId), {
        [`muted.${firebaseUser.uid}`]: !currentMuted,
      });
      showToast(!currentMuted ? 'Muted Notifications' : 'Unmuted Chat', undefined, 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  const startDirectConversation = async (targetProfile: {
    uid: string;
    splenderId: string;
    displayName: string;
    avatar: string;
  }): Promise<string> => {
    if (!firebaseUser || !currentUserProfile) return '';

    // Check if 1:1 conversation already exists
    const existing = conversations.find(
      (c) => !c.isGroup && c.participants.includes(targetProfile.uid) && c.participants.includes(firebaseUser.uid)
    );
    if (existing) {
      setActiveConversationId(existing.id);
      return existing.id;
    }

    try {
      const convColl = collection(db, 'conversations');
      const docRef = await addDoc(convColl, sanitizeForFirestore({
        isGroup: false,
        participants: [firebaseUser.uid, targetProfile.uid],
        participantSplenderIds: {
          [firebaseUser.uid]: currentUserProfile.splenderId,
          [targetProfile.uid]: targetProfile.splenderId,
        },
        participantNames: {
          [firebaseUser.uid]: currentUserProfile.displayName,
          [targetProfile.uid]: targetProfile.displayName,
        },
        participantAvatars: {
          [firebaseUser.uid]: currentUserProfile.avatar,
          [targetProfile.uid]: targetProfile.avatar,
        },
        unreadCounts: {
          [firebaseUser.uid]: 0,
          [targetProfile.uid]: 0,
        },
        updatedAt: Date.now(),
      }));

      // Add system announcement
      await addDoc(collection(db, 'conversations', docRef.id, 'messages'), sanitizeForFirestore({
        conversationId: docRef.id,
        senderUid: 'system',
        senderSplenderId: 'SPLENDER',
        senderName: 'System',
        text: `Peer connection established with ${targetProfile.displayName} over TLS.`,
        type: 'system',
        timestamp: Date.now(),
        status: 'delivered',
      }));

      setActiveConversationId(docRef.id);
      return docRef.id;
    } catch (err: any) {
      console.error('Error starting conversation:', err);
      showToast('Failed to Open Chat', err.message, 'error');
      return '';
    }
  };

  const createGroupConversation = async (name: string, members: ContactItem[]): Promise<string> => {
    if (!firebaseUser || !currentUserProfile) return '';

    const memberUids = [firebaseUser.uid, ...members.map((m) => m.targetUid)];
    const namesMap: Record<string, string> = { [firebaseUser.uid]: currentUserProfile.displayName };
    const avatarsMap: Record<string, string> = { [firebaseUser.uid]: currentUserProfile.avatar };
    const splenderMap: Record<string, string> = { [firebaseUser.uid]: currentUserProfile.splenderId };

    members.forEach((m) => {
      namesMap[m.targetUid] = m.displayName;
      avatarsMap[m.targetUid] = m.avatar;
      splenderMap[m.targetUid] = m.splenderId;
    });

    try {
      const convColl = collection(db, 'conversations');
      const docRef = await addDoc(convColl, sanitizeForFirestore({
        isGroup: true,
        groupName: name.trim(),
        groupAvatar: createDeterministicAvatarDataUri(name.trim() || 'Group', '#0D9488'),
        participants: memberUids,
        participantNames: namesMap,
        participantAvatars: avatarsMap,
        participantSplenderIds: splenderMap,
        unreadCounts: {},
        updatedAt: Date.now(),
      }));

      await addDoc(collection(db, 'conversations', docRef.id, 'messages'), sanitizeForFirestore({
        conversationId: docRef.id,
        senderUid: 'system',
        senderSplenderId: 'SPLENDER',
        senderName: 'System',
        text: `Group "${name.trim()}" created with ${memberUids.length} peers.`,
        type: 'system',
        timestamp: Date.now(),
        status: 'delivered',
      }));

      setActiveConversationId(docRef.id);
      showToast('Group Created', name, 'success');
      return docRef.id;
    } catch (err: any) {
      console.error('Error creating group:', err);
      showToast('Group Creation Failed', err.message, 'error');
      return '';
    }
  };

  // Contacts discovery & request management
  const searchUserBySplenderOrUsername = async (queryStr: string): Promise<UserProfile | null> => {
    const trimmed = queryStr.trim();
    if (!trimmed) return null;

    try {
      // Check if Splender ID format (e.g. SP-XXXXXX or #SP-XXXXXX)
      const cleanSplenderId = trimmed.replace(/^#/, '').toUpperCase();
      const splenderSnap = await getDoc(doc(db, 'splenderIds', cleanSplenderId));
      if (splenderSnap.exists()) {
        const uid = splenderSnap.data()?.uid;
        if (uid) {
          const uSnap = await getDoc(doc(db, 'users', uid));
          if (uSnap.exists()) return uSnap.data() as UserProfile;
        }
      }

      // Check normalized username
      const norm = normalizeUsername(trimmed);
      const userIndexSnap = await getDoc(doc(db, 'usernames', norm));
      if (userIndexSnap.exists()) {
        const uid = userIndexSnap.data()?.uid;
        if (uid) {
          const uSnap = await getDoc(doc(db, 'users', uid));
          if (uSnap.exists()) return uSnap.data() as UserProfile;
        }
      }

      return null;
    } catch (err: any) {
      console.error('Search error:', err);
      return null;
    }
  };

  const sendContactRequest = async (targetUser: UserProfile): Promise<boolean> => {
    if (!firebaseUser || !currentUserProfile) return false;
    if (targetUser.uid === firebaseUser.uid) {
      showToast('Cannot Add Self', 'You cannot add yourself as a contact.', 'warning');
      return false;
    }

    try {
      // Add to my contacts as pending (outgoing)
      await setDoc(doc(db, 'contacts', firebaseUser.uid, 'items', targetUser.uid), {
        targetUid: targetUser.uid,
        splenderId: targetUser.splenderId,
        username: targetUser.username,
        displayName: targetUser.displayName,
        avatar: targetUser.avatar,
        bio: targetUser.bio,
        state: 'pending',
        isIncoming: false,
        updatedAt: Date.now(),
      });

      // Add to recipient contacts as pending (incoming request)
      await setDoc(doc(db, 'contacts', targetUser.uid, 'items', firebaseUser.uid), {
        targetUid: firebaseUser.uid,
        splenderId: currentUserProfile.splenderId,
        username: currentUserProfile.username,
        displayName: currentUserProfile.displayName,
        avatar: currentUserProfile.avatar,
        bio: currentUserProfile.bio,
        state: 'pending',
        isIncoming: true,
        updatedAt: Date.now(),
      });

      showToast('Contact Request Sent', `Delivered to ${targetUser.displayName}`, 'success');
      return true;
    } catch (err: any) {
      console.error('Error sending contact request:', err);
      showToast('Request Failed', err.message, 'error');
      return false;
    }
  };

  const acceptContactRequest = async (contact: ContactItem) => {
    if (!firebaseUser || !currentUserProfile) return;
    try {
      // Update both sides to accepted
      await updateDoc(doc(db, 'contacts', firebaseUser.uid, 'items', contact.targetUid), {
        state: 'accepted',
        updatedAt: Date.now(),
      });
      await updateDoc(doc(db, 'contacts', contact.targetUid, 'items', firebaseUser.uid), {
        state: 'accepted',
        updatedAt: Date.now(),
      });
      showToast('Connected', `${contact.displayName} added to contacts`, 'success');
    } catch (err: any) {
      console.error('Error accepting contact:', err);
    }
  };

  const declineContactRequest = async (contact: ContactItem) => {
    if (!firebaseUser) return;
    try {
      await deleteDoc(doc(db, 'contacts', firebaseUser.uid, 'items', contact.targetUid));
      showToast('Request Declined', undefined, 'info');
    } catch (err: any) {
      console.error('Error declining contact:', err);
    }
  };

  const blockContact = async (targetUid: string) => {
    if (!firebaseUser) return;
    try {
      await setDoc(doc(db, 'contacts', firebaseUser.uid, 'items', targetUid), {
        targetUid,
        state: 'blocked',
        updatedAt: Date.now(),
      }, { merge: true });
      showToast('Contact Blocked', undefined, 'warning');
    } catch (err: any) {
      console.error(err);
    }
  };

  const unblockContact = async (targetUid: string) => {
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'contacts', firebaseUser.uid, 'items', targetUid), {
        state: 'accepted',
        updatedAt: Date.now(),
      });
      showToast('Contact Unblocked', undefined, 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  // Moments feed (Zero-Trust volumetric & schema compliant with firebase-blueprint.json)
  const postMoment = async (
    fileOrUrl: string,
    caption: string,
    mediaQualityOverride?: MediaQuality,
    thumbnailUrl?: string,
    mediaType: 'image' | 'video' | 'audio' | 'text' = 'image',
    extraOptions?: {
      poll?: Moment['poll'];
      isPermanentFeed?: boolean;
      arFilter?: string;
      bgColor?: string;
      privacy?: Moment['privacy'];
    }
  ) => {
    if (!firebaseUser || !currentUserProfile) return;
    try {
      const chosenQuality =
        mediaQualityOverride || currentUserProfile.mediaQuality || mediaQuality || 'high';

      const safeMedia = await ensureFirestoreSafeMomentMedia(
        fileOrUrl,
        firebaseUser.uid,
        mediaType,
        chosenQuality
      );

      const safeAvatar = sanitizeBoundedAvatar(
        currentUserProfile.avatar,
        currentUserProfile.displayName || 'Peer'
      );
      const safeThumbnail =
        thumbnailUrl && thumbnailUrl.length <= 786432 ? thumbnailUrl : null;
      const now = Date.now();
      const isPermanent = Boolean(extraOptions?.isPermanentFeed);

      let validatedPoll: Moment['poll'] | null = null;
      if (
        extraOptions?.poll &&
        extraOptions.poll.question.trim().length >= 1 &&
        extraOptions.poll.options.length >= 2
      ) {
        validatedPoll = {
          question: extraOptions.poll.question.trim().slice(0, 300),
          options: extraOptions.poll.options.slice(0, 6).map((opt) => ({
            text: (opt.text || 'Option').trim().slice(0, 120),
            votes: Array.isArray(opt.votes) ? opt.votes.slice(0, 200) : [],
          })),
        };
      }

      const momentPayload = sanitizeForFirestore({
        ownerUid: firebaseUser.uid,
        ownerSplenderId: (currentUserProfile.splenderId || 'SP-PEER').slice(0, 64),
        ownerName: (currentUserProfile.displayName || 'Splender Peer').slice(0, 200),
        ownerAvatar: safeAvatar,
        mediaUrl: safeMedia.mediaUrl,
        mediaType: safeMedia.mediaType,
        mediaQuality: chosenQuality,
        thumbnailUrl: safeThumbnail,
        caption: caption.trim().slice(0, 1500),
        bgColor: extraOptions?.bgColor ? extraOptions.bgColor.slice(0, 32) : null,
        arFilter: extraOptions?.arFilter ? extraOptions.arFilter.slice(0, 64) : null,
        privacy: extraOptions?.privacy || 'contacts',
        isPermanentFeed: isPermanent,
        createdAt: now,
        updatedAt: now,
        expiresAt: isPermanent ? now + 365 * 24 * 60 * 60 * 1000 : now + 24 * 60 * 60 * 1000,
        likes: [],
        viewers: [firebaseUser.uid],
        poll: validatedPoll,
        comments: [],
      });

      const docRef = await addDoc(collection(db, 'moments'), momentPayload);
      setMoments((prev) =>
        prev.some((m) => m.id === docRef.id)
          ? prev
          : [{ id: docRef.id, ...(momentPayload as unknown as Omit<Moment, 'id'>) }, ...prev]
      );
      showToast('Moment Published', 'Live for 24h across peer feeds', 'success');
      trackEvent('story_published', { mediaType: safeMedia.mediaType, hasCaption: !!caption.trim() }, 'engagement');
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.CREATE, 'moments');
      }
      console.error('Error posting moment:', err);
      showToast('Post Failed', err.message, 'error');
    }
  };

  const toggleLikeMoment = async (momentId: string) => {
    if (!firebaseUser) return;
    const m = moments.find((mom) => mom.id === momentId);
    if (!m) return;

    const hasLiked = m.likes.includes(firebaseUser.uid);
    const updatedLikes = (
      hasLiked
        ? m.likes.filter((u) => u !== firebaseUser.uid)
        : [...m.likes, firebaseUser.uid]
    ).slice(0, 500);
    const now = Date.now();

    setMoments((prev) =>
      prev.map((mom) => (mom.id === momentId ? { ...mom, likes: updatedLikes, updatedAt: now } : mom))
    );

    if (momentId.startsWith('demo_moment_')) return;

    try {
      await updateDoc(doc(db, 'moments', momentId), {
        likes: updatedLikes,
        updatedAt: now,
      });
      const reactionRef = doc(db, 'moments', momentId, 'reactions', firebaseUser.uid);
      if (hasLiked) {
        await deleteDoc(reactionRef).catch(() => {});
      } else {
        await setDoc(
          reactionRef,
          sanitizeForFirestore({
            momentId,
            userUid: firebaseUser.uid,
            emoji: '❤️',
            updatedAt: now,
          })
        ).catch(() => {});
      }
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.UPDATE, `moments/${momentId}`);
      }
      console.error(err);
    }
  };

  const voteMomentPoll = async (momentId: string, optionIndex: number) => {
    if (!firebaseUser) return;
    const m = moments.find((mom) => mom.id === momentId);
    if (!m) return;

    const basePoll = m.poll || {
      question: 'Love this capture?',
      options: [
        { text: '🔥 Love it!', votes: [] },
        { text: '⚡️ Super cool', votes: [] },
      ],
    };
    const updatedPoll = {
      question: basePoll.question.slice(0, 300),
      options: basePoll.options.slice(0, 6).map((opt, idx) => {
        const withoutMe = (opt.votes || []).filter((uid) => uid !== firebaseUser.uid);
        return {
          text: opt.text.slice(0, 120),
          votes: idx === optionIndex ? [...withoutMe, firebaseUser.uid].slice(0, 200) : withoutMe,
        };
      }),
    };
    const now = Date.now();

    setMoments((prev) =>
      prev.map((mom) => (mom.id === momentId ? { ...mom, poll: updatedPoll, updatedAt: now } : mom))
    );

    if (momentId.startsWith('demo_moment_')) return;

    try {
      await updateDoc(doc(db, 'moments', momentId), {
        poll: updatedPoll,
        updatedAt: now,
      });
      const pollReactionId = `${firebaseUser.uid}_poll`;
      await setDoc(
        doc(db, 'moments', momentId, 'reactions', pollReactionId),
        sanitizeForFirestore({
          momentId,
          userUid: firebaseUser.uid,
          optionIndex,
          updatedAt: now,
        })
      ).catch(() => {});
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.UPDATE, `moments/${momentId}`);
      }
      console.error('Error voting on moment poll:', err);
    }
  };

  const addMomentComment = async (momentId: string, text: string) => {
    const cleanText = text.trim().slice(0, 1000);
    if (!cleanText || !firebaseUser || !currentUserProfile) return;

    const now = Date.now();
    const commentId = `cmt_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const safeAvatar = sanitizeBoundedAvatar(
      currentUserProfile.avatar,
      currentUserProfile.displayName || 'Peer'
    );
    const newComment = {
      id: commentId,
      momentId,
      userUid: firebaseUser.uid,
      userName: (currentUserProfile.displayName || 'Splender Peer').slice(0, 200),
      userAvatar: safeAvatar.length <= 786432 ? safeAvatar : createDeterministicAvatarDataUri(currentUserProfile.displayName || 'Peer'),
      text: cleanText,
      createdAt: now,
    };

    const targetMoment = moments.find((mom) => mom.id === momentId);
    const updatedComments = [...(targetMoment?.comments || []), newComment].slice(-100);

    setMoments((prev) =>
      prev.map((mom) =>
        mom.id === momentId ? { ...mom, comments: updatedComments, updatedAt: now } : mom
      )
    );

    if (momentId.startsWith('demo_moment_')) return;

    try {
      await setDoc(
        doc(db, 'moments', momentId, 'comments', commentId),
        sanitizeForFirestore(newComment)
      );
      await updateDoc(doc(db, 'moments', momentId), {
        comments: updatedComments,
        updatedAt: now,
      });
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.CREATE, `moments/${momentId}/comments/${commentId}`);
      }
      console.error('Error adding moment comment:', err);
    }
  };

  const recordMomentView = async (momentId: string) => {
    if (!firebaseUser || momentId.startsWith('demo_moment_')) return;
    const m = moments.find((mom) => mom.id === momentId);
    if (!m || m.ownerUid === firebaseUser.uid) return;
    if (m.viewers?.includes(firebaseUser.uid)) return;

    const nextViewers = [...(m.viewers || []), firebaseUser.uid].slice(0, 500);
    const now = Date.now();
    setMoments((prev) =>
      prev.map((mom) => (mom.id === momentId ? { ...mom, viewers: nextViewers, updatedAt: now } : mom))
    );

    try {
      await updateDoc(doc(db, 'moments', momentId), {
        viewers: nextViewers,
        updatedAt: now,
      });
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.UPDATE, `moments/${momentId}`);
      }
    }
  };

  const deleteMoment = async (momentId: string) => {
    if (momentId.startsWith('demo_moment_')) {
      setMoments((prev) => prev.filter((m) => m.id !== momentId));
      showToast('Status Deleted', 'Your status update was removed', 'info');
      return;
    }
    try {
      await deleteDoc(doc(db, 'moments', momentId));
      setMoments((prev) => prev.filter((m) => m.id !== momentId));
      showToast('Status Deleted', 'Your status update was removed', 'info');
    } catch (err: any) {
      if (isPermissionDeniedError(err)) {
        handleFirestoreError(err, OperationType.DELETE, `moments/${momentId}`);
      }
      console.error(err);
      setMoments((prev) => prev.filter((m) => m.id !== momentId));
      showToast('Status Deleted', 'Your status update was removed', 'info');
    }
  };

  // ==========================================
  // MODULE 4: WEBRTC CALL SIGNALING ENGINE
  // ==========================================
  // Listen for incoming call signals directed to current UID
  useEffect(() => {
    if (!firebaseUser) return;

    const callsQuery = query(
      collection(db, 'calls'),
      where('recipientUid', '==', firebaseUser.uid),
      where('callState', 'in', ['calling', 'ringing']),
      limit(1)
    );

    const unsubscribe = onSnapshot(callsQuery, (snapshot) => {
      if (!snapshot.empty) {
        const docSnap = snapshot.docs[0];
        const data = { id: docSnap.id, ...docSnap.data() } as CallSignal;
        if (!activeCall) {
          setActiveCall(data);
        }
      }
    }, (error) => {
      console.debug('Calls subscription notice:', error);
    });

    return () => unsubscribe();
  }, [firebaseUser, activeCall]);

  // Call duration counter
  useEffect(() => {
    if (activeCall && activeCall.callState === 'connected') {
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [activeCall?.callState]);

  // Active ringtone lifecycle
  useEffect(() => {
    if (!activeCall) {
      stopRingtone();
      return;
    }
    if (activeCall.callState === 'calling' || activeCall.callState === 'ringing') {
      const isIncoming = activeCall.recipientUid === firebaseUser?.uid;
      startRingtone(isIncoming ? 'incoming' : 'outgoing');
    } else {
      stopRingtone();
    }
    return () => {
      stopRingtone();
    };
  }, [activeCall?.callState, activeCall?.recipientUid, firebaseUser?.uid]);

  const startCall = async (
    targetUid: string,
    targetName: string,
    targetAvatar: string,
    type: 'voice' | 'video'
  ) => {
    if (!firebaseUser || !currentUserProfile) return;

    try {
      // Acquire user media (Microphone / Camera) with graceful virtual fallback
      const { stream, isSimulated } = await getSafeUserMedia({
        audio: true,
        video: type === 'video',
      });
      if (isSimulated) {
        showToast('Virtual Media Link', 'Running in simulated device mode (no physical camera/mic detected).', 'info');
      }
      setLocalStream(stream);

      // Create WebRTC Peer Connection with dynamic STUN/TURN ICE configuration
      const pc = new RTCPeerConnection(getWebRtcConfiguration());
      peerConnectionRef.current = pc;

      // Attach genuine RTCDataChannel for direct peer messaging and file transfers
      SplenderWebRtcEngine.getInstance().setupDataChannel(targetUid, pc, true);

      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const remote = new MediaStream();
      setRemoteStream(remote);
      pc.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => remote.addTrack(track));
      };

      // Create Call Document in Firestore for signaling
      const callRef = doc(collection(db, 'calls'));
      const callerCandidates: RTCIceCandidateInit[] = [];

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          callerCandidates.push(event.candidate.toJSON());
          void updateDoc(callRef, { callerCandidates }).catch(() => {});
        }
      };

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      const callSignal: Omit<CallSignal, 'id'> = {
        callerUid: firebaseUser.uid,
        callerSplenderId: currentUserProfile.splenderId,
        callerName: currentUserProfile.displayName,
        callerAvatar: currentUserProfile.avatar,
        recipientUid: targetUid,
        type,
        callState: 'calling',
        offer: { type: offer.type, sdp: offer.sdp },
        callerCandidates: [],
        recipientCandidates: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      await setDoc(callRef, callSignal);
      setActiveCall({ id: callRef.id, ...callSignal });
      setCallDuration(0);

      // Listen for recipient answer and ICE candidates
      const unsubscribe = onSnapshot(callRef, (snapshot) => {
        const data = snapshot.data() as CallSignal | undefined;
        if (!data) return;

        if (data.callState === 'connected' && pc.signalingState !== 'closed') {
          setActiveCall((prev) => prev ? { ...prev, callState: 'connected' } : null);
        }

        if (data.answer && !pc.currentRemoteDescription) {
          const rtcAnswer = new RTCSessionDescription(data.answer);
          pc.setRemoteDescription(rtcAnswer);
        }

        if (data.recipientCandidates) {
          data.recipientCandidates.forEach((candidate) => {
            pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(console.warn);
          });
        }

        if (data.callState === 'ended' || data.callState === 'declined') {
          endCall();
        }
      }, (error) => {
        console.debug('Call session signaling listener notice:', error);
      });
    } catch (err: any) {
      console.warn('Call initialization recovered with fallback:', err);
      showToast('Media Fallback', 'Active in simulated audio/video mode.', 'info');
    }
  };

  const acceptCall = async () => {
    if (!activeCall || !firebaseUser) return;
    try {
      const { stream, isSimulated } = await getSafeUserMedia({
        audio: true,
        video: activeCall.type === 'video',
      });
      if (isSimulated) {
        showToast('Virtual Media Link', 'Connected with simulated audio/video link.', 'info');
      }
      setLocalStream(stream);

      const pc = new RTCPeerConnection(getWebRtcConfiguration());
      peerConnectionRef.current = pc;

      // Attach incoming RTCDataChannel listener
      SplenderWebRtcEngine.getInstance().setupDataChannel(activeCall.callerUid, pc, false);

      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const remote = new MediaStream();
      setRemoteStream(remote);
      pc.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => remote.addTrack(track));
      };

      const callRef = doc(db, 'calls', activeCall.id);
      const recipientCandidates: RTCIceCandidateInit[] = [];

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          recipientCandidates.push(event.candidate.toJSON());
          void updateDoc(callRef, { recipientCandidates }).catch(() => {});
        }
      };

      if (activeCall.offer) {
        await pc.setRemoteDescription(new RTCSessionDescription(activeCall.offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        await updateDoc(callRef, {
          answer: { type: answer.type, sdp: answer.sdp },
          callState: 'connected',
          updatedAt: Date.now(),
        });

        setActiveCall((prev) => prev ? { ...prev, callState: 'connected' } : null);
      }

      if (activeCall.callerCandidates) {
        activeCall.callerCandidates.forEach((c) => {
          pc.addIceCandidate(new RTCIceCandidate(c)).catch(console.warn);
        });
      }
    } catch (err: any) {
      console.error('Failed to answer call:', err);
      showToast('Call Answer Failed', err.message, 'error');
      endCall();
    }
  };

  const endCall = async () => {
    stopRingtone();
    if (activeCall) {
      try {
        await updateDoc(doc(db, 'calls', activeCall.id), {
          callState: 'ended',
          updatedAt: Date.now(),
        });
      } catch {
        // Ignored
      }
    }

    if (screenTrackRef.current) {
      screenTrackRef.current.stop();
      screenTrackRef.current = null;
    }
    setIsScreenSharing(false);

    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop());
    }
    if (remoteStream) {
      remoteStream.getTracks().forEach((track) => track.stop());
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    if (activeCall) {
      SplenderWebRtcEngine.getInstance().teardownPeer(activeCall.callerUid);
      SplenderWebRtcEngine.getInstance().teardownPeer(activeCall.recipientUid);
    }

    setLocalStream(null);
    setRemoteStream(null);
    setActiveCall(null);
    setIsCallMinimized(false);
    setCallDuration(0);
    showToast('Call Finished', undefined, 'info');
  };

  const toggleCallMute = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsCallMuted(!audioTrack.enabled);
      }
    }
  };

  const toggleCallCamera = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCallCameraOff(!videoTrack.enabled);
      }
    }
  };

  const toggleSpeaker = () => {
    const nextRoute: AudioSpeakerRoute =
      speakerRoute === 'speaker' ? 'earpiece' : speakerRoute === 'earpiece' ? 'bluetooth' : 'speaker';
    setSpeakerRoute(nextRoute);
    setIsSpeakerOn(nextRoute === 'speaker');
    showToast('Audio Output Route', `Switched to ${nextRoute.toUpperCase()}`, 'info');
  };

  const setConversationDisappearingTimer = async (convId: string, seconds: number) => {
    try {
      await updateDoc(doc(db, 'conversations', convId), {
        disappearingTimerSeconds: seconds,
        updatedAt: Date.now(),
      });
      setConversations((prev) =>
        prev.map((c) => (c.id === convId ? { ...c, disappearingTimerSeconds: seconds } : c))
      );
      showToast(
        'Disappearing Messages',
        seconds === 0 ? 'Disappearing messages turned off' : `Set to ${seconds === 86400 ? '24 Hours' : seconds === 604800 ? '7 Days' : '90 Days'}`,
        'info'
      );
    } catch (err: any) {
      console.error('Failed to set disappearing timer:', err);
      showToast('Error', err.message, 'error');
    }
  };

  const sendBroadcastMessage = async (recipientUids: string[], text: string, mediaUrl?: string) => {
    if (!firebaseUser || !currentUserProfile || !recipientUids.length) return;

    try {
      for (const targetUid of recipientUids) {
        let conv = conversations.find(
          (c) => !c.isGroup && c.participants.includes(targetUid) && c.participants.includes(firebaseUser.uid)
        );

        let convId = conv?.id;
        if (!convId) {
          const targetContact = contacts.find((ct) => ct.targetUid === targetUid);
          const newConvRef = doc(collection(db, 'conversations'));
          convId = newConvRef.id;
          const convData = {
            id: convId,
            isGroup: false,
            participants: [firebaseUser.uid, targetUid],
            participantSplenderIds: {
              [firebaseUser.uid]: currentUserProfile.splenderId,
              [targetUid]: targetContact?.splenderId || 'SP-PEER',
            },
            participantNames: {
              [firebaseUser.uid]: currentUserProfile.displayName,
              [targetUid]: targetContact?.displayName || 'Contact',
            },
            participantAvatars: {
              [firebaseUser.uid]: currentUserProfile.avatar,
              [targetUid]: targetContact?.avatar || createDeterministicAvatarDataUri(targetContact?.displayName || 'Peer', '#0F766E'),
            },
            unreadCounts: { [targetUid]: 1, [firebaseUser.uid]: 0 },
            updatedAt: Date.now(),
            createdAt: Date.now(),
          };
          await setDoc(newConvRef, sanitizeForFirestore(convData));
        }

        const broadcastPlain = text.trim();
        const canSealBroadcastMedia = !mediaUrl || mediaUrl.length <= 160_000;
        const { envelope: encryptedEnvelope } = await CryptoService.sealConversationPayload(
          convId,
          [firebaseUser.uid, targetUid],
          {
            text: broadcastPlain,
            mediaUrl: canSealBroadcastMedia ? mediaUrl : undefined,
          }
        );
        const { envelope: summaryEnvelope } = await CryptoService.sealConversationPayload(
          convId,
          [firebaseUser.uid, targetUid],
          broadcastPlain
        );

        const msgRef = doc(collection(db, 'conversations', convId, 'messages'));
        const msgData = {
          id: msgRef.id,
          conversationId: convId,
          senderUid: firebaseUser.uid,
          senderId: firebaseUser.uid,
          senderSplenderId: currentUserProfile.splenderId,
          senderName: currentUserProfile.displayName,
          text: '[Encrypted]',
          encryptedEnvelope,
          isEncrypted: true,
          encryptionProtocol: 'DOUBLE_RATCHET_V3',
          transportMode: 'e2ee_relay',
          type: mediaUrl ? 'image' : 'text',
          mediaUrl: canSealBroadcastMedia ? null : mediaUrl || null,
          timestamp: Date.now(),
          status: 'sent',
          forwarded: true,
        };
        await setDoc(msgRef, sanitizeForFirestore(msgData));

        await updateDoc(doc(db, 'conversations', convId), sanitizeForFirestore({
          updatedAt: Date.now(),
          lastMessage: {
            id: msgRef.id,
            text: '[Encrypted]',
            encryptedEnvelope: summaryEnvelope,
            senderUid: firebaseUser.uid,
            type: mediaUrl ? 'image' : 'text',
            timestamp: Date.now(),
            status: 'sent',
          },
          [`unreadCounts.${targetUid}`]: increment(1),
        }));
      }
      showToast('Broadcast Sent', `Encrypted independently for ${recipientUids.length} recipients`, 'success');
    } catch (err: any) {
      console.error('Failed to send broadcast:', err);
      showToast('Broadcast Error', err.message, 'error');
    }
  };

  const batchDeleteMessages = async (convId: string, messageIds: string[]) => {
    try {
      for (const mid of messageIds) {
        await updateDoc(doc(db, 'conversations', convId, 'messages', mid), {
          isDeleted: true,
          text: 'This message was deleted',
          mediaUrl: null,
          thumbnailUrl: null,
        });
      }
      setMessages((prev) =>
        prev.map((m) =>
          messageIds.includes(m.id)
            ? { ...m, isDeleted: true, text: 'This message was deleted', mediaUrl: undefined }
            : m
        )
      );
      showToast('Deleted', `${messageIds.length} messages removed`, 'info');
    } catch (err: any) {
      console.error('Batch delete failed:', err);
      showToast('Delete Failed', err.message, 'error');
    }
  };

  const toggleScreenShare = async () => {
    if (!activeCall || !peerConnectionRef.current) return;

    if (isScreenSharing) {
      // Revert back to standard camera track
      try {
        if (screenTrackRef.current) {
          screenTrackRef.current.stop();
          screenTrackRef.current = null;
        }

        const { stream: cameraStream } = await getSafeUserMedia({
          video: true,
          audio: !isCallMuted,
        });

        const newVideoTrack = cameraStream.getVideoTracks()[0];
        const senders = peerConnectionRef.current.getSenders();
        const videoSender = senders.find((s) => s.track && s.track.kind === 'video');

        if (videoSender && newVideoTrack) {
          await videoSender.replaceTrack(newVideoTrack);
        }

        setLocalStream(cameraStream);
        setIsScreenSharing(false);
        showToast('Camera Restored', 'Switched back to camera video', 'info');
      } catch (err: any) {
        console.error('Error restoring camera stream:', err);
        setIsScreenSharing(false);
      }
    } else {
      // Start Screen Share
      try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });
        const screenTrack = displayStream.getVideoTracks()[0];
        screenTrackRef.current = screenTrack;

        const senders = peerConnectionRef.current.getSenders();
        const videoSender = senders.find((s) => s.track && s.track.kind === 'video');

        if (videoSender && screenTrack) {
          await videoSender.replaceTrack(screenTrack);
        } else if (screenTrack) {
          peerConnectionRef.current.addTrack(screenTrack, displayStream);
        }

        setLocalStream(displayStream);
        setIsScreenSharing(true);
        showToast('Screen Sharing Active', 'Sharing your display with peer', 'success');

        screenTrack.onended = () => {
          toggleScreenShare();
        };
      } catch (err: any) {
        console.warn('Screen share request notice:', err);
        if (err.name !== 'NotAllowedError') {
          showToast('Screen Share Notice', 'Screen sharing was cancelled or unavailable', 'info');
        }
      }
    }
  };

  // Real-time presence lifecycle engine
  useEffect(() => {
    if (!firebaseUser) return;
    const cleanup = initPresenceTracking(firebaseUser.uid);
    return () => cleanup();
  }, [firebaseUser]);

  // Subscribe to real-time online status of network users
  useEffect(() => {
    if (!firebaseUser) {
      setOnlineUserIds(new Set());
      return;
    }

    const usersQuery = query(
      collection(db, 'users'),
      where('status', '==', 'online'),
      limit(50)
    );
    const unsubscribe = onSnapshot(
      usersQuery,
      (snapshot) => {
        const activeSet = new Set<string>();
        const now = Date.now();
        snapshot.forEach((docSnap) => {
          const u = docSnap.data();
          const lastSeenTime =
            u.lastSeen && typeof u.lastSeen === 'object' && 'toMillis' in u.lastSeen
              ? (u.lastSeen as any).toMillis()
              : typeof u.lastSeen === 'number'
              ? u.lastSeen
              : 0;

          if (u.isOnline || (lastSeenTime > 0 && now - lastSeenTime < 60000)) {
            activeSet.add(docSnap.id);
          }
        });
        setOnlineUserIds(activeSet);
      },
      (err) => {
        console.debug('Users online presence notice:', err);
      }
    );

    return () => unsubscribe();
  }, [firebaseUser]);

  const isUserOnline = (uid: string): boolean => {
    return onlineUserIds.has(uid);
  };

  const sendTypingStatus = (conversationId: string, recipientUid: string, isTyping: boolean) => {
    if (!firebaseUser) return;
    setDebouncedTypingStatus(conversationId, firebaseUser.uid, recipientUid, isTyping);
  };

  const toggleDataSaver = async () => {
    if (!currentUserProfile || !firebaseUser) return;
    const nextVal = !currentUserProfile.dataSaver;
    await updateProfile({ dataSaver: nextVal });
    showToast(nextVal ? 'Data Saver Active' : 'Standard Bandwidth Active', undefined, 'info');
  };

  const unlockApp = () => {
    setIsAppLocked(false);
    showToast('Device Unlocked', 'Authenticated via WebAuthn / Secure PIN', 'success');
  };

  const lockApp = () => {
    setIsAppLocked(true);
  };

  const fallbackStarterConv: Conversation = {
    id: 'conv_demo_starter',
    isGroup: false,
    participants: [currentUserProfile?.uid || 'user_local', 'peer_demo_vaibhav'],
    participantNames: {
      [currentUserProfile?.uid || 'user_local']: currentUserProfile?.displayName || 'You',
      peer_demo_vaibhav: 'Vaibhav Umbarkar',
    },
    participantAvatars: {
      [currentUserProfile?.uid || 'user_local']:
        currentUserProfile?.avatar || createDeterministicAvatarDataUri('You', '#0F766E'),
      peer_demo_vaibhav: createDeterministicAvatarDataUri('Vaibhav Umbarkar', '#115E59'),
    },
    lastMessage: {
      id: 'msg_starter_last',
      text: 'Splender Chat peer session ready. Double tap any message to react.',
      senderUid: 'peer_demo_vaibhav',
      type: 'text',
      timestamp: Date.now(),
      status: 'delivered',
    },
    updatedAt: Date.now(),
  };

  const fallbackAiAssistantConv: Conversation = {
    id: 'splender_ai_assistant',
    isGroup: false,
    groupName: 'Splender Assistant',
    groupAvatar: createDeterministicAvatarDataUri('SA', '#0D9488'),
    participants: [currentUserProfile?.uid || 'user_local', 'splender_ai_bot'],
    participantNames: {
      [currentUserProfile?.uid || 'user_local']: currentUserProfile?.displayName || 'You',
      splender_ai_bot: 'Splender Assistant',
    },
    participantAvatars: {
      splender_ai_bot: createDeterministicAvatarDataUri('SA', '#0D9488'),
    },
    lastMessage: {
      id: 'ai_welcome_intro',
      text: 'Ready to summarize threads or translate messages locally.',
      senderUid: 'splender_ai_bot',
      type: 'text',
      timestamp: Date.now(),
      status: 'read',
    },
    updatedAt: Date.now(),
  };

  const activeConversation =
    conversations.find((c) => c.id === activeConversationId) ||
    (activeConversationId === 'splender_ai_assistant'
      ? fallbackAiAssistantConv
      : activeConversationId === 'conv_demo_starter'
      ? fallbackStarterConv
      : null);

  const starterMessages: Message[] = [
    {
      id: 'msg_starter_first',
      conversationId: 'conv_demo_starter',
      senderUid: 'peer_demo_vaibhav',
      senderId: 'peer_demo_vaibhav',
      senderSplenderId: 'SP-992011',
      senderName: 'Vaibhav Umbarkar',
      text: 'Splender Chat mobile edition is active. Double tap this message bubble to react.',
      type: 'text',
      timestamp: Date.now() - 120000,
      status: 'delivered',
    },
    {
      id: 'msg_starter_view_once',
      conversationId: 'conv_demo_starter',
      senderUid: 'peer_demo_vaibhav',
      senderId: 'peer_demo_vaibhav',
      senderSplenderId: 'SP-992011',
      senderName: 'Vaibhav Umbarkar',
      text: 'View-once photo',
      type: 'image',
      mediaUrl: createDeterministicAvatarDataUri('VO', '#0F766E'),
      isViewOnce: true,
      isViewed: false,
      viewOnceOpened: false,
      timestamp: Date.now() - 60000,
      status: 'delivered',
    },
  ];

  const aiStarterMessages: Message[] = [
    {
      id: 'msg_ai_welcome',
      conversationId: 'splender_ai_assistant',
      senderUid: 'splender_ai_bot',
      senderId: 'splender_ai_bot',
      senderSplenderId: 'AI-001',
      senderName: 'Splender AI Assistant',
      text: 'Namaste & Welcome! 🤖 I am your built-in AI Assistant powered by Divya Drishti & Gemini. You can ask me to summarize chat threads, translate text into any language, draft smart responses, or answer questions!',
      type: 'text',
      timestamp: Date.now() - 30000,
      status: 'read',
    },
  ];

  const effectiveMessages =
    activeConversationId === 'splender_ai_assistant' && messages.length === 0
      ? aiStarterMessages
      : activeConversationId === 'conv_demo_starter' && messages.length === 0
      ? starterMessages
      : messages;

  return (
    <ChatContext.Provider
      value={{
        firebaseUser,
        currentUserProfile,
        isLoadingAuth,
        authError,
        authRestrictedInfo,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        tryAnonymousAuth,
        signOutUser,
        deleteAccountAndWipeData,
        updateProfile,
        linkGoogleAccount,
        linkEmailAccount,
        activeConversationId,
        setActiveConversationId,
        activeTab,
        setActiveTab,
        isAppLocked,
        unlockApp,
        lockApp,
        userPin,
        setUserPin,
        isQrScannerOpen,
        setIsQrScannerOpen,
        isIdentityModalOpen,
        setIsIdentityModalOpen,
        isPrivacySettingsModalOpen,
        setIsPrivacySettingsModalOpen,
        isSettingsModalOpen,
        setIsSettingsModalOpen,
        isDevDocsModalOpen,
        setIsDevDocsModalOpen,
        isVaultModalOpen,
        setIsVaultModalOpen,
        darkMode,
        toggleDarkMode,
        themeMode,
        setThemeMode,
        visualTheme,
        setVisualTheme,
        language,
        setLanguage,
        t,
        globalSearchQuery,
        setGlobalSearchQuery,
        globalSearchFilter,
        setGlobalSearchFilter,
        clearConversationMessages,
        networkStatus,
        handleHardwareBack,
        viewingStoryId,
        setViewingStoryId,
        viewingUserId,
        setViewingUserId,
        conversations,
        activeConversation,
        messages: effectiveMessages,
        contacts,
        moments,
        sendMessage,
        expireViewOnceMessage,
        votePoll,
        markMessagesRead,
        addReaction,
        deleteMessage,
        togglePinConversation,
        toggleMuteConversation,
        startDirectConversation,
        createGroupConversation,
        searchUserBySplenderOrUsername,
        sendContactRequest,
        acceptContactRequest,
        declineContactRequest,
        blockContact,
        unblockContact,
        postMoment,
        toggleLikeMoment,
        voteMomentPoll,
        addMomentComment,
        recordMomentView,
        deleteMoment,
        activeCall,
        localStream,
        remoteStream,
        isCallMuted,
        isCallCameraOff,
        isSpeakerOn,
        isScreenSharing,
        isCallMinimized,
        setIsCallMinimized,
        speakerRoute,
        setSpeakerRoute,
        targetJumpMessageId,
        setTargetJumpMessageId,
        setConversationDisappearingTimer,
        sendBroadcastMessage,
        batchDeleteMessages,
        callDuration,
        startCall,
        acceptCall,
        endCall,
        toggleCallMute,
        toggleCallCamera,
        toggleSpeaker,
        toggleScreenShare,
        isUserOnline,
        sendTypingStatus,
        toasts,
        showToast,
        dismissToast,
        toggleDataSaver,
        mediaQuality,
        setMediaQuality,
        theme,
        setTheme,
        activeCategory,
        setActiveCategory,
        commandPaletteOpen,
        setCommandPaletteOpen,
        batterySaver,
        setBatterySaver,
        copyToClipboard,
        copiedId,
        disappearingMode,
        setDisappearingMode,
        linkExpiryDuration,
        setLinkExpiryDuration,
        lockChatThread,
        setLockChatThread,
        snapshotGuard,
        setSnapshotGuard,
        screenShareLock,
        setScreenShareLock,
        smartThreadSummaries,
        setSmartThreadSummaries,
        autoQuickReplies,
        setAutoQuickReplies,
        contextSuperEngine,
        setContextSuperEngine,
        vpnStatus,
        setVpnStatus,
        lockScreenShield,
        setLockScreenShield,
        fontSize,
        setFontSize,
        realtimeTranslation,
        setRealtimeTranslation,
        voiceCommandControl,
        setVoiceCommandControl,
        storageBreakdown,
        cleanStorageCache,
        cleanStorageCategory,
        isQuickPollModalOpen,
        setIsQuickPollModalOpen,
        startAiAssistantChat,
        adaptiveThemeSync,
        setAdaptiveThemeSync,
        preferredDarkAccent,
        setPreferredDarkAccent,
        preferredLightAccent,
        setPreferredLightAccent,
        autoLockTimer,
        setAutoLockTimer,
        isP2PStorageDashboardOpen,
        setIsP2PStorageDashboardOpen,
        isOfflineQueueModalOpen,
        setIsOfflineQueueModalOpen,
        isE2eeHealthModalOpen,
        setIsE2eeHealthModalOpen,
        isVoiceCommandOverlayOpen,
        setIsVoiceCommandOverlayOpen,
        p2pChannelState,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
