/**
 * Splender Chat — Centralized Aurora Nebula UI & Theme Engine (`src/context/ThemeContext.tsx`)
 *
 * Implements a dynamic Theme Provider supporting 6 core palettes (plus 3 extended aliases)
 * driven by semantic CSS variables (`--bg-primary`, `--bg-secondary`, `--bg-tertiary`,
 * `--accent-color`, `--accent-hover`, `--accent-glow`, `--text-primary`,
 * `--text-secondary`, `--border-subtle`, `--bubble-outgoing`, `--bubble-incoming`)
 * and smooth hardware-composited CSS transition orchestration.
 */

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  ReactNode,
} from 'react';
import { ThemeMode } from '../types';
import { HapticsService } from '../services/HapticsService';

export type SplenderCoreThemeId =
  | 'midnight_oled'
  | 'emerald_luxury'
  | 'indigo_dawn'
  | 'apricot_bloom'
  | 'teal_dusk'
  | 'rose_quartz';

export interface SplenderThemeDefinition {
  id: SplenderCoreThemeId;
  name: string;
  tagline: string;
  isDark: boolean;
  variables: {
    '--bg-primary': string;
    '--bg-secondary': string;
    '--bg-tertiary': string;
    '--accent-color': string;
    '--accent-hover': string;
    '--accent-glow': string;
    '--text-primary': string;
    '--text-secondary': string;
    '--border-subtle': string;
    '--bubble-outgoing': string;
    '--bubble-incoming': string;
    '--header-bg': string;
    '--header-text': string;
  };
}

export const SPLENDER_SIX_THEMES: Record<SplenderCoreThemeId, SplenderThemeDefinition> = {
  midnight_oled: {
    id: 'midnight_oled',
    name: 'Midnight OLED',
    tagline: 'Pure #000000 AMOLED deep-space canvas for zero-halo contrast and battery longevity',
    isDark: true,
    variables: {
      '--bg-primary': '#000000',
      '--bg-secondary': '#080C16',
      '--bg-tertiary': '#0F1626',
      '--accent-color': '#22D3EE',
      '--accent-hover': '#8B5CF6',
      '--accent-glow': 'rgba(34, 211, 238, 0.24)',
      '--text-primary': '#F4F7FF',
      '--text-secondary': '#A8B3CC',
      '--border-subtle': '#1E293B',
      '--bubble-outgoing': '#2563EB',
      '--bubble-incoming': '#0D1424',
      '--header-bg': '#000000',
      '--header-text': '#F4F7FF',
    },
  },
  emerald_luxury: {
    id: 'emerald_luxury',
    name: 'Emerald Luxury',
    tagline: 'Bio-luminescent obsidian paired with sovereign emerald and cyan highlights',
    isDark: true,
    variables: {
      '--bg-primary': '#05110E',
      '--bg-secondary': '#091D18',
      '--bg-tertiary': '#0F2922',
      '--accent-color': '#10B981',
      '--accent-hover': '#34D399',
      '--accent-glow': 'rgba(16, 185, 129, 0.25)',
      '--text-primary': '#ECFDF5',
      '--text-secondary': '#A7F3D0',
      '--border-subtle': '#143D32',
      '--bubble-outgoing': '#059669',
      '--bubble-incoming': '#0B241E',
      '--header-bg': '#05110E',
      '--header-text': '#ECFDF5',
    },
  },
  indigo_dawn: {
    id: 'indigo_dawn',
    name: 'Indigo Dawn',
    tagline: 'Signature Aurora Nebula obsidian glass with neon cyan and electric violet accents',
    isDark: true,
    variables: {
      '--bg-primary': '#080B14',
      '--bg-secondary': '#0D1424',
      '--bg-tertiary': '#131D32',
      '--accent-color': '#22D3EE',
      '--accent-hover': '#8B5CF6',
      '--accent-glow': 'rgba(34, 211, 238, 0.24)',
      '--text-primary': '#F4F7FF',
      '--text-secondary': '#A8B3CC',
      '--border-subtle': '#293650',
      '--bubble-outgoing': '#3B82F6',
      '--bubble-incoming': '#131D32',
      '--header-bg': '#080B14',
      '--header-text': '#F4F7FF',
    },
  },
  apricot_bloom: {
    id: 'apricot_bloom',
    name: 'Apricot Bloom',
    tagline: 'Crisp solar daylight prism with warm amber-apricot and cobalt accents',
    isDark: false,
    variables: {
      '--bg-primary': '#F8FAFF',
      '--bg-secondary': '#EEF2FF',
      '--bg-tertiary': '#E2E8F0',
      '--accent-color': '#EA580C',
      '--accent-hover': '#C2410C',
      '--accent-glow': 'rgba(234, 88, 12, 0.20)',
      '--text-primary': '#0F172A',
      '--text-secondary': '#475569',
      '--border-subtle': '#CBD5E1',
      '--bubble-outgoing': '#3B82F6',
      '--bubble-incoming': '#FFFFFF',
      '--header-bg': '#F8FAFF',
      '--header-text': '#0F172A',
    },
  },
  teal_dusk: {
    id: 'teal_dusk',
    name: 'Teal Dusk',
    tagline: 'Cryo pelagic deep-space canvas illuminated by neon cyan bioluminescence',
    isDark: true,
    variables: {
      '--bg-primary': '#061018',
      '--bg-secondary': '#0B1B28',
      '--bg-tertiary': '#112638',
      '--accent-color': '#22D3EE',
      '--accent-hover': '#06B6D4',
      '--accent-glow': 'rgba(34, 211, 238, 0.24)',
      '--text-primary': '#ECFEFF',
      '--text-secondary': '#99F6E4',
      '--border-subtle': '#1B3A4B',
      '--bubble-outgoing': '#0284C7',
      '--bubble-incoming': '#0E2231',
      '--header-bg': '#061018',
      '--header-text': '#ECFEFF',
    },
  },
  rose_quartz: {
    id: 'rose_quartz',
    name: 'Rose Quartz',
    tagline: 'Luminous starlight quartz surface paired with soft magenta-violet accents',
    isDark: false,
    variables: {
      '--bg-primary': '#FDF7FF',
      '--bg-secondary': '#F6ECFC',
      '--bg-tertiary': '#EDE0F7',
      '--accent-color': '#DB2777',
      '--accent-hover': '#BE185D',
      '--accent-glow': 'rgba(219, 39, 119, 0.20)',
      '--text-primary': '#1E132A',
      '--text-secondary': '#6B5280',
      '--border-subtle': '#E2CEF0',
      '--bubble-outgoing': '#7C3AED',
      '--bubble-incoming': '#FFFFFF',
      '--header-bg': '#FDF7FF',
      '--header-text': '#1E132A',
    },
  },
};

export const CORE_THEME_ORDER: SplenderCoreThemeId[] = [
  'midnight_oled',
  'emerald_luxury',
  'indigo_dawn',
  'apricot_bloom',
  'teal_dusk',
  'rose_quartz',
];

export function resolveCoreThemeId(input?: string | null): SplenderCoreThemeId {
  if (!input) return 'indigo_dawn';
  if (input in SPLENDER_SIX_THEMES) {
    return input as SplenderCoreThemeId;
  }
  // Map legacy aliases gracefully into the 6 canonical themes
  if (input === 'emerald') return 'emerald_luxury';
  if (input === 'cyber_indigo') return 'indigo_dawn';
  if (input === 'dark_amber') return 'midnight_oled';
  return 'indigo_dawn';
}

export function injectThemeCssVariables(
  themeId: SplenderCoreThemeId,
  animateTransition = true
): SplenderThemeDefinition {
  const definition = SPLENDER_SIX_THEMES[themeId] || SPLENDER_SIX_THEMES.indigo_dawn;
  if (typeof document === 'undefined') {
    return definition;
  }

  const root = document.documentElement;
  const body = document.body;

  if (animateTransition) {
    root.classList.add('theme-transition');
    body.classList.add('theme-transition');
  }

  // Apply canonical CSS custom properties required across all components
  Object.entries(definition.variables).forEach(([cssVar, value]) => {
    root.style.setProperty(cssVar, value);
  });

  // Synchronize bridge variables so surfaces stay cohesive
  root.style.setProperty('--bg-main', definition.variables['--bg-primary']);
  root.style.setProperty('--bg-card', definition.variables['--bg-secondary']);
  root.style.setProperty('--bg-input', definition.variables['--bg-tertiary']);
  root.style.setProperty('--theme-primary', definition.variables['--header-bg']);
  root.style.setProperty('--theme-accent', definition.variables['--accent-color']);
  root.style.setProperty('--theme-surface', definition.variables['--bg-primary']);
  root.style.setProperty('--theme-header', definition.variables['--header-bg']);

  root.setAttribute('data-theme', definition.id);
  root.setAttribute('data-visual-theme', definition.id);
  root.classList.toggle('dark', definition.isDark);

  body.className = [
    `theme-${definition.id}`,
    `theme-${definition.id.replace(/_/g, '-')}`,
    animateTransition ? 'theme-transition' : '',
  ]
    .filter(Boolean)
    .join(' ');

  return definition;
}

export interface ThemeContextValue {
  themeId: SplenderCoreThemeId;
  currentTheme: SplenderThemeDefinition;
  availableThemes: SplenderThemeDefinition[];
  isDark: boolean;
  isTransitioning: boolean;
  setThemeById: (nextTheme: SplenderCoreThemeId | ThemeMode) => void;
  cycleNextTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

const STORAGE_KEY_PRIMARY = 'splender_elite_theme';
const STORAGE_KEY_VISUAL = 'splender_visual_theme';

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [themeId, setThemeIdState] = useState<SplenderCoreThemeId>(() => {
    if (typeof window === 'undefined') return 'indigo_dawn';
    const saved =
      localStorage.getItem(STORAGE_KEY_PRIMARY) || localStorage.getItem(STORAGE_KEY_VISUAL);
    return resolveCoreThemeId(saved);
  });

  const [isTransitioning, setIsTransitioning] = useState(false);
  const transitionTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Initial mount variable application without flash
  useEffect(() => {
    injectThemeCssVariables(themeId, false);
  }, []);

  const setThemeById = useCallback((nextInput: SplenderCoreThemeId | ThemeMode) => {
    const resolved = resolveCoreThemeId(nextInput);
    setIsTransitioning(true);
    setThemeIdState(resolved);

    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_PRIMARY, resolved);
      localStorage.setItem(STORAGE_KEY_VISUAL, resolved);
      localStorage.setItem(
        'splender_dark_mode',
        String(SPLENDER_SIX_THEMES[resolved].isDark)
      );
      localStorage.setItem(
        'splender_theme_mode',
        SPLENDER_SIX_THEMES[resolved].isDark ? 'dark' : 'light'
      );
      window.dispatchEvent(
        new CustomEvent('splender:theme-changed', { detail: { themeId: resolved } })
      );
    }

    injectThemeCssVariables(resolved, true);
    void HapticsService.selectionChanged();

    if (transitionTimerRef.current) {
      clearTimeout(transitionTimerRef.current);
    }
    transitionTimerRef.current = setTimeout(() => {
      setIsTransitioning(false);
    }, 240);
  }, []);

  const cycleNextTheme = useCallback(() => {
    const idx = CORE_THEME_ORDER.indexOf(themeId);
    const next = CORE_THEME_ORDER[(idx + 1) % CORE_THEME_ORDER.length];
    setThemeById(next);
  }, [themeId, setThemeById]);

  // Listen to external theme updates (e.g., from ChatContext calls) to keep 100% single-source sync
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onExternalSync = (ev: Event) => {
      const detail = (ev as CustomEvent<{ themeId?: string }>).detail;
      if (detail?.themeId) {
        const nextResolved = resolveCoreThemeId(detail.themeId);
        setThemeIdState((prev) => {
          if (prev !== nextResolved) {
            injectThemeCssVariables(nextResolved, true);
            return nextResolved;
          }
          return prev;
        });
      }
    };
    window.addEventListener('splender:external-theme-sync', onExternalSync);
    return () => {
      window.removeEventListener('splender:external-theme-sync', onExternalSync);
      if (transitionTimerRef.current) {
        clearTimeout(transitionTimerRef.current);
      }
    };
  }, []);

  const currentTheme = SPLENDER_SIX_THEMES[themeId];
  const availableThemes = CORE_THEME_ORDER.map((id) => SPLENDER_SIX_THEMES[id]);

  return (
    <ThemeContext.Provider
      value={{
        themeId,
        currentTheme,
        availableThemes,
        isDark: currentTheme.isDark,
        isTransitioning,
        setThemeById,
        cycleNextTheme,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return ctx;
}
