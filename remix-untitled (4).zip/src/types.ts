export type MediaQuality = 'medium' | 'high' | 'hd' | 'original';

export interface UserProfile {
  uid: string;
  splenderId: string; // e.g. "SP-492817"
  username: string; // e.g. "kalpak"
  normalizedUsername: string; // e.g. "kalpak"
  displayName: string;
  avatar: string;
  bio: string;
  isAnonymous: boolean;
  linkedProviders?: string[]; // e.g. ["google.com", "password"]
  email?: string;
  createdAt: number;
  updatedAt: number;
  lastSeen: number;
  isOnline?: boolean;
  typingTo?: string | null;
  status: 'online' | 'offline' | 'busy' | 'away';
  dataSaver: boolean;
  readReceipts: boolean;
  lastSeenPrivacy: 'everyone' | 'contacts' | 'nobody';
  mediaQuality?: MediaQuality;
  publicKey?: string; // RSA-OAEP-2048 SPKI Base64
  ecdhPublicKey?: string; // ECDH P-256 canonical JWK JSON
  publicKeyFingerprint?: string; // SHA-256 hex over identity public keys
}

export interface ContactItem {
  targetUid: string;
  splenderId: string;
  username: string;
  displayName: string;
  avatar: string;
  bio?: string;
  state: 'pending' | 'accepted' | 'declined' | 'blocked';
  updatedAt: number;
  isIncoming?: boolean;
}

export interface MessageReaction {
  emoji: string;
  count: number;
  uids: string[];
}

export interface MessageReplyTo {
  id: string;
  senderName: string;
  text: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderUid: string;
  senderId?: string;
  senderSplenderId: string;
  senderName: string;
  senderAvatar?: string;
  text?: string;
  type: 'text' | 'image' | 'video' | 'audio' | 'system' | 'document' | 'location' | 'contact' | 'poll' | 'event' | 'sticker';
  mediaUrl?: string;
  thumbnailUrl?: string;
  mediaQuality?: MediaQuality;
  audioDuration?: number; // in seconds
  fileName?: string;
  fileSize?: string;
  location?: { lat: number; lng: number; name?: string; address?: string };
  contactPayload?: { name: string; phone?: string; splenderId?: string };
  pollPayload?: { question: string; options: { id: string; text: string; votes: string[] }[]; multiSelect?: boolean };
  timestamp: number;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  idempotencyKey?: string;
  isDeleted?: boolean;
  isEdited?: boolean;
  starred?: Record<string, boolean>; // uid -> boolean
  pinned?: boolean;
  forwarded?: boolean;
  reactions?: MessageReaction[];
  replyTo?: MessageReplyTo;
  expiresAt?: number; // For self-destructing / disappearing messages
  scheduledFor?: number; // Scheduled send timestamp
  translation?: { text: string; targetLang: string };
  transcription?: string; // Voice-note AI transcription
  transcript?: string;
  isAudio?: boolean;
  isViewOnce?: boolean; // View-Once self-destructing media
  viewOnceOpened?: boolean; // Has been viewed and media wiped
  isViewed?: boolean; // Viewed status flag
  isEncrypted?: boolean; // Authenticated E2EE
  encryptionProtocol?: 'DOUBLE_RATCHET_V3' | 'AES_GCM_256' | 'SPLENDER_AUTHENTICATED_AES_GCM_256';
  encryptedEnvelope?: {
    ciphertext: string;
    iv: string;
    ratchetStep: number;
    protocol: 'SPLENDER_AUTHENTICATED_AES_GCM_256' | 'DOUBLE_RATCHET_V3';
    hmac: string;
  };
  mediaEncryption?: {
    ivBase64: string;
    hmacHex: string;
    mimeType: string;
    sha256Hex: string;
    cekBase64?: string;
  };
  transportMode?: 'webrtc_p2p' | 'turn_relay' | 'e2ee_relay';
  editedAt?: number; // Message edit timestamp
  linkPreview?: { title?: string; description?: string; image?: string; domain?: string; url?: string };
  fileTransferPayload?: {
    fileName: string;
    fileSize: number;
    chunksTotal: number;
    chunksTransferred: number;
    status: 'transferring' | 'paused' | 'completed' | 'queued_offline' | 'failed';
    hash?: string;
    speedKbps?: number;
    transport?: 'webrtc_datachannel' | 'turn_relay' | 'encrypted_relay';
  };
}

export interface Conversation {
  id: string;
  isGroup: boolean;
  groupName?: string;
  groupAvatar?: string;
  participants: string[]; // array of UIDs
  participantSplenderIds?: Record<string, string>; // uid -> splenderId
  participantNames?: Record<string, string>; // uid -> displayName
  participantAvatars?: Record<string, string>; // uid -> avatar
  participantEcdhKeys?: Record<string, string>; // uid -> ECDH P-256 canonical JWK JSON
  wrappedKeys?: Record<string, string>; // uid -> RSA-OAEP-2048 wrapped 256-bit session key (Base64)
  keyVersion?: number;
  unreadCounts?: Record<string, number>; // uid -> count
  pinned?: Record<string, boolean>; // uid -> boolean
  muted?: Record<string, boolean>; // uid -> boolean
  isFavorite?: Record<string, boolean>; // uid -> boolean
  isArchived?: Record<string, boolean>; // uid -> boolean
  screenGuardEnabled?: boolean; // OS/UI anti-screenshot protection
  isPeerVerified?: boolean; // Cryptographic safety fingerprint verified
  relayMode?: 'direct_p2p' | 'turn_relay' | 'onion_relay' | 'turn_proxy';
  isCommunityGroup?: boolean;
  communityId?: string;
  roles?: Record<string, 'admin' | 'moderator' | 'member'>;
  onlyAdminsCanSend?: boolean;
  groupAdminUid?: string;
  lastMessage?: {
    id: string;
    text: string;
    senderUid: string;
    senderId?: string;
    type: 'text' | 'image' | 'video' | 'audio' | 'system' | 'document' | 'location' | 'contact' | 'poll' | 'event' | 'sticker';
    timestamp: number;
    status: 'sending' | 'sent' | 'delivered' | 'read';
    isViewOnce?: boolean;
    isViewed?: boolean;
    viewOnceOpened?: boolean;
    encryptedEnvelope?: {
      ciphertext: string;
      iv: string;
      ratchetStep: number;
      protocol: 'SPLENDER_AUTHENTICATED_AES_GCM_256' | 'DOUBLE_RATCHET_V3';
      hmac: string;
    };
  };
  typing?: Record<string, boolean>; // uid -> boolean
  updatedAt: number;
  disappearingTimerSeconds?: number; // e.g., 0, 86400 (24h), 604800 (7d), 7776000 (90d)
  isLockedWithBiometrics?: boolean;
  pinnedMessageId?: string;
  pinnedAt?: string | number;
  inviteCode?: string;
  inviteCodeCreatedAt?: number;
  category?: 'personal' | 'work' | 'college';
  wallpaper?: string;
  isLocked?: boolean;
}

export type ThemeMode =
  | 'indigo_dawn'
  | 'apricot_bloom'
  | 'teal_dusk'
  | 'rose_quartz'
  | 'emerald'
  | 'midnight_oled'
  | 'emerald_luxury'
  | 'cyber_indigo'
  | 'dark_amber';
export type ChatCategory = 'all' | 'personal' | 'work' | 'college' | 'unread';

export interface ChatThread {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  isPinned?: boolean;
  isLocked?: boolean;
  category: 'personal' | 'work' | 'college';
  wallpaper?: string;
  messages: Message[];
}

export interface MomentPollOption {
  text: string;
  votes: string[]; // UIDs of voters
}

export interface MomentComment {
  id: string;
  momentId?: string;
  userUid: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: number;
  updatedAt?: number;
}

export interface Moment {
  id: string;
  ownerUid: string;
  ownerSplenderId: string;
  ownerName: string;
  ownerAvatar: string;
  mediaUrl: string;
  mediaType?: 'image' | 'video' | 'audio' | 'text';
  mediaQuality?: MediaQuality;
  thumbnailUrl?: string;
  caption: string;
  bgColor?: string;
  privacy?: 'everyone' | 'contacts' | 'except' | 'only' | 'private';
  allowedViewerUids?: string[];
  excludedViewerUids?: string[];
  createdAt: number;
  updatedAt?: number;
  expiresAt: number;
  likes: string[]; // UIDs
  viewers?: string[]; // UIDs
  poll?: {
    question: string;
    options: MomentPollOption[];
  };
  comments?: MomentComment[];
  isPermanentFeed?: boolean;
  arFilter?: string;
}

export interface BroadcastChannel {
  id: string;
  name: string;
  description: string;
  avatar: string;
  creatorUid: string;
  creatorName: string;
  subscriberUids: string[];
  lastUpdate: string;
  timestamp: number;
  isVerified?: boolean;
}

export interface CallLogItem {
  id: string;
  partnerUid: string;
  partnerName: string;
  partnerAvatar: string;
  partnerSplenderId: string;
  type: 'voice' | 'video';
  direction: 'incoming' | 'outgoing' | 'missed';
  timestamp: number;
  duration?: number;
}

export interface SplenderRewardsState {
  coins: number;
  streakDays: number;
  lastClaimDate: string;
  unlockedThemes: string[];
  unlockedBadges: string[];
}

export interface CallSignal {
  id: string;
  callerUid: string;
  callerSplenderId: string;
  callerName: string;
  callerAvatar: string;
  recipientUid: string;
  recipientSplenderId?: string;
  type: 'voice' | 'video';
  callState: 'calling' | 'ringing' | 'connecting' | 'connected' | 'ended' | 'declined';
  offer?: RTCSessionDescriptionInit;
  answer?: RTCSessionDescriptionInit;
  callerCandidates?: RTCIceCandidateInit[];
  recipientCandidates?: RTCIceCandidateInit[];
  createdAt: number;
  updatedAt: number;
  duration?: number;
  isScreenSharing?: boolean;
}

export type VisualThemeId =
  | 'indigo_dawn'
  | 'apricot_bloom'
  | 'teal_dusk'
  | 'rose_quartz'
  | 'emerald'
  | 'midnight_oled'
  | 'royal_indigo'
  | 'emerald_luxury'
  | 'cyber_indigo'
  | 'dark_amber';

export type ChatWallpaperPresetId =
  | 'soft_ivory'
  | 'pistachio_glow'
  | 'purple_aurora'
  | 'midnight_glass'
  | 'midnight_oled'
  | 'royal_indigo'
  | 'custom_url';

export interface ChatWallpaperSetting {
  preset: ChatWallpaperPresetId;
  customUrl?: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info' | 'warning' | 'error';
  senderAvatar?: string;
  conversationId?: string;
  replyAction?: (replyText: string) => void;
  onView?: () => void;
  quickReplies?: string[];
}

export interface Community {
  id: string;
  name: string;
  description: string;
  avatar: string;
  creatorUid: string;
  createdAt: number;
  announcementGroupId: string;
  groupIds: string[];
  membersCount: number;
}

export interface WhatsAppChannel {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  description: string;
  verified: boolean;
  followersCount: number;
  category: 'News' | 'Sports' | 'Tech' | 'Entertainment' | 'Lifestyle';
  lastPost: {
    text: string;
    mediaUrl?: string;
    timestamp: number;
    reactionsCount: number;
  };
  isFollowing?: boolean;
}

export interface StatusUpdate {
  id: string;
  uid: string;
  authorName: string;
  authorAvatar: string;
  type: 'text' | 'image' | 'video' | 'audio';
  mediaUrl?: string;
  textContent?: string;
  bgColor?: string;
  caption?: string;
  timestamp: number;
  expiresAt: number;
  viewsCount: number;
  viewers?: string[];
  isViewed?: boolean;
}

export type NavigationTab =
  | 'chats'
  | 'updates'
  | 'calls'
  | 'settings'
  | 'stories'; // backward compat

export type AudioSpeakerRoute = 'speaker' | 'earpiece' | 'bluetooth';

export interface GalleryMediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnailUrl?: string;
  timestamp: number;
  senderName: string;
  caption?: string;
}

export interface GalleryDocItem {
  id: string;
  fileName: string;
  fileSize?: string;
  url: string;
  timestamp: number;
  senderName: string;
}

export interface GalleryLinkItem {
  id: string;
  url: string;
  title?: string;
  timestamp: number;
  senderName: string;
}

