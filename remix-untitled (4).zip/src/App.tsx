import React, { Suspense, useState } from 'react';
import { ChatProvider, useChat } from './context/ChatContext';
import { TopStatusBar } from './components/TopStatusBar';
import { BottomNavBar, TabType } from './components/BottomNavBar';
import { ChatsList } from './components/ChatsList';
import { ChatRoom } from './components/ChatRoom';
import { UpdatesTab } from './components/UpdatesTab';
import { CallsTab } from './components/CallsTab';
import { Toast } from './components/Toast';
import { BiometricAuthScreen } from './components/BiometricAuthScreen';
import { OnboardingAuthScreen } from './components/OnboardingAuthScreen';
import { ErrorBoundary } from './components/ErrorBoundary';
import { PushNotificationBanner } from './components/PushNotificationBanner';
import { StarredMessagesModal } from './components/StarredMessagesModal';
import { CameraModal } from './components/CameraModal';
import { BroadcastModal } from './components/BroadcastModal';
import { NewGroupModal } from './components/NewGroupModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { QuickPollModal } from './components/QuickPollModal';
import { SplenderLogo } from './components/SplenderLogo';
import { Lock, ShieldCheck, QrCode, Smartphone } from 'lucide-react';

// Code Splitting with React.lazy for secondary modals
const DeveloperDocsModal = React.lazy(() =>
  import('./components/DeveloperDocsModal').then((m) => ({ default: m.DeveloperDocsModal }))
);
const MyEyesOnlyModal = React.lazy(() =>
  import('./components/MyEyesOnlyModal').then((m) => ({ default: m.MyEyesOnlyModal }))
);
const QrCodeScannerModal = React.lazy(() =>
  import('./components/QrCodeScannerModal').then((m) => ({ default: m.QrCodeScannerModal }))
);
const IdentityAccessModal = React.lazy(() =>
  import('./components/IdentityAccessModal').then((m) => ({ default: m.IdentityAccessModal }))
);
const PrivacySettingsModal = React.lazy(() =>
  import('./components/PrivacySettingsModal').then((m) => ({ default: m.PrivacySettingsModal }))
);
const SettingsModal = React.lazy(() =>
  import('./components/SettingsModal').then((m) => ({ default: m.SettingsModal }))
);
const UserProfileModal = React.lazy(() =>
  import('./components/UserProfileModal').then((m) => ({ default: m.UserProfileModal }))
);
const StoryViewerModal = React.lazy(() =>
  import('./components/StoryViewerModal').then((m) => ({ default: m.StoryViewerModal }))
);
const CallModal = React.lazy(() =>
  import('./components/CallModal').then((m) => ({ default: m.CallModal }))
);
const CallPipMiniPlayer = React.lazy(() =>
  import('./components/CallPipMiniPlayer').then((m) => ({ default: m.CallPipMiniPlayer }))
);
const P2PStorageCleanupModal = React.lazy(() =>
  import('./components/P2PStorageCleanupModal').then((m) => ({ default: m.P2PStorageCleanupModal }))
);
const E2eeHealthModal = React.lazy(() =>
  import('./components/E2eeHealthModal').then((m) => ({ default: m.E2eeHealthModal }))
);
const OfflineQueueManagerModal = React.lazy(() =>
  import('./components/OfflineQueueManagerModal').then((m) => ({ default: m.OfflineQueueManagerModal }))
);
const VoiceCommandOverlayModal = React.lazy(() =>
  import('./components/VoiceCommandOverlayModal').then((m) => ({ default: m.VoiceCommandOverlayModal }))
);

function TabLoadingFallback() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-3">
      <div className="w-7 h-7 rounded-full border-2 border-[#22D3EE] border-t-transparent animate-spin" />
      <span className="text-xs text-slate-500 dark:text-[#A8B3CC]">Loading workspace...</span>
    </div>
  );
}

function DesktopIdleWorkspace() {
  const {
    currentUserProfile,
    setIsIdentityModalOpen,
    setIsQrScannerOpen,
    setIsE2eeHealthModalOpen,
  } = useChat();

  return (
    <div className="hidden lg:flex flex-1 flex-col items-center justify-center p-12 bg-[#F4F7FF] dark:bg-[#080B14] dark:aurora-nebula-bg text-center select-none relative overflow-hidden">
      <div className="max-w-lg space-y-7 relative z-10">
        <div className="flex flex-col items-center space-y-4">
          <SplenderLogo size="xl" />
          <div className="space-y-2">
            <h2 className="font-display text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F4F7FF] text-balance">
              Splender Chat
            </h2>
            <p className="text-sm text-slate-600 dark:text-[#A8B3CC] leading-relaxed max-w-md mx-auto">
              Select a conversation from the directory or verify a peer QR code to exchange Signal-ratchet messages and SHA-256 verified files directly over WebRTC DataChannels.
            </p>
          </div>
        </div>

        {/* Clean unboxed metadata with typographic separators */}
        <div className="flex items-center justify-center gap-2.5 text-xs text-slate-500 dark:text-[#A8B3CC] flex-wrap">
          <span className="inline-flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-[#3B82F6] dark:text-[#22D3EE]" />
            Zero-Plaintext Control Plane
          </span>
          <span aria-hidden="true">·</span>
          <span>SHA-256 Chunked P2P</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">Android 17 (API 37)</span>
        </div>

        <div className="flex items-center justify-center gap-3 pt-1">
          <button
            type="button"
            onClick={() => setIsIdentityModalOpen(true)}
            className="min-h-[44px] px-5 py-2.5 rounded-xl aurora-cta-gradient text-[#F4F7FF] text-xs font-semibold transition-transform active:scale-[0.98] cursor-pointer whitespace-nowrap shrink-0"
          >
            {currentUserProfile?.splenderId ? `My ID: ${currentUserProfile.splenderId}` : 'Sovereign Identity'}
          </button>
          <button
            type="button"
            onClick={() => setIsQrScannerOpen(true)}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white/90 dark:bg-[#131D32]/90 border border-slate-200 dark:border-[#293650] hover:border-[#3B82F6] dark:hover:border-[#22D3EE]/60 text-slate-800 dark:text-[#F4F7FF] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <QrCode className="w-4 h-4 text-[#3B82F6] dark:text-[#22D3EE]" />
            <span>Scan Peer QR</span>
          </button>
          <button
            type="button"
            onClick={() => setIsE2eeHealthModalOpen(true)}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white/90 dark:bg-[#131D32]/90 border border-slate-200 dark:border-[#293650] hover:border-[#8B5CF6] dark:hover:border-[#8B5CF6]/60 text-slate-800 dark:text-[#F4F7FF] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <ShieldCheck className="w-4 h-4 text-[#8B5CF6] dark:text-[#8B5CF6]" />
            <span>Crypto Vault</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatAppContent() {
  const {
    firebaseUser,
    currentUserProfile,
    isLoadingAuth,
    activeConversationId,
    activeTab,
    setActiveTab,
    conversations,
    isAppLocked,
    unlockApp,
    isQrScannerOpen,
    setIsQrScannerOpen,
    isIdentityModalOpen,
    setIsIdentityModalOpen,
    isPrivacySettingsModalOpen,
    setIsPrivacySettingsModalOpen,
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    isDevDocsModalOpen,
    setIsDevDocsModalOpen,
    isVaultModalOpen,
    setIsVaultModalOpen,
    viewingStoryId,
    darkMode,
  } = useChat();

  const [isStarredModalOpen, setIsStarredModalOpen] = useState(false);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [isNewBroadcastModalOpen, setIsNewBroadcastModalOpen] = useState(false);
  const [isNewGroupModalOpen, setIsNewGroupModalOpen] = useState(false);

  const unreadCount = conversations.reduce((acc, c) => {
    if (!firebaseUser) return acc;
    return acc + (c.unreadCounts?.[firebaseUser.uid] || 0);
  }, 0);

  return (
    <div
      className={`min-h-[100dvh] w-full ${
        darkMode
          ? 'bg-[#080B14] aurora-nebula-bg text-[#F4F7FF]'
          : 'bg-[#EEF2FF] text-slate-900'
      } flex flex-col items-center justify-center p-0 lg:p-5 select-none transition-colors duration-200 font-sans`}
    >
      {/* Responsive Mobile Full-Bleed + Desktop Multi-Column Workspace */}
      <div
        className={`w-full lg:max-w-7xl h-[100dvh] lg:h-[88vh] lg:min-h-[680px] no-scrollbar ${
          darkMode
            ? 'bg-[#080B14]/95 text-[#F4F7FF] lg:border-[#293650] lg:shadow-[0_24px_64px_-16px_rgba(3,6,14,0.88)]'
            : 'bg-[#F8FAFF] text-slate-900 lg:border-slate-200 lg:shadow-xl'
        } flex flex-col lg:flex-row relative overflow-hidden lg:rounded-3xl lg:border transition-colors duration-200`}
      >
        {isLoadingAuth ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4 aurora-nebula-bg">
            <SplenderLogo size="xl" />
            <div>
              <h2 className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-[#F4F7FF]">
                Splender Chat
              </h2>
              <p className="text-xs text-slate-500 dark:text-[#A8B3CC] mt-1">
                Initializing Android 17 (API 37) cryptographic vault...
              </p>
            </div>
          </div>
        ) : !firebaseUser || !currentUserProfile ? (
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            <header className="px-4 lg:px-6 h-[48px] flex items-center justify-between gap-8 border-b border-slate-200/80 dark:border-[#293650]/80 bg-white/85 dark:bg-[#080B14]/85 backdrop-blur-xl shrink-0">
              <div className="flex items-center gap-2.5 shrink-0">
                <SplenderLogo size="xs" />
                <span className="font-display text-sm font-bold tracking-tight text-slate-900 dark:text-[#F4F7FF] whitespace-nowrap">
                  Splender Chat
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-[#A8B3CC] tabular-nums whitespace-nowrap shrink-0">
                Android 17 · API 37
              </span>
            </header>
            <OnboardingAuthScreen />
          </div>
        ) : (
          <>
            {/* Left Navigation & Directory Column */}
            <div
              className={`${
                activeConversationId ? 'hidden lg:flex' : 'flex'
              } w-full lg:w-[390px] xl:w-[420px] lg:shrink-0 flex-col h-full lg:border-r border-slate-200 dark:border-[#293650] bg-[#F8FAFF] dark:bg-[#0D1424] overflow-hidden`}
            >
              <TopStatusBar
                onSearchClick={() => {
                  setActiveTab('chats');
                  setTimeout(() => {
                    const searchEl = document.querySelector(
                      'input[placeholder*="Search"]'
                    ) as HTMLInputElement;
                    if (searchEl) searchEl.focus();
                  }, 50);
                }}
                onCameraClick={() => setIsCameraModalOpen(true)}
                onNewGroupClick={() => setIsNewGroupModalOpen(true)}
                onNewBroadcastClick={() => setIsNewBroadcastModalOpen(true)}
                onProfileClick={() => setIsIdentityModalOpen(true)}
                onStarredMessagesClick={() => setIsStarredModalOpen(true)}
                onSettingsClick={() => setIsSettingsModalOpen(true)}
                onIdentityClick={() => setIsIdentityModalOpen(true)}
                currentUser={{
                  name: currentUserProfile.displayName,
                  avatarUrl: currentUserProfile.avatar,
                }}
              />

              <main className="flex-1 flex flex-col overflow-hidden relative no-scrollbar bg-[#F8FAFF] dark:bg-[#080B14]">
                <Suspense fallback={<TabLoadingFallback />}>
                  <div key={activeTab} className="flex-1 flex flex-col h-full tab-fade-enter overflow-hidden">
                    {activeTab === 'chats' && <ChatsList />}
                    {(activeTab === 'updates' || activeTab === 'stories' || (activeTab as any) === 'moments') && (
                      <UpdatesTab onCameraClick={() => setActiveTab('updates')} />
                    )}
                    {activeTab === 'calls' && <CallsTab />}
                    {activeTab !== 'chats' &&
                      activeTab !== 'updates' &&
                      activeTab !== 'stories' &&
                      (activeTab as any) !== 'moments' &&
                      activeTab !== 'calls' && <ChatsList />}
                  </div>
                </Suspense>
              </main>

              <BottomNavBar
                activeTab={
                  activeTab === 'calls'
                    ? 'calls'
                    : activeTab === 'updates' || activeTab === 'stories' || (activeTab as any) === 'moments'
                    ? 'updates'
                    : 'chats'
                }
                setActiveTab={(tab: TabType) => {
                  if (tab === 'settings') {
                    setIsSettingsModalOpen(true);
                  } else {
                    setActiveTab(tab as any);
                  }
                }}
                unreadCount={unreadCount}
              />
            </div>

            {/* Right Conversation Pane */}
            {activeConversationId ? (
              <div key="chatroom" className="flex-1 flex flex-col h-full tab-fade-enter overflow-hidden">
                <ChatRoom />
              </div>
            ) : (
              <DesktopIdleWorkspace />
            )}
          </>
        )}

        {/* Floating In-App Push Notification Banner */}
        <PushNotificationBanner />

        {/* Modals & Overlays */}
        <Suspense fallback={null}>
          <UserProfileModal />
          {viewingStoryId && <StoryViewerModal />}
          <CallModal />
          <CallPipMiniPlayer />
        </Suspense>
        <Toast />
        <QuickPollModal />

        <StarredMessagesModal
          isOpen={isStarredModalOpen}
          onClose={() => setIsStarredModalOpen(false)}
        />

        <CameraModal
          isOpen={isCameraModalOpen}
          onClose={() => setIsCameraModalOpen(false)}
        />

        <BroadcastModal
          isOpen={isNewBroadcastModalOpen}
          onClose={() => setIsNewBroadcastModalOpen(false)}
        />

        <NewGroupModal
          isOpen={isNewGroupModalOpen}
          onClose={() => setIsNewGroupModalOpen(false)}
        />

        <BiometricAuthScreen
          isOpen={isAppLocked}
          onSuccess={unlockApp}
          title="Splender Privacy Lock"
          subtitle="Touch the fingerprint sensor to unlock or enter your 6-digit backup PIN"
          allowCancel={false}
        />

        <CommandPaletteModal />

        <Suspense fallback={null}>
          {isQrScannerOpen && (
            <QrCodeScannerModal
              isOpen={isQrScannerOpen}
              onClose={() => setIsQrScannerOpen(false)}
            />
          )}

          {isIdentityModalOpen && (
            <IdentityAccessModal
              isOpen={isIdentityModalOpen}
              onClose={() => setIsIdentityModalOpen(false)}
            />
          )}

          {isPrivacySettingsModalOpen && (
            <PrivacySettingsModal
              isOpen={isPrivacySettingsModalOpen}
              onClose={() => setIsPrivacySettingsModalOpen(false)}
            />
          )}

          {isSettingsModalOpen && (
            <SettingsModal
              isOpen={isSettingsModalOpen}
              onClose={() => setIsSettingsModalOpen(false)}
            />
          )}

          {isDevDocsModalOpen && (
            <DeveloperDocsModal
              isOpen={isDevDocsModalOpen}
              onClose={() => setIsDevDocsModalOpen(false)}
            />
          )}

          {isVaultModalOpen && (
            <MyEyesOnlyModal
              isOpen={isVaultModalOpen}
              onClose={() => setIsVaultModalOpen(false)}
            />
          )}

          <P2PStorageCleanupModal />
          <E2eeHealthModal />
          <OfflineQueueManagerModal />
          <VoiceCommandOverlayModal />
        </Suspense>
      </div>

      {/* Desktop Status Footer (hidden on mobile to preserve 85%+ open scrollable viewport) */}
      <div
        className={`hidden lg:flex items-center justify-between w-full max-w-7xl mt-2.5 px-1 text-xs ${
          darkMode ? 'text-[#A8B3CC]' : 'text-slate-500'
        }`}
      >
        <div className="flex items-center gap-2.5 tracking-tight">
          <SplenderLogo size="xs" />
          <span className={`${darkMode ? 'text-[#F4F7FF]' : 'text-slate-900'} font-display font-semibold`}>
            Splender Chat
          </span>
          <span aria-hidden="true">·</span>
          <span>Signal-Grade P2P Encrypted Messenger</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-mono tabular-nums">
          <Smartphone className="w-3.5 h-3.5 text-[#3B82F6] dark:text-[#22D3EE]" />
          <span>Android 17 Edition (API 37)</span>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ChatProvider>
        <ChatAppContent />
      </ChatProvider>
    </ErrorBoundary>
  );
}
