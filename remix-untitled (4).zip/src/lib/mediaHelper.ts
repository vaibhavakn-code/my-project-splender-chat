// src/lib/mediaHelper.ts
/**
 * Safe WebRTC UserMedia helper with graceful fallback for headless browsers,
 * virtualized environments, and devices lacking hardware camera/microphone.
 */

export async function getSafeUserMedia(constraints: MediaStreamConstraints): Promise<{
  stream: MediaStream;
  isSimulated: boolean;
}> {
  if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    return {
      stream: createSimulatedMediaStream(Boolean(constraints.video)),
      isSimulated: true,
    };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    return { stream, isSimulated: false };
  } catch (err: any) {
    const errorMsg = String(err?.message || err?.name || err);
    console.warn('Initial getUserMedia acquisition attempt failed:', errorMsg);

    // If video + audio was requested and failed (often due to missing webcam), try audio only
    if (constraints.video && constraints.audio) {
      try {
        const audioOnlyStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        // Add a blank video track if video was requested
        const canvasStream = createSimulatedCanvasStream();
        const videoTrack = canvasStream.getVideoTracks()[0];
        if (videoTrack) {
          audioOnlyStream.addTrack(videoTrack);
        }
        return { stream: audioOnlyStream, isSimulated: true };
      } catch (audioErr) {
        console.warn('Audio-only fallback also failed, falling back to simulated stream:', audioErr);
      }
    }

    // If audio-only was requested but no microphone exists (e.g. cloud VM / CI runner)
    const simulated = createSimulatedMediaStream(Boolean(constraints.video));
    return { stream: simulated, isSimulated: true };
  }
}

/**
 * Creates a valid synthetic MediaStream with a silent audio track and optional blank video track.
 */
export function createSimulatedMediaStream(includeVideo: boolean): MediaStream {
  const stream = new MediaStream();

  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioCtx) {
      const audioCtx = new AudioCtx();
      const dest = audioCtx.createMediaStreamDestination();
      const silentAudioTrack = dest.stream.getAudioTracks()[0];
      if (silentAudioTrack) {
        stream.addTrack(silentAudioTrack);
      }
    }
  } catch (e) {
    console.debug('Could not create synthetic AudioContext track:', e);
  }

  if (includeVideo) {
    try {
      const canvasStream = createSimulatedCanvasStream();
      const videoTrack = canvasStream.getVideoTracks()[0];
      if (videoTrack) {
        stream.addTrack(videoTrack);
      }
    } catch (e) {
      console.debug('Could not create synthetic canvas track:', e);
    }
  }

  return stream;
}

function createSimulatedCanvasStream(): MediaStream {
  if (typeof document === 'undefined') return new MediaStream();
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, 640, 480);
    ctx.fillStyle = '#06B6D4';
    ctx.font = '24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Splender Virtual Video Stream', 320, 240);
  }
  return (canvas as any).captureStream ? (canvas as any).captureStream(10) : new MediaStream();
}
