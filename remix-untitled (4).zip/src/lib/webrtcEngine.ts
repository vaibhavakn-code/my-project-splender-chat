/**
 * Splender Real-Time WebRTC DataChannel & P2P Media Engine
 *
 * Implements genuine peer-to-peer direct communication:
 * 1. Standalone RTCDataChannel negotiation via minimal ephemeral `p2p_signals` (SDP/ICE only)
 * 2. Low-latency direct device-to-device messaging with zero cloud message storage
 * 3. Cryptographic SHA-256 per-chunk & full-file verification with bufferedAmount backpressure
 * 4. Automatic ICE restart recovery on network handoff (Wi-Fi <-> Cellular)
 */

import { SplenderNativeBridge } from './nativeBridge';
import {
  db,
  doc,
  setDoc,
  updateDoc,
  getDoc,
  onSnapshot,
  sanitizeForFirestore,
} from './firebase';

export interface P2PFileHeader {
  transferId: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  totalChunks: number;
  chunkSize: number;
  fileSha256: string;
}

export interface P2PFileChunk {
  transferId: string;
  chunkIndex: number;
  chunkBase64: string;
  chunkSha256: string;
}

export interface P2PMessagePayload {
  type: 'direct_chat' | 'file_header' | 'file_chunk' | 'file_ack' | 'ping' | 'pong';
  transferId?: string;
  senderUid: string;
  recipientUid: string;
  timestamp: number;
  data?: any;
}

export type DataChannelState = 'disconnected' | 'connecting' | 'open' | 'closed';

export function getWebRtcConfiguration(): RTCConfiguration {
  const env = ((import.meta as any)?.env || {}) as Record<string, string | undefined>;
  const rawStun =
    env.VITE_STUN_URLS || 'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302';
  const stunUrls = rawStun
    .split(',')
    .map((u) => u.trim())
    .filter(Boolean);

  const iceServers: RTCIceServer[] = stunUrls.map((urls) => ({ urls }));

  const turnUrlRaw = (env.VITE_TURN_URL || '').trim();
  if (turnUrlRaw) {
    const turnUrls = turnUrlRaw
      .split(',')
      .map((u) => u.trim())
      .filter(Boolean);
    const turnServer: RTCIceServer = {
      urls: turnUrls.length === 1 ? turnUrls[0] : turnUrls,
    };
    if (env.VITE_TURN_USERNAME?.trim()) {
      turnServer.username = env.VITE_TURN_USERNAME.trim();
    }
    if (env.VITE_TURN_CREDENTIAL?.trim()) {
      turnServer.credential = env.VITE_TURN_CREDENTIAL.trim();
    }
    iceServers.push(turnServer);
  }

  return {
    iceServers,
    iceCandidatePoolSize: 4,
  };
}

export class SplenderWebRtcEngine {
  private static instance: SplenderWebRtcEngine | null = null;
  private activeConnections = new Map<string, RTCPeerConnection>();
  private activeDataChannels = new Map<string, RTCDataChannel>();
  private signalUnsubscribers = new Map<string, () => void>();
  private pendingTransfers = new Map<
    string,
    {
      header: P2PFileHeader;
      receivedChunks: Map<number, Uint8Array>;
      startedAt: number;
    }
  >();

  private onMessageCallback?: (peerUid: string, payload: P2PMessagePayload) => void;
  private onStateChangeCallback?: (peerUid: string, state: DataChannelState) => void;

  public static getInstance(): SplenderWebRtcEngine {
    if (!this.instance) {
      this.instance = new SplenderWebRtcEngine();
    }
    return this.instance;
  }

  public registerCallbacks(
    onMessage: (peerUid: string, payload: P2PMessagePayload) => void,
    onStateChange: (peerUid: string, state: DataChannelState) => void
  ) {
    this.onMessageCallback = onMessage;
    this.onStateChangeCallback = onStateChange;
  }

  public getChannelState(peerUid: string): DataChannelState {
    const dc = this.activeDataChannels.get(peerUid);
    if (!dc) return 'disconnected';
    if (dc.readyState === 'open') return 'open';
    if (dc.readyState === 'connecting') return 'connecting';
    return 'closed';
  }

  public isChannelOpen(peerUid: string): boolean {
    const dc = this.activeDataChannels.get(peerUid);
    return dc?.readyState === 'open';
  }

  /**
   * Negotiates a standalone direct P2P RTCDataChannel between `localUid` and `peerUid`
   * using deterministic ephemeral SDP/ICE signaling in `p2p_signals/{pairId}`.
   * No message text or attachments are ever written to `p2p_signals`.
   */
  public async connectPeerSession(localUid: string, peerUid: string): Promise<void> {
    if (!localUid || !peerUid || localUid === peerUid) return;
    if (peerUid.startsWith('peer_demo_') || peerUid === 'splender_ai_bot') return;
    if (this.isChannelOpen(peerUid) || typeof RTCPeerConnection === 'undefined') return;

    const existingPc = this.activeConnections.get(peerUid);
    if (
      existingPc &&
      (existingPc.connectionState === 'connecting' || existingPc.connectionState === 'connected')
    ) {
      return;
    }

    const sorted = [localUid, peerUid].sort();
    const pairId = `${sorted[0]}__${sorted[1]}`;
    const isDeterministicInitiator = localUid === sorted[0];

    const pc = new RTCPeerConnection(getWebRtcConfiguration());
    this.activeConnections.set(peerUid, pc);
    this.onStateChangeCallback?.(peerUid, 'connecting');

    this.attachConnectionRecovery(peerUid, pc, isDeterministicInitiator, pairId, localUid);
    this.setupDataChannel(peerUid, pc, isDeterministicInitiator);

    const signalRef = doc(db, 'p2p_signals', pairId);
    const localCandidates: RTCIceCandidateInit[] = [];

    pc.onicecandidate = (event) => {
      if (event.candidate && localCandidates.length < 30) {
        localCandidates.push(event.candidate.toJSON());
        const field = isDeterministicInitiator ? 'initiatorCandidates' : 'responderCandidates';
        updateDoc(signalRef, {
          [field]: localCandidates,
          updatedAt: Date.now(),
        }).catch(() => {});
      }
    };

    try {
      if (isDeterministicInitiator) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await setDoc(
          signalRef,
          sanitizeForFirestore({
            initiatorUid: localUid,
            responderUid: peerUid,
            offer: { type: offer.type, sdp: offer.sdp || '' },
            initiatorCandidates: [],
            responderCandidates: [],
            updatedAt: Date.now(),
          })
        );
      } else {
        const snap = await getDoc(signalRef).catch(() => null);
        const existingData = snap?.exists() ? snap.data() : null;
        if (existingData?.offer && !pc.currentRemoteDescription) {
          await pc.setRemoteDescription(new RTCSessionDescription(existingData.offer));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await updateDoc(
            signalRef,
            sanitizeForFirestore({
              answer: { type: answer.type, sdp: answer.sdp || '' },
              updatedAt: Date.now(),
            })
          );
        }
      }

      const prevUnsub = this.signalUnsubscribers.get(peerUid);
      if (prevUnsub) prevUnsub();

      const addedRemoteCandidates = new Set<string>();
      const unsub = onSnapshot(
        signalRef,
        async (snapshot) => {
          if (!snapshot.exists() || pc.signalingState === 'closed') return;
          const data = snapshot.data();

          try {
            if (isDeterministicInitiator && data.answer && !pc.currentRemoteDescription) {
              await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
            } else if (!isDeterministicInitiator && data.offer && !pc.currentRemoteDescription) {
              await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              await updateDoc(
                signalRef,
                sanitizeForFirestore({
                  answer: { type: answer.type, sdp: answer.sdp || '' },
                  updatedAt: Date.now(),
                })
              );
            }

            const remoteList: RTCIceCandidateInit[] = isDeterministicInitiator
              ? data.responderCandidates || []
              : data.initiatorCandidates || [];
            for (const cand of remoteList) {
              const key = cand.candidate || JSON.stringify(cand);
              if (!addedRemoteCandidates.has(key) && pc.remoteDescription) {
                addedRemoteCandidates.add(key);
                await pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
              }
            }
          } catch {
            // Transient SDP race safely ignored
          }
        },
        () => {
          // Ephemeral signaling unavailable offline; store-and-forward handles fallback
        }
      );

      this.signalUnsubscribers.set(peerUid, unsub);
    } catch {
      // Offline or unauthenticated; graceful fallback
    }
  }

  private attachConnectionRecovery(
    peerUid: string,
    pc: RTCPeerConnection,
    isInitiator: boolean,
    pairId: string,
    localUid: string
  ) {
    pc.oniceconnectionstatechange = async () => {
      const state = pc.iceConnectionState;
      if (state === 'failed' || state === 'disconnected') {
        this.onStateChangeCallback?.(peerUid, 'connecting');
        if (isInitiator && pc.signalingState === 'stable') {
          try {
            pc.restartIce();
            const restartOffer = await pc.createOffer({ iceRestart: true });
            await pc.setLocalDescription(restartOffer);
            await updateDoc(
              doc(db, 'p2p_signals', pairId),
              sanitizeForFirestore({
                initiatorUid: localUid,
                offer: { type: restartOffer.type, sdp: restartOffer.sdp || '' },
                updatedAt: Date.now(),
              })
            ).catch(() => {});
          } catch {
            // Will retry on online event
          }
        }
      }
    };
  }

  /**
   * Initializes a direct RTCDataChannel on an existing RTCPeerConnection
   */
  public setupDataChannel(peerUid: string, pc: RTCPeerConnection, isInitiator: boolean): RTCDataChannel {
    this.activeConnections.set(peerUid, pc);

    let dc: RTCDataChannel;
    if (isInitiator) {
      dc = pc.createDataChannel('splender_p2p_channel', {
        ordered: true,
      });
      this.bindDataChannelEvents(peerUid, dc);
    } else {
      pc.ondatachannel = (event) => {
        this.bindDataChannelEvents(peerUid, event.channel);
      };
      dc = (pc as any)._placeholderDc;
    }

    return dc;
  }

  /**
   * Attaches a negotiated RTCDataChannel (or compatible local loopback DataChannel) directly to the peer session.
   */
  public attachDataChannel(peerUid: string, dc: RTCDataChannel): void {
    this.bindDataChannelEvents(peerUid, dc);
    if (dc.readyState === 'open') {
      this.onStateChangeCallback?.(peerUid, 'open');
    }
  }

  /**
   * Establishes a direct zero-cloud inter-page peer DataChannel between two local peers (`localUid` <-> `peerUid`)
   * using BroadcastChannel when running across same-device browser contexts or inside link-local-only containers.
   */
  public connectLocalPeerChannel(localUid: string, peerUid: string): RTCDataChannel {
    const sorted = [localUid, peerUid].sort();
    const channelName = `splender_p2p_dc_${sorted[0]}__${sorted[1]}`;
    const bc = new BroadcastChannel(channelName);
    const listeners = new Map<string, Set<EventListener>>();

    const adapter: any = {
      label: 'splender_p2p_channel',
      ordered: true,
      readyState: 'connecting' as RTCDataChannelState,
      bufferedAmount: 0,
      bufferedAmountLowThreshold: 64 * 1024,
      onopen: null as ((ev: Event) => any) | null,
      onclose: null as ((ev: Event) => any) | null,
      onerror: null as ((ev: Event) => any) | null,
      onmessage: null as ((ev: MessageEvent) => any) | null,
      addEventListener(type: string, cb: EventListener) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(cb);
      },
      removeEventListener(type: string, cb: EventListener) {
        listeners.get(type)?.delete(cb);
      },
      send(raw: string) {
        if (adapter.readyState !== 'open') {
          throw new Error('DataChannel is not open');
        }
        bc.postMessage({ from: localUid, to: peerUid, frame: raw });
      },
      close() {
        if (adapter.readyState === 'closed') return;
        adapter.readyState = 'closed';
        try {
          bc.postMessage({ from: localUid, to: peerUid, control: 'close' });
        } catch {}
        bc.close();
        adapter.onclose?.(new Event('close'));
      },
    };

    bc.onmessage = (ev) => {
      const msg = ev.data;
      if (!msg || msg.from === localUid) return;
      if (msg.control === 'syn') {
        bc.postMessage({ from: localUid, to: peerUid, control: 'ack' });
        if (adapter.readyState !== 'open') {
          adapter.readyState = 'open';
          adapter.onopen?.(new Event('open'));
        }
        return;
      }
      if (msg.control === 'ack') {
        if (adapter.readyState !== 'open') {
          adapter.readyState = 'open';
          adapter.onopen?.(new Event('open'));
        }
        return;
      }
      if (msg.control === 'close') {
        if (adapter.readyState !== 'closed') {
          adapter.readyState = 'closed';
          bc.close();
          adapter.onclose?.(new Event('close'));
        }
        return;
      }
      if (typeof msg.frame === 'string') {
        adapter.onmessage?.(new MessageEvent('message', { data: msg.frame }));
      }
    };

    const dc = adapter as RTCDataChannel;
    this.bindDataChannelEvents(peerUid, dc);
    setTimeout(() => {
      try {
        bc.postMessage({ from: localUid, to: peerUid, control: 'syn' });
      } catch {}
    }, 5);
    return dc;
  }

  private bindDataChannelEvents(peerUid: string, dc: RTCDataChannel) {
    dc.bufferedAmountLowThreshold = 64 * 1024;
    this.activeDataChannels.set(peerUid, dc);

    dc.onopen = () => {
      this.onStateChangeCallback?.(peerUid, 'open');
      this.sendPayload(peerUid, {
        type: 'ping',
        senderUid: 'local',
        recipientUid: peerUid,
        timestamp: Date.now(),
      });
    };

    dc.bufferedAmountLowThreshold = 256 * 1024;

    dc.onclose = () => {
      this.onStateChangeCallback?.(peerUid, 'closed');
      this.activeDataChannels.delete(peerUid);
    };

    dc.onerror = (err) => {
      console.warn(`P2P DataChannel notice (${peerUid}):`, err);
    };

    dc.onmessage = async (event) => {
      try {
        const payload: P2PMessagePayload = JSON.parse(event.data);
        await this.handleIncomingPayload(peerUid, payload);
      } catch (e) {
        console.error('Failed to parse P2P payload:', e);
      }
    };
  }

  public sendPayload(peerUid: string, payload: P2PMessagePayload): boolean {
    const dc = this.activeDataChannels.get(peerUid);
    if (!dc || dc.readyState !== 'open') {
      return false;
    }

    try {
      dc.send(JSON.stringify(payload));
      return true;
    } catch (e) {
      console.warn(`P2P send to ${peerUid} failed:`, e);
      return false;
    }
  }

  private async waitForBufferDrain(dc: RTCDataChannel): Promise<void> {
    if (dc.bufferedAmount <= 256 * 1024) return;
    await new Promise<void>((resolve) => {
      const onLow = () => {
        dc.removeEventListener('bufferedamountlow', onLow);
        resolve();
      };
      dc.addEventListener('bufferedamountlow', onLow);
      setTimeout(() => {
        dc.removeEventListener('bufferedamountlow', onLow);
        resolve();
      }, 150);
    });
  }

  /**
   * Genuine P2P File Transfer with real SHA-256 digests, backpressure control, pause/cancel hooks,
   * strict DataChannel write verification, and measured KB/s throughput.
   */
  public async sendFileDirectly(
    peerUid: string,
    file: File | Blob,
    fileName: string,
    senderUid: string,
    onProgress?: (percent: number, transferredChunks: number, totalChunks: number, speedKbps: number) => void,
    options?: {
      shouldPause?: () => boolean;
      shouldCancel?: () => boolean;
    }
  ): Promise<{ transferId: string; fileSha256: string; speedKbps: number }> {
    const dc = this.activeDataChannels.get(peerUid);
    if (!dc || dc.readyState !== 'open') {
      throw new Error('Peer WebRTC DataChannel is not open');
    }

    const CHUNK_SIZE = 64 * 1024; // 64 KB WebRTC SCTP safe chunk size
    const fileSha256 = await SplenderNativeBridge.computeBlobSha256(file);
    const transferId = `p2p_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const totalChunks = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));
    const startedAt = performance.now();
    let pausedDurationMs = 0;

    const header: P2PFileHeader = {
      transferId,
      fileName,
      fileSize: file.size,
      mimeType: file.type || 'application/octet-stream',
      totalChunks,
      chunkSize: CHUNK_SIZE,
      fileSha256,
    };

    const headerSent = this.sendPayload(peerUid, {
      type: 'file_header',
      transferId,
      senderUid,
      recipientUid: peerUid,
      timestamp: Date.now(),
      data: header,
    });
    if (!headerSent) {
      throw new Error('Failed to send P2P file header over WebRTC DataChannel');
    }

    let measuredSpeedKbps = 0;
    for (let index = 0; index < totalChunks; index++) {
      if (options?.shouldCancel?.()) {
        throw new Error('Transfer cancelled');
      }

      if (options?.shouldPause?.()) {
        const pauseStart = performance.now();
        while (options.shouldPause()) {
          if (options.shouldCancel?.()) {
            throw new Error('Transfer cancelled');
          }
          await new Promise((r) => setTimeout(r, 80));
        }
        pausedDurationMs += performance.now() - pauseStart;
      }

      if (dc.readyState !== 'open') {
        throw new Error('WebRTC DataChannel closed before transfer completed');
      }

      await this.waitForBufferDrain(dc);

      const start = index * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, file.size);
      const chunkBytes = new Uint8Array(await file.slice(start, end).arrayBuffer());

      const chunkSha256 = await SplenderNativeBridge.computeSha256(chunkBytes);
      const chunkBase64 = SplenderNativeBridge.uint8ToBase64(chunkBytes);

      const chunkPayload: P2PFileChunk = {
        transferId,
        chunkIndex: index,
        chunkBase64,
        chunkSha256,
      };

      const chunkSent = this.sendPayload(peerUid, {
        type: 'file_chunk',
        transferId,
        chunkIndex: index,
        senderUid,
        recipientUid: peerUid,
        timestamp: Date.now(),
        data: chunkPayload,
      } as P2PMessagePayload);
      if (!chunkSent) {
        throw new Error(`WebRTC DataChannel failed while sending chunk ${index + 1}/${totalChunks}`);
      }

      const elapsedSec = Math.max(0.001, (performance.now() - startedAt - pausedDurationMs) / 1000);
      measuredSpeedKbps = Math.max(1, Math.round(end / 1024 / elapsedSec));

      if (onProgress) {
        onProgress(Math.round(((index + 1) / totalChunks) * 100), index + 1, totalChunks, measuredSpeedKbps);
      }
    }

    return { transferId, fileSha256, speedKbps: measuredSpeedKbps };
  }

  private async handleIncomingPayload(peerUid: string, payload: P2PMessagePayload) {
    switch (payload.type) {
      case 'direct_chat':
        this.onMessageCallback?.(peerUid, payload);
        break;

      case 'file_header': {
        const header: P2PFileHeader = payload.data;
        this.pendingTransfers.set(header.transferId, {
          header,
          receivedChunks: new Map(),
          startedAt: performance.now(),
        });
        break;
      }

      case 'file_chunk': {
        const chunk: P2PFileChunk = payload.data;
        const transfer = this.pendingTransfers.get(chunk.transferId);
        if (!transfer) return;

        const bytes = SplenderNativeBridge.base64ToUint8(chunk.chunkBase64);
        const actualChunkHash = await SplenderNativeBridge.computeSha256(bytes);
        if (actualChunkHash !== chunk.chunkSha256) {
          console.warn(`P2P chunk ${chunk.chunkIndex} SHA-256 mismatch — dropping corrupted frame`);
          return;
        }

        transfer.receivedChunks.set(chunk.chunkIndex, bytes);

        if (transfer.receivedChunks.size === transfer.header.totalChunks) {
          const orderedParts: BlobPart[] = [];
          for (let i = 0; i < transfer.header.totalChunks; i++) {
            const piece = transfer.receivedChunks.get(i);
            if (piece) {
              orderedParts.push(piece as unknown as BlobPart);
            }
          }

          const blob = new Blob(orderedParts, { type: transfer.header.mimeType });
          const actualFullSha256 = await SplenderNativeBridge.computeBlobSha256(blob);
          if (actualFullSha256 === transfer.header.fileSha256) {
            const elapsedSec = Math.max(0.001, (performance.now() - transfer.startedAt) / 1000);
            const speedKbps = Math.max(1, Math.round(transfer.header.fileSize / 1024 / elapsedSec));

            this.onMessageCallback?.(peerUid, {
              type: 'file_ack',
              transferId: transfer.header.transferId,
              senderUid: peerUid,
              recipientUid: payload.recipientUid,
              timestamp: Date.now(),
              data: {
                fileName: transfer.header.fileName,
                fileSize: transfer.header.fileSize,
                mimeType: transfer.header.mimeType,
                fileSha256: actualFullSha256,
                speedKbps,
                blob,
              },
            });
          } else {
            console.error('P2P full file SHA-256 verification failed.');
          }
          this.pendingTransfers.delete(chunk.transferId);
        }
        break;
      }

      case 'ping':
        this.sendPayload(peerUid, {
          type: 'pong',
          senderUid: 'local',
          recipientUid: peerUid,
          timestamp: Date.now(),
        });
        break;

      default:
        this.onMessageCallback?.(peerUid, payload);
        break;
    }
  }

  public teardownPeer(peerUid: string) {
    const unsub = this.signalUnsubscribers.get(peerUid);
    if (unsub) {
      unsub();
      this.signalUnsubscribers.delete(peerUid);
    }

    const dc = this.activeDataChannels.get(peerUid);
    if (dc) {
      try {
        dc.close();
      } catch {}
      this.activeDataChannels.delete(peerUid);
    }

    const pc = this.activeConnections.get(peerUid);
    if (pc) {
      try {
        pc.close();
      } catch {}
      this.activeConnections.delete(peerUid);
    }
  }
}
