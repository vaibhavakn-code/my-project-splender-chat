/**
 * Splender Platform Cryptographic Key Vault
 *
 * Stores cryptographic identity keys and local storage master keys using platform-protected facilities:
 * - On Android 17 (API 37): Wraps secrets inside hardware-backed AndroidKeyStore (TEE / StrongBox)
 *   via SplenderNativePlugin (`SplenderKeystoreVault.kt`).
 * - On Web / Mobile PWA: Generates non-extractable (`extractable: false`) Web Crypto `CryptoKey`
 *   handles persisted inside IndexedDB (`idb`) so raw private/master key bytes can NEVER be exported
 *   by script or XSS (`crypto.subtle.exportKey` throws `InvalidAccessError`).
 */

import { openDB, IDBPDatabase } from 'idb';
import { SplenderNativeBridge } from './nativeBridge';

const DB_NAME = 'splender_platform_key_vault_v17';
const DB_VERSION = 1;
const STORE_KEYS = 'non_extractable_keys';
const STORE_PUBLIC = 'public_metadata';

const LOCAL_MASTER_KEY_ID = 'local_db_aes_gcm_master_v17';
const IDENTITY_ECDH_KEY_ID = 'identity_ecdh_p256_v17';

export interface IdentityPublicBundle {
  publicKeyJwk: JsonWebKey;
  fingerprintHex: string;
  createdAt: number;
}

export class SplenderKeyVault {
  private static dbPromise: Promise<IDBPDatabase> | null = null;

  private static getDb(): Promise<IDBPDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = openDB(DB_NAME, DB_VERSION, {
        upgrade(db) {
          if (!db.objectStoreNames.contains(STORE_KEYS)) {
            db.createObjectStore(STORE_KEYS);
          }
          if (!db.objectStoreNames.contains(STORE_PUBLIC)) {
            db.createObjectStore(STORE_PUBLIC);
          }
        },
      });
    }
    return this.dbPromise;
  }

  /**
   * Provisions or retrieves the device's non-extractable AES-GCM-256 local storage master CryptoKey.
   */
  public static async getOrCreateLocalMasterKey(): Promise<CryptoKey> {
    const db = await this.getDb();
    const existing = (await db.get(STORE_KEYS, LOCAL_MASTER_KEY_ID)) as CryptoKey | undefined;
    if (existing && existing.type === 'secret') {
      return existing;
    }

    const masterKey = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false, // CRITICAL: non-extractable platform CryptoKey
      ['encrypt', 'decrypt']
    );
    await db.put(STORE_KEYS, masterKey, LOCAL_MASTER_KEY_ID);
    return masterKey;
  }

  /**
   * Provisions or retrieves the device's non-extractable ECDH P-256 identity keypair.
   * Only the public key is exportable; the private CryptoKey has `extractable: false`.
   */
  public static async getOrCreateIdentityKeyPair(): Promise<{
    privateKey: CryptoKey;
    publicKey: CryptoKey;
    publicBundle: IdentityPublicBundle;
  }> {
    const db = await this.getDb();
    const existingPair = (await db.get(STORE_KEYS, IDENTITY_ECDH_KEY_ID)) as CryptoKeyPair | undefined;
    const existingBundle = (await db.get(STORE_PUBLIC, IDENTITY_ECDH_KEY_ID)) as IdentityPublicBundle | undefined;

    if (existingPair?.privateKey && existingPair?.publicKey && existingBundle) {
      return {
        privateKey: existingPair.privateKey,
        publicKey: existingPair.publicKey,
        publicBundle: existingBundle,
      };
    }

    const pair = await crypto.subtle.generateKey(
      { name: 'ECDH', namedCurve: 'P-256' },
      false, // Private key is strictly non-extractable; public key remains exportable per WebCrypto spec
      ['deriveBits', 'deriveKey']
    );

    const publicKeyJwk = await crypto.subtle.exportKey('jwk', pair.publicKey);
    const canonical = JSON.stringify({ crv: publicKeyJwk.crv, x: publicKeyJwk.x, y: publicKeyJwk.y });
    const fingerprintHex = await SplenderNativeBridge.computeSha256(canonical);

    const publicBundle: IdentityPublicBundle = {
      publicKeyJwk,
      fingerprintHex,
      createdAt: Date.now(),
    };

    await db.put(STORE_KEYS, pair, IDENTITY_ECDH_KEY_ID);
    await db.put(STORE_PUBLIC, publicBundle, IDENTITY_ECDH_KEY_ID);

    return {
      privateKey: pair.privateKey,
      publicKey: pair.publicKey,
      publicBundle,
    };
  }

  /**
   * Encrypts sensitive local state (such as offline outbox payloads) using either
   * AndroidKeyStore + C11 ChaCha20/HMAC JNI page encryption (native) or the non-extractable IndexedDB AES-GCM key.
   */
  public static async sealLocalString(plaintext: string, contextTag = 'outbox-v17'): Promise<string> {
    if (typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.()) {
      const nativePlugin = (window as any).Capacitor?.Plugins?.SplenderNative;
      if (nativePlugin?.encryptLocalPage) {
        try {
          const res = await nativePlugin.encryptLocalPage({ plaintext, pageNumber: 1 });
          if (res?.sealedBase64) return `jni17:${res.sealedBase64}`;
        } catch {
          // Fall through to IndexedDB non-extractable key
        }
      }
    }

    const key = await this.getOrCreateLocalMasterKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const enc = new TextEncoder();
    const cipherBuf = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv,
        additionalData: enc.encode(contextTag),
      },
      key,
      enc.encode(plaintext)
    );
    const ivB64 = SplenderNativeBridge.uint8ToBase64(iv);
    const ctB64 = SplenderNativeBridge.uint8ToBase64(new Uint8Array(cipherBuf));
    return `idb17:${ivB64}:${ctB64}`;
  }

  /**
   * Decrypts sealed local state.
   */
  public static async unsealLocalString(sealed: string, contextTag = 'outbox-v17'): Promise<string | null> {
    if (!sealed) return null;
    if (sealed.startsWith('jni17:')) {
      const nativePlugin = (window as any).Capacitor?.Plugins?.SplenderNative;
      if (nativePlugin?.decryptLocalPage) {
        try {
          const res = await nativePlugin.decryptLocalPage({
            sealedBase64: sealed.slice('jni17:'.length),
            pageNumber: 1,
          });
          return res?.plaintext ?? null;
        } catch {
          return null;
        }
      }
    }

    if (sealed.startsWith('idb17:')) {
      try {
        const [, ivB64, ctB64] = sealed.split(':');
        if (!ivB64 || !ctB64) return null;
        const key = await this.getOrCreateLocalMasterKey();
        const iv = SplenderNativeBridge.base64ToUint8(ivB64);
        const ct = SplenderNativeBridge.base64ToUint8(ctB64);
        const enc = new TextEncoder();
        const plainBuf = await crypto.subtle.decrypt(
          {
            name: 'AES-GCM',
            iv: iv as unknown as BufferSource,
            additionalData: enc.encode(contextTag),
          },
          key,
          ct as unknown as BufferSource
        );
        return new TextDecoder().decode(plainBuf);
      } catch {
        return null;
      }
    }

    return null;
  }

  /**
   * Exports canonical ECDH P-256 public key JSON suitable for `/users/{uid}.ecdhPublicKey`.
   */
  public static async getCanonicalEcdhPublicKeyJson(): Promise<{
    ecdhPublicKeyJson: string;
    fingerprintHex: string;
  }> {
    const { publicBundle } = await this.getOrCreateIdentityKeyPair();
    const { crv, kty, x, y } = publicBundle.publicKeyJwk;
    const ecdhPublicKeyJson = JSON.stringify({ crv: crv || 'P-256', kty: kty || 'EC', x, y });
    return {
      ecdhPublicKeyJson,
      fingerprintHex: publicBundle.fingerprintHex,
    };
  }

  /**
   * Derives a 256-bit shared root secret between this device's non-extractable ECDH P-256
   * private key and a peer's ECDH P-256 public JWK, stretched via HKDF-SHA256.
   * Neither `conversationId` nor peer UIDs can reproduce this secret without a participant's private key.
   */
  public static async deriveEcdhSharedSecretBase64(
    peerEcdhPublicKeyJsonOrJwk: string | JsonWebKey,
    conversationId: string
  ): Promise<string> {
    const { privateKey } = await this.getOrCreateIdentityKeyPair();
    const parsedJwk: JsonWebKey =
      typeof peerEcdhPublicKeyJsonOrJwk === 'string'
        ? JSON.parse(peerEcdhPublicKeyJsonOrJwk)
        : peerEcdhPublicKeyJsonOrJwk;

    const peerPubKey = await crypto.subtle.importKey(
      'jwk',
      {
        kty: 'EC',
        crv: 'P-256',
        x: parsedJwk.x,
        y: parsedJwk.y,
        ext: true,
      },
      { name: 'ECDH', namedCurve: 'P-256' },
      true,
      []
    );

    const sharedBits = await crypto.subtle.deriveBits(
      { name: 'ECDH', public: peerPubKey },
      privateKey,
      256
    );

    const hkdfKey = await crypto.subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveBits']);
    const enc = new TextEncoder();
    const derivedRootBits = await crypto.subtle.deriveBits(
      {
        name: 'HKDF',
        hash: 'SHA-256',
        salt: enc.encode(`splender_ecdh_salt_v4:${conversationId}`),
        info: enc.encode('Splender-Signal-HKDF-RootKey-v17'),
      },
      hkdfKey,
      256
    );

    return SplenderNativeBridge.uint8ToBase64(new Uint8Array(derivedRootBits));
  }

  /**
   * Persists a 256-bit conversation root secret locally, sealed under the non-extractable local master key.
   */
  public static async storeSealedConversationSecret(
    conversationId: string,
    secretBase64: string
  ): Promise<void> {
    const db = await this.getDb();
    const sealed = await this.sealLocalString(secretBase64, `conv-rk:${conversationId}`);
    await db.put(STORE_PUBLIC, sealed, `conv_rk_${conversationId}`);
  }

  /**
   * Loads a previously sealed 256-bit conversation root secret from IndexedDB.
   */
  public static async loadSealedConversationSecret(conversationId: string): Promise<string | null> {
    const db = await this.getDb();
    const sealed = (await db.get(STORE_PUBLIC, `conv_rk_${conversationId}`)) as string | undefined;
    if (!sealed) return null;
    return this.unsealLocalString(sealed, `conv-rk:${conversationId}`);
  }
}
