// src/lib/rewards.ts
// Splender Gamified Rewards & Daily Streak Engine

import { SplenderRewardsState } from '../types';

const STORAGE_KEY = 'splender_rewards_profile';

export const REWARD_THEMES = [
  { id: 'cyber_neon', name: 'Cyber Neon Matrix', cost: 100, color: '#00FF66' },
  { id: 'aurora_borealis', name: 'Aurora Borealis', cost: 180, color: '#7928CA' },
  { id: 'champagne_gold', name: 'Royal Champagne', cost: 250, color: '#D4AF37' },
  { id: 'stealth_matte', name: 'Stealth Matte Black', cost: 320, color: '#111111' },
];

export const REWARD_BADGES = [
  { id: 'early_pioneer', title: 'Early Pioneer', icon: '🚀', cost: 50 },
  { id: 'verified_vip', title: 'Verified VIP', icon: '👑', cost: 150 },
  { id: 'privacy_sentinel', title: 'Privacy Sentinel', icon: '🛡️', cost: 200 },
  { id: 'speed_demon', title: 'Fast Communicator', icon: '⚡', cost: 300 },
];

export function getRewardsProfile(): SplenderRewardsState {
  if (typeof window === 'undefined') {
    return {
      coins: 250,
      streakDays: 3,
      lastClaimDate: '',
      unlockedThemes: [],
      unlockedBadges: ['early_pioneer'],
    };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.debug('Failed to parse rewards state:', e);
  }

  const initial: SplenderRewardsState = {
    coins: 250, // Welcome bonus
    streakDays: 3,
    lastClaimDate: '',
    unlockedThemes: [],
    unlockedBadges: ['early_pioneer'],
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

export function saveRewardsProfile(state: SplenderRewardsState): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }
}

export function awardCoins(amount: number, reason: string): { state: SplenderRewardsState; awarded: number } {
  const current = getRewardsProfile();
  current.coins += amount;
  saveRewardsProfile(current);
  return { state: current, awarded: amount };
}

export function claimDailyStreak(): { success: boolean; coinsAwarded: number; newStreak: number } {
  const current = getRewardsProfile();
  const todayStr = new Date().toISOString().slice(0, 10);

  if (current.lastClaimDate === todayStr) {
    return { success: false, coinsAwarded: 0, newStreak: current.streakDays };
  }

  // Check if yesterday or consecutive
  current.streakDays += 1;
  const reward = 50 + current.streakDays * 10;
  current.coins += reward;
  current.lastClaimDate = todayStr;
  saveRewardsProfile(current);

  return { success: true, coinsAwarded: reward, newStreak: current.streakDays };
}

export function unlockRewardItem(type: 'theme' | 'badge', id: string, cost: number): boolean {
  const current = getRewardsProfile();
  if (current.coins < cost) return false;

  if (type === 'theme') {
    if (current.unlockedThemes.includes(id)) return true;
    current.coins -= cost;
    current.unlockedThemes.push(id);
  } else {
    if (current.unlockedBadges.includes(id)) return true;
    current.coins -= cost;
    current.unlockedBadges.push(id);
  }

  saveRewardsProfile(current);
  return true;
}
