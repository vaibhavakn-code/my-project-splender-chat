// src/lib/sound.ts
import { HapticsService } from '../services/HapticsService';

let audioCtx: AudioContext | null = null;
let lastClickTime = 0;
const DUPLICATE_GUARD_MS = 160; // Guard against accidental double triggers (pointerdown + click)
let soundEnabled = true;
let hapticsEnabled = true;

if (typeof window !== 'undefined') {
  const savedSound = localStorage.getItem('splender_sound_enabled');
  soundEnabled = savedSound !== 'false';
  const savedHaptics = localStorage.getItem('splender_haptics_enabled');
  hapticsEnabled = savedHaptics !== 'false';
}

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;

  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }

  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }

  return audioCtx;
}

/**
 * Toggle or query global sound status
 */
export function setSoundEnabled(enabled: boolean): void {
  soundEnabled = enabled;
  if (typeof window !== 'undefined') {
    localStorage.setItem('splender_sound_enabled', String(enabled));
  }
}

export function isSoundEnabled(): boolean {
  return soundEnabled;
}

export function setHapticsEnabled(enabled: boolean): void {
  hapticsEnabled = enabled;
  HapticsService.setEnabled(enabled);
}

export function isHapticsEnabled(): boolean {
  return hapticsEnabled;
}

/**
 * Soft, gentle haptic pulse for double-tap reactions (Instagram/Snapchat style)
 * Deliberately produces NO audible synth clicks.
 */
export function triggerHeartHaptic(): void {
  if (!hapticsEnabled) return;
  void HapticsService.reactionPulse();
}

/**
 * Centralized Splender Chat Interaction Sound
 * Synthesizes exactly ONE clean glass "TIK" per explicit user action on interactive controls.
 */
export function playClickSound(customPitchMultiplier: number = 1.0): void {
  if (!soundEnabled) {
    if (hapticsEnabled) {
      void HapticsService.tapLight();
    }
    return;
  }

  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();

  // Guard against duplicate triggers
  if (now - lastClickTime < DUPLICATE_GUARD_MS) {
    return;
  }
  lastClickTime = now;

  // 1. Tactile Capacitor Haptic Response
  if (hapticsEnabled) {
    void HapticsService.tapLight();
  }

  // 2. Synthesize Single Clean Glass "TIK"
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const startTime = ctx.currentTime;

    // Master Gain
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.2, startTime);
    masterGain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.035);
    masterGain.connect(ctx.destination);

    // Primary Fundamental Glass Strike Oscillator (Sine)
    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    const baseFreq = 1850 * customPitchMultiplier;
    osc1.frequency.setValueAtTime(baseFreq, startTime);
    osc1.frequency.exponentialRampToValueAtTime(2450 * customPitchMultiplier, startTime + 0.006);
    osc1.frequency.exponentialRampToValueAtTime(1200 * customPitchMultiplier, startTime + 0.035);

    const gain1 = ctx.createGain();
    gain1.gain.setValueAtTime(0.7, startTime);
    gain1.gain.exponentialRampToValueAtTime(0.001, startTime + 0.035);
    osc1.connect(gain1);
    gain1.connect(masterGain);

    // Crystalline Overtone Harmonic (Triangle)
    const osc2 = ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(3700 * customPitchMultiplier, startTime);
    osc2.frequency.exponentialRampToValueAtTime(4200 * customPitchMultiplier, startTime + 0.004);

    const gain2 = ctx.createGain();
    gain2.gain.setValueAtTime(0.25, startTime);
    gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.02);
    osc2.connect(gain2);
    gain2.connect(masterGain);

    osc1.start(startTime);
    osc1.stop(startTime + 0.035);
    osc2.start(startTime);
    osc2.stop(startTime + 0.025);
  } catch (err) {
    console.debug('Audio play click error:', err);
  }
}

export const playClick = playClickSound;

export function playPopSound(): void {
  playClickSound(1.35);
}

export function playCallConnectSound(): void {
  playClickSound(1.5);
}

export function playNotificationChime(): void {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.setValueAtTime(880, now + 0.08); // A5

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1174.66, now + 0.08); // D6

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.45);
    osc2.stop(now + 0.45);
  } catch {
    // Audio context error ignored
  }
}

/**
 * Event handler wrapper to ensure single execution
 */
export function withClickSound<T extends (e?: any) => void>(fn?: T): (e: any) => void {
  return (e: any) => {
    playClickSound();
    if (fn) {
      fn(e);
    }
  };
}

/**
 * Call Ringtone Synthesizer using Web Audio API
 */
let ringtoneInterval: any = null;

export function startRingtone(type: 'incoming' | 'outgoing' = 'outgoing'): void {
  if (!soundEnabled) return;
  stopRingtone();

  const playTone = () => {
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      if (type === 'outgoing') {
        // Dual-tone 440Hz + 480Hz phone ringback chime
        const now = ctx.currentTime;
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.frequency.value = 440;
        osc2.frequency.value = 480;
        osc1.type = 'sine';
        osc2.type = 'sine';

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.exponentialRampToValueAtTime(0.08, now + 0.05);
        gain.gain.setValueAtTime(0.08, now + 1.2);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 1.5);
        osc2.stop(now + 1.5);
      } else {
        // Melodic marimba/harp incoming chime (E5, G#5, B5, E6)
        const notes = [659.25, 830.61, 987.77, 1318.51];
        notes.forEach((freq, idx) => {
          const now = ctx.currentTime + idx * 0.12;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, now);

          gain.gain.setValueAtTime(0.001, now);
          gain.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.36);
        });
      }
    } catch {
      // Audio context may require user interaction
    }
  };

  playTone();
  ringtoneInterval = setInterval(playTone, type === 'outgoing' ? 3200 : 2200);
}

export function stopRingtone(): void {
  if (ringtoneInterval) {
    clearInterval(ringtoneInterval);
    ringtoneInterval = null;
  }
}

/**
 * Backward compatibility facade for components importing `sound`
 */
export const sound = {
  playGlassClick: (pitch: number = 1.0) => playClickSound(pitch),
  triggerInteraction: (pitch: number = 1.0) => playClickSound(pitch),
  playGlassSend: () => {
    void HapticsService.messageSent();
    playClickSound(1.2);
  },
  playGlassPing: () => playClickSound(1.35),
  triggerHeartHaptic: () => triggerHeartHaptic(),
  toggleSound: (enabled?: boolean): boolean => {
    const next = enabled !== undefined ? enabled : !soundEnabled;
    setSoundEnabled(next);
    return next;
  },
  isSoundEnabled: () => isSoundEnabled(),
  toggleHaptics: (enabled?: boolean): boolean => {
    const next = enabled !== undefined ? enabled : !hapticsEnabled;
    setHapticsEnabled(next);
    return next;
  },
  isHapticsEnabled: () => isHapticsEnabled(),
  triggerHaptic: (pattern: number | number[] = 6) => {
    if (!hapticsEnabled) return;
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Ignored
      }
    }
  },
};
