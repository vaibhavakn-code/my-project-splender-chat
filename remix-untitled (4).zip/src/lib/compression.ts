import { MediaQuality } from '../types';

export type { MediaQuality };

export interface MediaQualityOption {
  id: MediaQuality;
  label: string;
  badge: string;
  description: string;
  imageSpec: string;
  videoSpec: string;
  audioSpec: string;
}

export const MEDIA_QUALITY_OPTIONS: MediaQualityOption[] = [
  {
    id: 'medium',
    label: 'Medium (Data Saver)',
    badge: 'DATA SAVER',
    description: 'Optimized for cellular & constrained bandwidth',
    imageSpec: 'Max 720p • 60% WebP',
    videoSpec: '480p • ~1 Mbps',
    audioSpec: '32 kbps mono',
  },
  {
    id: 'high',
    label: 'High (Default)',
    badge: 'HQ',
    description: 'Balanced visual fidelity and fast delivery',
    imageSpec: 'Max 1080p • 80% WebP',
    videoSpec: '720p • ~2.5 Mbps',
    audioSpec: '96 kbps stereo',
  },
  {
    id: 'hd',
    label: 'HD (1080p)',
    badge: 'HD',
    description: 'Crisp high definition for high-dpi screens',
    imageSpec: 'Max 2K (2048p) • 90% WebP',
    videoSpec: '1080p • ~6 Mbps',
    audioSpec: '192 kbps HD',
  },
  {
    id: 'original',
    label: 'Original (Uncompressed)',
    badge: 'RAW',
    description: 'Bit-for-bit lossless source preservation',
    imageSpec: 'Original Dimensions • Zero Loss',
    videoSpec: 'Full Native Bitrate',
    audioSpec: '320 kbps / Lossless',
  },
];

const LOCAL_STORAGE_KEY = 'splender_media_quality';

/**
 * Retrieve saved media quality preference from localStorage with fallback to 'high'
 */
export function getStoredMediaQuality(): MediaQuality {
  if (typeof window === 'undefined') return 'high';
  try {
    const val = localStorage.getItem(LOCAL_STORAGE_KEY) as MediaQuality | null;
    if (val && ['medium', 'high', 'hd', 'original'].includes(val)) {
      return val;
    }
  } catch (err) {
    console.debug('Error reading stored media quality:', err);
  }
  return 'high';
}

/**
 * Persist user media quality preference
 */
export function setStoredMediaQuality(quality: MediaQuality): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, quality);
  } catch (err) {
    console.debug('Error saving stored media quality:', err);
  }
}

/**
 * Audio bitrate mapping for MediaRecorder & WebAudio notes
 */
export function getAudioBitrateForQuality(quality: MediaQuality): {
  bitsPerSecond: number;
  channels: number;
  sampleRate: number;
} {
  switch (quality) {
    case 'medium':
      return { bitsPerSecond: 32000, channels: 1, sampleRate: 22050 };
    case 'hd':
      return { bitsPerSecond: 192000, channels: 2, sampleRate: 48000 };
    case 'original':
      return { bitsPerSecond: 320000, channels: 2, sampleRate: 48000 };
    case 'high':
    default:
      return { bitsPerSecond: 96000, channels: 2, sampleRate: 44100 };
  }
}

export interface ProcessedMediaResult {
  dataUrl: string;
  blob?: Blob;
  size: number;
  width?: number;
  height?: number;
  quality: MediaQuality;
  thumbnailUrl?: string;
}

/**
 * Generates an ultra-lightweight thumbnail for instant lazy-loading and blur previews
 */
export async function generateThumbnail(
  fileOrBlobOrUrl: File | Blob | string,
  maxDimension = 160
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    const onLoaded = () => {
      let width = img.width || 160;
      let height = img.height || 160;

      if (width > height) {
        if (width > maxDimension) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        }
      } else {
        if (height > maxDimension) {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, width);
      canvas.height = Math.max(1, height);
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve('');

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'medium';
      ctx.drawImage(img, 0, 0, width, height);

      // WebP or fallback to JPEG at 40% quality for tiny thumbnail payload (~3-6KB)
      try {
        const thumb = canvas.toDataURL('image/webp', 0.45);
        resolve(thumb);
      } catch {
        try {
          const thumb = canvas.toDataURL('image/jpeg', 0.45);
          resolve(thumb);
        } catch {
          resolve('');
        }
      }
    };

    if (typeof fileOrBlobOrUrl === 'string') {
      img.src = fileOrBlobOrUrl;
      img.onload = onLoaded;
      img.onerror = () => resolve('');
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
        img.onload = onLoaded;
        img.onerror = () => resolve('');
      };
      reader.onerror = () => resolve('');
      reader.readAsDataURL(fileOrBlobOrUrl);
    }
  });
}

/**
 * Micro blur placeholder generator (~500 bytes - 1KB) for instant progressive blur-up rendering
 */
export async function generateBlurPlaceholder(
  fileOrBlobOrUrl: File | Blob | string
): Promise<string> {
  return generateThumbnail(fileOrBlobOrUrl, 32);
}

/**
 * Multi-Quality Image Processing Pipeline
 * Supports WebP/JPEG encoding with dimensional constraints:
 * - Medium: Max 720p resolution, 60% WebP compression
 * - High: Max 1080p resolution, 80% WebP compression
 * - HD: Max 2K (2048p) resolution, 90% WebP compression
 * - Original: 100% original dimensions, zero quality loss
 */
export async function processImageWithQuality(
  file: File | Blob,
  quality: MediaQuality = 'high'
): Promise<ProcessedMediaResult> {
  // If original quality requested, return uncompressed dataUrl or original blob
  if (quality === 'original') {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const dataUrl = e.target?.result as string;
        const thumbnail = await generateThumbnail(dataUrl, 160).catch(() => undefined);
        resolve({
          dataUrl,
          blob: file,
          size: file.size,
          quality: 'original',
          thumbnailUrl: thumbnail,
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  }

  // Quality specification parameters
  let maxWidth = 1920;
  let maxHeight = 1080;
  let compressionRatio = 0.8;

  switch (quality) {
    case 'medium':
      // Max 720p resolution, 60% WebP compression
      maxWidth = 1280;
      maxHeight = 720;
      compressionRatio = 0.6;
      break;
    case 'hd':
      // Max 2K (2048p) resolution, 90% WebP compression
      maxWidth = 2048;
      maxHeight = 2048;
      compressionRatio = 0.9;
      break;
    case 'high':
    default:
      // Max 1080p resolution, 80% WebP compression
      maxWidth = 1920;
      maxHeight = 1080;
      compressionRatio = 0.8;
      break;
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = async () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, width);
        canvas.height = Math.max(1, height);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return reject(new Error('Canvas context not available'));
        }

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        let dataUrl = '';
        try {
          dataUrl = canvas.toDataURL('image/webp', compressionRatio);
        } catch {
          dataUrl = canvas.toDataURL('image/jpeg', compressionRatio);
        }

        // Generate tiny fast thumbnail for instant feed scroll
        const thumbnailUrl = await generateThumbnail(dataUrl, 160).catch(() => undefined);

        resolve({
          dataUrl,
          size: Math.round((dataUrl.length * 3) / 4),
          width,
          height,
          quality,
          thumbnailUrl,
        });
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

/**
 * Process video files with quality settings & extract first-frame thumbnail
 */
export async function processVideoWithQuality(
  file: File | Blob,
  quality: MediaQuality = 'high'
): Promise<ProcessedMediaResult> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const url = URL.createObjectURL(file);
    video.src = url;

    video.onloadeddata = async () => {
      try {
        video.currentTime = Math.min(0.5, (video.duration || 1) / 2);
      } catch {
        // seek error ignored
      }
    };

    video.onseeked = async () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, video.videoWidth || 640);
        canvas.height = Math.max(1, video.videoHeight || 360);
        const ctx = canvas.getContext('2d');
        let thumbnailUrl = '';
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          thumbnailUrl = canvas.toDataURL('image/jpeg', 0.6);
        }

        const reader = new FileReader();
        reader.onload = (e) => {
          URL.revokeObjectURL(url);
          const dataUrl = e.target?.result as string;
          resolve({
            dataUrl,
            blob: file,
            size: file.size,
            width: video.videoWidth,
            height: video.videoHeight,
            quality,
            thumbnailUrl,
          });
        };
        reader.onerror = (err) => {
          URL.revokeObjectURL(url);
          reject(err);
        };
        reader.readAsDataURL(file);
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };

    video.onerror = () => {
      URL.revokeObjectURL(url);
      // Fallback: read file directly
      const reader = new FileReader();
      reader.onload = (e) => {
        resolve({
          dataUrl: e.target?.result as string,
          blob: file,
          size: file.size,
          quality,
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    };
  });
}

/**
 * Universal media processor: detects image vs video and processes according to quality
 */
export async function processMediaWithQuality(
  file: File | Blob,
  quality: MediaQuality = 'high'
): Promise<ProcessedMediaResult & { type: 'image' | 'video' }> {
  const isVideo = file.type.startsWith('video/');
  if (isVideo) {
    const res = await processVideoWithQuality(file, quality);
    return { ...res, type: 'video' };
  } else {
    const res = await processImageWithQuality(file, quality);
    return { ...res, type: 'image' };
  }
}

/**
 * Backwards-compatible compressImage wrapper
 */
export async function compressImage(
  file: File | Blob,
  maxWidth = 1280,
  maxHeight = 1280,
  quality = 0.8
): Promise<{ dataUrl: string; size: number }> {
  const res = await processImageWithQuality(file, 'high');
  return { dataUrl: res.dataUrl, size: res.size };
}

/**
 * Generate a safe collision-resistant Splender ID format: SP-XXXXXX (6 alphanumeric caps)
 */
export function generateSplenderId(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = 'SP-';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Normalize username for collision checks and safe Firestore document IDs
 */
export function normalizeUsername(username: string): string {
  const cleaned = username
    .trim()
    .toLowerCase()
    .replace(/^@+/, '')
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_.-]/g, '')
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 64);
  return cleaned || 'peer';
}

/**
 * WebAuthn Biometric registration/verification helper
 */
export async function verifyWebAuthn(): Promise<boolean> {
  if (
    typeof window !== 'undefined' &&
    window.PublicKeyCredential &&
    window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable
  ) {
    try {
      const isAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (!isAvailable) return false;

      const challenge = new Uint8Array(32);
      window.crypto.getRandomValues(challenge);

      const credential = await navigator.credentials.get({
        publicKey: {
          challenge,
          rpId: window.location.hostname,
          userVerification: 'required',
          timeout: 60000,
        },
      });

      return !!credential;
    } catch {
      return false;
    }
  }
  return false;
}
