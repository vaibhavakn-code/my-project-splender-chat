// ============================================================================
// SPLENDER CHAT - ADVANCED PRODUCTION MODULES (REACTIONS, TYPING, POLLS, ETC.)
// ============================================================================

import {
  db,
  auth,
  doc,
  collection,
  setDoc,
  getDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  runTransaction,
  sanitizeForFirestore,
} from './firebase';
import { playClickSound, playPopSound } from './sound';

// ----------------------------------------------------------------------------
// 1. MESSAGE REACTIONS & EMOJI PICKER ENGINE
// ----------------------------------------------------------------------------
export const ReactionEngine = {
  /**
   * Toggles a user's reaction on a message with atomic transaction
   * Compatible with both conversation messages subcollection and chats
   */
  async toggleReaction(chatId: string, messageId: string, emoji: string, userId: string): Promise<void> {
    if (!chatId || !messageId || !emoji || !userId) return;

    try {
      // Primary modular path: conversations/{chatId}/messages/{messageId}
      const msgRef = doc(db, 'conversations', chatId, 'messages', messageId);

      await runTransaction(db, async (transaction) => {
        const docSnap = await transaction.get(msgRef);
        if (!docSnap.exists()) return;

        const data = docSnap.data();
        let reactionsList: any[] = Array.isArray(data?.reactions) ? [...data.reactions] : [];

        // Check if reactions is structured as array: [{ emoji, count, uids }]
        const existingIdx = reactionsList.findIndex((r) => r.emoji === emoji);

        if (existingIdx >= 0) {
          const current = reactionsList[existingIdx];
          const uids: string[] = Array.isArray(current.uids) ? current.uids : [];

          if (uids.includes(userId)) {
            // Remove user reaction
            const newUids = uids.filter((id) => id !== userId);
            if (newUids.length === 0) {
              reactionsList.splice(existingIdx, 1);
            } else {
              reactionsList[existingIdx] = {
                ...current,
                count: newUids.length,
                uids: newUids,
              };
            }
          } else {
            // Add user reaction
            const newUids = [...uids, userId];
            reactionsList[existingIdx] = {
              ...current,
              count: newUids.length,
              uids: newUids,
            };
          }
        } else {
          // New emoji reaction
          reactionsList.push({
            emoji,
            count: 1,
            uids: [userId],
          });
        }

        transaction.update(msgRef, sanitizeForFirestore({ reactions: reactionsList }));
      });
    } catch {
      // Fallback compatibility path: chats/{chatId}/messages/{messageId}
      try {
        const legacyRef = doc(db, 'chats', chatId, 'messages', messageId);
        await runTransaction(db, async (transaction) => {
          const docSnap = await transaction.get(legacyRef);
          if (!docSnap.exists()) return;
          const reactions = docSnap.data()?.reactions || {};
          const userList: string[] = reactions[emoji] || [];

          if (userList.includes(userId)) {
            reactions[emoji] = userList.filter((id: string) => id !== userId);
            if (reactions[emoji].length === 0) delete reactions[emoji];
          } else {
            reactions[emoji] = [...userList, userId];
          }
          transaction.update(legacyRef, sanitizeForFirestore({ reactions }));
        });
      } catch (err) {
        console.warn('ReactionEngine toggleReaction notice:', err);
      }
    }
  },
};

// ----------------------------------------------------------------------------
// 2. REAL-TIME TYPING INDICATOR & USER PRESENCE HEARTBEAT
// ----------------------------------------------------------------------------
const typingTimeouts: Record<string, NodeJS.Timeout> = {};

export const PresenceEngine = {
  /**
   * Set typing status with auto-clearing timer
   */
  setTypingStatus(chatId: string, userId: string, isTyping: boolean) {
    if (!chatId || !userId) return;

    const key = `${chatId}_${userId}`;
    if (typingTimeouts[key]) {
      clearTimeout(typingTimeouts[key]);
      delete typingTimeouts[key];
    }

    try {
      const convRef = doc(db, 'conversations', chatId);
      updateDoc(convRef, {
        [`typing.${userId}`]: isTyping,
      }).catch(() => {});
    } catch {
      // Fallback chats collection
      try {
        const chatRef = doc(db, 'chats', chatId);
        updateDoc(chatRef, {
          [`typing.${userId}`]: isTyping,
        }).catch(() => {});
      } catch {}
    }

    // Auto-clear typing status after 3.5 seconds
    if (isTyping) {
      typingTimeouts[key] = setTimeout(() => {
        PresenceEngine.setTypingStatus(chatId, userId, false);
      }, 3500);
    }
  },

  /**
   * Set typing status with custom timeout/heartbeat
   */
  setTypingStatusWithHeartbeat(
    chatId: string,
    userId: string,
    isTyping: boolean,
    timeoutMs: number = 3500
  ) {
    if (!chatId || !userId) return;

    const key = `${chatId}_${userId}`;
    if (typingTimeouts[key]) {
      clearTimeout(typingTimeouts[key]);
      delete typingTimeouts[key];
    }

    try {
      const convRef = doc(db, 'conversations', chatId);
      updateDoc(convRef, {
        [`typing.${userId}`]: isTyping,
      }).catch(() => {});
    } catch {
      try {
        const chatRef = doc(db, 'chats', chatId);
        updateDoc(chatRef, {
          [`typing.${userId}`]: isTyping,
        }).catch(() => {});
      } catch {}
    }

    if (isTyping) {
      typingTimeouts[key] = setTimeout(() => {
        PresenceEngine.setTypingStatus(chatId, userId, false);
      }, timeoutMs);
    }
  },

  /**
   * Update user online presence & last seen timestamp
   */
  async updatePresence(userId: string, status: 'online' | 'offline'): Promise<void> {
    if (!userId) return;
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, {
        status,
        isOnline: status === 'online',
        lastSeen: Date.now(),
        lastSeenIso: new Date().toISOString(),
      });
    } catch (err) {
      console.debug('PresenceEngine updatePresence notice:', err);
    }
  },
};

// ----------------------------------------------------------------------------
// 3. PINNED MESSAGES & STARRED MESSAGES VAULT
// ----------------------------------------------------------------------------
export const BookmarkEngine = {
  /**
   * Pin message to top banner of chat
   */
  async pinMessage(chatId: string, messageId: string): Promise<void> {
    if (!chatId || !messageId) return;
    try {
      const convRef = doc(db, 'conversations', chatId);
      await updateDoc(convRef, {
        pinnedMessageId: messageId,
        pinnedAt: new Date().toISOString(),
      });
    } catch {
      try {
        const chatRef = doc(db, 'chats', chatId);
        await updateDoc(chatRef, {
          pinnedMessageId: messageId,
          pinnedAt: new Date().toISOString(),
        });
      } catch (err) {
        console.error('BookmarkEngine pinMessage error:', err);
      }
    }
  },

  /**
   * Unpin message from chat header
   */
  async unpinMessage(chatId: string): Promise<void> {
    if (!chatId) return;
    try {
      const convRef = doc(db, 'conversations', chatId);
      await updateDoc(convRef, {
        pinnedMessageId: null,
        pinnedAt: null,
      });
    } catch {
      try {
        const chatRef = doc(db, 'chats', chatId);
        await updateDoc(chatRef, {
          pinnedMessageId: null,
          pinnedAt: null,
        });
      } catch {}
    }
  },

  /**
   * Toggle Starred status for quick lookup in user vault
   */
  async toggleStarMessage(userId: string, messageDoc: any): Promise<boolean> {
    if (!userId || !messageDoc?.id) return false;
    try {
      const starRef = doc(db, 'users', userId, 'starredMessages', messageDoc.id);
      const starSnap = await getDoc(starRef);

      if (starSnap.exists()) {
        await deleteDoc(starRef);
        return false; // Now unstarred
      } else {
        await setDoc(starRef, sanitizeForFirestore({
          ...messageDoc,
          starredAt: new Date().toISOString(),
        }));
        return true; // Now starred
      }
    } catch (err) {
      console.warn('BookmarkEngine toggleStarMessage notice:', err);
      return false;
    }
  },
};

// ----------------------------------------------------------------------------
// 4. INTERACTIVE IN-CHAT VOTING POLLS
// ----------------------------------------------------------------------------
export const PollEngine = {
  /**
   * Create an interactive voting poll
   */
  async createPoll(chatId: string, question: string, options: string[]) {
    if (!chatId || !question.trim()) return null;

    const pollData = {
      question: question.trim(),
      options: options.map((opt, idx) => ({
        id: `opt_${Date.now()}_${idx}`,
        text: opt.trim(),
        votes: [],
      })),
      multiSelect: false,
    };

    const { CryptoService } = await import('../services/CryptoService');
    const { envelope: encryptedEnvelope } = await CryptoService.sealConversationPayload(
      chatId,
      undefined,
      {
        text: `Poll: ${question.trim()}`,
        pollPayload: pollData,
      }
    );

    const pollPayload = {
      type: 'poll',
      text: '[Encrypted]',
      encryptedEnvelope,
      pollPayload: pollData,
      isEncrypted: true,
      encryptionProtocol: 'DOUBLE_RATCHET_V3',
      transportMode: 'e2ee_relay',
      createdAt: new Date().toISOString(),
      timestamp: Date.now(),
      senderId: auth?.currentUser?.uid || 'user',
      senderUid: auth?.currentUser?.uid || 'user',
      status: 'sent',
    };

    try {
      const msgColl = collection(db, 'conversations', chatId, 'messages');
      return await addDoc(msgColl, sanitizeForFirestore(pollPayload));
    } catch {
      const legacyColl = collection(db, 'chats', chatId, 'messages');
      return await addDoc(legacyColl, sanitizeForFirestore(pollPayload));
    }
  },

  /**
   * Cast or toggle vote in a poll
   */
  async voteInPoll(
    chatId: string,
    messageId: string,
    optionId: string | number,
    userId: string
  ): Promise<void> {
    if (!chatId || !messageId || !userId) return;

    try {
      const msgRef = doc(db, 'conversations', chatId, 'messages', messageId);

      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(msgRef);
        if (!snap.exists()) return;

        const data = snap.data();
        const poll = data?.pollPayload;
        if (!poll || !Array.isArray(poll.options)) return;

        const updatedOptions = poll.options.map((opt: any) => {
          const currentVotes: string[] = Array.isArray(opt.votes) ? [...opt.votes] : [];
          const optMatches = String(opt.id) === String(optionId);

          if (optMatches) {
            // Toggle vote on selected option
            if (currentVotes.includes(userId)) {
              return { ...opt, votes: currentVotes.filter((id) => id !== userId) };
            } else {
              return { ...opt, votes: [...currentVotes, userId] };
            }
          } else {
            // Single select: remove vote from other options
            return { ...opt, votes: currentVotes.filter((id) => id !== userId) };
          }
        });

        transaction.update(msgRef, sanitizeForFirestore({
          'pollPayload.options': updatedOptions,
        }));
      });
    } catch (err) {
      console.warn('PollEngine voteInPoll notice:', err);
    }
  },
};

// ----------------------------------------------------------------------------
// 5. RICH LINK PREVIEW & OG METADATA PARSER
// ----------------------------------------------------------------------------
export interface LinkPreviewData {
  title?: string;
  description?: string;
  image?: string;
  domain?: string;
  url: string;
}

const previewCache = new Map<string, LinkPreviewData>();

export const LinkPreviewEngine = {
  /**
   * Extract first URL from a plaintext message
   */
  extractFirstUrl(text: string): string | null {
    if (!text) return null;
    const match = text.match(/(https?:\/\/[^\s]+|www\.[^\s]+)/i);
    if (!match) return null;
    let url = match[0];
    if (url.startsWith('www.')) url = `https://${url}`;
    return url;
  },

  /**
   * Fetches OpenGraph metadata using OpenGraph API with caching
   */
  async fetchLinkPreview(rawUrl: string): Promise<LinkPreviewData | null> {
    if (!rawUrl) return null;
    let cleanUrl = rawUrl.trim();
    if (cleanUrl.startsWith('www.')) cleanUrl = `https://${cleanUrl}`;

    if (previewCache.has(cleanUrl)) {
      return previewCache.get(cleanUrl)!;
    }

    try {
      const response = await fetch(`https://api.microlink.io?url=${encodeURIComponent(cleanUrl)}`);
      if (!response.ok) throw new Error('Preview fetch failed');
      const json = await response.json();

      if (json.status === 'success' && json.data) {
        const preview: LinkPreviewData = {
          title: json.data.title || undefined,
          description: json.data.description || undefined,
          image: json.data.image?.url || json.data.logo?.url || undefined,
          domain: json.data.publisher || new URL(cleanUrl).hostname,
          url: cleanUrl,
        };
        previewCache.set(cleanUrl, preview);
        return preview;
      }
    } catch (err) {
      console.debug('Link preview network fallback:', err);
    }

    // Graceful offline fallback
    try {
      const domain = new URL(cleanUrl).hostname.replace(/^www\./, '');
      const fallback: LinkPreviewData = {
        title: domain,
        description: cleanUrl,
        domain,
        url: cleanUrl,
      };
      previewCache.set(cleanUrl, fallback);
      return fallback;
    } catch {
      return null;
    }
  },
};

// ----------------------------------------------------------------------------
// 6. APP SECURITY & BIOMETRIC PIN LOCK
// ----------------------------------------------------------------------------
export const AppSecurityLock = {
  /**
   * Initializes user inactivity auto-lock and tab blur trigger
   */
  initAutoLock(lockTimeoutMinutes = 1, onLockTrigger: () => void): () => void {
    if (typeof window === 'undefined') return () => {};

    let timer: NodeJS.Timeout | null = null;

    const resetTimer = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(onLockTrigger, Math.max(1, lockTimeoutMinutes) * 60 * 1000);
    };

    const handleBlur = () => {
      // Auto lock when window loses focus (e.g. tab switch)
      onLockTrigger();
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        onLockTrigger();
      }
    };

    // User activity listeners
    window.addEventListener('mousemove', resetTimer, { passive: true });
    window.addEventListener('keypress', resetTimer, { passive: true });
    window.addEventListener('touchstart', resetTimer, { passive: true });
    window.addEventListener('scroll', resetTimer, { passive: true });
    window.addEventListener('blur', handleBlur);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    resetTimer();

    return () => {
      if (timer) clearTimeout(timer);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keypress', resetTimer);
      window.removeEventListener('touchstart', resetTimer);
      window.removeEventListener('scroll', resetTimer);
      window.removeEventListener('blur', handleBlur);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  },
};
