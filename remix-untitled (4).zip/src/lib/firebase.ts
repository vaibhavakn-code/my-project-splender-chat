import { initializeApp, getApps, getApp, onLog } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  linkWithPopup,
  signOut,
  onAuthStateChanged,
  linkWithCredential,
  GoogleAuthProvider,
  EmailAuthProvider,
  signInWithCredential,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  disableNetwork,
  enableNetwork,
  waitForPendingWrites,
  onSnapshotsInSync,
  setLogLevel as setFirestoreLogLevel,
  getDocFromCache,
  getDocsFromCache,
  doc,
  collection,
  setDoc as rawSetDoc,
  getDoc as rawGetDoc,
  getDocFromServer as rawGetDocFromServer,
  getDocs as rawGetDocs,
  updateDoc as rawUpdateDoc,
  deleteDoc as rawDeleteDoc,
  addDoc as rawAddDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot as rawOnSnapshot,
  runTransaction as rawRunTransaction,
  writeBatch as rawWriteBatch,
  serverTimestamp,
  increment,
  arrayUnion,
  deleteField,
  type Firestore,
  type Unsubscribe,
  type WriteBatch,
} from 'firebase/firestore';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';
import { MediaQuality } from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firebase Storage with bounded retry budgets so offline/unprovisioned buckets fail fast
export const storage = getStorage(app);
storage.maxUploadRetryTime = 3500;
storage.maxOperationRetryTime = 3500;

// Initialize Firestore with multi-tab persistent cache, auto-detect long polling, and HMR-safe fallback
function createResilientFirestore(): Firestore {
  try {
    return initializeFirestore(
      app,
      {
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
        experimentalAutoDetectLongPolling: true,
        experimentalLongPollingOptions: {
          timeoutSeconds: 25,
        },
        ignoreUndefinedProperties: true,
      },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}

export const db: Firestore = createResilientFirestore();

// Structured Firestore Error Diagnostics (per Firebase Integration specification)
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function isPermissionDeniedError(error: unknown): boolean {
  const msg = error instanceof Error ? error.message : String(error);
  const code = (error as { code?: string })?.code || '';
  return (
    code === 'permission-denied' ||
    code === 'firestore/permission-denied' ||
    msg.includes('Missing or insufficient permissions') ||
    msg.includes('PERMISSION_DENIED')
  );
}

export function isFirestoreWebChannelTransportLog(message: string): boolean {
  if (!message) return false;
  if (
    message.includes('PERMISSION_DENIED') ||
    message.includes('Missing or insufficient permissions') ||
    message.includes('requires an index') ||
    message.includes('Quota exceeded')
  ) {
    return false;
  }
  return (
    message.includes('WebChannelConnection RPC') ||
    message.includes("RPC 'Listen' stream") ||
    message.includes("RPC 'Write' stream") ||
    message.includes('transport errored') ||
    message.includes('Could not reach Cloud Firestore backend') ||
    message.includes('Disconnecting idle stream') ||
    message.includes("Backend didn't respond within") ||
    message.includes('Connection failed.')
  );
}

export function isTransientFirestoreTransportError(error: unknown): boolean {
  if (!error || isPermissionDeniedError(error)) {
    return false;
  }
  if ((error as { isFirestoreStreamPaused?: boolean })?.isFirestoreStreamPaused === true) {
    return true;
  }

  const rawCode = String((error as { code?: string })?.code || '').replace(/^firestore\//, '');
  const msg = error instanceof Error ? error.message : String(error);

  if (
    rawCode === 'not-found' ||
    rawCode === 'already-exists' ||
    rawCode === 'invalid-argument' ||
    rawCode === 'failed-precondition' ||
    rawCode === 'unauthenticated' ||
    msg.includes('Quota exceeded') ||
    msg.includes('requires an index')
  ) {
    return false;
  }

  if (
    rawCode === 'unavailable' ||
    rawCode === 'cancelled' ||
    rawCode === 'deadline-exceeded' ||
    rawCode === 'aborted' ||
    rawCode === 'internal'
  ) {
    return true;
  }

  return (
    msg.includes('the client is offline') ||
    msg.includes('client is offline') ||
    msg.includes('Failed to fetch') ||
    msg.includes('NetworkError') ||
    msg.includes('network error') ||
    msg.includes('transport errored') ||
    msg.includes('WebChannelConnection') ||
    msg.includes('Stream closed') ||
    msg.includes("Backend didn't respond") ||
    msg.includes('Could not reach Cloud Firestore backend') ||
    msg.includes('ERR_NETWORK') ||
    msg.includes('ERR_INTERNET_DISCONNECTED') ||
    msg.includes('ERR_CONNECTION_REFUSED') ||
    msg.includes('ERR_CONNECTION_RESET') ||
    msg.includes('Load failed') ||
    msg.includes('Firestore stream temporarily paused')
  );
}

// ============================================================================
// FIRESTORE CONNECTION & LISTEN / WRITE STREAM RESILIENCE ENGINE
// ============================================================================

export type FirestoreStreamState = 'online' | 'paused' | 'reconnecting' | 'offline';
export type FirestoreStreamKind = 'Listen' | 'Write';

export interface FirestoreStreamStatus {
  state: FirestoreStreamState;
  networkEnabled: boolean;
  activeListenStreams: number;
  pausedListenStreams: number;
  inFlightWrites: number;
  listenRecoveries: number;
  writeRetries: number;
  suppressedTransportErrors: number;
  reconnectAttempt: number;
  lastDisconnectReason: string | null;
  lastSyncedAt: number | null;
}

interface ManagedListenEntry {
  id: number;
  pathHint: string;
  disposed: boolean;
  paused: boolean;
  wasPreviouslyAttached: boolean;
  rawUnsub: Unsubscribe | null;
  attach: () => void;
  detachRaw: () => void;
}

function createPausedStreamError(operation: string, pathHint: string | null): Error {
  const err = new Error(
    `Firestore stream temporarily paused (${operation}${pathHint ? ` @ ${pathHint}` : ''})`
  ) as Error & { code: string; isFirestoreStreamPaused: boolean };
  err.code = 'unavailable';
  err.isFirestoreStreamPaused = true;
  return err;
}

function sleepMs(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export class FirestoreStreamResilienceManager {
  private static instance: FirestoreStreamResilienceManager | null = null;

  private state: FirestoreStreamState =
    typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : 'online';
  private networkEnabled = true;
  private streamsPaused = false;
  private nextListenerId = 1;
  private listenStreams = new Map<number, ManagedListenEntry>();
  private inFlightWrites = 0;
  private listenRecoveries = 0;
  private writeRetries = 0;
  private suppressedTransportErrors = 0;
  private reconnectAttempt = 0;
  private lastDisconnectReason: string | null = null;
  private lastSyncedAt: number | null = null;

  private statusListeners = new Set<(status: FirestoreStreamStatus) => void>();
  private reconnectListeners = new Set<() => void | Promise<void>>();
  private pauseWaiters = new Set<(err: Error) => void>();
  private networkGate: Promise<void> = Promise.resolve();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private recentTransportSignals: number[] = [];
  private lifecycleAttached = false;
  private customOriginProbe: (() => Promise<boolean>) | null = null;

  private constructor() {
    this.configureSdkTransportLogger();
    this.attachEnvironmentMonitors();
  }

  public static getInstance(): FirestoreStreamResilienceManager {
    if (!FirestoreStreamResilienceManager.instance) {
      FirestoreStreamResilienceManager.instance = new FirestoreStreamResilienceManager();
    }
    return FirestoreStreamResilienceManager.instance;
  }

  private configureSdkTransportLogger(): void {
    try {
      setFirestoreLogLevel('silent');
      onLog(
        (logEntry) => {
          if (
            logEntry.type === '@firebase/firestore' &&
            isFirestoreWebChannelTransportLog(logEntry.message)
          ) {
            const streamKind: FirestoreStreamKind = logEntry.message.includes("'Write'")
              ? 'Write'
              : 'Listen';
            this.recordTransportSignal(streamKind, logEntry.message);
            return;
          }
          if (logEntry.level === 'error') {
            console.error(`[${logEntry.type}]`, logEntry.message);
          } else if (logEntry.level === 'warn') {
            console.warn(`[${logEntry.type}]`, logEntry.message);
          }
        },
        { level: 'warn' }
      );
    } catch {
      // Safe no-op if SDK logger cannot be re-bound
    }
  }

  private attachEnvironmentMonitors(): void {
    if (this.lifecycleAttached || typeof window === 'undefined') return;
    this.lifecycleAttached = true;

    window.addEventListener('offline', () => {
      void this.pauseStreams('browser_offline', {
        scheduleAutoResume: false,
        markOffline: true,
      });
    });

    window.addEventListener('online', () => {
      void this.resumeStreams('browser_online');
    });

    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        if (
          document.visibilityState === 'visible' &&
          (this.state === 'paused' || this.state === 'reconnecting') &&
          (typeof navigator === 'undefined' || navigator.onLine !== false)
        ) {
          void this.resumeStreams('visibility_foreground');
        }
      });
    }

    // Cleanly detach raw Listen XHR/fetch streams on page reload/unload so dev-server reloads never throw transport errors
    const cleanUnload = () => {
      this.detachAllRawListenersSync();
    };
    window.addEventListener('pagehide', cleanUnload);
    window.addEventListener('beforeunload', cleanUnload);

    // Prevent asynchronous internal WebChannel transport rejections from surfacing as uncaught errors during restarts
    window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
      if (
        event.reason &&
        isTransientFirestoreTransportError(event.reason) &&
        !isPermissionDeniedError(event.reason)
      ) {
        event.preventDefault();
        this.recordTransportSignal(
          'Write',
          event.reason instanceof Error ? event.reason.message : String(event.reason)
        );
      }
    });

    // Vite Dev Server HMR WebSocket lifecycle hooks (handles dev server restart gracefully when HMR is active)
    const hot = (import.meta as unknown as { hot?: { on?: (ev: string, cb: () => void) => void } })?.hot;
    if (hot && typeof hot.on === 'function') {
      hot.on('vite:ws:disconnect', () => {
        void this.pauseStreams('vite_dev_server_restart', { scheduleAutoResume: true });
      });
      hot.on('vite:beforeFullReload', () => {
        this.detachAllRawListenersSync();
      });
      hot.on('vite:ws:connect', () => {
        void this.resumeStreams('vite_dev_server_reconnected');
      });
    }

    // Track when all active Listen streams settle in sync
    try {
      onSnapshotsInSync(db, () => {
        if (!this.streamsPaused && this.networkEnabled) {
          this.lastSyncedAt = Date.now();
          if (this.state === 'reconnecting') {
            this.state = 'online';
            this.reconnectAttempt = 0;
            this.emitStatus();
          }
        }
      });
    } catch {
      // Non-fatal in non-browser contexts
    }

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      void this.pauseStreams('initial_offline', {
        scheduleAutoResume: false,
        markOffline: true,
      });
    }
  }

  public isStreamPausedOrOffline(): boolean {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return true;
    }
    return this.streamsPaused || !this.networkEnabled || this.state === 'offline';
  }

  public getStatus(): FirestoreStreamStatus {
    let activeListenStreams = 0;
    let pausedListenStreams = 0;
    for (const entry of this.listenStreams.values()) {
      if (entry.disposed) continue;
      if (entry.rawUnsub) {
        activeListenStreams += 1;
      } else {
        pausedListenStreams += 1;
      }
    }

    return {
      state: this.state,
      networkEnabled: this.networkEnabled,
      activeListenStreams,
      pausedListenStreams,
      inFlightWrites: this.inFlightWrites,
      listenRecoveries: this.listenRecoveries,
      writeRetries: this.writeRetries,
      suppressedTransportErrors: this.suppressedTransportErrors,
      reconnectAttempt: this.reconnectAttempt,
      lastDisconnectReason: this.lastDisconnectReason,
      lastSyncedAt: this.lastSyncedAt,
    };
  }

  public subscribeStatus(listener: (status: FirestoreStreamStatus) => void): () => void {
    this.statusListeners.add(listener);
    try {
      listener(this.getStatus());
    } catch {
      // Ignore subscriber error
    }
    return () => {
      this.statusListeners.delete(listener);
    };
  }

  public onReconnect(callback: () => void | Promise<void>): () => void {
    this.reconnectListeners.add(callback);
    return () => {
      this.reconnectListeners.delete(callback);
    };
  }

  public setCustomOriginProbe(probe: (() => Promise<boolean>) | null): void {
    this.customOriginProbe = probe;
  }

  private emitStatus(): void {
    if (this.statusListeners.size === 0) return;
    const snapshot = this.getStatus();
    this.statusListeners.forEach((cb) => {
      try {
        cb(snapshot);
      } catch {
        // Ignore listener error
      }
    });
  }

  private enqueueNetworkTransition(task: () => Promise<void>): Promise<void> {
    this.networkGate = this.networkGate.then(task, task).catch(() => {});
    return this.networkGate;
  }

  private detachAllRawListenersSync(): void {
    for (const entry of this.listenStreams.values()) {
      if (!entry.disposed) {
        entry.paused = true;
        entry.detachRaw();
      }
    }
  }

  /**
   * Gracefully pauses Firestore `Listen` and `Write` streams without losing logical subscriptions.
   */
  public async pauseStreams(
    reason = 'manual_pause',
    options?: { scheduleAutoResume?: boolean; markOffline?: boolean }
  ): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    this.streamsPaused = true;
    this.lastDisconnectReason = reason;
    this.state = options?.markOffline ? 'offline' : 'paused';

    // Release any mid-flight write waiters cleanly so callers can queue to IndexedDB instead of hanging
    if (this.pauseWaiters.size > 0) {
      const pauseErr = createPausedStreamError('write', reason);
      this.pauseWaiters.forEach((rejectWaiter) => {
        try {
          rejectWaiter(pauseErr);
        } catch {
          // Ignore
        }
      });
      this.pauseWaiters.clear();
    }

    this.detachAllRawListenersSync();
    this.emitStatus();

    await this.enqueueNetworkTransition(async () => {
      if (!this.streamsPaused || !this.networkEnabled) return;
      try {
        await disableNetwork(db);
        this.networkEnabled = false;
      } catch {
        this.networkEnabled = false;
      }
    });

    this.emitStatus();

    if (options?.scheduleAutoResume) {
      this.scheduleReconnect(reason);
    }
  }

  /**
   * Resumes Firestore network transport, re-subscribes paused/errored `Listen` streams, and flushes pending `Write`s.
   */
  public async resumeStreams(reason = 'manual_resume', forceIgnoreNavigator = false): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (
      !forceIgnoreNavigator &&
      typeof navigator !== 'undefined' &&
      navigator.onLine === false
    ) {
      this.state = 'offline';
      this.emitStatus();
      return;
    }

    this.streamsPaused = false;
    this.state = 'reconnecting';
    this.recentTransportSignals = [];
    this.emitStatus();

    await this.enqueueNetworkTransition(async () => {
      if (this.streamsPaused) return;
      if (!this.networkEnabled) {
        try {
          await enableNetwork(db);
          this.networkEnabled = true;
        } catch {
          // Keep attempting listener recovery
          this.networkEnabled = true;
        }
      }
    });

    if (this.streamsPaused) {
      return;
    }

    // Re-attach all active logical Listen subscriptions whose underlying stream was paused or errored
    for (const entry of this.listenStreams.values()) {
      if (!entry.disposed && !entry.rawUnsub) {
        entry.paused = false;
        const wasPreviouslyAttached = entry.wasPreviouslyAttached;
        entry.attach();
        if (wasPreviouslyAttached) {
          this.listenRecoveries += 1;
        }
      }
    }

    // Allow pending SDK Write mutations to settle with a non-blocking timeout guard
    try {
      await Promise.race([
        waitForPendingWrites(db).catch(() => {}),
        sleepMs(2000),
      ]);
    } catch {
      // Non-fatal
    }

    if (!this.streamsPaused) {
      this.state = 'online';
      this.reconnectAttempt = 0;
      this.lastSyncedAt = Date.now();
      this.lastDisconnectReason = reason === 'manual_resume' ? null : this.lastDisconnectReason;
      this.emitStatus();

      this.reconnectListeners.forEach((cb) => {
        try {
          void Promise.resolve(cb()).catch(() => {});
        } catch {
          // Ignore callback error
        }
      });
    }
  }

  private async probeServerReachability(): Promise<boolean> {
    if (this.customOriginProbe) {
      try {
        return await this.customOriginProbe();
      } catch {
        return false;
      }
    }

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return false;
    }

    if (
      typeof window === 'undefined' ||
      typeof fetch === 'undefined' ||
      !window.location?.protocol?.startsWith('http')
    ) {
      return true;
    }

    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timeout = controller ? setTimeout(() => controller.abort(), 2000) : null;
    try {
      const resp = await fetch(`${window.location.origin}/manifest.json`, {
        method: 'HEAD',
        cache: 'no-store',
        signal: controller?.signal,
      });
      return resp.ok || resp.status === 304 || resp.status === 404;
    } catch {
      return false;
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }

  public scheduleReconnect(reason = 'transport_backoff', baseDelayOverrideMs?: number): void {
    if (this.reconnectTimer) {
      return;
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      this.state = 'offline';
      this.emitStatus();
      return;
    }

    const attempt = this.reconnectAttempt;
    this.reconnectAttempt += 1;
    if (this.state !== 'paused') {
      this.state = 'reconnecting';
    }
    this.emitStatus();

    const baseDelay =
      typeof baseDelayOverrideMs === 'number'
        ? baseDelayOverrideMs
        : Math.min(12_000, 350 * Math.pow(2, Math.min(attempt, 5)));
    const jitter = Math.floor(Math.random() * Math.max(40, Math.round(baseDelay * 0.25)));
    const delayMs = baseDelay + jitter;

    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      const reachable = await this.probeServerReachability();
      if (!reachable) {
        this.scheduleReconnect(reason, baseDelayOverrideMs);
        return;
      }
      await this.resumeStreams(`recovered:${reason}`);
    }, delayMs);
  }

  public recordTransportSignal(kind: FirestoreStreamKind, detail: string): void {
    this.suppressedTransportErrors += 1;
    const now = Date.now();
    this.recentTransportSignals = this.recentTransportSignals.filter((t) => now - t < 5000);
    this.recentTransportSignals.push(now);

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      void this.pauseStreams('browser_offline', {
        scheduleAutoResume: false,
        markOffline: true,
      });
      return;
    }

    // When repeated Listen/Write WebChannel drops occur (e.g., dev server or proxy restart), pause briefly & auto-resume
    if (this.recentTransportSignals.length >= 2 && !this.streamsPaused) {
      void this.pauseStreams(`${kind.toLowerCase()}_stream_interrupted`, {
        scheduleAutoResume: true,
      });
      return;
    }

    // Ensure any individual terminated Listen stream gets re-attached
    const hasDetachedListener = Array.from(this.listenStreams.values()).some(
      (entry) => !entry.disposed && !entry.rawUnsub
    );
    if (hasDetachedListener) {
      this.lastDisconnectReason = detail.slice(0, 120);
      this.scheduleReconnect(`${kind.toLowerCase()}_stream_reattach`);
    } else {
      this.emitStatus();
    }
  }

  private recordListenSuccess(): void {
    this.lastSyncedAt = Date.now();
    if (this.state === 'reconnecting' && !this.streamsPaused) {
      this.state = 'online';
      this.reconnectAttempt = 0;
      this.emitStatus();
    }
  }

  /**
   * Managed `Listen` (`onSnapshot`) stream wrapper with automatic pause/resume & transient error recovery.
   */
  public listen(...args: any[]): Unsubscribe {
    const target = args[0];
    const pathHint: string =
      (target && typeof target.path === 'string' && target.path) || 'query';

    const second = args[1];
    const hasListenOptions =
      Boolean(second) &&
      typeof second === 'object' &&
      typeof second.next !== 'function' &&
      typeof second.error !== 'function';

    const listenOptions = hasListenOptions ? second : undefined;
    const callbackArgStart = hasListenOptions ? 2 : 1;
    const primaryCallbackOrObserver = args[callbackArgStart];

    let userNext: ((snapshot: any) => void) | undefined;
    let userError: ((error: any) => void) | undefined;
    let userComplete: (() => void) | undefined;

    if (primaryCallbackOrObserver && typeof primaryCallbackOrObserver === 'object') {
      userNext =
        typeof primaryCallbackOrObserver.next === 'function'
          ? primaryCallbackOrObserver.next.bind(primaryCallbackOrObserver)
          : undefined;
      userError =
        typeof primaryCallbackOrObserver.error === 'function'
          ? primaryCallbackOrObserver.error.bind(primaryCallbackOrObserver)
          : undefined;
      userComplete =
        typeof primaryCallbackOrObserver.complete === 'function'
          ? primaryCallbackOrObserver.complete.bind(primaryCallbackOrObserver)
          : undefined;
    } else {
      userNext =
        typeof primaryCallbackOrObserver === 'function' ? primaryCallbackOrObserver : undefined;
      userError =
        typeof args[callbackArgStart + 1] === 'function'
          ? args[callbackArgStart + 1]
          : undefined;
      userComplete =
        typeof args[callbackArgStart + 2] === 'function'
          ? args[callbackArgStart + 2]
          : undefined;
    }

    const id = this.nextListenerId++;
    const entry: ManagedListenEntry = {
      id,
      pathHint,
      disposed: false,
      paused: this.streamsPaused,
      wasPreviouslyAttached: false,
      rawUnsub: null,
      detachRaw: () => {
        if (entry.rawUnsub) {
          const prev = entry.rawUnsub;
          entry.rawUnsub = null;
          try {
            prev();
          } catch {
            // Safe teardown
          }
        }
      },
      attach: () => {
        if (entry.disposed || entry.rawUnsub || this.streamsPaused) {
          return;
        }

        const onNextWrapped = (snapshot: any) => {
          if (entry.disposed) return;
          this.recordListenSuccess();
          userNext?.(snapshot);
        };

        const onErrorWrapped = (err: any) => {
          // Firestore permanently terminates the underlying listener once onError fires
          entry.rawUnsub = null;
          if (entry.disposed) return;

          if (isTransientFirestoreTransportError(err) && !isPermissionDeniedError(err)) {
            entry.paused = true;
            this.recordTransportSignal(
              'Listen',
              err instanceof Error ? err.message : String(err)
            );
            return;
          }

          // Non-transient error (e.g., permission-denied or invalid query): surface to caller without retry loop
          entry.disposed = true;
          this.listenStreams.delete(entry.id);
          this.emitStatus();
          if (userError) {
            userError(err);
          } else {
            console.error(`Firestore Listen error [${pathHint}]:`, err);
          }
        };

        try {
          entry.wasPreviouslyAttached = true;
          entry.rawUnsub = listenOptions
            ? (rawOnSnapshot as any)(
                target,
                listenOptions,
                onNextWrapped,
                onErrorWrapped,
                userComplete
              )
            : (rawOnSnapshot as any)(target, onNextWrapped, onErrorWrapped, userComplete);
        } catch (syncAttachErr) {
          entry.rawUnsub = null;
          if (
            isTransientFirestoreTransportError(syncAttachErr) &&
            !isPermissionDeniedError(syncAttachErr)
          ) {
            entry.paused = true;
            this.recordTransportSignal(
              'Listen',
              syncAttachErr instanceof Error ? syncAttachErr.message : String(syncAttachErr)
            );
          } else {
            entry.disposed = true;
            this.listenStreams.delete(entry.id);
            if (userError) {
              userError(syncAttachErr);
            } else {
              throw syncAttachErr;
            }
          }
        }
      },
    };

    this.listenStreams.set(id, entry);
    if (!this.streamsPaused) {
      entry.attach();
    } else {
      entry.wasPreviouslyAttached = true;
    }
    this.emitStatus();

    return () => {
      if (entry.disposed) return;
      entry.disposed = true;
      entry.detachRaw();
      this.listenStreams.delete(id);
      this.emitStatus();
    };
  }

  /**
   * Managed `Write` stream executor with pause awareness, mid-flight disconnect guard, and transient backoff retry.
   */
  public async write<T>(
    operationName: string,
    pathHint: string | null,
    executeFn: () => Promise<T>,
    options?: { maxRetries?: number }
  ): Promise<T> {
    if (this.isStreamPausedOrOffline()) {
      throw createPausedStreamError(operationName, pathHint);
    }

    const maxRetries = options?.maxRetries ?? 2;
    this.inFlightWrites += 1;
    this.emitStatus();

    try {
      let attempt = 0;
      while (true) {
        if (this.isStreamPausedOrOffline()) {
          throw createPausedStreamError(operationName, pathHint);
        }

        let removePauseWaiter: (() => void) | null = null;
        try {
          const pauseAbortPromise = new Promise<never>((_, reject) => {
            const waiter = (err: Error) => reject(err);
            this.pauseWaiters.add(waiter);
            removePauseWaiter = () => this.pauseWaiters.delete(waiter);
          });

          const opPromise = executeFn();
          // Guard against unhandled rejection if pauseAbortPromise wins the race while SDK parks the write
          opPromise.catch(() => {});

          const result = await Promise.race([opPromise, pauseAbortPromise]);
          this.lastSyncedAt = Date.now();
          return result;
        } catch (err) {
          if (isPermissionDeniedError(err) || !isTransientFirestoreTransportError(err)) {
            throw err;
          }

          if (
            (err as { isFirestoreStreamPaused?: boolean })?.isFirestoreStreamPaused ||
            this.isStreamPausedOrOffline() ||
            attempt >= maxRetries
          ) {
            if (!(err as { isFirestoreStreamPaused?: boolean })?.isFirestoreStreamPaused) {
              this.recordTransportSignal(
                'Write',
                err instanceof Error ? err.message : String(err)
              );
            }
            throw err;
          }

          attempt += 1;
          this.writeRetries += 1;
          this.recordTransportSignal(
            'Write',
            err instanceof Error ? err.message : String(err)
          );
          const backoffMs = 180 * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 80);
          await sleepMs(backoffMs);
        } finally {
          if (removePauseWaiter) {
            (removePauseWaiter as () => void)();
          }
        }
      }
    } finally {
      this.inFlightWrites = Math.max(0, this.inFlightWrites - 1);
      this.emitStatus();
    }
  }

  /**
   * Managed `Read` executor that seamlessly falls back to local persistent cache during temporary drops.
   */
  public async read<T>(
    operationName: 'getDoc' | 'getDocs',
    pathHint: string | null,
    executeFn: () => Promise<T>,
    target: any
  ): Promise<T> {
    if (this.isStreamPausedOrOffline()) {
      try {
        return operationName === 'getDoc'
          ? ((await getDocFromCache(target)) as unknown as T)
          : ((await getDocsFromCache(target)) as unknown as T);
      } catch {
        throw createPausedStreamError(operationName, pathHint);
      }
    }

    try {
      return await executeFn();
    } catch (err) {
      if (isTransientFirestoreTransportError(err) && !isPermissionDeniedError(err)) {
        this.recordTransportSignal('Listen', err instanceof Error ? err.message : String(err));
        try {
          return operationName === 'getDoc'
            ? ((await getDocFromCache(target)) as unknown as T)
            : ((await getDocsFromCache(target)) as unknown as T);
        } catch {
          // Fall through if not in cache
        }
      }
      throw err;
    }
  }

  /**
   * Replayable `WriteBatch` factory so transient `Write` stream retries never fail with
   * "A write batch can no longer be used after commit() has been called".
   */
  public createResilientBatch(firestore: Firestore): WriteBatch {
    const recordedOps: Array<(batch: WriteBatch) => void> = [];
    let committed = false;

    const batchProxy: WriteBatch = {
      set(documentRef: any, data: any, options?: any): WriteBatch {
        const sanitized = sanitizeForFirestore(data);
        recordedOps.push((b) => {
          if (options !== undefined) {
            b.set(documentRef, sanitized, options);
          } else {
            b.set(documentRef, sanitized);
          }
        });
        return batchProxy;
      },
      update(documentRef: any, ...rest: any[]): WriteBatch {
        const normalizedArgs = rest.length === 1 ? [sanitizeForFirestore(rest[0])] : rest;
        recordedOps.push((b) => {
          (b.update as any)(documentRef, ...normalizedArgs);
        });
        return batchProxy;
      },
      delete(documentRef: any): WriteBatch {
        recordedOps.push((b) => {
          b.delete(documentRef);
        });
        return batchProxy;
      },
      commit: async (): Promise<void> => {
        if (committed) {
          throw new Error('WriteBatch has already been committed.');
        }
        await this.write('writeBatch.commit', 'batch', async () => {
          const freshBatch = rawWriteBatch(firestore);
          for (const applyOp of recordedOps) {
            applyOp(freshBatch);
          }
          await freshBatch.commit();
        });
        committed = true;
      },
    };

    return batchProxy;
  }
}

export const FirestoreStreamResilience = FirestoreStreamResilienceManager.getInstance();

// Resilient Firestore SDK Wrappers (drop-in typed replacements for all Listen, Write, and Read operations)
export const resilientOnSnapshot: typeof rawOnSnapshot = ((...args: any[]) =>
  FirestoreStreamResilience.listen(...args)) as typeof rawOnSnapshot;

export const onSnapshot: typeof rawOnSnapshot = resilientOnSnapshot;

export const setDoc: typeof rawSetDoc = ((ref: any, data: any, options?: any) =>
  FirestoreStreamResilience.write('setDoc', ref?.path || null, () =>
    options !== undefined
      ? rawSetDoc(ref, sanitizeForFirestore(data), options)
      : rawSetDoc(ref, sanitizeForFirestore(data))
  )) as typeof rawSetDoc;

export const updateDoc: typeof rawUpdateDoc = ((ref: any, ...rest: any[]) =>
  FirestoreStreamResilience.write('updateDoc', ref?.path || null, () =>
    (rawUpdateDoc as any)(
      ref,
      ...(rest.length === 1 ? [sanitizeForFirestore(rest[0])] : rest)
    )
  )) as typeof rawUpdateDoc;

export const addDoc: typeof rawAddDoc = ((ref: any, data: any) =>
  FirestoreStreamResilience.write('addDoc', ref?.path || null, () =>
    rawAddDoc(ref, sanitizeForFirestore(data))
  )) as typeof rawAddDoc;

export const deleteDoc: typeof rawDeleteDoc = ((ref: any) =>
  FirestoreStreamResilience.write('deleteDoc', ref?.path || null, () =>
    rawDeleteDoc(ref)
  )) as typeof rawDeleteDoc;

export const runTransaction: typeof rawRunTransaction = ((
  firestore: any,
  updateFunction: any,
  options?: any
) =>
  FirestoreStreamResilience.write(
    'runTransaction',
    'transaction',
    () => rawRunTransaction(firestore, updateFunction, options),
    { maxRetries: 1 }
  )) as typeof rawRunTransaction;

export const writeBatch: typeof rawWriteBatch = ((firestore: Firestore) =>
  FirestoreStreamResilience.createResilientBatch(firestore)) as typeof rawWriteBatch;

export const getDoc: typeof rawGetDoc = ((ref: any) =>
  FirestoreStreamResilience.read('getDoc', ref?.path || null, () => rawGetDoc(ref), ref)) as typeof rawGetDoc;

export const getDocs: typeof rawGetDocs = ((q: any) =>
  FirestoreStreamResilience.read('getDocs', (q as any)?.path || 'query', () => rawGetDocs(q), q)) as typeof rawGetDocs;

export const getDocFromServer: typeof rawGetDocFromServer = ((ref: any) =>
  rawGetDocFromServer(ref)) as typeof rawGetDocFromServer;

// Validate connection to Firestore on boot (per Firebase Integration specification)
async function testConnection(): Promise<void> {
  if (FirestoreStreamResilience.isStreamPausedOrOffline()) {
    return;
  }
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      if (typeof navigator === 'undefined' || navigator.onLine !== false) {
        console.error('Please check your Firebase configuration.');
      } else {
        void FirestoreStreamResilience.pauseStreams('boot_offline', {
          scheduleAutoResume: false,
          markOffline: true,
        });
      }
    } else if (isTransientFirestoreTransportError(error)) {
      FirestoreStreamResilience.recordTransportSignal(
        'Listen',
        error instanceof Error ? error.message : String(error)
      );
    }
  }
}
if (typeof window !== 'undefined') {
  void testConnection();
}

// Deterministic offline-resilient SVG avatar generator (replaces fragile external image hosts)
export function createDeterministicAvatarDataUri(label: string, accentHex = '#0F766E'): string {
  const clean = (label || 'S').trim();
  const initials =
    clean
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() || '')
      .join('') || 'S';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" rx="28" fill="${accentHex}"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="#FAF8F5" font-family="Plus Jakarta Sans, system-ui, sans-serif" font-weight="700" font-size="34">${initials.replace(/[<>&"']/g, '')}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Offline-resilient atmospheric scenic Moment & gallery illustration SVG generator
export function createScenicMomentDataUri(
  title: string,
  subtitle = 'Splender Moment',
  primaryHex = '#0F766E',
  secondaryHex = '#1E293B'
): string {
  const safeTitle = (title || 'Moment')
    .slice(0, 56)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  const safeSubtitle = (subtitle || 'Splender Moment')
    .slice(0, 64)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 960"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${primaryHex}"/><stop offset="100%" stop-color="${secondaryHex}"/></linearGradient></defs><rect width="720" height="960" fill="url(#bg)"/><circle cx="548" cy="216" r="108" fill="#FDE68A" fill-opacity="0.22"/><path d="M0 680 L210 510 L390 645 L560 475 L720 620 L720 960 L0 960 Z" fill="#0B1120" fill-opacity="0.34"/><path d="M0 760 L165 640 L355 745 L540 595 L720 715 L720 960 L0 960 Z" fill="#020617" fill-opacity="0.52"/><text x="56" y="828" fill="#F8FAFC" font-family="Plus Jakarta Sans, system-ui, sans-serif" font-weight="700" font-size="34">${safeTitle}</text><text x="56" y="872" fill="#CBD5E1" font-family="Plus Jakarta Sans, system-ui, sans-serif" font-weight="500" font-size="20">${safeSubtitle}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function sanitizeBoundedAvatar(
  avatarUrl: string | undefined | null,
  fallbackLabel: string,
  accentHex = '#0F766E'
): string {
  if (!avatarUrl || avatarUrl.length > 800_000) {
    return createDeterministicAvatarDataUri(fallbackLabel, accentHex);
  }
  return avatarUrl;
}

// Backward compatibility bridge for db.collection(...).doc(...) style calls (routed through resilient wrappers)
(db as any).collection = (collPath: string) => ({
  doc: (docId: string) => ({
    update: (data: any) => updateDoc(doc(db, collPath, docId), sanitizeForFirestore(data)),
    set: (data: any, options?: any) => setDoc(doc(db, collPath, docId), sanitizeForFirestore(data), options),
    get: () => getDoc(doc(db, collPath, docId)),
    delete: () => deleteDoc(doc(db, collPath, docId)),
    onSnapshot: (callback: any, errorCallback?: any) =>
      onSnapshot(
        doc(db, collPath, docId),
        callback,
        errorCallback || ((err: any) => console.debug(`Snapshot listener notice [${collPath}/${docId}]:`, err))
      ),
    collection: (subCollPath: string) => (db as any).collection(`${collPath}/${docId}/${subCollPath}`),
  }),
  add: (data: any) => addDoc(collection(db, collPath), sanitizeForFirestore(data)),
  get: () => getDocs(collection(db, collPath)),
  onSnapshot: (callback: any, errorCallback?: any) =>
    onSnapshot(
      collection(db, collPath),
      callback,
      errorCallback || ((err: any) => console.debug(`Collection listener notice [${collPath}]:`, err))
    ),
});
(db as any).runTransaction = (updateFn: any) => runTransaction(db, updateFn);

export {
  signInAnonymously,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  linkWithPopup,
  signOut,
  onAuthStateChanged,
  linkWithCredential,
  GoogleAuthProvider,
  EmailAuthProvider,
  signInWithCredential,
  disableNetwork,
  enableNetwork,
  waitForPendingWrites,
  onSnapshotsInSync,
  doc,
  collection,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  increment,
  arrayUnion,
  deleteField,
};
export type { FirebaseUser };

// ==========================================
// REAL-TIME USER PRESENCE & TYPING TRACKER
// ==========================================
const typingTimeouts: Record<string, NodeJS.Timeout> = {};

export async function updateUserPresence(uid: string, isOnline: boolean): Promise<void> {
  if (!uid || FirestoreStreamResilience.isStreamPausedOrOffline()) return;
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      isOnline,
      status: isOnline ? 'online' : 'offline',
      lastSeen: Date.now(),
    });
  } catch (err) {
    console.debug('Presence update notice:', err);
  }
}

export function initPresenceTracking(uid: string): () => void {
  if (typeof window === 'undefined' || !uid) return () => {};

  void updateUserPresence(uid, true);

  const handleVisibility = () => {
    if (document.visibilityState === 'hidden') {
      void updateUserPresence(uid, false);
    } else {
      void updateUserPresence(uid, true);
    }
  };

  const handleOffline = () => void updateUserPresence(uid, false);
  const handleOnline = () => void updateUserPresence(uid, true);

  const heartbeat = setInterval(() => {
    if (document.visibilityState === 'visible' && !FirestoreStreamResilience.isStreamPausedOrOffline()) {
      void updateUserPresence(uid, true);
    }
  }, 25000);

  const unsubReconnect = FirestoreStreamResilience.onReconnect(() => {
    if (typeof document === 'undefined' || document.visibilityState === 'visible') {
      void updateUserPresence(uid, true);
    }
  });

  document.addEventListener('visibilitychange', handleVisibility);
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
  window.addEventListener('beforeunload', handleOffline);
  window.addEventListener('pagehide', handleOffline);

  return () => {
    clearInterval(heartbeat);
    unsubReconnect();
    document.removeEventListener('visibilitychange', handleVisibility);
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
    window.removeEventListener('beforeunload', handleOffline);
    window.removeEventListener('pagehide', handleOffline);
    void updateUserPresence(uid, false);
  };
}

export async function setDebouncedTypingStatus(
  conversationId: string,
  myUid: string,
  recipientUid: string,
  isTyping: boolean
): Promise<void> {
  if (
    !conversationId ||
    !myUid ||
    conversationId === 'conv_demo_starter' ||
    conversationId === 'splender_ai_assistant' ||
    conversationId.startsWith('p2p_') ||
    FirestoreStreamResilience.isStreamPausedOrOffline()
  ) {
    return;
  }

  const key = `${conversationId}_${myUid}`;

  if (typingTimeouts[key]) {
    clearTimeout(typingTimeouts[key]);
    delete typingTimeouts[key];
  }

  try {
    const convRef = doc(db, 'conversations', conversationId);
    await updateDoc(convRef, {
      [`typing.${myUid}`]: isTyping,
    });

    const userRef = doc(db, 'users', myUid);
    await updateDoc(userRef, {
      typingTo: isTyping ? recipientUid : null,
    });
  } catch (err) {
    console.debug('Typing status update notice:', err);
  }

  if (isTyping) {
    typingTimeouts[key] = setTimeout(async () => {
      try {
        if (FirestoreStreamResilience.isStreamPausedOrOffline()) return;
        const convRef = doc(db, 'conversations', conversationId);
        await updateDoc(convRef, {
          [`typing.${myUid}`]: false,
        });

        const userRef = doc(db, 'users', myUid);
        await updateDoc(userRef, {
          typingTo: null,
        });
      } catch (err) {
        console.debug('Typing debounce clear notice:', err);
      } finally {
        delete typingTimeouts[key];
      }
    }, 3000);
  }
}

async function dataUrlToBytes(dataUrl: string): Promise<{ bytes: Uint8Array; mime: string }> {
  const [header, b64] = dataUrl.split(',');
  const mimeMatch = header?.match(/data:([^;]+)/);
  const mime = mimeMatch?.[1] || 'application/octet-stream';
  const binary = atob(b64 || '');
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return { bytes, mime };
}

function bytesToBase64Attachment(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return btoa(binary);
}

function base64ToBytesAttachment(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Encrypts binary bytes with a fresh cryptographically random 256-bit AES-GCM Content Encryption Key (CEK)
 * so zero plaintext media bytes or targetId-derivable ciphertexts are ever stored in Firebase Storage.
 */
async function encryptAttachmentForStorage(
  plainBytes: Uint8Array
): Promise<{ blob: Blob; cekBase64: string }> {
  const cekBytes = crypto.getRandomValues(new Uint8Array(32));
  const cekBase64 = bytesToBase64Attachment(cekBytes);
  const key = await crypto.subtle.importKey(
    'raw',
    cekBytes as unknown as BufferSource,
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipherBuf = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    plainBytes as unknown as BufferSource
  );
  const cipherBytes = new Uint8Array(cipherBuf);
  const frame = new Uint8Array(12 + cipherBytes.length);
  frame.set(iv, 0);
  frame.set(cipherBytes, 12);
  return {
    blob: new Blob([frame], { type: 'application/octet-stream' }),
    cekBase64,
  };
}

export async function decryptAttachmentFromStorageUrl(url: string, targetId: string): Promise<string> {
  if (!url) return url;

  // 1. Primary path: random 256-bit CEK fragment (`#splender_e2ee_cek=...&mime=...`)
  if (url.includes('#splender_e2ee_cek=')) {
    try {
      const [cleanUrl, hashPart] = url.split('#');
      const params = new URLSearchParams(hashPart || '');
      const cekBase64 = params.get('splender_e2ee_cek');
      const mime = params.get('mime') || 'application/octet-stream';
      if (!cekBase64) return url;

      const resp = await fetch(cleanUrl);
      if (!resp.ok) return url;
      const frame = new Uint8Array(await resp.arrayBuffer());
      if (frame.length <= 28) return url;

      const iv = frame.slice(0, 12);
      const cipherBytes = frame.slice(12);
      const cekBytes = base64ToBytesAttachment(cekBase64);
      const key = await crypto.subtle.importKey(
        'raw',
        cekBytes as unknown as BufferSource,
        { name: 'AES-GCM' },
        false,
        ['decrypt']
      );
      const plainBuf = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        key,
        cipherBytes as unknown as BufferSource
      );
      return URL.createObjectURL(new Blob([plainBuf], { type: mime }));
    } catch {
      return url;
    }
  }

  // 2. Read-only legacy fallback for pre-upgrade attachments (`#splender_e2ee_mime=...`)
  if (!url.includes('#splender_e2ee_mime=')) return url;
  try {
    const [cleanUrl, hashPart] = url.split('#splender_e2ee_mime=');
    const mime = decodeURIComponent(hashPart || 'application/octet-stream');
    const resp = await fetch(cleanUrl);
    if (!resp.ok) return url;
    const frame = new Uint8Array(await resp.arrayBuffer());
    if (frame.length <= 28) return url;

    const iv = frame.slice(0, 12);
    const cipherBytes = frame.slice(12);
    const enc = new TextEncoder();
    const keyBuf = await crypto.subtle.digest('SHA-256', enc.encode(`splender_v17_chat_storage::${targetId}`));
    const key = await crypto.subtle.importKey('raw', keyBuf, { name: 'AES-GCM' }, false, ['decrypt']);
    const plainBuf = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      cipherBytes as unknown as BufferSource
    );
    return URL.createObjectURL(new Blob([plainBuf], { type: mime }));
  } catch {
    return url;
  }
}

/**
 * Uploads media files to Firebase Storage.
 * For `chats`, binary payloads are always encrypted client-side with a random 256-bit AES-GCM CEK
 * (`application/octet-stream`) before upload so plaintext attachments are NEVER stored on Firebase Storage.
 */
export async function uploadMediaToStorage(
  category: 'chats' | 'moments' | 'stories',
  targetId: string,
  mediaType: 'images' | 'videos' | 'audio' | 'files',
  quality: MediaQuality = 'high',
  fileOrDataUrl: File | Blob | string,
  customFilename?: string
): Promise<{ url: string; quality: MediaQuality; storagePath: string }> {
  const extension =
    category === 'chats' || mediaType === 'files'
      ? 'bin'
      : mediaType === 'audio'
      ? 'webm'
      : mediaType === 'videos'
      ? 'mp4'
      : 'webp';

  const filename =
    customFilename || `${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${extension}`;
  const storagePath = `${category}/${targetId}/${mediaType}/${quality}/${filename}`;

  try {
    if (
      !auth.currentUser ||
      FirestoreStreamResilience.isStreamPausedOrOffline()
    ) {
      throw new Error('Storage upload skipped: offline or unauthenticated session');
    }

    const performStorageUpload = async (): Promise<{
      url: string;
      quality: MediaQuality;
      storagePath: string;
    }> => {
      const fileRef = storageRef(storage, storagePath);
      const metadata = {
        contentType: category === 'chats' ? 'application/octet-stream' : undefined,
        customMetadata: {
          quality,
          mediaType,
          category,
          targetId,
          e2ee: category === 'chats' ? 'aes-gcm-256-cek' : 'public-ephemeral',
          uploadedAt: String(Date.now()),
        },
      };

      if (category === 'chats') {
        let plainBytes: Uint8Array;
        let origMime =
          mediaType === 'audio'
            ? 'audio/webm'
            : mediaType === 'videos'
            ? 'video/mp4'
            : mediaType === 'files'
            ? 'application/octet-stream'
            : 'image/webp';

        if (typeof fileOrDataUrl === 'string') {
          if (!fileOrDataUrl.startsWith('data:')) {
            return { url: fileOrDataUrl, quality, storagePath };
          }
          const parsed = await dataUrlToBytes(fileOrDataUrl);
          plainBytes = parsed.bytes;
          origMime = parsed.mime;
        } else {
          plainBytes = new Uint8Array(await fileOrDataUrl.arrayBuffer());
          origMime = fileOrDataUrl.type || origMime;
        }

        const { blob: encryptedBlob, cekBase64 } = await encryptAttachmentForStorage(plainBytes);
        await uploadBytes(fileRef, encryptedBlob, metadata);
        const rawDownloadUrl = await getDownloadURL(fileRef);
        return {
          url: `${rawDownloadUrl}#splender_e2ee_cek=${encodeURIComponent(cekBase64)}&mime=${encodeURIComponent(origMime)}`,
          quality,
          storagePath,
        };
      }

      if (typeof fileOrDataUrl === 'string') {
        if (fileOrDataUrl.startsWith('data:')) {
          const parsed = await dataUrlToBytes(fileOrDataUrl);
          await uploadBytes(
            fileRef,
            new Blob([parsed.bytes as unknown as BlobPart], { type: parsed.mime }),
            metadata
          );
          const url = await getDownloadURL(fileRef);
          return { url, quality, storagePath };
        }
        return { url: fileOrDataUrl, quality, storagePath };
      } else {
        await uploadBytes(fileRef, fileOrDataUrl, metadata);
        const url = await getDownloadURL(fileRef);
        return { url, quality, storagePath };
      }
    };

    const timeoutGuard = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Storage upload timed out after 4000ms')), 4000);
    });

    return await Promise.race([performStorageUpload(), timeoutGuard]);
  } catch (err) {
    console.debug('Firebase storage upload fallback to local encrypted/memory payload:', err);
    if (typeof fileOrDataUrl === 'string') {
      return { url: fileOrDataUrl, quality, storagePath };
    } else {
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve((e.target?.result as string) || '');
        reader.onerror = () => resolve('');
        reader.readAsDataURL(fileOrDataUrl);
      });
      return { url: dataUrl, quality, storagePath };
    }
  }
}

async function compressInlineImageDataUrl(
  dataUrl: string,
  maxChars = 680_000
): Promise<string> {
  if (typeof document === 'undefined' || dataUrl.length <= maxChars) {
    return dataUrl.length <= maxChars
      ? dataUrl
      : createScenicMomentDataUri('Moment Snapshot', 'Compressed for peer sync');
  }

  return new Promise<string>((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const tiers: Array<{ maxDim: number; quality: number }> = [
          { maxDim: 1080, quality: 0.78 },
          { maxDim: 820, quality: 0.65 },
          { maxDim: 600, quality: 0.52 },
          { maxDim: 420, quality: 0.42 },
        ];
        for (const tier of tiers) {
          const scale = Math.min(1, tier.maxDim / Math.max(img.width || 1, img.height || 1));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round((img.width || 640) * scale));
          canvas.height = Math.max(1, Math.round((img.height || 640) * scale));
          const ctx = canvas.getContext('2d');
          if (!ctx) break;
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const candidate = canvas.toDataURL('image/jpeg', tier.quality);
          if (candidate.length <= maxChars) {
            resolve(candidate);
            return;
          }
        }
      } catch {
        // Fallback below
      }
      resolve(createScenicMomentDataUri('Moment Snapshot', 'Compressed for peer sync'));
    };
    img.onerror = () => {
      resolve(createScenicMomentDataUri('Moment Snapshot', 'Compressed for peer sync'));
    };
    img.src = dataUrl;
  });
}

/**
 * Programmatically guarantees Moment media payloads adhere to `firebase-blueprint.json`
 * (`mediaUrl` maxLength <= 900,000 and safely within Firestore's 1 MiB document cap).
 * Uploads `data:` payloads to Firebase Storage (`moments/{ownerUid}/...`) first, and
 * downscales/compresses inline fallbacks if Storage is offline or unprovisioned.
 */
export async function ensureFirestoreSafeMomentMedia(
  fileOrUrl: string,
  ownerUid: string,
  mediaType: 'image' | 'video' | 'audio' | 'text' = 'image',
  quality: MediaQuality = 'high',
  maxInlineChars = 680_000
): Promise<{ mediaUrl: string; mediaType: 'image' | 'video' | 'audio' | 'text' }> {
  const trimmed = (fileOrUrl || '').trim();
  if (!trimmed) {
    return {
      mediaUrl: createScenicMomentDataUri('Splender Moment', '24h Ephemeral Status'),
      mediaType: 'image',
    };
  }

  // Compact SVG data URIs (e.g., text statuses) already fit well under 32 KB
  if (trimmed.startsWith('data:image/svg+xml') && trimmed.length <= maxInlineChars) {
    return { mediaUrl: trimmed, mediaType };
  }

  // Binary data URIs: attempt Storage upload under `moments/{ownerUid}/...` first when authenticated
  if (trimmed.startsWith('data:')) {
    let candidateUrl = trimmed;
    if (ownerUid && auth.currentUser) {
      const storageCategory: 'images' | 'videos' | 'audio' =
        mediaType === 'video' ? 'videos' : mediaType === 'audio' ? 'audio' : 'images';
      const uploaded = await uploadMediaToStorage(
        'moments',
        ownerUid,
        storageCategory,
        quality,
        trimmed
      );
      if (uploaded.url && !uploaded.url.startsWith('data:') && uploaded.url.length <= 900_000) {
        return { mediaUrl: uploaded.url, mediaType };
      }
      candidateUrl = uploaded.url || trimmed;
    }

    if (candidateUrl.length <= maxInlineChars) {
      return { mediaUrl: candidateUrl, mediaType };
    }

    if (candidateUrl.startsWith('data:image/')) {
      const compressed = await compressInlineImageDataUrl(candidateUrl, maxInlineChars);
      return { mediaUrl: compressed, mediaType: 'image' };
    }

    // Oversized inline audio/video when Storage is unreachable: fall back to a bounded poster card
    return {
      mediaUrl: createScenicMomentDataUri(
        mediaType === 'video' ? 'Video Moment' : 'Voice Moment',
        'Preview optimized for offline sync',
        '#0F766E',
        '#111827'
      ),
      mediaType: 'image',
    };
  }

  // External / Storage HTTPS URLs: enforce strict blueprint maxLength
  if (trimmed.length > 900_000) {
    return {
      mediaUrl: createScenicMomentDataUri('Splender Moment', '24h Ephemeral Status'),
      mediaType: 'image',
    };
  }
  return { mediaUrl: trimmed, mediaType };
}

export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined || typeof data !== 'object') {
    return data;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => (typeof item === 'object' && item !== null ? sanitizeForFirestore(item) : item)) as unknown as T;
  }
  const result: Record<string, any> = {};
  for (const [key, val] of Object.entries(data as Record<string, any>)) {
    if (val === undefined) {
      continue;
    }
    if (val !== null && typeof val === 'object' && !(val instanceof Date)) {
      result[key] = sanitizeForFirestore(val);
    } else {
      result[key] = val;
    }
  }
  return result as T;
}
