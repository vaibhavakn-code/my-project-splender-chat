// src/lib/sanjivaniResilience.ts
/**
 * ==============================================================================
 * SANJIVANI RESILIENCE ENGINE (संजीवनी पुनरुत्थान संहित)
 * Self-Healing Offline Local State, Circuit Breaker & Resilient Network Adapter
 * ==============================================================================
 *
 * Capabilities:
 * 1. Circuit Breaker (CLOSED -> OPEN -> HALF_OPEN) preventing network thundering herds.
 * 2. Self-Healing IndexedDB Queue with automatic schema repair and deduplication.
 * 3. Exponential Backoff with randomized full-jitter retry scheduling.
 * 4. In-Memory Shadow Buffer fallback if browser storage is blocked or quota exceeded.
 * 5. Reconnection handshake reconciliation with real-time health telemetry.
 */

import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { SplenderKeyVault } from './keyVault';

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface SanjivaniHealthTelemetry {
  circuitState: CircuitState;
  consecutiveFailures: number;
  inMemoryFallbackActive: boolean;
  lastSyncTimestamp: number;
  queueLength: number;
}

export interface ResilientMessageItem {
  id: string;
  roomId: string;
  content: string;
  timestamp: number;
  retryCount: number;
  lastAttemptAt?: number;
}

interface SanjivaniDB extends DBSchema {
  pending_messages: {
    key: string;
    value: ResilientMessageItem;
    indexes: { 'by-room': string; 'by-timestamp': number };
  };
}

export class SanjivaniResilience {
  private static instance: SanjivaniResilience;
  private dbPromise: Promise<IDBPDatabase<SanjivaniDB>> | null = null;
  private circuitState: CircuitState = 'CLOSED';
  private failureCount = 0;
  private lastFailureTime = 0;
  private inMemoryQueue: Map<string, ResilientMessageItem> = new Map();
  private inMemoryFallback = false;

  private readonly FAILURE_THRESHOLD = 4;
  private readonly RECOVERY_COOLDOWN_MS = 12000; // 12 seconds cooldown before half-open
  private readonly MAX_RETRIES = 6;

  private constructor() {
    this.initDatabase();
  }

  public static getInstance(): SanjivaniResilience {
    if (!SanjivaniResilience.instance) {
      SanjivaniResilience.instance = new SanjivaniResilience();
    }
    return SanjivaniResilience.instance;
  }

  private initDatabase(): void {
    if (typeof window === 'undefined') return;

    try {
      this.dbPromise = openDB<SanjivaniDB>('splender-db', 2, {
        upgrade(db, _oldVersion, _newVersion, transaction) {
          let store;
          if (!db.objectStoreNames.contains('pending_messages')) {
            store = db.createObjectStore('pending_messages', { keyPath: 'id' });
          } else {
            store = transaction.objectStore('pending_messages');
          }
          try {
            if (!store.indexNames.contains('by-room')) {
              store.createIndex('by-room', 'roomId');
            }
            if (!store.indexNames.contains('by-timestamp')) {
              store.createIndex('by-timestamp', 'timestamp');
            }
          } catch {
            // Non-blocking index creation
          }
        },
      }).catch((err) => {
        console.warn('Sanjivani DB initialization fell back to in-memory mode:', err);
        this.inMemoryFallback = true;
        return null as any;
      });
    } catch (e) {
      console.warn('Sanjivani DB catch fallback:', e);
      this.inMemoryFallback = true;
    }
  }

  /**
   * Evaluates if execution is permitted based on circuit state
   */
  public canExecuteNetworkRequest(): boolean {
    const now = Date.now();
    if (this.circuitState === 'OPEN') {
      if (now - this.lastFailureTime > this.RECOVERY_COOLDOWN_MS) {
        this.circuitState = 'HALF_OPEN';
        return true; // Probe request permitted
      }
      return false; // Fast fail without spamming network
    }
    return true;
  }

  /**
   * Reports network execution success to circuit breaker
   */
  public recordSuccess(): void {
    this.failureCount = 0;
    this.circuitState = 'CLOSED';
  }

  /**
   * Reports network execution failure to circuit breaker
   */
  public recordFailure(): void {
    this.failureCount += 1;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.FAILURE_THRESHOLD) {
      this.circuitState = 'OPEN';
    }
  }

  /**
   * Computes exponential backoff delay with randomized full-jitter
   */
  public computeBackoffDelay(retryCount: number): number {
    const base = Math.min(100 * Math.pow(2, retryCount), 4000);
    // Full jitter: uniformly distributed between 0 and base
    return Math.floor(Math.random() * base);
  }

  /**
   * Pushes message into resilient queue (IndexedDB sealed via SplenderKeyVault + In-Memory shadow backup)
   */
  public async enqueue(item: Omit<ResilientMessageItem, 'retryCount'>): Promise<ResilientMessageItem> {
    const messageItem: ResilientMessageItem = {
      ...item,
      retryCount: 0,
      timestamp: item.timestamp || Date.now(),
    };

    // Mirror in memory for instantaneous zero-latency UI retrieval
    this.inMemoryQueue.set(messageItem.id, messageItem);

    if (this.dbPromise && !this.inMemoryFallback) {
      try {
        const db = await this.dbPromise;
        if (db) {
          const sealedContent = await SplenderKeyVault.sealLocalString(
            messageItem.content,
            `sanjivani:${messageItem.id}`
          );
          await db.put('pending_messages', {
            ...messageItem,
            content: sealedContent,
          });
        }
      } catch (err) {
        console.debug('Sanjivani IndexedDB put failed; safe in-memory preserved:', err);
        this.inMemoryFallback = true;
      }
    }

    return messageItem;
  }

  /**
   * Retrieves all pending messages for a specific room or globally, unsealing IndexedDB records
   */
  public async getPending(roomId?: string): Promise<ResilientMessageItem[]> {
    let items: ResilientMessageItem[] = [];

    if (this.dbPromise && !this.inMemoryFallback) {
      try {
        const db = await this.dbPromise;
        if (db) {
          const rawItems = await db.getAll('pending_messages');
          items = await Promise.all(
            rawItems.map(async (raw) => {
              if (
                typeof raw.content === 'string' &&
                (raw.content.startsWith('idb17:') || raw.content.startsWith('jni17:'))
              ) {
                const unsealed = await SplenderKeyVault.unsealLocalString(
                  raw.content,
                  `sanjivani:${raw.id}`
                );
                return {
                  ...raw,
                  content: unsealed ?? '',
                };
              }
              return raw;
            })
          );
        }
      } catch (err) {
        console.debug('Sanjivani read fell back to memory queue:', err);
        this.inMemoryFallback = true;
      }
    }

    if (this.inMemoryFallback || items.length === 0) {
      items = Array.from(this.inMemoryQueue.values());
    }

    // Self-Healing deduplication & chronological ordering
    const uniqueMap = new Map<string, ResilientMessageItem>();
    for (const msg of items) {
      if (!uniqueMap.has(msg.id)) {
        uniqueMap.set(msg.id, msg);
      }
    }

    const sorted = Array.from(uniqueMap.values()).sort((a, b) => a.timestamp - b.timestamp);

    if (roomId) {
      return sorted.filter((m) => m.roomId === roomId || !m.roomId);
    }
    return sorted;
  }

  /**
   * Removes sent message from both persistent store and in-memory cache
   */
  public async remove(id: string): Promise<void> {
    this.inMemoryQueue.delete(id);

    if (this.dbPromise && !this.inMemoryFallback) {
      try {
        const db = await this.dbPromise;
        if (db) {
          await db.delete('pending_messages', id);
        }
      } catch (err) {
        console.debug('Sanjivani remove error:', err);
      }
    }
  }

  /**
   * Auto-healing procedure to purge poisoned/exceeded messages
   */
  public async selfHealQueue(): Promise<{ healedCount: number }> {
    const all = await this.getPending();
    let healedCount = 0;

    for (const msg of all) {
      if (msg.retryCount > this.MAX_RETRIES) {
        await this.remove(msg.id);
        healedCount += 1;
      }
    }

    return { healedCount };
  }

  /**
   * Telemetry snapshot for UI and diagnostics
   */
  public getTelemetry(queueLength: number): SanjivaniHealthTelemetry {
    return {
      circuitState: this.circuitState,
      consecutiveFailures: this.failureCount,
      inMemoryFallbackActive: this.inMemoryFallback,
      lastSyncTimestamp: this.lastFailureTime || Date.now(),
      queueLength,
    };
  }
}
