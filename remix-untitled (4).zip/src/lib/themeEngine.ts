import { ThemeMode } from '../types';
import {
  injectThemeCssVariables,
  resolveCoreThemeId,
} from '../context/ThemeContext';

export interface LuxuryThemeConfig {
  id: ThemeMode;
  name: string;
  tagline: string;
  primary: string;
  accent: string;
  surface: string;
  softWarm?: string;
  softCream?: string;
  isDark: boolean;
  headerBg: string;
  headerText: string;
  cardBg: string;
  cardText: string;
  borderClass: string;
}

export const LUXURY_THEMES: Record<ThemeMode, LuxuryThemeConfig> = {
  midnight_oled: {
    id: 'midnight_oled',
    name: 'Midnight OLED',
    tagline: 'Pure #000000 AMOLED deep-space canvas for zero-halo contrast and battery longevity',
    primary: '#000000',
    accent: '#22D3EE',
    surface: '#000000',
    isDark: true,
    headerBg: '#000000',
    headerText: '#F4F7FF',
    cardBg: '#080C16',
    cardText: '#F4F7FF',
    borderClass: 'border-[#1E293B]',
  },
  emerald_luxury: {
    id: 'emerald_luxury',
    name: 'Emerald Luxury',
    tagline: 'Bio-luminescent obsidian paired with sovereign emerald and cyan highlights',
    primary: '#05110E',
    accent: '#10B981',
    surface: '#05110E',
    isDark: true,
    headerBg: '#05110E',
    headerText: '#ECFDF5',
    cardBg: '#091D18',
    cardText: '#ECFDF5',
    borderClass: 'border-[#143D32]',
  },
  indigo_dawn: {
    id: 'indigo_dawn',
    name: 'Indigo Dawn',
    tagline: 'Signature Aurora Nebula obsidian glass with neon cyan and electric violet accents',
    primary: '#080B14',
    accent: '#22D3EE',
    surface: '#080B14',
    isDark: true,
    headerBg: '#080B14',
    headerText: '#F4F7FF',
    cardBg: '#0D1424',
    cardText: '#F4F7FF',
    borderClass: 'border-[#293650]',
  },
  apricot_bloom: {
    id: 'apricot_bloom',
    name: 'Apricot Bloom',
    tagline: 'Crisp solar daylight prism with warm amber-apricot and cobalt accents',
    primary: '#3B82F6',
    accent: '#EA580C',
    surface: '#F8FAFF',
    softWarm: '#EEF2FF',
    isDark: false,
    headerBg: '#F8FAFF',
    headerText: '#0F172A',
    cardBg: '#EEF2FF',
    cardText: '#0F172A',
    borderClass: 'border-slate-200',
  },
  teal_dusk: {
    id: 'teal_dusk',
    name: 'Teal Dusk',
    tagline: 'Cryo pelagic deep-space canvas illuminated by neon cyan bioluminescence',
    primary: '#061018',
    accent: '#22D3EE',
    surface: '#061018',
    isDark: true,
    headerBg: '#061018',
    headerText: '#ECFEFF',
    cardBg: '#0B1B28',
    cardText: '#ECFEFF',
    borderClass: 'border-[#1B3A4B]',
  },
  rose_quartz: {
    id: 'rose_quartz',
    name: 'Rose Quartz',
    tagline: 'Luminous starlight quartz surface paired with soft magenta-violet accents',
    primary: '#7C3AED',
    accent: '#DB2777',
    surface: '#FDF7FF',
    softCream: '#F6ECFC',
    isDark: false,
    headerBg: '#FDF7FF',
    headerText: '#1E132A',
    cardBg: '#F6ECFC',
    cardText: '#1E132A',
    borderClass: 'border-[#E2CEF0]',
  },
  emerald: {
    id: 'emerald',
    name: 'Splender Emerald',
    tagline: 'Clean daylight mint surface with crisp sovereign emerald highlights',
    primary: '#059669',
    accent: '#10B981',
    surface: '#F4FBF8',
    isDark: false,
    headerBg: '#F4FBF8',
    headerText: '#0B1915',
    cardBg: '#E6F5EE',
    cardText: '#0B1915',
    borderClass: 'border-emerald-200/70',
  },
  cyber_indigo: {
    id: 'cyber_indigo',
    name: 'Cyber Indigo',
    tagline: 'Electric violet horizon over deep architectural starlight slate',
    primary: '#090A1A',
    accent: '#8B5CF6',
    surface: '#090A1A',
    isDark: true,
    headerBg: '#090A1A',
    headerText: '#F4F7FF',
    cardBg: '#11132E',
    cardText: '#F4F7FF',
    borderClass: 'border-violet-500/25',
  },
  dark_amber: {
    id: 'dark_amber',
    name: 'Dark Amber',
    tagline: 'Solar flare obsidian paired with luminous warm gold accents',
    primary: '#0B0A08',
    accent: '#F59E0B',
    surface: '#0B0A08',
    softWarm: '#F59E0B',
    isDark: true,
    headerBg: '#0B0A08',
    headerText: '#FEFCE8',
    cardBg: '#16130E',
    cardText: '#FEFCE8',
    borderClass: 'border-amber-500/25',
  },
};

export function getThemeConfig(theme: ThemeMode): LuxuryThemeConfig {
  return LUXURY_THEMES[theme] || LUXURY_THEMES.indigo_dawn;
}

export function applyThemeToDOM(theme: ThemeMode) {
  if (typeof document === 'undefined') return;
  const coreId = resolveCoreThemeId(theme);
  injectThemeCssVariables(coreId, true);

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('splender:external-theme-sync', { detail: { themeId: coreId } })
    );
  }
}
