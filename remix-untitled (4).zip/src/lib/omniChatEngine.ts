// src/lib/omniChatEngine.ts
/**
 * ==============================================================================
 * OMNICHAT ULTIMATE ENGINE - MASTER SUPER-APP SYSTEM ARCHITECTURE
 * Unified Zero-Dependency Modular JavaScript/TypeScript Engine
 * Pillars: Pulse, Community, Signal E2EE, Ephemeral Streaks, Shorts, Radar Map
 * ==============================================================================
 */

import { P2PCryptoEngine } from './p2pSecurity';

export type OmniTabId = 'home' | 'chats' | 'camera' | 'shorts' | 'world';

export interface OmniNavigationMapItem {
  id: OmniTabId;
  label: string;
  sourcePillars: string[];
  subFeatures: string[];
  badgeCount?: number;
  iconName: string;
}

export interface PostMetricInput {
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  watchTime: number; // in seconds
  createdAt: number; // epoch ms
}

export interface StreakRecord {
  partnerUid: string;
  streakCount: number;
  lastInteractionTimestamp: number;
  status: 'active' | 'warning' | 'grace_period' | 'expired';
  hoursRemaining: number;
  streakFrozen: boolean;
}

export interface TransmissionFrictionResult {
  networkLatencyMs: number;
  thermalServerLoadPercent: number;
  energyConsumptionJoules: number;
  hopsSimulated: number;
}

export type QuantumState = 'SUPERPOSITION' | 'COLLAPSED_OBSERVED';

export interface QuantumMessageEnvelope {
  id: string;
  senderUid: string;
  recipientUid: string;
  ciphertext: string;
  quantumState: QuantumState;
  superpositionHash: string;
  e2eeProtocol: 'SIGNAL_DOUBLE_RATCHET_V3';
  disappearingTimer: 'off' | '24h' | '7d' | '90d';
  transmissionFriction: TransmissionFrictionResult;
  timestamp: number;
}

export interface UserEntanglementMetrics {
  userA: string;
  userB: string;
  interactionDensity: number; // 0.0 - 1.0
  coherenceScore: number;     // 0.0 - 1.0
  quantumPhase: 'ENTANGLED_RESONANT' | 'SEMI_COHERENT' | 'DECOHERENT';
  mutualChannels: number;
  lastObservation: number;
}

export type ModerationLevel = 'strict' | 'medium' | 'off';

export interface ModerationResult {
  flagged: boolean;
  score: number; // 0.0 - 1.0
  reason?: string;
  category?: 'toxic' | 'spam' | 'nsfw' | 'clean';
  actionTaken: 'deliver' | 'filter_to_requests' | 'quarantine';
}

export interface GhostModeSetting {
  enabled: boolean;
  precisionBlurRadiusKm: number;
  lastUpdated: number;
}

export interface VaultSecretItem {
  id: string;
  title: string;
  mediaUrl?: string;
  note?: string;
  encryptedData: string;
  createdAt: number;
}

export type OmniEventType =
  | 'SEND_MESSAGE'
  | 'COLLAPSE_QUANTUM'
  | 'UPDATE_STREAK'
  | 'RANK_POST'
  | 'GET_NAVIGATION'
  | 'CALCULATE_ENTANGLEMENT'
  | 'VAULT_VERIFY'
  | 'VAULT_STORE'
  | 'VAULT_GET_ITEMS'
  | 'VAULT_DELETE_ITEM'
  | 'SET_GHOST_MODE'
  | 'FILTER_CONTENT';

export interface OmniEvent<T = any> {
  type: OmniEventType;
  payload: T;
  meta?: {
    clientTimestamp?: number;
    sessionId?: string;
  };
}

export interface OmniResponse<T = any> {
  success: boolean;
  eventType: OmniEventType;
  executionDurationMs: number;
  data: T;
  telemetry: {
    engineVersion: string;
    quantumCollapseVerified?: boolean;
    friction?: TransmissionFrictionResult;
    timestamp: number;
  };
}

class OmniChatMasterEngineClass {
  private readonly version = 'OmniEngine-v5.8.0-Universal';
  private ghostModeState: GhostModeSetting = {
    enabled: false,
    precisionBlurRadiusKm: 0,
    lastUpdated: Date.now(),
  };

  private vaultPinCommitment = P2PCryptoEngine.generateSafetyFingerprint(
    'splender_vault_pin_v17',
    'pin::123456'
  );
  private vaultStorage: Map<string, VaultSecretItem> = new Map();
  private streaksCache: Map<string, StreakRecord> = new Map();

  constructor() {
    this.seedDefaultData();
  }

  private seedDefaultData() {
    // Seed initial vault items
    this.vaultStorage.set('vault-1', {
      id: 'vault-1',
      title: 'Biometric Recovery Seed Words',
      note: 'matrix quantum cyber cipher beacon zero horizon orbit eclipse prism sovereign',
      encryptedData: 'ENC_AES256_GCM_98a712f8...',
      createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
    });
    this.vaultStorage.set('vault-2', {
      id: 'vault-2',
      title: 'Confidential Prototype Wireframe',
      mediaUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="320" height="200" viewBox="0 0 320 200"><rect width="320" height="200" rx="20" fill="%230F766E"/><text x="50%25" y="52%25" dominant-baseline="middle" text-anchor="middle" fill="%23FAF8F5" font-family="Inter,sans-serif" font-weight="700" font-size="18">SPLENDER VAULT</text></svg>',
      note: 'Encrypted architecture wireframe stored locally.',
      encryptedData: 'ENC_MEDIA_BLOB_8921a4...',
      createdAt: Date.now() - 1000 * 60 * 60 * 48,
    });

    // Seed sample streak records
    this.streaksCache.set('user_alex', {
      partnerUid: 'user_alex',
      streakCount: 42,
      lastInteractionTimestamp: Date.now() - 3600 * 1000 * 5, // 5 hours ago
      status: 'active',
      hoursRemaining: 19,
      streakFrozen: false,
    });
    this.streaksCache.set('user_sara', {
      partnerUid: 'user_sara',
      streakCount: 18,
      lastInteractionTimestamp: Date.now() - 3600 * 1000 * 22, // 22 hours ago
      status: 'warning',
      hoursRemaining: 2,
      streakFrozen: false,
    });
  }

  // ============================================================================
  // PILLAR 1: MECHANICAL LAYER - 5-TAB DYNAMIC NAVIGATION MAP
  // ============================================================================
  public getNavigationMap(): OmniNavigationMapItem[] {
    return [
      {
        id: 'home',
        label: 'Home',
        sourcePillars: ['Pulse', 'Community Feed', 'Stories Stream'],
        subFeatures: ['Pulse Streams', 'Community Posts & Groups', 'Stories Carousel', 'Topic Discussions'],
        iconName: 'Home',
      },
      {
        id: 'chats',
        label: 'Chats',
        sourcePillars: ['Signal E2EE', 'Direct Chat', 'Active Streaks'],
        subFeatures: ['Signal E2EE Messaging', 'Direct Requests Filter', 'Daily Active Streaks', 'My Eyes Only Vault'],
        badgeCount: 3,
        iconName: 'MessageSquare',
      },
      {
        id: 'camera',
        label: 'Camera',
        sourcePillars: ['AR Lenses', 'Creator Studio'],
        subFeatures: ['AR Lenses & Filters', 'Quick Snaps', 'Sound Studio', 'Custom Stickers'],
        iconName: 'Camera',
      },
      {
        id: 'shorts',
        label: 'Shorts',
        sourcePillars: ['Spotlight', 'Pulse Shorts', 'Community Video'],
        subFeatures: ['Vertical Short Video Engine', 'AI Recommender', 'Audio Sync', 'Creator Tipping'],
        iconName: 'Film',
      },
      {
        id: 'world',
        label: 'World',
        sourcePillars: ['Radar Map', 'Marketplace', 'Local Events'],
        subFeatures: ['Radar Map & Ghost Mode', 'Marketplace Buy/Sell', 'Local Meetups & Pages'],
        iconName: 'Compass',
      },
    ];
  }

  // ============================================================================
  // PILLAR 2: LOGICAL & SECURITY LAYER
  // ============================================================================
  public processContentModeration(text: string, level: ModerationLevel = 'medium'): ModerationResult {
    if (level === 'off') {
      return { flagged: false, score: 0.0, actionTaken: 'deliver', category: 'clean' };
    }

    const toxicKeywords = ['scam', 'phishing', 'hacked', 'password', 'wire transfer', 'crypto bonus', 'free money'];
    const lower = text.toLowerCase();
    const hits = toxicKeywords.filter((k) => lower.includes(k));

    if (hits.length > 0) {
      const score = Math.min(1.0, hits.length * 0.4);
      if (level === 'strict' || score > 0.5) {
        return {
          flagged: true,
          score,
          category: 'spam',
          reason: `Filtered trigger keywords: ${hits.join(', ')}`,
          actionTaken: 'filter_to_requests',
        };
      }
    }

    return { flagged: false, score: 0.05, actionTaken: 'deliver', category: 'clean' };
  }

  public verifyVaultPin(enteredPin: string): boolean {
    if (!enteredPin) return false;
    const candidate = P2PCryptoEngine.generateSafetyFingerprint(
      'splender_vault_pin_v17',
      `pin::${enteredPin}`
    );
    if (candidate.length !== this.vaultPinCommitment.length) return false;
    let diff = 0;
    for (let i = 0; i < candidate.length; i++) {
      diff |= candidate.charCodeAt(i) ^ this.vaultPinCommitment.charCodeAt(i);
    }
    return diff === 0;
  }

  public setGhostMode(enabled: boolean, blurRadiusKm: number = 5): GhostModeSetting {
    this.ghostModeState = {
      enabled,
      precisionBlurRadiusKm: enabled ? blurRadiusKm : 0,
      lastUpdated: Date.now(),
    };
    return this.ghostModeState;
  }

  public getGhostMode(): GhostModeSetting {
    return { ...this.ghostModeState };
  }

  // ============================================================================
  // PILLAR 3: ARITHMETICAL & MATHEMATICAL LAYER (RANKING & STREAKS)
  // ============================================================================
  /**
   * Unified Engagement Ranking Formula with Gravity Decay:
   * Rank = [(Likes * 1.0) + (Comments * 2.5) + (Shares * 4.0) + (Saves * 3.0) + (WatchTime * 5.0)] / (AgeHours + 2)^1.8
   */
  public calculatePostRank(metrics: PostMetricInput): {
    rankScore: number;
    rawEngagementNumerator: number;
    decayDenominator: number;
    ageHours: number;
  } {
    const { likes, comments, shares, saves, watchTime, createdAt } = metrics;
    const now = Date.now();
    const ageHours = Math.max(0, (now - createdAt) / (1000 * 60 * 60));

    const rawEngagementNumerator =
      likes * 1.0 +
      comments * 2.5 +
      shares * 4.0 +
      saves * 3.0 +
      watchTime * 5.0;

    const decayDenominator = Math.pow(ageHours + 2.0, 1.8);
    const rankScore = parseFloat((rawEngagementNumerator / decayDenominator).toFixed(4));

    return {
      rankScore,
      rawEngagementNumerator,
      decayDenominator: parseFloat(decayDenominator.toFixed(4)),
      ageHours: parseFloat(ageHours.toFixed(2)),
    };
  }

  /**
   * Ephemeral Streak Evaluation Algorithm with 24h active window, 20h warning, and 48h expiry logic
   */
  public evaluateStreak(partnerUid: string, recordInteraction: boolean = false): StreakRecord {
    let streak = this.streaksCache.get(partnerUid);
    const now = Date.now();

    if (!streak) {
      streak = {
        partnerUid,
        streakCount: recordInteraction ? 1 : 0,
        lastInteractionTimestamp: now,
        status: 'active',
        hoursRemaining: 24,
        streakFrozen: false,
      };
      this.streaksCache.set(partnerUid, streak);
      return streak;
    }

    const diffHours = (now - streak.lastInteractionTimestamp) / (1000 * 60 * 60);

    if (recordInteraction) {
      if (diffHours >= 1 && diffHours < 48) {
        // Increment valid streak
        streak.streakCount += 1;
        streak.lastInteractionTimestamp = now;
        streak.status = 'active';
        streak.hoursRemaining = 24;
      } else if (diffHours >= 48) {
        // Expired, reset to 1 on new snap
        streak.streakCount = 1;
        streak.lastInteractionTimestamp = now;
        streak.status = 'active';
        streak.hoursRemaining = 24;
      }
      this.streaksCache.set(partnerUid, streak);
      return streak;
    }

    // Passive evaluation without new snap
    if (diffHours < 20) {
      streak.status = 'active';
      streak.hoursRemaining = parseFloat((24 - diffHours).toFixed(1));
    } else if (diffHours >= 20 && diffHours < 24) {
      streak.status = 'warning'; // ⏳ Hourglass warning
      streak.hoursRemaining = parseFloat((24 - diffHours).toFixed(1));
    } else if (diffHours >= 24 && diffHours < 48) {
      streak.status = 'grace_period'; // Snap restore window
      streak.hoursRemaining = 0;
    } else {
      streak.status = 'expired';
      streak.streakCount = 0;
      streak.hoursRemaining = 0;
    }

    this.streaksCache.set(partnerUid, streak);
    return streak;
  }

  // ============================================================================
  // PILLAR 4: PHYSICAL & QUANTUM-PHYSICAL SIMULATION LAYER
  // ============================================================================
  public calculatePhysicalFriction(payloadSizeBytes: number, isVideo: boolean = false): TransmissionFrictionResult {
    // Distance simulation: 120km to 2400km
    const simulatedDistanceKm = Math.floor(Math.random() * 800) + 150;
    const baseLatency = (simulatedDistanceKm / 100) * 1.8 + 12; // speed of light in optical fiber + routers
    const payloadLatency = (payloadSizeBytes / 1024) * 0.08;
    const networkLatencyMs = Math.round(baseLatency + payloadLatency + (isVideo ? 18 : 0));

    // Thermal Server Load simulation: 18% - 74%
    const thermalServerLoadPercent = Math.min(95, Math.floor(22 + (payloadSizeBytes / 2048) + Math.random() * 15));

    // Energy consumption in Joules: E = P * t (approx ~ 0.00015 J per KB transmitted over 5G/WiFi)
    const energyConsumptionJoules = parseFloat(((payloadSizeBytes / 1024) * 0.00032 * (networkLatencyMs / 20)).toFixed(6));

    return {
      networkLatencyMs,
      thermalServerLoadPercent,
      energyConsumptionJoules,
      hopsSimulated: Math.floor(Math.random() * 4) + 3,
    };
  }

  public calculateUserEntanglement(userA: string, userB: string, streakCount: number = 0): UserEntanglementMetrics {
    const baseDensity = Math.min(0.95, 0.25 + (streakCount * 0.015));
    const coherenceScore = parseFloat((baseDensity * (0.85 + Math.random() * 0.15)).toFixed(3));
    
    let quantumPhase: UserEntanglementMetrics['quantumPhase'] = 'SEMI_COHERENT';
    if (coherenceScore > 0.7) {
      quantumPhase = 'ENTANGLED_RESONANT';
    } else if (coherenceScore < 0.35) {
      quantumPhase = 'DECOHERENT';
    }

    return {
      userA,
      userB,
      interactionDensity: parseFloat(baseDensity.toFixed(3)),
      coherenceScore,
      quantumPhase,
      mutualChannels: Math.floor(coherenceScore * 6) + 1,
      lastObservation: Date.now(),
    };
  }

  // ============================================================================
  // PILLAR 5: MASTER EVENT ROUTER (OmniChatMasterEngine.processUnifiedEvent)
  // ============================================================================
  public processUnifiedEvent<T = any, R = any>(event: OmniEvent<T>): OmniResponse<R> {
    const startTime = performance.now();
    let resultData: any;
    let friction: TransmissionFrictionResult | undefined;
    let quantumCollapseVerified = false;

    switch (event.type) {
      case 'GET_NAVIGATION': {
        resultData = this.getNavigationMap();
        break;
      }

      case 'SEND_MESSAGE': {
        const payload = event.payload as {
          id: string;
          senderUid: string;
          recipientUid: string;
          text: string;
          disappearingTimer?: 'off' | '24h' | '7d' | '90d';
        };

        const payloadSize = (payload.text || '').length * 2 + 128;
        friction = this.calculatePhysicalFriction(payloadSize);

        const nonceHex = Array.from(crypto.getRandomValues(new Uint8Array(16)))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
        const commitment = P2PCryptoEngine.generateSafetyFingerprint(
          `${payload.senderUid}:${nonceHex}`,
          payload.text || ''
        ).replace(/\s+/g, '');

        const envelope: QuantumMessageEnvelope = {
          id: payload.id || `omni_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          senderUid: payload.senderUid,
          recipientUid: payload.recipientUid,
          ciphertext: `SEALED_DR_V3:${nonceHex}:${commitment}`,
          quantumState: 'SUPERPOSITION',
          superpositionHash: `Ψ_${this.simpleHash(nonceHex + Date.now())}`,
          e2eeProtocol: 'SIGNAL_DOUBLE_RATCHET_V3',
          disappearingTimer: payload.disappearingTimer || 'off',
          transmissionFriction: friction,
          timestamp: Date.now(),
        };

        resultData = envelope;
        break;
      }

      case 'COLLAPSE_QUANTUM': {
        // Observer effect: observation collapses wave function from SUPERPOSITION to COLLAPSED_OBSERVED
        const { messageId, observerUid } = event.payload as { messageId: string; observerUid: string };
        quantumCollapseVerified = true;
        resultData = {
          messageId,
          observerUid,
          quantumState: 'COLLAPSED_OBSERVED',
          collapseTimestamp: Date.now(),
          decoherenceLatencyMs: 0.42,
        };
        break;
      }

      case 'UPDATE_STREAK': {
        const { partnerUid, recordInteraction } = event.payload as { partnerUid: string; recordInteraction: boolean };
        resultData = this.evaluateStreak(partnerUid, recordInteraction);
        break;
      }

      case 'RANK_POST': {
        const metrics = event.payload as PostMetricInput;
        resultData = this.calculatePostRank(metrics);
        break;
      }

      case 'CALCULATE_ENTANGLEMENT': {
        const { userA, userB, streakCount } = event.payload as { userA: string; userB: string; streakCount?: number };
        resultData = this.calculateUserEntanglement(userA, userB, streakCount || 0);
        break;
      }

      case 'VAULT_VERIFY': {
        const { pin } = event.payload as { pin: string };
        const isValid = this.verifyVaultPin(pin);
        resultData = { verified: isValid };
        break;
      }

      case 'VAULT_STORE': {
        const item = event.payload as VaultSecretItem;
        this.vaultStorage.set(item.id, item);
        resultData = { stored: true, totalItems: this.vaultStorage.size };
        break;
      }

      case 'VAULT_GET_ITEMS': {
        resultData = Array.from(this.vaultStorage.values()).sort((a, b) => b.createdAt - a.createdAt);
        break;
      }

      case 'VAULT_DELETE_ITEM': {
        const { id } = event.payload as { id: string };
        const deleted = this.vaultStorage.delete(id);
        resultData = { deleted, totalItems: this.vaultStorage.size };
        break;
      }

      case 'SET_GHOST_MODE': {
        const { enabled, blurRadiusKm } = event.payload as { enabled: boolean; blurRadiusKm?: number };
        resultData = this.setGhostMode(enabled, blurRadiusKm);
        break;
      }

      case 'FILTER_CONTENT': {
        const { text, level } = event.payload as { text: string; level?: ModerationLevel };
        resultData = this.processContentModeration(text, level);
        break;
      }

      default:
        throw new Error(`[OmniChatMasterEngine] Unsupported event type: ${(event as any).type}`);
    }

    const duration = performance.now() - startTime;

    return {
      success: true,
      eventType: event.type,
      executionDurationMs: parseFloat(duration.toFixed(3)),
      data: resultData as R,
      telemetry: {
        engineVersion: this.version,
        quantumCollapseVerified,
        friction,
        timestamp: Date.now(),
      },
    };
  }

  // Fast DJB2 hash generator for lightweight idempotency and zero-dep hashing
  private simpleHash(str: string): string {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 33) ^ str.charCodeAt(i);
    }
    return (hash >>> 0).toString(16);
  }
}

export const OmniChatMasterEngine = new OmniChatMasterEngineClass();
