// src/lib/analytics.ts
// Lightweight client-side analytics and session interaction tracker

export interface AnalyticsEvent {
  name: string;
  category?: 'navigation' | 'interaction' | 'engagement' | 'performance';
  properties?: Record<string, any>;
  timestamp: number;
}

const STORAGE_KEY = 'splender_analytics_events';
const MAX_STORED_EVENTS = 50;

class AnalyticsTracker {
  private sessionStartTime: number = Date.now();
  private activeTab: string = 'home';
  private tabStartTime: number = Date.now();
  private inMemoryEvents: AnalyticsEvent[] = [];

  constructor() {
    this.sessionStartTime = Date.now();
    this.tabStartTime = Date.now();
  }

  /**
   * Track general user feature interaction
   */
  trackEvent(name: string, properties?: Record<string, any>, category: AnalyticsEvent['category'] = 'interaction'): void {
    const event: AnalyticsEvent = {
      name,
      category,
      properties,
      timestamp: Date.now(),
    };

    this.inMemoryEvents.push(event);
    if (this.inMemoryEvents.length > MAX_STORED_EVENTS) {
      this.inMemoryEvents.shift();
    }

    try {
      if (typeof window !== 'undefined') {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
        stored.push(event);
        if (stored.length > MAX_STORED_EVENTS) {
          stored.splice(0, stored.length - MAX_STORED_EVENTS);
        }
        localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
      }
    } catch {
      // Safe fallback if localStorage is unavailable
    }
  }

  /**
   * Track switching between app tabs
   */
  trackTabView(tabName: string): void {
    const durationOnPrevTab = Math.round((Date.now() - this.tabStartTime) / 1000);
    
    this.trackEvent('tab_view', {
      tab: tabName,
      previousTab: this.activeTab,
      previousTabDurationSeconds: durationOnPrevTab,
    }, 'navigation');

    this.activeTab = tabName;
    this.tabStartTime = Date.now();
  }

  /**
   * Get total current session duration in seconds
   */
  getSessionDurationSeconds(): number {
    return Math.round((Date.now() - this.sessionStartTime) / 1000);
  }

  /**
   * Get recent interactions for internal telemetry
   */
  getRecentEvents(): AnalyticsEvent[] {
    return [...this.inMemoryEvents];
  }
}

export const analytics = new AnalyticsTracker();
export const trackEvent = (
  name: string,
  props?: Record<string, any>,
  category?: AnalyticsEvent['category']
) => analytics.trackEvent(name, props, category);
export const trackTabView = (tabName: string) => analytics.trackTabView(tabName);
export const getSessionDuration = () => analytics.getSessionDurationSeconds();
