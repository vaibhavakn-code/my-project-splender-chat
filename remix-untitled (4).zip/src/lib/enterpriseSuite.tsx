// ============================================================================
// SPLENDER CHAT - MASTER ADVANCED ENTERPRISE SUITE (ALL-IN-ONE SINGLE MODULE)
// ============================================================================

import React, { useState } from 'react';
import { db, auth } from './firebase';
import { P2PCryptoEngine, OfflineOutboxManager } from './p2pSecurity';
import { SplenderKeyVault } from './keyVault';
import { PollEngine as ProductionPollEngine } from './productionModules';

// ----------------------------------------------------------------------------
// 1. CHAT BACKGROUND DOODLE PATTERN & GLASSMORPHISM VECTOR BACKDROP
// ----------------------------------------------------------------------------
export const ChatBackgroundPattern: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`absolute inset-0 pointer-events-none opacity-[0.06] dark:opacity-[0.08] overflow-hidden z-0 select-none ${className}`}>
      <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="chat-doodles" width="80" height="80" patternUnits="userSpaceOnUse">
            {/* WhatsApp-style Chat Bubbles, Locks, Stars, Hearts, and Search Doodles */}
            <path d="M10 10 h12 v8 h-8 l-4 4 z" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <path d="M50 15 a4 4 0 1 0 0.1 0 z" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <path d="M25 45 l2 4 h5 l-4 3 l2 5 l-4 -3 l-4 3 l2 -5 l-4 -3 h5 z" fill="none" stroke="currentColor" strokeWidth="1" />
            <path d="M60 50 c0 -4 6 -4 6 0 c0 4 -6 7 -6 7 s-6 -3 -6 -7 c0 -4 6 -4 6 0 z" fill="none" stroke="currentColor" strokeWidth="1" />
            <circle cx="15" cy="65" r="5" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <path d="M19 69 l4 4" stroke="currentColor" strokeWidth="1.2" />
            <rect x="55" y="25" width="8" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <path d="M57 25 v-3 a2 2 0 0 1 4 0 v3" fill="none" stroke="currentColor" strokeWidth="1.2" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#chat-doodles)" />
      </svg>
    </div>
  );
};

// ----------------------------------------------------------------------------
// 2. STATUS BACKGROUND THEMES, FONT STYLES & ULTIMATE STATUS CREATOR ENGINE
// ----------------------------------------------------------------------------
export {
  STATUS_COLOR_SWATCHES,
  STATUS_FONT_OPTIONS,
  STATUS_PATTERNS,
  createAdvancedStatusSvg,
  UltimateAdvancedStatusCreatorScreen,
  StatusEditorModal,
} from '../components/UltimateAdvancedStatusCreator';
export type {
  StatusPayload,
  StatusPublishPayload,
  StatusTextAlignment,
  StatusBackdropPattern,
} from '../components/UltimateAdvancedStatusCreator';

export const STATUS_THEMES = {
  colors: [
    '#0F9D58',
    '#1E1B4B',
    '#4C1D95',
    '#0E7490',
    '#1D4ED8',
    '#BE185D',
    '#C2410C',
    '#080B14',
  ],
  fonts: [
    { id: 'sans', name: 'Plus Jakarta Sans', cssClass: 'font-sans' },
    { id: 'mono', name: 'JetBrains Mono', cssClass: 'font-mono' },
    { id: 'serif', name: 'Editorial Serif', cssClass: 'font-serif' },
    { id: 'display', name: 'Outfit Display', cssClass: 'font-display font-bold tracking-tight' },
  ],
};

// ----------------------------------------------------------------------------
// 3. 3D WHATSAPP EMOJI SET & RENDERER ENGINE
// ----------------------------------------------------------------------------
export const THREE_D_EMOJI_MAP: Record<string, string> = {
  '👍': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/thumbs_up_3d.png',
  '❤️': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/red_heart_3d.png',
  '🔥': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/fire_3d.png',
  '⚡': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/high_voltage_3d.png',
  '⚡️': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/high_voltage_3d.png',
  '🎉': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/party_popper_3d.png',
  '😮': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/astonished_face_3d.png',
  '😲': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/astonished_face_3d.png',
  '😂': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/face_with_tears_of_joy_3d.png',
  '🙏': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/folded_hands_3d.png',
  '😍': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/smiling_face_with_heart_eyes_3d.png',
  '🚀': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/rocket_3d.png',
  '👏': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/clapping_hands_3d.png',
  '💯': 'https://raw.githubusercontent.com/Tolerable/3D-Emojis/main/assets/hundred_points_3d.png',
};

export const Render3DEmoji: React.FC<{ emoji: string; size?: number; className?: string }> = ({
  emoji,
  size = 24,
  className = '',
}) => {
  const [hasError, setHasError] = useState(false);
  const cleanEmoji = emoji.trim();
  const cdn3dUrl = !hasError ? THREE_D_EMOJI_MAP[cleanEmoji] : undefined;

  if (cdn3dUrl) {
    return (
      <img
        src={cdn3dUrl}
        alt={emoji}
        loading="lazy"
        onError={() => setHasError(true)}
        style={{ width: size, height: size, minWidth: size, minHeight: size }}
        className={`inline-block object-contain transition-transform hover:scale-125 select-none ${className}`}
      />
    );
  }
  return (
    <span
      style={{ fontSize: size }}
      className={`inline-flex items-center justify-center select-none leading-none ${className}`}
    >
      {emoji}
    </span>
  );
};

// ----------------------------------------------------------------------------
// 4. REAL-TIME PRESENCE & TYPING HEARTBEAT ENGINE
// ----------------------------------------------------------------------------
export const PresenceEngine = {
  setTypingStatus(chatId: string, userId: string, isTyping: boolean) {
    if (!chatId || !userId) return;
    try {
      (db as any).collection('chats').doc(chatId).update({
        [`typing.${userId}`]: isTyping,
      }).catch(() => {
        // Fallback to conversations
        (db as any).collection('conversations').doc(chatId).update({
          [`typing.${userId}`]: isTyping,
        }).catch(() => {});
      });
    } catch (e) {
      console.error('PresenceEngine setTypingStatus error:', e);
    }
  },

  updateUserPresence(userId: string, status: 'online' | 'offline') {
    if (!userId) return;
    try {
      return (db as any).collection('users').doc(userId).update({
        status,
        lastSeen: new Date().toISOString(),
      }).catch(console.error);
    } catch (e) {
      console.error('PresenceEngine updateUserPresence error:', e);
    }
  },
};

// ----------------------------------------------------------------------------
// 5. MESSAGE REACTIONS & EMOJI PICKER ENGINE
// ----------------------------------------------------------------------------
export const ReactionEngine = {
  async toggleReaction(chatId: string, messageId: string, emoji: string, userId: string) {
    const msgRef = (db as any).collection('chats').doc(chatId).collection('messages').doc(messageId);
    return (db as any).runTransaction(async (transaction: any) => {
      const doc = await transaction.get(msgRef);
      if (!doc.exists) return;

      const reactions = doc.data()?.reactions || {};
      const userList = reactions[emoji] || [];

      if (userList.includes(userId)) {
        reactions[emoji] = userList.filter((id: string) => id !== userId);
        if (reactions[emoji].length === 0) delete reactions[emoji];
      } else {
        reactions[emoji] = [...userList, userId];
      }
      transaction.update(msgRef, { reactions });
    });
  },
};

// ----------------------------------------------------------------------------
// 6. PINNED MESSAGES & STARRED VAULT ENGINE
// ----------------------------------------------------------------------------
export const BookmarkEngine = {
  async pinMessage(chatId: string, messageId: string) {
    return (db as any).collection('chats').doc(chatId).update({
      pinnedMessageId: messageId,
      pinnedAt: new Date().toISOString(),
    }).catch(() => {
      return (db as any).collection('conversations').doc(chatId).update({
        pinnedMessageId: messageId,
        pinnedAt: new Date().toISOString(),
      });
    });
  },

  async unpinMessage(chatId: string) {
    return (db as any).collection('chats').doc(chatId).update({
      pinnedMessageId: null,
      pinnedAt: null,
    }).catch(() => {
      return (db as any).collection('conversations').doc(chatId).update({
        pinnedMessageId: null,
        pinnedAt: null,
      });
    });
  },

  async toggleStarMessage(userId: string, messageDoc: any) {
    const starRef = (db as any).collection('users').doc(userId).collection('starredMessages').doc(messageDoc.id);
    const doc = await starRef.get();
    if (doc.exists) {
      return starRef.delete();
    } else {
      return starRef.set({ ...messageDoc, starredAt: new Date().toISOString() });
    }
  },
};

// ----------------------------------------------------------------------------
// 7. INTERACTIVE IN-CHAT VOTING POLLS
// ----------------------------------------------------------------------------
export const PollEngine = {
  async createPoll(chatId: string, question: string, optionsArray: string[]) {
    return ProductionPollEngine.createPoll(chatId, question, optionsArray);
  },

  async voteInPoll(chatId: string, messageId: string, optionId: number, userId: string) {
    return ProductionPollEngine.voteInPoll(chatId, messageId, optionId, userId);
  },
};

// ----------------------------------------------------------------------------
// 8. RICH LINK PREVIEW ENGINE
// ----------------------------------------------------------------------------
export const LinkPreviewEngine = {
  async fetchPreview(url: string) {
    try {
      let cleanUrl = url.trim();
      if (cleanUrl.startsWith('www.')) cleanUrl = `https://${cleanUrl}`;
      const response = await fetch(`https://api.microlink.io?url=${encodeURIComponent(cleanUrl)}`);
      const data = await response.json();
      if (data.status === 'success' && data.data) {
        return {
          title: data.data.title,
          description: data.data.description,
          image: data.data.image?.url || data.data.logo?.url,
          domain: data.data.publisher || new URL(cleanUrl).hostname,
          url: cleanUrl,
        };
      }
    } catch (err) {
      console.error('Link preview error:', err);
    }
    return null;
  },
};

// ----------------------------------------------------------------------------
// 9. VOICE NOTES SPEECH-TO-TEXT TRANSCRIPTION
// ----------------------------------------------------------------------------
export const VoiceTranscriptionEngine = {
  transcribe(lang = 'mr-IN'): Promise<string> {
    return new Promise((resolve, reject) => {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        return reject('तुमच्या ब्राऊझरमध्ये Speech-to-Text सपोर्ट नाही.');
      }
      const recognition = new SpeechRecognition();
      recognition.lang = lang;
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        resolve(text);
      };
      recognition.onerror = (err: any) => reject('ट्रान्सक्रिप्शन एरर: ' + err.error);
      recognition.start();
    });
  },
};

// ----------------------------------------------------------------------------
// 10. E2EE SECURITY MANAGEMENT & SAFETY NUMBER FINGERPRINT
// ----------------------------------------------------------------------------
export const SecurityE2EE = {
  generateSafetyNumber(userPubKey: string, peerPubKey: string) {
    return P2PCryptoEngine.generateSafetyFingerprint(userPubKey || 'local', peerPubKey || 'peer');
  },
};

// ----------------------------------------------------------------------------
// 11. PUSH NOTIFICATIONS & AUDIO SOUND ALERTS
// ----------------------------------------------------------------------------
export const SoundAndNotificationEngine = {
  playTone(type: 'send' | 'receive' = 'send') {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'send') {
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08);
      } else if (type === 'receive') {
        osc.frequency.setValueAtTime(500, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + 0.12);
      }

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch {
      console.warn('Audio Context disabled or not supported.');
    }
  },

  async triggerPushNotification(title: string, body: string, iconUrl?: string) {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon: iconUrl });
    } else if (Notification.permission !== 'denied') {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        new Notification(title, { body, icon: iconUrl });
      }
    }
  },
};

// ----------------------------------------------------------------------------
// 12. MEDIA COMPRESSION & HD QUALITY RESOLUTION ENGINE
// ----------------------------------------------------------------------------
export const MediaQualityEngine = {
  async compressImage(
    file: File,
    qualityLevel: 'standard' | 'hd' = 'standard'
  ): Promise<Blob | null> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event: any) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          const maxDim = qualityLevel === 'hd' ? 2048 : 1080;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          const compressRatio = qualityLevel === 'hd' ? 0.85 : 0.65;
          canvas.toBlob((blob) => resolve(blob), 'image/jpeg', compressRatio);
        };
      };
    });
  },
};

// ----------------------------------------------------------------------------
// 13. AUTOMATED ENCRYPTED CLOUD BACKUP SCHEDULER
// ----------------------------------------------------------------------------
export const AutoBackupScheduler = {
  async scheduleBackup(userId: string, chatData: any) {
    if (!userId) return;
    const lastBackupTime = localStorage.getItem(`splender_last_backup_${userId}`);
    const now = Date.now();
    const oneDayInMs = 24 * 60 * 60 * 1000;

    if (!lastBackupTime || now - Number(lastBackupTime) > oneDayInMs) {
      const backupData = {
        timestamp: new Date().toISOString(),
        userId,
        chats: chatData,
      };

      try {
        const sealedPayload = await SplenderKeyVault.sealLocalString(
          JSON.stringify(backupData),
          `auto-backup-v17:${userId}`
        );
        await (db as any).collection('users').doc(userId).collection('backups').add({
          sealedEnvelope: sealedPayload,
          protocol: 'SPLENDER_KEYVAULT_AES_GCM_256',
          createdAt: new Date().toISOString(),
        });

        localStorage.setItem(`splender_last_backup_${userId}`, String(now));
      } catch (e) {
        console.warn('Auto-backup notice:', e);
      }
    }
  },
};

// ----------------------------------------------------------------------------
// 14. QUICK REPLIES PRESETS
// ----------------------------------------------------------------------------
export const QUICK_REPLIES_PRESETS = [
  '👍 मी निघालो आहे!',
  '👌 उत्तम! नक्की.',
  '📞 बैठकीत आहे, नंतर कॉल करतो.',
  '📁 कृपया फाईल पुन्हा पाठवा.',
  '🚀 कॉल सुरू करूया?',
  "👍 I'm on my way!",
  '👌 Sounds good!',
  '📞 In a meeting, call you later.',
];

// ----------------------------------------------------------------------------
// 15. PRIVACY SCREENSHOT GUARD DETECTOR
// ----------------------------------------------------------------------------
export const PrivacyGuardListener = {
  listenForScreenshots(onDetectedCallback: (msg: string) => void) {
    if (typeof window === 'undefined') return () => {};
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'p')) {
        onDetectedCallback('Privacy Guard: Screen capture attempt registered!');
      }
    };
    window.addEventListener('keyup', handleKey);
    return () => window.removeEventListener('keyup', handleKey);
  },
};

// ----------------------------------------------------------------------------
// 16. OFFLINE MESSAGE QUEUE ENGINE
// ----------------------------------------------------------------------------
export interface OfflineQueuedItem {
  id: string;
  chatId: string;
  payload: any;
  timestamp: number;
  retryCount: number;
}

const OFFLINE_QUEUE_STORAGE_KEY = 'splender_enterprise_offline_queue';

export const OfflineMessageQueue = {
  getQueue(): OfflineQueuedItem[] {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(OFFLINE_QUEUE_STORAGE_KEY);
    }
    return OfflineOutboxManager.getQueue().map((m) => ({
      id: m.id,
      chatId: m.targetConversationId,
      payload: m.payload,
      timestamp: m.timestamp,
      retryCount: m.retryAttempts,
    }));
  },

  enqueue(chatId: string, payload: any): OfflineQueuedItem {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(OFFLINE_QUEUE_STORAGE_KEY);
    }
    const item: OfflineQueuedItem = {
      id: `off_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      chatId,
      payload,
      timestamp: Date.now(),
      retryCount: 0,
    };
    OfflineOutboxManager.enqueue({
      id: item.id,
      targetConversationId: chatId,
      senderUid: auth?.currentUser?.uid || 'local',
      payload,
      timestamp: item.timestamp,
      retryAttempts: 0,
    });
    return item;
  },

  async flushQueue(sendFn: (item: OfflineQueuedItem) => Promise<boolean>): Promise<number> {
    await OfflineOutboxManager.loadSealedSnapshot();
    const queue = this.getQueue();
    if (queue.length === 0) return 0;

    let successful = 0;
    for (const item of queue) {
      try {
        const ok = await sendFn(item);
        if (ok) {
          successful++;
          OfflineOutboxManager.remove(item.id);
        }
      } catch {
        // Keep in sealed outbox for next retry window
      }
    }
    return successful;
  },

  clearQueue() {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(OFFLINE_QUEUE_STORAGE_KEY);
    }
    OfflineOutboxManager.clear();
  },
};
