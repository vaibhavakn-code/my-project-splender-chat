import { playNotificationChime } from './sound';
import { trackEvent } from './analytics';

const NOTIFICATIONS_STORAGE_KEY = 'splender_notifications_enabled';

export interface InAppNotificationEvent {
  id: string;
  title: string;
  body: string;
  icon?: string;
  tag?: string;
  timestamp: number;
  conversationId?: string;
  senderUid?: string;
  senderName?: string;
}

type NotificationListener = (event: InAppNotificationEvent) => void;
const listeners = new Set<NotificationListener>();

/**
 * Register listener for in-app notification banner
 */
export function onNotification(listener: NotificationListener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * Check if the browser environment supports Notifications
 */
export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

/**
 * Check if the user has globally toggled notifications on in-app
 */
export function areNotificationsEnabled(): boolean {
  if (typeof window === 'undefined') return false;
  return localStorage.getItem(NOTIFICATIONS_STORAGE_KEY) !== 'false';
}

/**
 * Set the in-app notification preference
 */
export function setNotificationsEnabled(enabled: boolean): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, String(enabled));
  }
}

/**
 * Get current browser notification permission
 */
export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

/**
 * Request notification permission from user
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;
  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      setNotificationsEnabled(true);
      trackEvent('push_permission_granted', { platform: 'web' }, 'engagement');
      return true;
    }
    trackEvent('push_permission_denied', { permission }, 'engagement');
    return false;
  } catch {
    return false;
  }
}

export function isLockScreenShieldEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  return localStorage.getItem('splender_lock_screen_shield') !== 'false';
}

/**
 * Dispatches an in-app notification banner and a privacy-safe OS / ServiceWorker notification.
 * OS-level notifications never expose decrypted plaintext message previews.
 */
export function sendPushNotification(
  title: string,
  options: NotificationOptions & {
    conversationId?: string;
    senderUid?: string;
    senderName?: string;
    redactOsPreview?: boolean;
  } = {}
): boolean {
  if (!areNotificationsEnabled()) return false;

  playNotificationChime();

  const shieldActive = isLockScreenShieldEnabled();
  const inAppBody = shieldActive && options.redactOsPreview
    ? 'New encrypted message'
    : (options.body as string) || '';

  const eventPayload: InAppNotificationEvent = {
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    title,
    body: inAppBody,
    icon: (options.icon as string) || undefined,
    tag: options.tag,
    timestamp: Date.now(),
    conversationId: options.conversationId,
    senderUid: options.senderUid,
    senderName: options.senderName,
  };

  listeners.forEach((listener) => {
    try {
      listener(eventPayload);
    } catch {
      // Ignore listener error
    }
  });

  trackEvent('notification_dispatched', { tag: options.tag }, 'engagement');

  if (isNotificationSupported() && Notification.permission === 'granted') {
    const osTitle = options.redactOsPreview && shieldActive ? 'Splender Chat' : title;
    const osBody = options.redactOsPreview
      ? 'New encrypted message'
      : (options.body as string) || 'Tap to open Splender Chat';

    const osOptions: NotificationOptions = {
      body: osBody,
      icon: '/icon.svg',
      badge: '/icon.svg',
      tag: options.tag,
      silent: false,
      data: {
        conversationId: options.conversationId || null,
        senderUid: options.senderUid || null,
      },
    };

    try {
      const notification = new Notification(osTitle, osOptions);
      notification.onclick = () => {
        window.focus();
        if (options.conversationId) {
          window.dispatchEvent(
            new CustomEvent('splender:navigate-conversation', {
              detail: { conversationId: options.conversationId },
            })
          );
        }
        notification.close();
      };
      return true;
    } catch {
      if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
        void navigator.serviceWorker.ready
          .then((reg) => reg.showNotification(osTitle, osOptions))
          .catch(() => {});
        return true;
      }
      return false;
    }
  }

  return false;
}

/**
 * Notification helper for incoming chat messages — always redacts plaintext from OS lock-screen previews.
 */
export function notifyIncomingChat(
  senderName: string,
  text: string,
  avatarUrl?: string,
  conversationId?: string,
  senderUid?: string
): boolean {
  return sendPushNotification(`New message from ${senderName}`, {
    body: text.length > 80 ? `${text.slice(0, 77)}...` : text,
    icon: avatarUrl || '/icon.svg',
    tag: `chat_${conversationId || senderName}`,
    conversationId,
    senderUid,
    senderName,
    redactOsPreview: true,
  });
}

/**
 * Notification helper for new story / moment updates
 */
export function notifyNewStory(authorName: string, storyTitle?: string): boolean {
  return sendPushNotification(`${authorName} shared a Moment`, {
    body: storyTitle || 'Tap to view their 24h ephemeral moment.',
    tag: `story_${authorName}`,
    redactOsPreview: false,
  });
}

/**
 * Send a test notification to verify client-side push & audio chimes
 */
export function sendTestNotification(): boolean {
  return sendPushNotification('Splender Chat Notification', {
    body: 'Encrypted push channel and audio chime verified.',
    tag: 'test_notification',
    redactOsPreview: false,
  });
}

