/**
 * Android 17 (API 37) & Modern Web Runtime Permissions & Lifecycle Manager
 *
 * Handles:
 * 1. `ACCESS_LOCAL_NETWORK` (Android 17 LAN P2P ICE host discovery)
 * 2. Scoped Photo Picker (`READ_MEDIA_VISUAL_USER_SELECTED` / zero-storage-sweep `<input type="file">`)
 * 3. `CAMERA` & `RECORD_AUDIO` runtime permission checks with graceful denial handling
 * 4. `POST_NOTIFICATIONS` (Android 13-17 runtime notifications)
 * 5. Android 17 background-audio restriction enforcement (pauses transient voice notes when
 *    app enters background unless an active Foreground Call Service is running).
 */

export type SplenderPermissionKind =
  | 'localNetwork'
  | 'scopedPhotoPicker'
  | 'camera'
  | 'microphone'
  | 'notifications';

export type PermissionGrantState = 'granted' | 'denied' | 'prompt' | 'scoped';

export interface Android17PermissionSnapshot {
  localNetwork: PermissionGrantState;
  scopedPhotoPicker: PermissionGrantState;
  camera: PermissionGrantState;
  microphone: PermissionGrantState;
  notifications: PermissionGrantState;
  targetSdk: 37;
}

export class Android17PermissionManager {
  private static foregroundCallActive = false;

  public static setForegroundCallActive(active: boolean) {
    this.foregroundCallActive = active;
  }

  public static isForegroundCallActive(): boolean {
    return this.foregroundCallActive;
  }

  /**
   * Queries current Android 17 / Browser permission states without triggering invasive prompts.
   */
  public static async getSnapshot(): Promise<Android17PermissionSnapshot> {
    if (typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.()) {
      const nativePlugin = (window as any).Capacitor?.Plugins?.SplenderNative;
      if (nativePlugin?.getAndroid17Permissions) {
        try {
          const res = await nativePlugin.getAndroid17Permissions();
          return {
            localNetwork: res?.localNetwork ? 'granted' : 'prompt',
            scopedPhotoPicker: res?.scopedPhotoPicker ? 'scoped' : 'prompt',
            camera: res?.camera ? 'granted' : 'prompt',
            microphone: res?.microphone ? 'granted' : 'prompt',
            notifications: res?.notifications ? 'granted' : 'prompt',
            targetSdk: 37,
          };
        } catch {
          // Fall through to standard web query
        }
      }
    }

    const queryWebPerm = async (name: string): Promise<PermissionGrantState> => {
      try {
        if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
          const status = await navigator.permissions.query({ name: name as PermissionName });
          return status.state as PermissionGrantState;
        }
      } catch {
        // Unsupported permission descriptor in this browser engine
      }
      return 'prompt';
    };

    const [camera, microphone] = await Promise.all([
      queryWebPerm('camera'),
      queryWebPerm('microphone'),
    ]);

    const notifications: PermissionGrantState =
      typeof Notification === 'undefined'
        ? 'denied'
        : Notification.permission === 'default'
        ? 'prompt'
        : (Notification.permission as PermissionGrantState);

    // Local Network Access (`local-network-access` / Android 17 ACCESS_LOCAL_NETWORK)
    const localNetwork = await queryWebPerm('local-network-access');

    return {
      localNetwork: localNetwork === 'denied' ? 'denied' : localNetwork === 'granted' ? 'granted' : 'prompt',
      // Scoped picker requires zero broad storage permissions on Android 14-17 and modern browsers
      scopedPhotoPicker: 'scoped',
      camera,
      microphone,
      notifications,
      targetSdk: 37,
    };
  }

  /**
   * Requests a specific permission at the moment of user action with graceful degradation.
   */
  public static async requestPermission(kind: SplenderPermissionKind): Promise<{
    state: PermissionGrantState;
    fallbackMessage?: string;
  }> {
    if (typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.()) {
      const nativePlugin = (window as any).Capacitor?.Plugins?.SplenderNative;
      if (nativePlugin?.requestAndroid17Permission && kind !== 'scopedPhotoPicker') {
        try {
          const res = await nativePlugin.requestAndroid17Permission({ kind });
          const granted = Boolean(res?.[kind]);
          return {
            state: granted ? 'granted' : 'denied',
            fallbackMessage: granted
              ? undefined
              : kind === 'localNetwork'
              ? 'Local LAN discovery disabled; falling back to STUN/TURN relay.'
              : kind === 'notifications'
              ? 'System notifications disabled; using in-app banners.'
              : `${kind === 'camera' ? 'Camera' : 'Microphone'} permission denied by Android 17 runtime guard.`,
          };
        } catch {
          // Continue to graceful web/P2P fallback
        }
      } else if (nativePlugin && (kind === 'localNetwork' || kind === 'notifications')) {
        try {
          const res = await nativePlugin.requestP2pPermissions();
          const granted = Boolean(res?.[kind]);
          return {
            state: granted ? 'granted' : 'denied',
            fallbackMessage: granted
              ? undefined
              : kind === 'localNetwork'
              ? 'Local LAN discovery disabled; falling back to STUN/TURN relay.'
              : 'System notifications disabled; using in-app banners.',
          };
        } catch {
          // Continue to graceful web fallback
        }
      }
    }

    switch (kind) {
      case 'scopedPhotoPicker':
        return { state: 'scoped' };

      case 'localNetwork':
        return {
          state: 'granted',
          fallbackMessage: undefined,
        };

      case 'notifications': {
        if (typeof Notification === 'undefined') {
          return { state: 'denied', fallbackMessage: 'Notifications unavailable; using in-app banners.' };
        }
        try {
          const perm = await Notification.requestPermission();
          return {
            state: perm === 'default' ? 'prompt' : perm,
            fallbackMessage:
              perm === 'granted' ? undefined : 'System notifications declined; in-app alerts remain active.',
          };
        } catch {
          return { state: 'denied', fallbackMessage: 'Using in-app notification banners.' };
        }
      }

      case 'camera':
      case 'microphone': {
        if (!navigator?.mediaDevices?.getUserMedia) {
          return {
            state: 'denied',
            fallbackMessage: `Physical ${kind} unavailable in this environment.`,
          };
        }
        try {
          const constraints = kind === 'camera' ? { video: true } : { audio: true };
          const stream = await navigator.mediaDevices.getUserMedia(constraints);
          stream.getTracks().forEach((t) => t.stop());
          return { state: 'granted' };
        } catch {
          return {
            state: 'denied',
            fallbackMessage: `${kind === 'camera' ? 'Camera' : 'Microphone'} permission declined; continuing safely without hardware capture.`,
          };
        }
      }
    }
  }

  /**
   * Enforces Android 17 background-audio playback rules on transient `<audio>` elements
   * (e.g., voice notes). Automatically pauses audio if the document enters background
   * while no Foreground Call Service is active.
   */
  public static attachBackgroundAudioLifecycle(
    audio: HTMLAudioElement,
    onPausedByLifecycle: () => void
  ): () => void {
    if (typeof document === 'undefined') return () => {};

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && !this.foregroundCallActive && !audio.paused) {
        audio.pause();
        onPausedByLifecycle();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }
}
