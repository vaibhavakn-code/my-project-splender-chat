export type LanguageCode = 'mr' | 'hi' | 'en' | 'es' | 'fr' | 'de';

export interface TranslationStrings {
  // Tabs
  chats: string;
  updates: string;
  communities: string;
  calls: string;

  // Search & Filter
  searchPlaceholder: string;
  filterAll: string;
  filterUnread: string;
  filterFavorites: string;
  filterGroups: string;
  filterPhotos: string;
  filterVideos: string;
  filterLinks: string;
  filterAudio: string;
  filterDocs: string;

  // Chats
  lockedChats: string;
  archivedChats: string;
  newChat: string;
  newGroup: string;
  tapToChat: string;
  typeMessage: string;
  online: string;
  offline: string;
  typing: string;

  // Status & Updates
  myStatus: string;
  tapToAddStatus: string;
  recentUpdates: string;
  createStatus: string;
  viewers: string;
  viewedBy: string;

  // Communities & Calls
  newCommunity: string;
  startCall: string;
  callLogs: string;
  createCallLink: string;

  // Settings & Actions
  settings: string;
  profile: string;
  privacy: string;
  account: string;
  notifications: string;
  storage: string;
  language: string;
  help: string;
  disappearingMessages: string;
  blockContact: string;
  unblockContact: string;
  blockedNotice: string;
  clearChat: string;
  deleteMessage: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationStrings> = {
  en: {
    chats: 'Chats',
    updates: 'Updates',
    communities: 'Communities',
    calls: 'Calls',
    searchPlaceholder: 'Search chats, contacts, messages...',
    filterAll: 'All',
    filterUnread: 'Unread',
    filterFavorites: 'Favorites',
    filterGroups: 'Groups',
    filterPhotos: 'Photos',
    filterVideos: 'Videos',
    filterLinks: 'Links',
    filterAudio: 'Audio',
    filterDocs: 'Docs',
    lockedChats: 'Locked chats',
    archivedChats: 'Archived chats',
    newChat: 'New chat',
    newGroup: 'New group',
    tapToChat: 'Tap to chat',
    typeMessage: 'Type a message...',
    online: 'Online',
    offline: 'Offline',
    typing: 'typing...',
    myStatus: 'My status',
    tapToAddStatus: 'Tap to add status update',
    recentUpdates: 'Recent updates',
    createStatus: 'Create Status Update',
    viewers: 'Viewers',
    viewedBy: 'Viewed by',
    newCommunity: 'New Community',
    startCall: 'Start Call',
    callLogs: 'Call Logs',
    createCallLink: 'Create call link',
    settings: 'Settings',
    profile: 'Profile',
    privacy: 'Privacy',
    account: 'Account',
    notifications: 'Notifications',
    storage: 'Storage & Data',
    language: 'App Language',
    help: 'Help',
    disappearingMessages: 'Disappearing messages',
    blockContact: 'Block Contact',
    unblockContact: 'Unblock Contact',
    blockedNotice: 'This contact is blocked. Tap to unblock.',
    clearChat: 'Clear chat',
    deleteMessage: 'Delete message',
  },
  mr: {
    chats: 'गप्पा',
    updates: 'अपडेट्स',
    communities: 'समुदाय',
    calls: 'कॉल्स',
    searchPlaceholder: 'गप्पा, संपर्क, संदेश शोधा...',
    filterAll: 'सर्व',
    filterUnread: 'न वाचलेले',
    filterFavorites: 'आवडते',
    filterGroups: 'गट',
    filterPhotos: 'फोटो',
    filterVideos: 'व्हिडिओ',
    filterLinks: 'लिंक्स',
    filterAudio: 'ऑडिओ',
    filterDocs: 'दस्तऐवज',
    lockedChats: 'कुलूपबंद गप्पा',
    archivedChats: 'संग्रहित गप्पा',
    newChat: 'नवीन चॅट',
    newGroup: 'नवीन गट',
    tapToChat: 'चॅट करण्यासाठी टॅप करा',
    typeMessage: 'संदेश लिहा...',
    online: 'ऑनलाइन',
    offline: 'ऑफलाइन',
    typing: 'टाईप करत आहे...',
    myStatus: 'माझा स्टेटस',
    tapToAddStatus: 'नवीन स्टेटस जोडण्यासाठी टॅप करा',
    recentUpdates: 'नुकतेच अपडेट्स',
    createStatus: 'स्टेटस तयार करा',
    viewers: 'पाहणारे',
    viewedBy: 'यांनी पाहिले',
    newCommunity: 'नवीन समुदाय',
    startCall: 'कॉल सुरू करा',
    callLogs: 'कॉल इतिहास',
    createCallLink: 'कॉल लिंक तयार करा',
    settings: 'सेटिंग्ज',
    profile: 'प्रोफाइल',
    privacy: 'गोपनीयता',
    account: 'खाते',
    notifications: 'सूचना',
    storage: 'स्टोरेज आणि डेटा',
    language: 'अ‍ॅप भाषा',
    help: 'मदत',
    disappearingMessages: 'गायब होणारे संदेश',
    blockContact: 'ब्लॉक करा',
    unblockContact: 'अनब्लॉक करा',
    blockedNotice: 'हा संपर्क ब्लॉक केला आहे. अनब्लॉक करण्यासाठी टॅप करा.',
    clearChat: 'गप्पा हटवा',
    deleteMessage: 'संदेश हटवा',
  },
  hi: {
    chats: 'चैट्स',
    updates: 'अपडेट्स',
    communities: 'समुदाय',
    calls: 'कॉल्स',
    searchPlaceholder: 'चैट्स, संपर्क, संदेश खोजें...',
    filterAll: 'सभी',
    filterUnread: 'अपठित',
    filterFavorites: 'पसंदीदा',
    filterGroups: 'ग्रुप्स',
    filterPhotos: 'फ़ोटो',
    filterVideos: 'वीडियो',
    filterLinks: 'लिंक्स',
    filterAudio: 'ऑडियो',
    filterDocs: 'दस्तावेज़',
    lockedChats: 'लॉक की गई चैट्स',
    archivedChats: 'संग्रहीत चैट्स',
    newChat: 'नई चैट',
    newGroup: 'नया ग्रुप',
    tapToChat: 'चैट करने के लिए टैप करें',
    typeMessage: 'संदेश लिखें...',
    online: 'ऑनलाइन',
    offline: 'ऑफ़लाइन',
    typing: 'टाइप कर रहा है...',
    myStatus: 'मेरा स्टेटस',
    tapToAddStatus: 'नया स्टेटस जोड़ने के लिए टैप करें',
    recentUpdates: 'हालिया अपडेट्स',
    createStatus: 'स्टेटस बनाएं',
    viewers: 'दर्शक',
    viewedBy: 'देखा गया',
    newCommunity: 'नया समुदाय',
    startCall: 'कॉल शुरू करें',
    callLogs: 'कॉल रिकॉर्ड',
    createCallLink: 'कॉल लिंक बनाएं',
    settings: 'सेटिंग्स',
    profile: 'प्रोफ़ाइल',
    privacy: 'गोपनीयता',
    account: 'खाता',
    notifications: 'सूचनाएं',
    storage: 'स्टोरेज और डेटा',
    language: 'ऐप की भाषा',
    help: 'सहायता',
    disappearingMessages: 'गायब होने वाले संदेश',
    blockContact: 'ब्लॉक करें',
    unblockContact: 'अनब्लॉक करें',
    blockedNotice: 'यह संपर्क ब्लॉक है। अनब्लॉक करने के लिए टैप करें।',
    clearChat: 'चैट साफ़ करें',
    deleteMessage: 'संदेश हटाएं',
  },
  es: {
    chats: 'Chats',
    updates: 'Novedades',
    communities: 'Comunidades',
    calls: 'Llamadas',
    searchPlaceholder: 'Buscar chats, contactos, mensajes...',
    filterAll: 'Todos',
    filterUnread: 'No leídos',
    filterFavorites: 'Favoritos',
    filterGroups: 'Grupos',
    filterPhotos: 'Fotos',
    filterVideos: 'Videos',
    filterLinks: 'Enlaces',
    filterAudio: 'Audio',
    filterDocs: 'Documentos',
    lockedChats: 'Chats bloqueados',
    archivedChats: 'Chats archivados',
    newChat: 'Nuevo chat',
    newGroup: 'Nuevo grupo',
    tapToChat: 'Toca para chatear',
    typeMessage: 'Escribe un mensaje...',
    online: 'En línea',
    offline: 'Desconectado',
    typing: 'escribiendo...',
    myStatus: 'Mi estado',
    tapToAddStatus: 'Toca para añadir una actualización',
    recentUpdates: 'Recientes',
    createStatus: 'Crear estado',
    viewers: 'Vistas',
    viewedBy: 'Visto por',
    newCommunity: 'Nueva comunidad',
    startCall: 'Iniciar llamada',
    callLogs: 'Registro de llamadas',
    createCallLink: 'Crear enlace de llamada',
    settings: 'Ajustes',
    profile: 'Perfil',
    privacy: 'Privacidad',
    account: 'Cuenta',
    notifications: 'Notificaciones',
    storage: 'Almacenamiento y datos',
    language: 'Idioma de la aplicación',
    help: 'Ayuda',
    disappearingMessages: 'Mensajes temporales',
    blockContact: 'Bloquear',
    unblockContact: 'Desbloquear',
    blockedNotice: 'Has bloqueado este contacto. Toca para desbloquear.',
    clearChat: 'Vaciar chat',
    deleteMessage: 'Eliminar mensaje',
  },
  fr: {
    chats: 'Discussions',
    updates: 'Actus',
    communities: 'Communautés',
    calls: 'Appels',
    searchPlaceholder: 'Rechercher discussions, contacts, messages...',
    filterAll: 'Tous',
    filterUnread: 'Non lus',
    filterFavorites: 'Favoris',
    filterGroups: 'Groupes',
    filterPhotos: 'Photos',
    filterVideos: 'Vidéos',
    filterLinks: 'Liens',
    filterAudio: 'Audio',
    filterDocs: 'Documents',
    lockedChats: 'Discussions verrouillées',
    archivedChats: 'Discussions archivées',
    newChat: 'Nouvelle discussion',
    newGroup: 'Nouveau groupe',
    tapToChat: 'Appuyez pour discuter',
    typeMessage: 'Écrivez un message...',
    online: 'En ligne',
    offline: 'Hors ligne',
    typing: 'écrit...',
    myStatus: 'Mon statut',
    tapToAddStatus: 'Appuyez pour ajouter un statut',
    recentUpdates: 'Récents',
    createStatus: 'Créer un statut',
    viewers: 'Vues',
    viewedBy: 'Vu par',
    newCommunity: 'Nouvelle communauté',
    startCall: 'Démarrer un appel',
    callLogs: 'Historique des appels',
    createCallLink: 'Créer un lien d’appel',
    settings: 'Paramètres',
    profile: 'Profil',
    privacy: 'Confidentialité',
    account: 'Compte',
    notifications: 'Notifications',
    storage: 'Stockage et données',
    language: 'Langue de l’application',
    help: 'Aide',
    disappearingMessages: 'Messages éphémères',
    blockContact: 'Bloquer',
    unblockContact: 'Débloquer',
    blockedNotice: 'Ce contact est bloqué. Appuyez pour débloquer.',
    clearChat: 'Effacer la discussion',
    deleteMessage: 'Supprimer le message',
  },
  de: {
    chats: 'Chats',
    updates: 'Aktuelles',
    communities: 'Communitys',
    calls: 'Anrufe',
    searchPlaceholder: 'Chats, Kontakte, Nachrichten suchen...',
    filterAll: 'Alle',
    filterUnread: 'Ungelesen',
    filterFavorites: 'Favoriten',
    filterGroups: 'Gruppen',
    filterPhotos: 'Fotos',
    filterVideos: 'Videos',
    filterLinks: 'Links',
    filterAudio: 'Audio',
    filterDocs: 'Dokumente',
    lockedChats: 'Gesperrte Chats',
    archivedChats: 'Archivierte Chats',
    newChat: 'Neuer Chat',
    newGroup: 'Neue Gruppe',
    tapToChat: 'Tippen zum Chatten',
    typeMessage: 'Nachricht eingeben...',
    online: 'Online',
    offline: 'Offline',
    typing: 'tippt...',
    myStatus: 'Mein Status',
    tapToAddStatus: 'Tippen, um Status hinzuzufügen',
    recentUpdates: 'Aktuelle Updates',
    createStatus: 'Status erstellen',
    viewers: 'Aufrufe',
    viewedBy: 'Gesehen von',
    newCommunity: 'Neue Community',
    startCall: 'Anruf starten',
    callLogs: 'Anrufprotokoll',
    createCallLink: 'Anruflink erstellen',
    settings: 'Einstellungen',
    profile: 'Profil',
    privacy: 'Datenschutz',
    account: 'Konto',
    notifications: 'Benachrichtigungen',
    storage: 'Speicher und Daten',
    language: 'App-Sprache',
    help: 'Hilfe',
    disappearingMessages: 'Selbstlöschende Nachrichten',
    blockContact: 'Blockieren',
    unblockContact: 'Freigeben',
    blockedNotice: 'Kontakt blockiert. Tippen zum Freigeben.',
    clearChat: 'Chat leeren',
    deleteMessage: 'Nachricht löschen',
  },
};

export function getTranslation(lang: LanguageCode, key: keyof TranslationStrings): string {
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.mr || TRANSLATIONS.en;
  return dict[key] || TRANSLATIONS.en[key] || key;
}
