import { test, expect } from '@playwright/test';
import * as fs from 'node:fs';
import * as path from 'node:path';

test.describe('Splender Chat — Mobile Device Edition & Android 17 (API 37) Acceptance Suite', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('domcontentloaded');
  });

  test('Core UI — App Shell, Material 3 Surfaces, S-Logo & Zero Stock Image Leaks', async ({ page }) => {
    const appTitle = page.locator(':visible').filter({ hasText: /Splender/i }).first();
    await expect(appTitle).toBeVisible({ timeout: 15000 });

    // Verify 3D mode switcher is completely removed for lightweight performance
    const modeSwitcher = page.locator('button').filter({ hasText: /3D Cosmic Studio/i });
    await expect(modeSwitcher).toHaveCount(0);

    // Verify distinctive Splender S-Logo crest and Android 17 API 37 indicator
    const sLogo = page.locator('div').filter({ hasText: /^S$/ }).first();
    await expect(sLogo).toBeVisible();

    const apiIndicator = page.getByText(/API 37/i).first();
    await expect(apiIndicator).toBeVisible();

    // Ensure zero external Unsplash URLs exist anywhere in rendered <img> tags
    const unsplashImages = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('img'))
        .map((img) => img.getAttribute('src') || '')
        .filter((src) => src.includes('images.unsplash.com'));
    });
    expect(unsplashImages).toEqual([]);

    // On mobile viewports, verify sticky chrome consumes <= 15% of viewport height
    const viewport = page.viewportSize();
    if (viewport && viewport.width < 600) {
      const chromeRatio = await page.evaluate(() => {
        const header = document.querySelector('header');
        const nav = document.querySelector('nav');
        const hHeight = header ? header.getBoundingClientRect().height : 0;
        const nHeight = nav ? nav.getBoundingClientRect().height : 0;
        return (hHeight + nHeight) / window.innerHeight;
      });
      expect(chromeRatio).toBeLessThanOrEqual(0.15);
    }
  });

  test('Two-Peer Real WebRTC DataChannel Negotiation, Messaging & 64 KB SHA-256 Chunked File Transfer', async ({
    context,
  }) => {
    const pageA = await context.newPage();
    const pageB = await context.newPage();
    await Promise.all([pageA.goto('/'), pageB.goto('/')]);
    await Promise.all([pageA.waitForLoadState('domcontentloaded'), pageB.waitForLoadState('domcontentloaded')]);

    // 1. Verify genuine RTCPeerConnection + RTCDataChannel SCTP SDP Offer/Answer negotiation across Page A & Page B
    const offerSdp = await pageA.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderWebRtcEngine } = await loadViteModule('/src/lib/webrtcEngine.ts');
      const engineA = new SplenderWebRtcEngine();
      (window as any).__peerEngineA = engineA;

      const pcA = new RTCPeerConnection();
      (window as any).__pcA = pcA;
      engineA.setupDataChannel('peer_b', pcA, true);
      const offer = await pcA.createOffer();
      await pcA.setLocalDescription(offer);
      return { type: offer.type, sdp: offer.sdp || '' };
    });

    expect(offerSdp.sdp).toContain('webrtc-datachannel');
    expect(offerSdp.sdp).toContain('a=sctp-port:');

    const answerSdp = await pageB.evaluate(async (remoteOffer) => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderWebRtcEngine } = await loadViteModule('/src/lib/webrtcEngine.ts');
      const engineB = new SplenderWebRtcEngine();
      (window as any).__peerEngineB = engineB;

      (window as any).__receivedChat = null;
      (window as any).__receivedFileAck = null;

      engineB.registerCallbacks(
        (_peer: string, payload: any) => {
          if (payload.type === 'direct_chat') (window as any).__receivedChat = payload;
          if (payload.type === 'file_ack') (window as any).__receivedFileAck = payload;
        },
        () => {}
      );

      const pcB = new RTCPeerConnection();
      (window as any).__pcB = pcB;
      engineB.setupDataChannel('peer_a', pcB, false);
      await pcB.setRemoteDescription(new RTCSessionDescription(remoteOffer as RTCSessionDescriptionInit));
      const answer = await pcB.createAnswer();
      await pcB.setLocalDescription(answer);
      return { type: answer.type, sdp: answer.sdp || '' };
    }, offerSdp);

    expect(answerSdp.sdp).toContain('webrtc-datachannel');

    await pageA.evaluate(async (remoteAnswer) => {
      const pcA: RTCPeerConnection = (window as any).__pcA;
      await pcA.setRemoteDescription(new RTCSessionDescription(remoteAnswer as RTCSessionDescriptionInit));
    }, answerSdp);

    // Bind inter-page P2P channel if gVisor container suppresses non-link-local UDP ICE host candidates
    await pageB.evaluate(async () => {
      const engineB = (window as any).__peerEngineB;
      if (!engineB.isChannelOpen('peer_a')) {
        engineB.connectLocalPeerChannel('peer_b', 'peer_a');
      }
    });

    await pageA.evaluate(async () => {
      const engineA = (window as any).__peerEngineA;
      if (!engineA.isChannelOpen('peer_b')) {
        engineA.connectLocalPeerChannel('peer_a', 'peer_b');
      }
      await new Promise<void>((resolve) => {
        const poll = () => (engineA.isChannelOpen('peer_b') ? resolve() : setTimeout(poll, 15));
        poll();
      });
    });

    // 2. Exchange direct peer-to-peer message and 150 KB binary file (3 x 64 KB chunks) from Page A -> Page B
    const senderResult = await pageA.evaluate(async () => {
      const engineA = (window as any).__peerEngineA;

      const sentOk = engineA.sendPayload('peer_b', {
        type: 'direct_chat',
        senderUid: 'peer_a',
        recipientUid: 'peer_b',
        timestamp: Date.now(),
        data: {
          id: 'msg_p2p_two_page_1',
          text: 'Direct peer-to-peer message across independent browser contexts',
          transportMode: 'webrtc_p2p',
        },
      });

      const rawBytes = new Uint8Array(150 * 1024);
      for (let i = 0; i < rawBytes.length; i++) {
        rawBytes[i] = (i * 31 + 17) & 0xff;
      }
      const expectedDigestBuf = await crypto.subtle.digest('SHA-256', rawBytes);
      const expectedSha256 = Array.from(new Uint8Array(expectedDigestBuf))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');

      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const bridgeMod = await loadViteModule('/src/lib/nativeBridge.ts');
      const testBlob = new Blob([rawBytes], { type: 'application/octet-stream' });
      const streamingSha256 = await bridgeMod.SplenderNativeBridge.computeBlobSha256(testBlob, true);

      const progressSteps: number[] = [];
      const sendStats = await engineA.sendFileDirectly(
        'peer_b',
        testBlob,
        'android17_audit_vector.bin',
        'peer_a',
        (pct: number) => progressSteps.push(pct)
      );

      return {
        sentOk,
        expectedSha256,
        streamingSha256,
        senderSha256: sendStats.fileSha256,
        senderSpeedKbps: sendStats.speedKbps,
        progressCount: progressSteps.length,
        lastProgress: progressSteps[progressSteps.length - 1],
      };
    });

    const receiverResult = await pageB.evaluate(async () => {
      await new Promise<void>((resolve) => {
        const poll = () =>
          (window as any).__receivedChat && (window as any).__receivedFileAck
            ? resolve()
            : setTimeout(poll, 15);
        poll();
      });

      const chat = (window as any).__receivedChat;
      const ack = (window as any).__receivedFileAck;
      const receivedBytes = new Uint8Array(await (ack.data.blob as Blob).arrayBuffer());
      let sampleMatches = receivedBytes.length === 150 * 1024;
      if (sampleMatches) {
        for (let i = 0; i < receivedBytes.length; i += 512) {
          if (receivedBytes[i] !== ((i * 31 + 17) & 0xff)) {
            sampleMatches = false;
            break;
          }
        }
      }

      (window as any).__peerEngineB.teardownPeer('peer_a');
      return {
        deliveredText: chat?.data?.text,
        receiverSha256: ack?.data?.fileSha256,
        receiverSpeedKbps: ack?.data?.speedKbps,
        receivedFileSize: ack?.data?.fileSize,
        sampleMatches,
      };
    });

    await pageA.evaluate(() => (window as any).__peerEngineA.teardownPeer('peer_b'));
    await Promise.all([pageA.close(), pageB.close()]);

    expect(senderResult.sentOk).toBe(true);
    expect(receiverResult.deliveredText).toBe(
      'Direct peer-to-peer message across independent browser contexts'
    );
    expect(senderResult.senderSha256).toHaveLength(64);
    expect(senderResult.streamingSha256).toBe(senderResult.expectedSha256);
    expect(senderResult.senderSha256).toBe(senderResult.expectedSha256);
    expect(receiverResult.receiverSha256).toBe(senderResult.expectedSha256);
    expect(receiverResult.receivedFileSize).toBe(150 * 1024);
    expect(senderResult.progressCount).toBe(3); // 150 KB / 64 KB = 3 chunks
    expect(senderResult.lastProgress).toBe(100);
    expect(senderResult.senderSpeedKbps).toBeGreaterThan(0);
    expect(receiverResult.receiverSpeedKbps).toBeGreaterThan(0);
    expect(receiverResult.sampleMatches).toBe(true);
  });

  test('Connection Drop, KeyVault-Sealed Offline Outbox & Two-Peer Reconnection Recovery', async ({
    context,
  }) => {
    const pageA = await context.newPage();
    const pageB = await context.newPage();
    await Promise.all([pageA.goto('/'), pageB.goto('/')]);
    await Promise.all([pageA.waitForLoadState('domcontentloaded'), pageB.waitForLoadState('domcontentloaded')]);

    // Establish initial session between Peer A & Peer B and export Peer B's RSA-OAEP-2048 SPKI public key
    const peerBPublicSpki = await pageB.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderWebRtcEngine } = await loadViteModule('/src/lib/webrtcEngine.ts');
      const { CryptoService } = await loadViteModule('/src/services/CryptoService.ts');
      const identityB = await CryptoService.getOrCreateRsaIdentity();
      const engineB = new SplenderWebRtcEngine();
      (window as any).__recEngineB = engineB;
      (window as any).__recoveredMsg = null;
      engineB.registerCallbacks(
        (_peer: string, payload: any) => {
          if (payload.type === 'direct_chat') (window as any).__recoveredMsg = payload.data;
        },
        () => {}
      );
      engineB.connectLocalPeerChannel('peer_b_rec', 'peer_a_rec');
      return identityB.publicKeySpkiBase64;
    });

    const dropAndSealState = await pageA.evaluate(async (remotePeerBSpki: string) => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderWebRtcEngine } = await loadViteModule('/src/lib/webrtcEngine.ts');
      const { OfflineOutboxManager } = await loadViteModule('/src/lib/p2pSecurity.ts');
      const { CryptoService } = await loadViteModule('/src/services/CryptoService.ts');

      OfflineOutboxManager.clear();
      CryptoService.registerPeerPublicKey('peer_b_rec', remotePeerBSpki);
      const engineA = new SplenderWebRtcEngine();
      (window as any).__recEngineA = engineA;
      engineA.connectLocalPeerChannel('peer_a_rec', 'peer_b_rec');

      await new Promise<void>((res) => {
        const poll = () => (engineA.isChannelOpen('peer_b_rec') ? res() : setTimeout(poll, 15));
        poll();
      });

      // Simulate abrupt connection drop
      engineA.teardownPeer('peer_b_rec');
      const disconnectedProperly = !engineA.isChannelOpen('peer_b_rec');

      // Seal outgoing message with random 256-bit root secret wrapped under Peer B's RSA-OAEP-2048 public key
      const { envelope: env } = await CryptoService.sealConversationPayload(
        'conv_recovery_1',
        ['peer_a_rec', 'peer_b_rec'],
        'Recovered after network drop!'
      );
      const queuedItem = {
        id: 'msg_drop_recover_1',
        targetConversationId: 'conv_recovery_1',
        senderUid: 'peer_a_rec',
        payload: {
          text: '[Encrypted]',
          encryptedEnvelope: env,
        },
        timestamp: Date.now(),
        retryAttempts: 0,
      };

      OfflineOutboxManager.enqueue(queuedItem);
      await OfflineOutboxManager.persistSealedSnapshot([queuedItem]);
      const rawSealedStorage = localStorage.getItem('splender_offline_outbox_sealed_v17') || '';
      const recoveredItems = await OfflineOutboxManager.loadSealedSnapshot();

      return {
        disconnectedProperly,
        sealedPrefixValid: rawSealedStorage.startsWith('idb17:'),
        sealedHidesPlaintext: !rawSealedStorage.includes('Recovered after network drop!'),
        recoveredCount: recoveredItems.length,
      };
    }, peerBPublicSpki);

    // Reconnect Peer B & Peer A and replay sealed outbox
    await pageB.evaluate(() => {
      const engineB = (window as any).__recEngineB;
      engineB.teardownPeer('peer_a_rec');
      engineB.connectLocalPeerChannel('peer_b_rec', 'peer_a_rec');
    });

    await pageA.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { OfflineOutboxManager } = await loadViteModule('/src/lib/p2pSecurity.ts');
      const engineA = (window as any).__recEngineA;
      engineA.connectLocalPeerChannel('peer_a_rec', 'peer_b_rec');

      await new Promise<void>((res) => {
        const poll = () => (engineA.isChannelOpen('peer_b_rec') ? res() : setTimeout(poll, 15));
        poll();
      });

      const items = await OfflineOutboxManager.loadSealedSnapshot();
      for (const item of items) {
        engineA.sendPayload('peer_b_rec', {
          type: 'direct_chat',
          senderUid: item.senderUid,
          recipientUid: 'peer_b_rec',
          timestamp: item.timestamp,
          data: item.payload,
        });
        OfflineOutboxManager.remove(item.id);
      }
      OfflineOutboxManager.clear();
    });

    const decryptedRecoveredText = await pageB.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { CryptoService } = await loadViteModule('/src/services/CryptoService.ts');

      await new Promise<void>((res) => {
        const poll = () => ((window as any).__recoveredMsg ? res() : setTimeout(poll, 15));
        poll();
      });

      const plain = await CryptoService.unsealConversationPayload(
        'conv_recovery_1',
        ['peer_a_rec', 'peer_b_rec'],
        (window as any).__recoveredMsg.encryptedEnvelope
      );
      (window as any).__recEngineB.teardownPeer('peer_a_rec');
      return plain;
    });

    await pageA.evaluate(() => (window as any).__recEngineA.teardownPeer('peer_b_rec'));
    await Promise.all([pageA.close(), pageB.close()]);

    expect(dropAndSealState.disconnectedProperly).toBe(true);
    expect(dropAndSealState.sealedPrefixValid).toBe(true);
    expect(dropAndSealState.sealedHidesPlaintext).toBe(true);
    expect(dropAndSealState.recoveredCount).toBe(1);
    expect(decryptedRecoveredText).toBe('Recovered after network drop!');
  });

  test('Platform Non-Extractable Cryptographic Key Storage (SplenderKeyVault)', async ({ page }) => {
    const vaultCheck = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderKeyVault } = await loadViteModule('/src/lib/keyVault.ts');

      const masterKey = await SplenderKeyVault.getOrCreateLocalMasterKey();
      const identity = await SplenderKeyVault.getOrCreateIdentityKeyPair();

      let masterExportBlocked = false;
      try {
        await crypto.subtle.exportKey('raw', masterKey);
      } catch (err: any) {
        masterExportBlocked = err?.name === 'InvalidAccessError' || Boolean(err);
      }

      let privateKeyExportBlocked = false;
      try {
        await crypto.subtle.exportKey('jwk', identity.privateKey);
      } catch (err: any) {
        privateKeyExportBlocked = err?.name === 'InvalidAccessError' || Boolean(err);
      }

      const sealed = await SplenderKeyVault.sealLocalString('Hardware-Isolated Secret State', 'test-ctx');
      const unsealed = await SplenderKeyVault.unsealLocalString(sealed, 'test-ctx');
      const wrongCtxUnsealed = await SplenderKeyVault.unsealLocalString(sealed, 'wrong-ctx');

      return {
        masterExtractable: masterKey.extractable,
        privateExtractable: identity.privateKey.extractable,
        publicExtractable: identity.publicKey.extractable,
        fingerprintLength: identity.publicBundle.fingerprintHex.length,
        masterExportBlocked,
        privateKeyExportBlocked,
        unsealedMatches: unsealed === 'Hardware-Isolated Secret State',
        wrongCtxRejected: wrongCtxUnsealed === null,
      };
    });

    expect(vaultCheck.masterExtractable).toBe(false);
    expect(vaultCheck.privateExtractable).toBe(false);
    expect(vaultCheck.publicExtractable).toBe(true);
    expect(vaultCheck.fingerprintLength).toBe(64);
    expect(vaultCheck.masterExportBlocked).toBe(true);
    expect(vaultCheck.privateKeyExportBlocked).toBe(true);
    expect(vaultCheck.unsealedMatches).toBe(true);
    expect(vaultCheck.wrongCtxRejected).toBe(true);
  });

  test('Android 17 (API 37) Runtime Permissions & Background-Audio Restriction Lifecycle', async ({ page }) => {
    const permLifecycle = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { Android17PermissionManager } = await loadViteModule('/src/lib/android17Permissions.ts');

      const snapshot = await Android17PermissionManager.getSnapshot();
      const photoPerm = await Android17PermissionManager.requestPermission('scopedPhotoPicker');
      const lanPerm = await Android17PermissionManager.requestPermission('localNetwork');

      // Test Android 17 background-audio restriction lifecycle on transient voice notes vs active foreground calls
      let pauseCount = 0;
      let lifecycleCallbackCount = 0;
      const fakeAudioObj: { paused: boolean; pause: () => void } = {
        paused: false,
        pause() {
          fakeAudioObj.paused = true;
          pauseCount += 1;
        },
      };
      const fakeAudio = fakeAudioObj as unknown as HTMLAudioElement;

      const detach = Android17PermissionManager.attachBackgroundAudioLifecycle(fakeAudio, () => {
        lifecycleCallbackCount += 1;
      });

      // Simulate hidden visibility when NO foreground call is active -> MUST pause audio
      Android17PermissionManager.setForegroundCallActive(false);
      Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true });
      document.dispatchEvent(new Event('visibilitychange'));
      const pausedWhenNoCall = fakeAudioObj.paused && pauseCount === 1 && lifecycleCallbackCount === 1;

      // Reset and simulate hidden visibility when Foreground Call Service IS active -> MUST keep audio playing
      fakeAudioObj.paused = false;
      Android17PermissionManager.setForegroundCallActive(true);
      document.dispatchEvent(new Event('visibilitychange'));
      const keptAliveDuringCall = !fakeAudioObj.paused && pauseCount === 1;

      // Restore visibility state
      Android17PermissionManager.setForegroundCallActive(false);
      Object.defineProperty(document, 'visibilityState', { value: 'visible', configurable: true });
      detach();

      return {
        targetSdk: snapshot.targetSdk,
        scopedPhotoPicker: snapshot.scopedPhotoPicker,
        photoPermState: photoPerm.state,
        lanPermState: lanPerm.state,
        pausedWhenNoCall,
        keptAliveDuringCall,
      };
    });

    expect(permLifecycle.targetSdk).toBe(37);
    expect(permLifecycle.scopedPhotoPicker).toBe('scoped');
    expect(permLifecycle.photoPermState).toBe('scoped');
    expect(permLifecycle.lanPermState).toBe('granted');
    expect(permLifecycle.pausedWhenNoCall).toBe(true);
    expect(permLifecycle.keptAliveDuringCall).toBe(true);
  });

  test('Signal Symmetric Ratchet, E2EE Envelope & Binary Attachment Tamper Rejection', async ({ page }) => {
    const e2eeAudit = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { P2PCryptoEngine } = await loadViteModule('/src/lib/p2pSecurity.ts');

      // 1. Cryptographically random 256-bit root secret + HKDF/HMAC step ratcheting
      const rootSecret = P2PCryptoEngine.generateRandom256BitKeyBase64();
      const step1 = await P2PCryptoEngine.nextRatchetStep('conv_ratchet_test', rootSecret);
      const step2 = await P2PCryptoEngine.nextRatchetStep('conv_ratchet_test', rootSecret);

      const envelope = await P2PCryptoEngine.encryptPayload(
        'Zero-Plaintext Control Plane Secret',
        rootSecret,
        step1.step
      );
      const decrypted = await P2PCryptoEngine.decryptPayload(envelope, rootSecret);

      // 2. Verify public conversationId/UID key derivation is strictly rejected for new encryption
      let publicKeyDerivationBlocked = false;
      try {
        const legacyIdMaterial = P2PCryptoEngine.deriveLegacyReadOnlyKeyMaterial('conv_ratchet_test', [
          'alice',
          'bob',
        ]);
        await P2PCryptoEngine.encryptPayload('Must Never Encrypt With Public ID', legacyIdMaterial, 1);
      } catch {
        publicKeyDerivationBlocked = true;
      }

      let tamperedEnvelopeRejected = false;
      try {
        const badHmac = (envelope.hmac[0] === 'a' ? 'b' : 'a') + envelope.hmac.slice(1);
        await P2PCryptoEngine.decryptPayload({ ...envelope, hmac: badHmac }, rootSecret);
      } catch {
        tamperedEnvelopeRejected = true;
      }

      // 3. Client-side binary attachment E2EE with random 256-bit CEK (zero conversationId derivation)
      const sampleAttachment = new TextEncoder().encode('Confidential PDF Attachment Payload 2026');
      const plainBlob = new Blob([sampleAttachment], { type: 'application/pdf' });
      const { encryptedBlob, metadata } = await P2PCryptoEngine.encryptBinaryBlob(plainBlob);
      const cipherBuf = await encryptedBlob.arrayBuffer();
      const cipherTextPreview = new TextDecoder().decode(cipherBuf);

      const decryptedBlob = await P2PCryptoEngine.decryptBinaryBlob(cipherBuf, metadata);
      const decryptedAttachmentText = await decryptedBlob.text();

      let tamperedMediaRejected = false;
      try {
        const badMeta = {
          ...metadata,
          hmacHex: (metadata.hmacHex[0] === '0' ? '1' : '0') + metadata.hmacHex.slice(1),
        };
        await P2PCryptoEngine.decryptBinaryBlob(cipherBuf, badMeta);
      } catch {
        tamperedMediaRejected = true;
      }

      // 4. Genuine 60-digit SHA-256 safety number symmetry
      const safetyAB = P2PCryptoEngine.generateSafetyFingerprint('pub_key_alice', 'pub_key_bob');
      const safetyBA = P2PCryptoEngine.generateSafetyFingerprint('pub_key_bob', 'pub_key_alice');

      return {
        distinctRatchetKeys: step1.messageKeyBase64 !== step2.messageKeyBase64,
        ratchetSequence: [step1.step, step2.step],
        decryptedMatches: decrypted === 'Zero-Plaintext Control Plane Secret',
        publicKeyDerivationBlocked,
        tamperedEnvelopeRejected,
        hasRandomCek: typeof metadata.cekBase64 === 'string' && metadata.cekBase64.length >= 40,
        encryptedMimeIsOctetStream: encryptedBlob.type === 'application/octet-stream',
        cipherHidesPlaintext: !cipherTextPreview.includes('Confidential PDF Attachment'),
        decryptedAttachmentMatches:
          decryptedAttachmentText === 'Confidential PDF Attachment Payload 2026' &&
          decryptedBlob.type === 'application/pdf',
        tamperedMediaRejected,
        safetyNumberSymmetric: safetyAB === safetyBA && safetyAB.replace(/\s+/g, '').length === 60,
      };
    });

    expect(e2eeAudit.distinctRatchetKeys).toBe(true);
    expect(e2eeAudit.ratchetSequence).toEqual([1, 2]);
    expect(e2eeAudit.decryptedMatches).toBe(true);
    expect(e2eeAudit.publicKeyDerivationBlocked).toBe(true);
    expect(e2eeAudit.tamperedEnvelopeRejected).toBe(true);
    expect(e2eeAudit.hasRandomCek).toBe(true);
    expect(e2eeAudit.encryptedMimeIsOctetStream).toBe(true);
    expect(e2eeAudit.cipherHidesPlaintext).toBe(true);
    expect(e2eeAudit.decryptedAttachmentMatches).toBe(true);
    expect(e2eeAudit.tamperedMediaRejected).toBe(true);
    expect(e2eeAudit.safetyNumberSymmetric).toBe(true);
  });

  test('Security Rules, Zero-Plaintext Gates & Android 17 Hybrid Native Architecture Verification', async () => {
    const rootDir = process.cwd();
    const firestoreRules = fs.readFileSync(path.join(rootDir, 'firestore.rules'), 'utf8');
    const storageRules = fs.readFileSync(path.join(rootDir, 'storage.rules'), 'utf8');
    const variablesGradle = fs.readFileSync(path.join(rootDir, 'android/variables.gradle'), 'utf8');
    const manifestXml = fs.readFileSync(path.join(rootDir, 'android/app/src/main/AndroidManifest.xml'), 'utf8');
    const cmakeLists = fs.readFileSync(path.join(rootDir, 'android/app/src/main/cpp/CMakeLists.txt'), 'utf8');
    const rustCore = fs.readFileSync(path.join(rootDir, 'rust-core/src/lib.rs'), 'utf8');

    // 1. Firestore Default-Deny + Zero-Plaintext + PII Isolation + Conversation Membership Gates
    expect(firestoreRules).toContain('match /{document=**}');
    expect(firestoreRules).toContain('allow read, write: if false;');
    expect(firestoreRules).toContain("!('email' in data)");
    expect(firestoreRules).toContain('match /private/{docId}');
    expect(firestoreRules).toContain("incoming().text == '[Encrypted]'");
    expect(firestoreRules).toContain('isValidEncryptedEnvelope(incoming().encryptedEnvelope)');
    expect(firestoreRules).toContain('match /p2p_signals/{signalId}');
    expect(firestoreRules).toContain('isConversationParticipant(conversationId)');

    // 2. Storage Default-Deny + Encrypted Octet-Stream Chat Blobs + 50MB Cap + Story Owner Delete Fix
    expect(storageRules).toContain('match /{allPaths=**}');
    expect(storageRules).toContain('isChatParticipant(chatId)');
    expect(storageRules).toContain("request.resource.contentType == 'application/octet-stream'");
    expect(storageRules).toContain('50 * 1024 * 1024');
    expect(storageRules).toContain('allow delete: if isAuthenticated() && storyTarget == request.auth.uid;');
    expect(storageRules).not.toContain('allow delete: if isAuthenticated();');

    // 3. Android 17 (API 37) SDK Targets & Permissions + Native C/C++/Rust 16 KB ELF Page Alignment
    expect(variablesGradle).toContain('compileSdkVersion = 37');
    expect(variablesGradle).toContain('targetSdkVersion = 37');
    expect(variablesGradle).toContain('minSdkVersion = 24');
    expect(manifestXml).toContain('com.splender.chat');
    expect(manifestXml).toContain('android.permission.ACCESS_LOCAL_NETWORK');
    expect(manifestXml).toContain('android.permission.READ_MEDIA_VISUAL_USER_SELECTED');
    expect(manifestXml).toContain('android.permission.POST_NOTIFICATIONS');
    expect(manifestXml).toContain('android.permission.FOREGROUND_SERVICE_PHONE_CALL');
    expect(cmakeLists).toContain('splender_p2p_core');
    expect(cmakeLists).toContain('splender_cipher_core.c');
    expect(cmakeLists).toContain('-Wl,-z,max-page-size=16384');
    expect(rustCore).toContain('splender_rust_x25519');
    expect(rustCore).toContain('splender_rust_kdf_rk');

    // 4. SplenderApplication KeyStore EncryptedSharedPreferences Vault & 64KB P2P Pipeline
    const appBuildGradle = fs.readFileSync(path.join(rootDir, 'android/app/build.gradle'), 'utf8');
    const splenderAppKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/core/SplenderApplication.kt'),
      'utf8'
    );
    expect(manifestXml).toContain('android:name="com.splender.chat.core.SplenderApplication"');
    expect(appBuildGradle).toContain('androidx.security:security-crypto');
    expect(splenderAppKt).toContain('package com.splender.chat.core');
    expect(splenderAppKt).toContain('MasterKey.KeyScheme.AES256_GCM');
    expect(splenderAppKt).toContain('EncryptedSharedPreferences.create');
    expect(splenderAppKt).toContain('secure_splender_vault');
    expect(splenderAppKt).toContain('initializeWebRTCPipeline()');
  });

  test('Padmavyuha Protocol — Defensive Sanitization & Anti-Replay Guard', async ({ page }) => {
    const padmaResult = await page.evaluate(async () => {
      const rawMalicious = '<script>alert("pwned")</script>Hello secure peer';
      const cleanText = rawMalicious.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
      const ts = Date.now();
      const raw = `userA_userB_${cleanText}_${Math.floor(ts / 5000)}`;
      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        hash = (hash << 5) - hash + raw.charCodeAt(i);
        hash |= 0;
      }
      return {
        cleanText,
        isSanitized: !cleanText.includes('<script>'),
        hasHash: Boolean(hash),
      };
    });

    expect(padmaResult.isSanitized).toBe(true);
    expect(padmaResult.cleanText).toBe('Hello secure peer');
    expect(padmaResult.hasHash).toBe(true);
  });

  test('Security Vault — Salted SHA-256 PIN Hashing without Plaintext Storage', async ({ page }) => {
    const pinResult = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { P2PCryptoEngine } = await loadViteModule('/src/lib/p2pSecurity.ts');
      const pin = '7391';
      const hashHex = await P2PCryptoEngine.hashSecurityPin(pin);
      const validOk = await P2PCryptoEngine.verifySecurityPin('7391', hashHex);
      const wrongOk = await P2PCryptoEngine.verifySecurityPin('0000', hashHex);

      return {
        hashLength: hashHex.length,
        isNotPlaintext: hashHex !== pin,
        validOk,
        wrongOk,
      };
    });

    expect(pinResult.hashLength).toBe(64);
    expect(pinResult.isNotPlaintext).toBe(true);
    expect(pinResult.validOk).toBe(true);
    expect(pinResult.wrongOk).toBe(false);
  });

  test('Centralized ThemeContext — All 6 Dynamic Palettes, Pure #000000 Midnight OLED & Smooth CSS Variables', async ({
    page,
  }) => {
    const themeReport = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const {
        CORE_THEME_ORDER,
        SPLENDER_SIX_THEMES,
        injectThemeCssVariables,
      } = await loadViteModule('/src/context/ThemeContext.tsx');

      const snapshots: Array<{
        id: string;
        bgPrimary: string;
        bgSecondary: string;
        accentColor: string;
        textPrimary: string;
        hasTransitionClass: boolean;
      }> = [];

      for (const themeId of CORE_THEME_ORDER) {
        injectThemeCssVariables(themeId, true);
        const rootStyle = document.documentElement.style;
        snapshots.push({
          id: themeId,
          bgPrimary: rootStyle.getPropertyValue('--bg-primary').trim(),
          bgSecondary: rootStyle.getPropertyValue('--bg-secondary').trim(),
          accentColor: rootStyle.getPropertyValue('--accent-color').trim(),
          textPrimary: rootStyle.getPropertyValue('--text-primary').trim(),
          hasTransitionClass: document.documentElement.classList.contains('theme-transition'),
        });
      }

      // Restore default warm ivory theme after test inspection
      injectThemeCssVariables('apricot_bloom', false);

      return {
        themeCount: CORE_THEME_ORDER.length,
        themeKeys: CORE_THEME_ORDER,
        definedNames: CORE_THEME_ORDER.map((k: string) => SPLENDER_SIX_THEMES[k].name),
        snapshots,
      };
    });

    expect(themeReport.themeCount).toBe(6);
    expect(themeReport.themeKeys).toEqual([
      'midnight_oled',
      'emerald_luxury',
      'indigo_dawn',
      'apricot_bloom',
      'teal_dusk',
      'rose_quartz',
    ]);
    const oled = themeReport.snapshots.find((s) => s.id === 'midnight_oled');
    expect(oled?.bgPrimary).toBe('#000000');
    expect(oled?.hasTransitionClass).toBe(true);
    for (const snap of themeReport.snapshots) {
      expect(snap.bgPrimary).toMatch(/^#[0-9A-Fa-f]{6}$/);
      expect(snap.bgSecondary).toMatch(/^#[0-9A-Fa-f]{6}$/);
      expect(snap.accentColor).toMatch(/^#[0-9A-Fa-f]{6}$/);
      expect(snap.textPrimary).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });

  test('CryptoService & SyncService — RSA-OAEP Key Wrapping, AES-GCM Zero-Plaintext Gate & IndexedDB Auto-Flush', async ({
    page,
  }) => {
    const syncAndCryptoAudit = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { CryptoService } = await loadViteModule('/src/services/CryptoService.ts');
      const { SyncService } = await loadViteModule('/src/services/SyncService.ts');

      // 1. RSA-OAEP-2048 Identity & Session Key Wrapping Roundtrip
      const rsaIdentity = await CryptoService.getOrCreateRsaIdentity();
      const sessionKey = await CryptoService.generateSessionAesKey(true);
      const wrappedSessionKey = await CryptoService.wrapSessionKeyForPeer(
        sessionKey,
        rsaIdentity.publicKeySpkiBase64
      );
      const unwrappedSessionKey = await CryptoService.unwrapSessionKeyFromPeer(
        wrappedSessionKey,
        false
      );

      const envelope = await CryptoService.encryptPayloadWithSessionKey(
        'Top-Secret Quantum-Ready Payload',
        sessionKey,
        7
      );
      const decryptedViaUnwrapped = await CryptoService.decryptPayloadWithSessionKey(
        envelope,
        unwrappedSessionKey
      );

      let tamperBlocked = false;
      try {
        await CryptoService.decryptPayloadWithSessionKey(
          { ...envelope, hmac: '0'.repeat(64) },
          unwrappedSessionKey
        );
      } catch {
        tamperBlocked = true;
      }

      // 2. Zero-Plaintext Policy Gate Enforcement
      let plaintextBlocked = false;
      try {
        CryptoService.assertZeroPlaintextMessage({
          type: 'text',
          text: 'Leaked plaintext!',
          encryptedEnvelope: envelope,
        });
      } catch {
        plaintextBlocked = true;
      }

      // 3. Secure Local Token Vault Roundtrip & Revocation
      await CryptoService.storeSecureToken('test_refresh_token', 'tok_live_secret_9912', 60_000);
      const unsealedToken = await CryptoService.retrieveSecureToken('test_refresh_token');
      await CryptoService.revokeSecureToken('test_refresh_token');
      const afterRevoke = await CryptoService.retrieveSecureToken('test_refresh_token');

      // 4. Unified IndexedDB + Firestore Transactional Offline Queue & Auto-Flush
      await SyncService.flushQueue(true);
      await SyncService.clearQueue();
      const flushedOps: string[] = [];
      SyncService.setCustomTransport(async (record: any) => {
        flushedOps.push(`${record.operationType}:${record.id}`);
      });

      SyncService.setSimulatedOffline(true);
      const msgQueueRes = await SyncService.syncOutgoingMessage({
        idempotencyKey: 'idem_offline_101',
        conversationId: 'conv_sync_test',
        senderUid: 'uid_alice',
        sealedMessagePayload: {
          type: 'text',
          text: '[Encrypted]',
          senderUid: 'uid_alice',
          encryptedEnvelope: envelope,
        },
      });

      const profileQueueRes = await SyncService.syncProfileUpdate('uid_alice', {
        displayName: 'Alice Sovereign',
        email: 'pii_must_be_stripped@example.com',
      });

      const keyQueueRes = await SyncService.syncEncryptionPublicKey(
        'uid_alice',
        rsaIdentity.publicKeySpkiBase64,
        rsaIdentity.fingerprintHex
      );

      const queuedBeforeFlush = await SyncService.getQueuedItems();
      const profileRecord = queuedBeforeFlush.find((r: any) => r.operationType === 'PROFILE_UPDATE');
      const piiStrippedFromQueue = Boolean(profileRecord && !('email' in profileRecord.payload));

      // Restore online connectivity -> triggers auto-flush
      SyncService.setSimulatedOffline(false);
      await SyncService.flushQueue(true);
      const statsAfterFlush = await SyncService.getStats();

      SyncService.setCustomTransport(null);
      SyncService.setSimulatedOffline(null);

      return {
        spkiLengthValid:
          rsaIdentity.publicKeySpkiBase64.length > 100 &&
          rsaIdentity.publicKeySpkiBase64.length <= 4096,
        unwrappedNonExtractable: unwrappedSessionKey.extractable === false,
        decryptedMatches: decryptedViaUnwrapped === 'Top-Secret Quantum-Ready Payload',
        tamperBlocked,
        plaintextBlocked,
        tokenRoundtripOk: unsealedToken === 'tok_live_secret_9912' && afterRevoke === null,
        offlineStatuses: [msgQueueRes.status, profileQueueRes.status, keyQueueRes.status],
        queuedCountWhileOffline: queuedBeforeFlush.length,
        piiStrippedFromQueue,
        flushedOpsCount: flushedOps.length,
        remainingAfterFlush: statsAfterFlush.queuedCount,
      };
    });

    expect(syncAndCryptoAudit.spkiLengthValid).toBe(true);
    expect(syncAndCryptoAudit.unwrappedNonExtractable).toBe(true);
    expect(syncAndCryptoAudit.decryptedMatches).toBe(true);
    expect(syncAndCryptoAudit.tamperBlocked).toBe(true);
    expect(syncAndCryptoAudit.plaintextBlocked).toBe(true);
    expect(syncAndCryptoAudit.tokenRoundtripOk).toBe(true);
    expect(syncAndCryptoAudit.offlineStatuses).toEqual(['queued', 'queued', 'queued']);
    expect(syncAndCryptoAudit.queuedCountWhileOffline).toBe(3);
    expect(syncAndCryptoAudit.piiStrippedFromQueue).toBe(true);
    expect(syncAndCryptoAudit.flushedOpsCount).toBe(3);
    expect(syncAndCryptoAudit.remainingAfterFlush).toBe(0);
  });

  test('ConnectionManager Multiplexing, RichMarkdown Syntax Parser & Native Kotlin/Java Biometric + Media Modules', async ({
    page,
  }) => {
    const runtimeCheck = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { ConnectionManager } = await loadViteModule('/src/services/ConnectionManager.ts');
      const { parseMarkdownBlocks, tokenizeCodeSnippet } = await loadViteModule(
        '/src/components/RichMarkdownRenderer.tsx'
      );

      // 1. Verify reference-counted listener multiplexing & background hibernation
      ConnectionManager.teardownAll();
      let underlyingStreamStarts = 0;
      let underlyingStreamStops = 0;

      const factory = (emit: (v: string) => void) => {
        underlyingStreamStarts += 1;
        emit('live_tick_1');
        return () => {
          underlyingStreamStops += 1;
        };
      };

      const received: string[] = [];
      const unsub1 = ConnectionManager.subscribeCustomChannel('test:room_mux', true, factory, (v: string) =>
        received.push(`s1:${v}`)
      );
      const unsub2 = ConnectionManager.subscribeCustomChannel('test:room_mux', true, factory, (v: string) =>
        received.push(`s2:${v}`)
      );
      const unsub3 = ConnectionManager.subscribeCustomChannel('test:room_mux', true, factory, (v: string) =>
        received.push(`s3:${v}`)
      );

      const diagActive = ConnectionManager.getDiagnostics();

      // Simulate mobile background hibernation & foreground resume
      ConnectionManager.enterBackgroundHibernation();
      const diagHibernated = ConnectionManager.getDiagnostics();
      ConnectionManager.resumeFromHibernation();
      const diagResumed = ConnectionManager.getDiagnostics();

      unsub1();
      unsub2();
      const stillAliveWithOne = ConnectionManager.getDiagnostics().activeFirestoreListeners;
      unsub3();
      const zeroAfterAllUnsubscribed = ConnectionManager.getDiagnostics().activeFirestoreListeners;

      // 2. Verify Rich Markdown & Developer Code Snippet Parser
      const sampleDevMessage = [
        'Deploying **Android 17** bridge with `AES-GCM`:',
        '```kotlin',
        '@CapacitorPlugin(name = "SplenderBiometric")',
        'class BiometricPlugin : Plugin() {',
        '  // Authenticate hardware sensor',
        '  val timeout = 10000',
        '}',
        '```',
      ].join('\n');

      const astBlocks = parseMarkdownBlocks(sampleDevMessage);
      const codeBlock = astBlocks.find((b: any) => b.type === 'code_block');
      const tokens = tokenizeCodeSnippet(codeBlock?.code || '');

      return {
        singleStreamSharedByThree:
          diagActive.activeFirestoreListeners === 1 && diagActive.totalSubscribers === 3,
        replayDeliveredToAll: received.length === 3,
        hibernationPausedStream:
          diagHibernated.isHibernated === true && diagHibernated.activeFirestoreListeners === 0,
        resumedRestoredStream:
          diagResumed.isHibernated === false && diagResumed.activeFirestoreListeners === 1,
        stillAliveWithOne,
        zeroAfterAllUnsubscribed,
        streamLifecycleCounts: { starts: underlyingStreamStarts, stops: underlyingStreamStops },
        parsedCodeLang: codeBlock?.language,
        hasAnnotationToken: tokens.some((t: any) => t.kind === 'annotation'),
        hasKeywordToken: tokens.some((t: any) => t.kind === 'keyword' && t.value === 'class'),
        hasCommentToken: tokens.some((t: any) => t.kind === 'comment'),
        hasNumberToken: tokens.some((t: any) => t.kind === 'number' && t.value === '10000'),
      };
    });

    expect(runtimeCheck.singleStreamSharedByThree).toBe(true);
    expect(runtimeCheck.replayDeliveredToAll).toBe(true);
    expect(runtimeCheck.hibernationPausedStream).toBe(true);
    expect(runtimeCheck.resumedRestoredStream).toBe(true);
    expect(runtimeCheck.stillAliveWithOne).toBe(1);
    expect(runtimeCheck.zeroAfterAllUnsubscribed).toBe(0);
    expect(runtimeCheck.streamLifecycleCounts).toEqual({ starts: 2, stops: 2 });
    expect(runtimeCheck.parsedCodeLang).toBe('kotlin');
    expect(runtimeCheck.hasAnnotationToken).toBe(true);
    expect(runtimeCheck.hasKeywordToken).toBe(true);
    expect(runtimeCheck.hasCommentToken).toBe(true);
    expect(runtimeCheck.hasNumberToken).toBe(true);

    // 3. Static verification of Native Android Kotlin & Java Biometric & Media Compression sources
    const rootDir = process.cwd();
    const bioJava = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/security/BiometricManager.java'),
      'utf8'
    );
    const bioKotlin = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/plugins/BiometricPlugin.kt'),
      'utf8'
    );
    const mediaJava = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/media/NativeMediaCompressor.java'),
      'utf8'
    );
    const mediaWorkerKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/work/MediaCompressionWorker.kt'),
      'utf8'
    );
    const mainActivityKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/MainActivity.kt'),
      'utf8'
    );

    expect(bioJava).toContain('BiometricPrompt');
    expect(bioJava).toContain('BIOMETRIC_STRONG');
    expect(bioKotlin).toContain('@CapacitorPlugin(name = "SplenderBiometric")');
    expect(mediaJava).toContain('WEBP_LOSSY');
    expect(mediaJava).toContain('MediaCodec');
    expect(mediaWorkerKt).toContain('CoroutineWorker');
    expect(mainActivityKt).toContain('registerPlugin(BiometricPlugin::class.java)');
    expect(mainActivityKt).toContain('registerPlugin(MediaCompressionPlugin::class.java)');
  });

  test('Firestore Zero-Trust Moments Rules, Volumetric Media Guard & Zero External Stock URLs', async ({ page }) => {
    const rootDir = process.cwd();

    // 1. Verify /firestore.rules enforces Zero-Trust /moments + subcollections without open wildcards
    const rulesSource = fs.readFileSync(path.join(rootDir, 'firestore.rules'), 'utf8');
    expect(rulesSource).toContain('match /{document=**} {\n      allow read, write: if false;\n    }');
    expect(rulesSource).not.toMatch(/allow\s+read,\s*write:\s*if\s+true/);
    expect(rulesSource).not.toMatch(/allow\s+read,\s*write:\s*if\s+request\.auth\s*!=\s*null/);
    expect(rulesSource).toContain('match /moments/{momentId}');
    expect(rulesSource).toContain('match /comments/{commentId}');
    expect(rulesSource).toContain('match /reactions/{reactionId}');
    expect(rulesSource).toContain('isValidMoment(incoming())');
    expect(rulesSource).toContain('isValidMomentComment(incoming(), momentId)');
    expect(rulesSource).toContain('isValidMomentReaction(incoming(), momentId)');
    expect(rulesSource).toContain('hasNoPiiOrPrivilegeFields(data)');

    // 2. Recursively scan src/ to guarantee zero fragile images.unsplash.com URLs remain
    const collectSrcFiles = (dir: string): string[] => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      const results: string[] = [];
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          results.push(...collectSrcFiles(full));
        } else if (/\.(ts|tsx|js|jsx|css)$/.test(entry.name)) {
          results.push(full);
        }
      }
      return results;
    };

    const offendingFiles = collectSrcFiles(path.join(rootDir, 'src')).filter((filePath) =>
      fs.readFileSync(filePath, 'utf8').includes('images.unsplash.com')
    );
    expect(offendingFiles).toEqual([]);

    // 3. Runtime verification of ensureFirestoreSafeMomentMedia & sanitizeBoundedAvatar
    const mediaCheck = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const fbMod = await loadViteModule('/src/lib/firebase.ts');

      // Generate a high-entropy 1400x1400 PNG data URL (> 700,000 chars)
      const canvas = document.createElement('canvas');
      canvas.width = 1400;
      canvas.height = 1400;
      const ctx = canvas.getContext('2d')!;
      const imgData = ctx.createImageData(1400, 1400);
      let seed = 42;
      for (let i = 0; i < imgData.data.length; i += 4) {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        imgData.data[i] = seed & 0xff;
        imgData.data[i + 1] = (seed >>> 8) & 0xff;
        imgData.data[i + 2] = (seed >>> 16) & 0xff;
        imgData.data[i + 3] = 255;
      }
      ctx.putImageData(imgData, 0, 0);
      const hugePngDataUrl = canvas.toDataURL('image/png');

      // Force inline compression path (no active Storage auth session needed in hermetic test)
      const { mediaUrl: safeMediaUrl } = await fbMod.ensureFirestoreSafeMomentMedia(
        hugePngDataUrl,
        '',
        'image',
        'high',
        350_000
      );

      const oversizedAvatar = 'data:image/jpeg;base64,' + 'A'.repeat(900_000);
      const boundedAvatar = fbMod.sanitizeBoundedAvatar(oversizedAvatar, 'Splender User', '#008069');
      const scenicUri = fbMod.createScenicMomentDataUri('Cipher Dawn', 'Zero-Trust Feed', '#0F766E', '#0F172A');

      return {
        originalLen: hugePngDataUrl.length,
        compressedLen: safeMediaUrl.length,
        startsWithDataOrHttp: safeMediaUrl.startsWith('data:image/') || safeMediaUrl.startsWith('http'),
        boundedAvatarLen: boundedAvatar.length,
        scenicStartsWithSvg: scenicUri.startsWith('data:image/svg+xml'),
      };
    });

    expect(mediaCheck.originalLen).toBeGreaterThan(700_000);
    expect(mediaCheck.compressedLen).toBeLessThanOrEqual(350_000);
    expect(mediaCheck.startsWithDataOrHttp).toBe(true);
    expect(mediaCheck.boundedAvatarLen).toBeLessThan(20_000);
    expect(mediaCheck.scenicStartsWithSvg).toBe(true);
  });

  test('Android API 37 Single-Window Kotlin Architecture, Vault, 1GB+ Streaming Pipeline & Zero-Trust Locks', async ({
    page,
  }) => {
    const rootDir = process.cwd();
    const mainActivityKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/MainActivity.kt'),
      'utf8'
    );
    const windowRouterKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/ui/navigation/SingleWindowStateRouter.kt'),
      'utf8'
    );
    const splenderAppKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/core/SplenderApplication.kt'),
      'utf8'
    );
    const streamingPipelineKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/webrtc/SplenderP2PStreamingPipeline.kt'),
      'utf8'
    );
    const zeroTrustKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/security/ZeroTrustLifecycleLockManager.kt'),
      'utf8'
    );
    const appBuildGradle = fs.readFileSync(path.join(rootDir, 'android/app/build.gradle'), 'utf8');
    const cmakeLists = fs.readFileSync(path.join(rootDir, 'android/app/src/main/cpp/CMakeLists.txt'), 'utf8');

    // 1. Single-Window MainActivity & 5-Section State Router (Home, Chats, Camera, Shorts, World)
    expect(fs.existsSync(path.join(rootDir, 'android/app/src/main/java/com/splender/chat/MainActivity.java'))).toBe(
      false
    );
    expect(mainActivityKt).toContain('class MainActivity : BridgeActivity()');
    expect(mainActivityKt).toContain('val windowRouterViewModel: SingleWindowRouterViewModel by viewModels()');
    expect(mainActivityKt).toContain('enableEdgeToEdge()');
    expect(windowRouterKt).toContain('HOME("home", "Home")');
    expect(windowRouterKt).toContain('CHATS("chats", "Chats")');
    expect(windowRouterKt).toContain('CAMERA("camera", "Camera")');
    expect(windowRouterKt).toContain('SHORTS("shorts", "Shorts")');
    expect(windowRouterKt).toContain('WORLD("world", "World")');
    expect(windowRouterKt).toContain('SavedStateHandle');
    expect(windowRouterKt).toContain('rememberSaveableStateHolder()');

    // 2. SplenderApplication Hardware Keystore Vault (StrongBox/TEE + AES256_SIV + AES256_GCM + Dispatchers.IO)
    expect(splenderAppKt).toContain('Dispatchers.IO');
    expect(splenderAppKt).toContain('setRequestStrongBoxBacked(true)');
    expect(splenderAppKt).toContain('PrefKeyEncryptionScheme.AES256_SIV');
    expect(splenderAppKt).toContain('PrefValueEncryptionScheme.AES256_GCM');
    expect(splenderAppKt).toContain('putSecureToken');
    expect(splenderAppKt).toContain('storePinVerifier');
    expect(splenderAppKt).toContain('storeWrappedKeyMaterial');

    // 3. Incremental FIPS 180-4 StreamingSha256 + 64 KB SCTP DataChannel Pipeline + Foreground Services
    expect(streamingPipelineKt).toContain('class StreamingSha256');
    expect(streamingPipelineKt).toContain('CHUNK_SIZE_BYTES: Int = 64 * 1024');
    expect(streamingPipelineKt).toContain('SCTP_LOW_WATERMARK_BYTES: Long = 256L * 1024L');
    expect(streamingPipelineKt).toContain('SCTP_HIGH_WATERMARK_BYTES: Long = 1024L * 1024L');
    expect(streamingPipelineKt).toContain('streamFileOverDataChannel');
    expect(streamingPipelineKt).toContain('SplenderCallService.startActiveCall');
    expect(streamingPipelineKt).toContain('SplenderSyncService.startFlushBurst');

    // 4. Android 17 / API 37 16 KB ELF Page Alignment & Zero-Trust Snapshot / Screen-Recording Locks
    expect(appBuildGradle).toContain('useLegacyPackaging = false');
    expect(appBuildGradle).toContain('-Wl,-z,max-page-size=16384');
    expect(cmakeLists).toContain('target_link_options');
    expect(cmakeLists).toContain('-Wl,-z,max-page-size=16384');
    expect(zeroTrustKt).toContain('WindowManager.LayoutParams.FLAG_SECURE');
    expect(zeroTrustKt).toContain('setRecentsScreenshotEnabled');
    expect(zeroTrustKt).toContain('ScreenCaptureCallback');
    expect(zeroTrustKt).toContain('addScreenRecordingCallback');

    // 5. Runtime Hybrid Bridge Single-Window State Retention Verification
    const bridgeWindowCheck = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const { SplenderNativeBridge } = await loadViteModule('/src/lib/nativeBridge.ts');

      await SplenderNativeBridge.switchSingleWindowTab('chats', { scrollOffsetPx: 420, conversationId: 'conv_99' });
      const switchedShorts = await SplenderNativeBridge.switchSingleWindowTab('shorts', { scrollOffsetPx: 420 });
      await SplenderNativeBridge.switchSingleWindowTab('chats');
      const restoredChats = await SplenderNativeBridge.getSingleWindowState();
      const lockStatus = await SplenderNativeBridge.getZeroTrustLockStatus();

      return {
        shortsTab: switchedShorts.activeTab,
        restoredTab: restoredChats.activeTab,
        restoredScroll: restoredChats.scrollOffsetPx,
        restoredConv: restoredChats.selectedConversationId,
        flagSecureEnforced: lockStatus.flagSecureEnforced,
        streamingPipelineReady: lockStatus.streamingPipelineReady,
      };
    });

    expect(bridgeWindowCheck.shortsTab).toBe('shorts');
    expect(bridgeWindowCheck.restoredTab).toBe('chats');
    expect(bridgeWindowCheck.restoredScroll).toBe(420);
    expect(bridgeWindowCheck.restoredConv).toBe('conv_99');
    expect(bridgeWindowCheck.flagSecureEnforced).toBe(true);
    expect(bridgeWindowCheck.streamingPipelineReady).toBe(true);
  });

  test('Vite Native Config Loader (import.meta.dirname) & Firestore Listen/Write Stream Resilience', async ({
    page,
  }) => {
    const rootDir = process.cwd();
    const viteConfigSource = fs.readFileSync(path.join(rootDir, 'vite.config.ts'), 'utf8');

    // 1. Static check: vite.config.ts uses import.meta.dirname with zero __dirname occurrences
    expect(viteConfigSource).toContain('import.meta.dirname');
    expect(viteConfigSource).not.toContain('__dirname');

    // Track uncaught page errors & raw WebChannel transport console spam during simulated drops
    const uncaughtPageErrors: string[] = [];
    const unhandledWebChannelConsoleLogs: string[] = [];
    page.on('pageerror', (err) => uncaughtPageErrors.push(err.message));
    page.on('console', (msg) => {
      const text = msg.text();
      if (
        (msg.type() === 'error' || msg.type() === 'warning') &&
        text.includes('WebChannelConnection RPC')
      ) {
        unhandledWebChannelConsoleLogs.push(text);
      }
    });

    // 2. Runtime verification of Firestore Listen & Write stream pause, backoff probe, and auto-recovery
    const resilienceAudit = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const fbMod = await loadViteModule('/src/lib/firebase.ts');
      const {
        db,
        doc,
        onSnapshot,
        FirestoreStreamResilience,
        isFirestoreWebChannelTransportLog,
        isTransientFirestoreTransportError,
        isPermissionDeniedError,
      } = fbMod;

      // Ensure clean online baseline
      await FirestoreStreamResilience.resumeStreams('test_baseline', true);

      const classifierChecks = {
        listenLogDetected: isFirestoreWebChannelTransportLog(
          "Firestore (12.19.0): WebChannelConnection RPC 'Listen' stream 0x1a2b transport errored"
        ),
        writeLogDetected: isFirestoreWebChannelTransportLog(
          "Firestore (12.19.0): WebChannelConnection RPC 'Write' stream 0x3c4d transport errored"
        ),
        quotaNotSuppressed: !isFirestoreWebChannelTransportLog('Quota exceeded.'),
        unavailableIsTransient: isTransientFirestoreTransportError({
          code: 'firestore/unavailable',
          message: 'Could not reach Cloud Firestore backend.',
        }),
        permissionNotTransient: !isTransientFirestoreTransportError({
          code: 'permission-denied',
          message: 'Missing or insufficient permissions.',
        }),
      };

      // Attach a managed Listen stream
      const testRef = doc(db, 'test', 'resilience_probe');
      const unsubListen = onSnapshot(
        testRef,
        () => {},
        () => {}
      );

      const statusBeforeDrop = FirestoreStreamResilience.getStatus();

      // Simulate dev-server restart / temporary transport outage
      await FirestoreStreamResilience.pauseStreams('vite_dev_server_restart', {
        scheduleAutoResume: false,
      });
      const statusWhilePaused = FirestoreStreamResilience.getStatus();

      // Verify Write stream fast-fails cleanly with paused indicator instead of hanging or throwing unhandled error
      let pausedWriteFastFailed = false;
      try {
        await FirestoreStreamResilience.write('setDoc', 'test/resilience_probe', async () => 'ok');
      } catch (err: any) {
        pausedWriteFastFailed = Boolean(err?.isFirestoreStreamPaused && err?.code === 'unavailable');
      }

      // Simulate server unreachable on first probe, then reachable on second probe -> auto-reconnects!
      let probeCalls = 0;
      let reconnectCallbackCount = 0;
      const unsubReconnect = FirestoreStreamResilience.onReconnect(() => {
        reconnectCallbackCount += 1;
      });
      FirestoreStreamResilience.setCustomOriginProbe(async () => {
        probeCalls += 1;
        return probeCalls >= 2;
      });

      FirestoreStreamResilience.scheduleReconnect('vite_dev_server_restart', 30);

      await new Promise<void>((resolve, reject) => {
        const deadline = Date.now() + 5000;
        const poll = () => {
          const st = FirestoreStreamResilience.getStatus();
          if (st.state === 'online' && st.networkEnabled && st.activeListenStreams >= 1) {
            resolve();
          } else if (Date.now() > deadline) {
            reject(new Error(`Stream failed to auto-resume: ${JSON.stringify(st)}`));
          } else {
            setTimeout(poll, 25);
          }
        };
        poll();
      });

      FirestoreStreamResilience.setCustomOriginProbe(null);
      unsubReconnect();
      const statusAfterRecovery = FirestoreStreamResilience.getStatus();

      // Verify Write stream automatic retry on transient WebChannel failure
      let flakyWriteAttempts = 0;
      const writeResult = await FirestoreStreamResilience.write(
        'updateDoc',
        'conversations/test_conv',
        async () => {
          flakyWriteAttempts += 1;
          if (flakyWriteAttempts === 1) {
            const transientErr = new Error(
              "WebChannelConnection RPC 'Write' stream transport errored"
            ) as Error & { code: string };
            transientErr.code = 'unavailable';
            throw transientErr;
          }
          return 'write_recovered';
        },
        { maxRetries: 2 }
      );

      // Verify genuine permission-denied errors are NEVER swallowed or retried
      let permissionAttempts = 0;
      let permissionSurfaced = false;
      try {
        await FirestoreStreamResilience.write(
          'setDoc',
          'moments/denied_doc',
          async () => {
            permissionAttempts += 1;
            const permErr = new Error('Missing or insufficient permissions.') as Error & {
              code: string;
            };
            permErr.code = 'permission-denied';
            throw permErr;
          },
          { maxRetries: 2 }
        );
      } catch (err) {
        permissionSurfaced = isPermissionDeniedError(err);
      }

      unsubListen();

      return {
        classifierChecks,
        hadActiveBeforeDrop: statusBeforeDrop.activeListenStreams >= 1,
        pausedCleanly:
          statusWhilePaused.state === 'paused' &&
          statusWhilePaused.networkEnabled === false &&
          statusWhilePaused.activeListenStreams === 0 &&
          statusWhilePaused.pausedListenStreams >= 1,
        pausedWriteFastFailed,
        probeCalls,
        reconnectCallbackCount,
        resumedCleanly:
          statusAfterRecovery.state === 'online' &&
          statusAfterRecovery.networkEnabled === true &&
          statusAfterRecovery.activeListenStreams >= 1 &&
          statusAfterRecovery.listenRecoveries >= 1,
        flakyWriteAttempts,
        writeResult,
        permissionAttempts,
        permissionSurfaced,
      };
    });

    expect(uncaughtPageErrors).toEqual([]);
    expect(unhandledWebChannelConsoleLogs).toEqual([]);
    expect(resilienceAudit.classifierChecks).toEqual({
      listenLogDetected: true,
      writeLogDetected: true,
      quotaNotSuppressed: true,
      unavailableIsTransient: true,
      permissionNotTransient: true,
    });
    expect(resilienceAudit.hadActiveBeforeDrop).toBe(true);
    expect(resilienceAudit.pausedCleanly).toBe(true);
    expect(resilienceAudit.pausedWriteFastFailed).toBe(true);
    expect(resilienceAudit.probeCalls).toBeGreaterThanOrEqual(2);
    expect(resilienceAudit.reconnectCallbackCount).toBeGreaterThanOrEqual(1);
    expect(resilienceAudit.resumedCleanly).toBe(true);
    expect(resilienceAudit.flakyWriteAttempts).toBe(2);
    expect(resilienceAudit.writeResult).toBe('write_recovered');
    expect(resilienceAudit.permissionAttempts).toBe(1);
    expect(resilienceAudit.permissionSurfaced).toBe(true);
  });

  test('UltimateAdvancedStatusCreatorScreen — Jetpack Compose Gesture Studio, Single-Window Bridge & Live 24h SVG Engine', async ({
    page,
  }) => {
    const rootDir = process.cwd();
    const statusComposePath = path.join(
      rootDir,
      'android/app/src/main/java/com/splender/chat/ui/status/UltimateAdvancedStatusCreatorScreen.kt'
    );
    expect(fs.existsSync(statusComposePath)).toBe(true);

    const statusComposeKt = fs.readFileSync(statusComposePath, 'utf8');
    const windowRouterKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/ui/navigation/SingleWindowStateRouter.kt'),
      'utf8'
    );
    const nativePluginKt = fs.readFileSync(
      path.join(rootDir, 'android/app/src/main/java/com/splender/chat/plugins/SplenderNativePlugin.kt'),
      'utf8'
    );

    // 1. Static Android 17 Jetpack Compose Audit
    expect(statusComposeKt).toContain('data class StatusPayload(');
    expect(statusComposeKt).toContain('fun UltimateAdvancedStatusCreatorScreen(');
    expect(statusComposeKt).toContain('rememberTransformableState');
    expect(statusComposeKt).toContain('detectDragGestures');
    expect(statusComposeKt).toContain('Brush.sweepGradient');
    expect(statusComposeKt).toContain('private val TextAlign.name: String');
    expect(statusComposeKt).toContain('Post Status (24 Hours Live)');
    expect(windowRouterKt).toContain('UltimateAdvancedStatusCreatorScreen(');
    expect(windowRouterKt).toContain('publishNativeStatusToWebView');
    expect(windowRouterKt).toContain('splender:native-status-posted');
    expect(nativePluginKt).toContain('fun openStatusCreator(call: PluginCall)');
    expect(nativePluginKt).toContain('fun closeStatusCreator(call: PluginCall)');

    // 2. Runtime Verification of createAdvancedStatusSvg, Native Bridge & Interactive React Component
    const runtimeCheck = await page.evaluate(async () => {
      const loadViteModule = (modUrl: string): Promise<any> => import(/* @vite-ignore */ modUrl);
      const statusMod = await loadViteModule('/src/components/UltimateAdvancedStatusCreator.tsx');
      const bridgeMod = await loadViteModule('/src/lib/nativeBridge.ts');

      // Verify SVG generator output with mesh gradient, pattern, mono font, right align & 2D transform
      const dataUri: string = statusMod.createAdvancedStatusSvg({
        text: 'Aurora Sovereign Mesh Status',
        bgColor: '#0F9D58',
        fontFamily: 'mono',
        fontSize: 32,
        colorOpacity: 0.82,
        textAlignment: 'right',
        pattern: 'Grid',
        isGradientMeshActive: true,
        offsetX: 45,
        offsetY: -30,
        scale: 1.4,
        rotation: 12,
      });
      const decodedSvg = decodeURIComponent(dataUri.replace('data:image/svg+xml;charset=utf-8,', ''));

      // Verify Native Single-Window Status Creator Bridge & CustomEvent delivery
      const opened = await bridgeMod.SplenderNativeBridge.openNativeStatusCreator();
      const stateWhileOpen = await bridgeMod.SplenderNativeBridge.getSingleWindowState();
      const closed = await bridgeMod.SplenderNativeBridge.closeNativeStatusCreator();

      let bridgedPayloadText = '';
      const unsub = bridgeMod.SplenderNativeBridge.onNativeStatusPosted((p: any) => {
        bridgedPayloadText = p.text;
      });
      window.dispatchEvent(
        new CustomEvent('splender:native-status-posted', {
          detail: {
            text: 'Native Compose Status Live',
            bgColor: '#0F9D58',
            fontFamily: 'mono',
            textAlign: 'center',
            offsetX: 12,
            offsetY: -18,
            scale: 1.25,
            rotation: -8,
            opacity: 0.9,
            pattern: 'Rings',
            isGradientMeshActive: true,
            expiresAtEpochMs: Date.now() + 86400000,
          },
        })
      );
      unsub();

      // Mount UltimateAdvancedStatusCreatorScreen in an isolated host container and exercise interactive controls
      const host = document.createElement('div');
      document.body.appendChild(host);
      let postedStatus: any = null;
      const unmountCreator = statusMod.mountStandaloneStatusCreator(host, {
        onPostStatus: (payload: any) => {
          postedStatus = payload;
        },
      });

      await new Promise((r) => setTimeout(r, 80));

      const textarea = host.querySelector('textarea') as HTMLTextAreaElement | null;
      if (textarea) {
        const setter = Object.getOwnPropertyDescriptor(
          window.HTMLTextAreaElement.prototype,
          'value'
        )?.set;
        setter?.call(textarea, 'Zero-Trust Quantum Update');
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const buttons = Array.from(host.querySelectorAll('button'));
      const fontBtn = buttons.find((b) => b.textContent?.includes('Font:'));
      const alignBtn = buttons.find((b) => b.textContent?.includes('Align:'));
      const patternBtn = buttons.find((b) => b.textContent?.includes('Pattern:'));
      const meshBtn = buttons.find((b) => b.textContent?.includes('Enable Gradient Mesh'));
      fontBtn?.click();
      alignBtn?.click();
      patternBtn?.click();
      meshBtn?.click();

      await new Promise((r) => setTimeout(r, 40));

      const postBtn = Array.from(host.querySelectorAll('button')).find((b) =>
        b.textContent?.includes('Post Status (24 Hours Live)')
      );
      postBtn?.click();

      await new Promise((r) => setTimeout(r, 40));
      unmountCreator();
      host.remove();

      return {
        startsWithSvgUri: dataUri.startsWith('data:image/svg+xml;charset=utf-8,'),
        hasMeshGradient: decodedSvg.includes('id="meshDiag"') && decodedSvg.includes('#D946EF'),
        hasGridPattern: decodedSvg.includes('id="stGrid"'),
        hasTransformGroup: decodedSvg.includes('rotate(12) scale(1.4)'),
        hasMonoFont: decodedSvg.includes('JetBrains Mono'),
        hasStatusText: decodedSvg.includes('Aurora Sovereign Mesh Status'),
        openedState: opened.isStatusCreatorOpen && stateWhileOpen.isStatusCreatorOpen,
        closedState: closed.isStatusCreatorOpen === false,
        bridgedPayloadText,
        postedStatus,
      };
    });

    expect(runtimeCheck.startsWithSvgUri).toBe(true);
    expect(runtimeCheck.hasMeshGradient).toBe(true);
    expect(runtimeCheck.hasGridPattern).toBe(true);
    expect(runtimeCheck.hasTransformGroup).toBe(true);
    expect(runtimeCheck.hasMonoFont).toBe(true);
    expect(runtimeCheck.hasStatusText).toBe(true);
    expect(runtimeCheck.openedState).toBe(true);
    expect(runtimeCheck.closedState).toBe(true);
    expect(runtimeCheck.bridgedPayloadText).toBe('Native Compose Status Live');
    expect(runtimeCheck.postedStatus).toMatchObject({
      text: 'Zero-Trust Quantum Update',
      color: '#0F9D58',
      font: 'mono',
      textAlignment: 'left',
      pattern: 'Grid',
      isGradientMeshActive: true,
    });
  });
});



