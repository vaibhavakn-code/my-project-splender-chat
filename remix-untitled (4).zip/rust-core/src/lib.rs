//! Splender Chat — Native Rust Cryptographic Core (`libsplender_p2p_core_rust`)
//!
//! Zero-dependency `#![no_std]` cryptographic module implementing:
//! 1. RFC 7748 X25519 Elliptic-Curve Diffie-Hellman Montgomery ladder over GF(2^255 - 19)
//! 2. FIPS 180-4 SHA-256, RFC 2104 HMAC-SHA256, and RFC 5869 HKDF-SHA256
//! 3. Signal Protocol Double Ratchet Root-Key (`kdf_rk`) & Chain-Key (`kdf_ck`) state transitions
//! 4. Constant-time comparison and volatile memory zeroization
//! 5. C-ABI FFI exports for direct linkage into `libsplender_p2p_core.so`

#![cfg_attr(not(test), no_std)]

/// Constant-time volatile memory wipe
#[inline(never)]
pub fn secure_zero(slice: &mut [u8]) {
    for byte in slice.iter_mut() {
        unsafe {
            core::ptr::write_volatile(byte, 0);
        }
    }
}

/// Constant-time slice equality check
pub fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (&x, &y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

// ============================================================================
// GF(2^255 - 19) Field Arithmetic & RFC 7748 X25519 Montgomery Ladder
// ============================================================================
type FieldElem = [i64; 16];

fn fe_zero() -> FieldElem {
    [0i64; 16]
}

fn fe_one() -> FieldElem {
    let mut out = [0i64; 16];
    out[0] = 1;
    out
}

fn fe_carry(elem: &mut FieldElem) {
    for i in 0..16 {
        let carry = elem[i] >> 16;
        elem[i] -= carry << 16;
        if i < 15 {
            elem[i + 1] += carry;
        } else {
            elem[0] += 38 * carry;
        }
    }
}

fn fe_add(out: &mut FieldElem, a: &FieldElem, b: &FieldElem) {
    for i in 0..16 {
        out[i] = a[i] + b[i];
    }
}

fn fe_sub(out: &mut FieldElem, a: &FieldElem, b: &FieldElem) {
    for i in 0..16 {
        out[i] = a[i] - b[i];
    }
}

fn fe_mul(out: &mut FieldElem, a: &FieldElem, b: &FieldElem) {
    let mut prod = [0i64; 31];
    for i in 0..16 {
        for j in 0..16 {
            prod[i + j] += a[i] * b[j];
        }
    }
    for i in 0..15 {
        prod[i] += 38 * prod[i + 16];
    }
    for i in 0..16 {
        out[i] = prod[i];
    }
    fe_carry(out);
    fe_carry(out);
}

fn fe_cswap(p: &mut FieldElem, q: &mut FieldElem, bit: i64) {
    let mask = !(bit - 1);
    for i in 0..16 {
        let t = mask & (p[i] ^ q[i]);
        p[i] ^= t;
        q[i] ^= t;
    }
}

fn fe_invert(out: &mut FieldElem, z: &FieldElem) {
    let mut c = *z;
    for i in (0..=253).rev() {
        let mut sq = fe_zero();
        fe_mul(&mut sq, &c, &c);
        if i != 2 && i != 4 {
            fe_mul(&mut c, &sq, z);
        } else {
            c = sq;
        }
    }
    *out = c;
}

fn fe_unpack(bytes: &[u8; 32]) -> FieldElem {
    let mut out = fe_zero();
    for i in 0..16 {
        out[i] = (bytes[2 * i] as i64) + ((bytes[2 * i + 1] as i64) << 8);
    }
    out[15] &= 0x7fff;
    out
}

fn fe_pack(out: &mut [u8; 32], n: &FieldElem) {
    let mut t = *n;
    fe_carry(&mut t);
    fe_carry(&mut t);
    fe_carry(&mut t);
    let mut m = fe_zero();
    for _ in 0..2 {
        m[0] = t[0] - 0xffed;
        for i in 1..15 {
            m[i] = t[i] - 0xffff - ((m[i - 1] >> 16) & 1);
            m[i - 1] &= 0xffff;
        }
        m[15] = t[15] - 0x7fff - ((m[14] >> 16) & 1);
        let b = (m[15] >> 16) & 1;
        m[14] &= 0xffff;
        fe_cswap(&mut t, &mut m, 1 - b);
    }
    for i in 0..16 {
        out[2 * i] = (t[i] & 0xff) as u8;
        out[2 * i + 1] = ((t[i] >> 8) & 0xff) as u8;
    }
}

/// RFC 7748 X25519 scalar multiplication
pub fn x25519_scalarmult(scalar: &[u8; 32], u_coord: &[u8; 32]) -> [u8; 32] {
    let mut clamped = *scalar;
    clamped[0] &= 248;
    clamped[31] &= 127;
    clamped[31] |= 64;

    let x1 = fe_unpack(u_coord);
    let mut a = fe_one();
    let mut b = x1;
    let mut c = fe_zero();
    let mut d = fe_one();

    let mut a121665 = fe_zero();
    a121665[0] = 0xdb41;
    a121665[1] = 1;

    for pos in (0..255).rev() {
        let bit = ((clamped[pos >> 3] >> (pos & 7)) & 1) as i64;
        fe_cswap(&mut a, &mut b, bit);
        fe_cswap(&mut c, &mut d, bit);

        let mut e = fe_zero();
        let mut f = fe_zero();
        fe_add(&mut e, &a, &c);
        fe_sub(&mut a, &a, &c);
        fe_add(&mut c, &b, &d);
        fe_sub(&mut b, &b, &d);

        fe_mul(&mut d, &e, &e);
        fe_mul(&mut f, &a, &a);
        let mut cb = fe_zero();
        let mut da = fe_zero();
        fe_mul(&mut cb, &c, &a);
        fe_mul(&mut da, &b, &e);

        fe_add(&mut e, &cb, &da);
        fe_sub(&mut a, &cb, &da);
        let mut a_sq = fe_zero();
        fe_mul(&mut a_sq, &a, &a);
        fe_sub(&mut c, &d, &f);

        let mut c121665 = fe_zero();
        fe_mul(&mut c121665, &c, &a121665);
        fe_add(&mut a, &c121665, &d);
        let mut next_c = fe_zero();
        fe_mul(&mut next_c, &c, &a);
        let mut next_a = fe_zero();
        fe_mul(&mut next_a, &d, &f);
        let mut next_d = fe_zero();
        fe_mul(&mut next_d, &a_sq, &x1);
        let mut next_b = fe_zero();
        fe_mul(&mut next_b, &e, &e);

        a = next_a;
        b = next_b;
        c = next_c;
        d = next_d;

        fe_cswap(&mut a, &mut b, bit);
        fe_cswap(&mut c, &mut d, bit);
    }

    let mut inv_c = fe_zero();
    fe_invert(&mut inv_c, &c);
    let mut prod = fe_zero();
    fe_mul(&mut prod, &a, &inv_c);
    let mut out = [0u8; 32];
    fe_pack(&mut out, &prod);
    secure_zero(&mut clamped);
    out
}

pub fn x25519_public_from_private(private_scalar: &[u8; 32]) -> [u8; 32] {
    let mut basepoint = [0u8; 32];
    basepoint[0] = 9;
    x25519_scalarmult(private_scalar, &basepoint)
}

// ============================================================================
// Pure Rust SHA-256, HMAC-SHA256 & Signal Double Ratchet KDF
// ============================================================================
const K256: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

fn sha256_compress(state: &mut [u32; 8], block: &[u8; 64]) {
    let mut w = [0u32; 64];
    for i in 0..16 {
        let j = i * 4;
        w[i] = u32::from_be_bytes([block[j], block[j + 1], block[j + 2], block[j + 3]]);
    }
    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16].wrapping_add(s0).wrapping_add(w[i - 7]).wrapping_add(s1);
    }

    let mut a = state[0];
    let mut b = state[1];
    let mut c = state[2];
    let mut d = state[3];
    let mut e = state[4];
    let mut f = state[5];
    let mut g = state[6];
    let mut h = state[7];

    for i in 0..64 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ ((!e) & g);
        let temp1 = h.wrapping_add(s1).wrapping_add(ch).wrapping_add(K256[i]).wrapping_add(w[i]);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let temp2 = s0.wrapping_add(maj);

        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(temp1);
        d = c;
        c = b;
        b = a;
        a = temp1.wrapping_add(temp2);
    }

    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

pub struct Sha256 {
    state: [u32; 8],
    buf: [u8; 64],
    len_bytes: u64,
}

impl Sha256 {
    pub fn new() -> Self {
        Self {
            state: [
                0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
            ],
            buf: [0u8; 64],
            len_bytes: 0,
        }
    }

    pub fn update(&mut self, data: &[u8]) {
        let mut idx = (self.len_bytes % 64) as usize;
        self.len_bytes += data.len() as u64;
        for &byte in data {
            self.buf[idx] = byte;
            idx += 1;
            if idx == 64 {
                let block = self.buf;
                sha256_compress(&mut self.state, &block);
                idx = 0;
            }
        }
    }

    pub fn finalize(mut self) -> [u8; 32] {
        let total_bits = self.len_bytes * 8;
        let mut idx = (self.len_bytes % 64) as usize;
        self.buf[idx] = 0x80;
        idx += 1;
        if idx > 56 {
            while idx < 64 {
                self.buf[idx] = 0;
                idx += 1;
            }
            let block = self.buf;
            sha256_compress(&mut self.state, &block);
            idx = 0;
        }
        while idx < 56 {
            self.buf[idx] = 0;
            idx += 1;
        }
        self.buf[56..64].copy_from_slice(&total_bits.to_be_bytes());
        let block = self.buf;
        sha256_compress(&mut self.state, &block);

        let mut out = [0u8; 32];
        for (i, word) in self.state.iter().enumerate() {
            out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
        }
        out
    }
}

pub fn hmac_sha256(key: &[u8], data: &[u8]) -> [u8; 32] {
    let mut k0 = [0u8; 64];
    if key.len() > 64 {
        let mut h = Sha256::new();
        h.update(key);
        k0[..32].copy_from_slice(&h.finalize());
    } else {
        k0[..key.len()].copy_from_slice(key);
    }

    let mut ipad = [0x36u8; 64];
    let mut opad = [0x5cu8; 64];
    for i in 0..64 {
        ipad[i] ^= k0[i];
        opad[i] ^= k0[i];
    }

    let mut inner = Sha256::new();
    inner.update(&ipad);
    inner.update(data);
    let inner_digest = inner.finalize();

    let mut outer = Sha256::new();
    outer.update(&opad);
    outer.update(&inner_digest);
    let out = outer.finalize();

    secure_zero(&mut k0);
    secure_zero(&mut ipad);
    secure_zero(&mut opad);
    out
}

/// Signal Double Ratchet Symmetric Chain Step: returns `(next_chain_key, message_key)`
pub fn signal_kdf_ck(chain_key: &[u8; 32]) -> ([u8; 32], [u8; 32]) {
    let mk = hmac_sha256(chain_key, &[0x01]);
    let next_ck = hmac_sha256(chain_key, &[0x02]);
    (next_ck, mk)
}

/// Signal Double Ratchet Root Key Step (HKDF-SHA256): returns `(new_root_key, new_chain_key)`
pub fn signal_kdf_rk(root_key: &[u8; 32], dh_out: &[u8; 32]) -> ([u8; 32], [u8; 32]) {
    let prk = hmac_sha256(root_key, dh_out);
    let info = b"SplenderSignalRatchetV3";
    let mut t1_in = [0u8; 24];
    t1_in[..23].copy_from_slice(info);
    t1_in[23] = 1;
    let t1 = hmac_sha256(&prk, &t1_in);

    let mut t2_in = [0u8; 56];
    t2_in[..32].copy_from_slice(&t1);
    t2_in[32..55].copy_from_slice(info);
    t2_in[55] = 2;
    let t2 = hmac_sha256(&prk, &t2_in);
    (t1, t2)
}

// ============================================================================
// C-ABI FFI Exports
// ============================================================================
#[no_mangle]
pub extern "C" fn splender_rust_core_version() -> u32 {
    0x0002_0000 // v0.2.0
}

#[no_mangle]
pub unsafe extern "C" fn splender_rust_x25519(
    scalar_ptr: *const u8,
    point_ptr: *const u8,
    out_shared_ptr: *mut u8,
) {
    if scalar_ptr.is_null() || point_ptr.is_null() || out_shared_ptr.is_null() {
        return;
    }
    let mut scalar = [0u8; 32];
    let mut point = [0u8; 32];
    core::ptr::copy_nonoverlapping(scalar_ptr, scalar.as_mut_ptr(), 32);
    core::ptr::copy_nonoverlapping(point_ptr, point.as_mut_ptr(), 32);

    let shared = x25519_scalarmult(&scalar, &point);
    core::ptr::copy_nonoverlapping(shared.as_ptr(), out_shared_ptr, 32);
    secure_zero(&mut scalar);
}

#[no_mangle]
pub unsafe extern "C" fn splender_rust_kdf_rk(
    root_key_ptr: *const u8,
    dh_out_ptr: *const u8,
    out_new_rk_ptr: *mut u8,
    out_new_ck_ptr: *mut u8,
) {
    if root_key_ptr.is_null()
        || dh_out_ptr.is_null()
        || out_new_rk_ptr.is_null()
        || out_new_ck_ptr.is_null()
    {
        return;
    }
    let mut rk = [0u8; 32];
    let mut dh = [0u8; 32];
    core::ptr::copy_nonoverlapping(root_key_ptr, rk.as_mut_ptr(), 32);
    core::ptr::copy_nonoverlapping(dh_out_ptr, dh.as_mut_ptr(), 32);

    let (new_rk, new_ck) = signal_kdf_rk(&rk, &dh);
    core::ptr::copy_nonoverlapping(new_rk.as_ptr(), out_new_rk_ptr, 32);
    core::ptr::copy_nonoverlapping(new_ck.as_ptr(), out_new_ck_ptr, 32);
    secure_zero(&mut rk);
    secure_zero(&mut dh);
}

#[no_mangle]
pub unsafe extern "C" fn splender_rust_kdf_ck(
    chain_key_ptr: *const u8,
    out_next_ck_ptr: *mut u8,
    out_msg_key_ptr: *mut u8,
) {
    if chain_key_ptr.is_null() || out_next_ck_ptr.is_null() || out_msg_key_ptr.is_null() {
        return;
    }
    let mut ck = [0u8; 32];
    core::ptr::copy_nonoverlapping(chain_key_ptr, ck.as_mut_ptr(), 32);

    let (next_ck, mk) = signal_kdf_ck(&ck);
    core::ptr::copy_nonoverlapping(next_ck.as_ptr(), out_next_ck_ptr, 32);
    core::ptr::copy_nonoverlapping(mk.as_ptr(), out_msg_key_ptr, 32);
    secure_zero(&mut ck);
}

#[cfg(not(test))]
#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rfc7748_x25519_dh_agreement() {
        let alice_priv = [7u8; 32];
        let bob_priv = [42u8; 32];
        let alice_pub = x25519_public_from_private(&alice_priv);
        let bob_pub = x25519_public_from_private(&bob_priv);
        let s1 = x25519_scalarmult(&alice_priv, &bob_pub);
        let s2 = x25519_scalarmult(&bob_priv, &alice_pub);
        assert!(constant_time_eq(&s1, &s2));
    }

    #[test]
    fn test_signal_ratchet_forward_secrecy() {
        let rk = [0x11u8; 32];
        let dh = [0x22u8; 32];
        let (rk2, ck1) = signal_kdf_rk(&rk, &dh);
        let (ck2, mk1) = signal_kdf_ck(&ck1);
        assert!(!constant_time_eq(&rk, &rk2));
        assert!(!constant_time_eq(&ck1, &ck2));
        assert!(!constant_time_eq(&ck2, &mk1));
    }
}
