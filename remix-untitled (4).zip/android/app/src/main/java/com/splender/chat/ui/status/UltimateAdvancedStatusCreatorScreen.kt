package com.splender.chat.ui.status

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.math.min
import kotlin.math.roundToInt

private const val TWENTY_FOUR_HOURS_MS: Long = 24L * 60L * 60L * 1000L
private const val MAX_STATUS_TEXT_CHARS: Int = 700

/**
 * Safe extension for [TextAlign] (`@JvmInline value class` in Compose UI Text),
 * providing deterministic human-readable labels for `${textAlignment.name}` across API 24–37.
 */
private val TextAlign.name: String
    get() = when (this) {
        TextAlign.Left -> "Left"
        TextAlign.Right -> "Right"
        TextAlign.Center -> "Center"
        TextAlign.Justify -> "Justify"
        TextAlign.Start -> "Start"
        TextAlign.End -> "End"
        else -> "Center"
    }

private val STATUS_COLOR_PALETTE: List<Color> = listOf(
    Color(0xFF0F9D58), // Sovereign Emerald (Default)
    Color(0xFF1E1B4B), // Cosmic Indigo
    Color(0xFF4C1D95), // Electric Violet
    Color(0xFF0E7490), // Nebula Cyan
    Color(0xFF1D4ED8), // Aurora Royal Blue
    Color(0xFFBE185D), // Magenta Nebula
    Color(0xFFC2410C), // Solar Amber
    Color(0xFF080B14)  // Obsidian Night
)

private val STATUS_PATTERNS: List<String> = listOf("None", "Grid", "Rings", "Dots")

data class StatusPayload(
    val text: String,
    val color: Color,
    val font: FontFamily,
    val offsetX: Float,
    val offsetY: Float,
    val scale: Float,
    val rotation: Float,
    val opacity: Float = 1f,
    val textAlign: TextAlign = TextAlign.Center,
    val pattern: String = "None",
    val isGradientMeshActive: Boolean = false,
    val expiresAtEpochMs: Long = System.currentTimeMillis() + TWENTY_FOUR_HOURS_MS
) {
    fun toJsonObject(): JSONObject {
        val argb = color.toArgb()
        val hexColor = String.format("#%06X", 0xFFFFFF and argb)
        val fontKey = when (font) {
            FontFamily.Monospace -> "mono"
            FontFamily.Serif -> "serif"
            else -> "sans"
        }
        val alignKey = when (textAlign) {
            TextAlign.Left, TextAlign.Start -> "left"
            TextAlign.Right, TextAlign.End -> "right"
            else -> "center"
        }
        return JSONObject().apply {
            put("text", text)
            put("bgColor", hexColor)
            put("fontFamily", fontKey)
            put("textAlign", alignKey)
            put("offsetX", offsetX.toDouble())
            put("offsetY", offsetY.toDouble())
            put("scale", scale.toDouble())
            put("rotation", rotation.toDouble())
            put("opacity", opacity.toDouble())
            put("pattern", pattern)
            put("isGradientMeshActive", isGradientMeshActive)
            put("expiresAtEpochMs", expiresAtEpochMs)
        }
    }
}

@Composable
fun UltimateAdvancedStatusCreatorScreen(
    onPostStatus: (StatusPayload) -> Unit,
    modifier: Modifier = Modifier,
    onDismiss: (() -> Unit)? = null
) {
    // 1. Styling States (Saveable across Single-Window rotation / foldable posture changes)
    var statusText by rememberSaveable { mutableStateOf("") }
    var fontIndex by rememberSaveable { mutableIntStateOf(0) } // 0 = SansSerif, 1 = Monospace, 2 = Serif
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var colorOpacity by rememberSaveable { mutableFloatStateOf(1f) }
    var alignIndex by rememberSaveable { mutableIntStateOf(0) } // 0 = Center, 1 = Left, 2 = Right
    var patternIndex by rememberSaveable { mutableIntStateOf(0) }
    var isGradientMeshActive by rememberSaveable { mutableStateOf(false) }

    val selectedFont: FontFamily = remember(fontIndex) {
        when (fontIndex) {
            1 -> FontFamily.Monospace
            2 -> FontFamily.Serif
            else -> FontFamily.SansSerif
        }
    }
    val selectedFontLabel: String = when (fontIndex) {
        1 -> "Mono"
        2 -> "Serif"
        else -> "Sans"
    }
    val selectedColor: Color = STATUS_COLOR_PALETTE[colorIndex.coerceIn(0, STATUS_COLOR_PALETTE.lastIndex)]
    val textAlignment: TextAlign = when (alignIndex) {
        1 -> TextAlign.Left
        2 -> TextAlign.Right
        else -> TextAlign.Center
    }
    val selectedPattern: String = STATUS_PATTERNS[patternIndex.coerceIn(0, STATUS_PATTERNS.lastIndex)]

    // 2. Interactive Gesture States (Drag, Pinch-Zoom, Two-Finger Rotate)
    var offsetX by rememberSaveable { mutableFloatStateOf(0f) }
    var offsetY by rememberSaveable { mutableFloatStateOf(0f) }
    var scale by rememberSaveable { mutableFloatStateOf(1f) }
    var rotation by rememberSaveable { mutableFloatStateOf(0f) }

    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(),
        label = "status_text_scale"
    )

    val transformableState = rememberTransformableState { zoomChange, offsetChange, rotationChange ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3.0f)
        rotation = (rotation + rotationChange) % 360f
        offsetX = (offsetX + offsetChange.x).coerceIn(-600f, 600f)
        offsetY = (offsetY + offsetChange.y).coerceIn(-900f, 900f)
    }

    val isTransformed = offsetX != 0f || offsetY != 0f || scale != 1f || rotation != 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF080B14))
            .background(
                brush = if (isGradientMeshActive) {
                    Brush.sweepGradient(
                        listOf(
                            selectedColor.copy(alpha = colorOpacity),
                            Color.Magenta.copy(alpha = colorOpacity),
                            Color.Cyan.copy(alpha = colorOpacity),
                            selectedColor.copy(alpha = colorOpacity)
                        )
                    )
                } else {
                    SolidColor(selectedColor.copy(alpha = colorOpacity))
                }
            )
            .systemBarsPadding()
            .imePadding()
            .padding(16.dp)
    ) {
        // Optional Geometric Backdrop Pattern Layer
        if (selectedPattern != "None") {
            StatusBackdropPatternCanvas(
                pattern = selectedPattern,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Interactive Canvas Layer for Draggable, Scalable, Rotatable Status Text
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .graphicsLayer(
                    scaleX = animatedScale,
                    scaleY = animatedScale,
                    rotationZ = rotation
                )
                .transformable(state = transformableState)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(-600f, 600f)
                        offsetY = (offsetY + dragAmount.y).coerceIn(-900f, 900f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            OutlinedTextField(
                value = statusText,
                onValueChange = { next ->
                    if (next.length <= MAX_STATUS_TEXT_CHARS) {
                        statusText = next
                    }
                },
                placeholder = {
                    Text(
                        text = "Type a futuristic status...",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = textAlignment,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                textStyle = LocalTextStyle.current.copy(
                    fontFamily = selectedFont,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = textAlignment,
                    color = Color.White,
                    fontSize = 24.sp
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    cursorColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth(0.85f)
            )
        }

        // Overlay UI Controls (Top Bar & Bottom Controls)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Toolbar: Dismiss, Font selector, Alignment & Pattern
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onDismiss != null) {
                        OutlinedButton(
                            onClick = onDismiss,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("Close")
                        }
                    }

                    Button(
                        onClick = { fontIndex = (fontIndex + 1) % 3 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Black.copy(alpha = 0.38f),
                            contentColor = Color.White
                        )
                    ) {
                        Text("Font: $selectedFontLabel")
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { patternIndex = (patternIndex + 1) % STATUS_PATTERNS.size },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Black.copy(alpha = 0.38f),
                            contentColor = Color.White
                        )
                    ) {
                        Text("Pattern: $selectedPattern")
                    }

                    // Alignment toggle
                    Button(
                        onClick = { alignIndex = (alignIndex + 1) % 3 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Black.copy(alpha = 0.38f),
                            contentColor = Color.White
                        )
                    ) {
                        Text("Align: ${textAlignment.name}")
                    }
                }
            }

            // Bottom Controls: Colors, Opacity, Gradient Toggle & Post Button
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isTransformed) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Scale ${"%.1f".format(scale)}x · ${rotation.roundToInt()}°",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        OutlinedButton(
                            onClick = {
                                offsetX = 0f
                                offsetY = 0f
                                scale = 1f
                                rotation = 0f
                            },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("Reset Transform", fontSize = 12.sp)
                        }
                    }
                }

                // Color Swatches Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    STATUS_COLOR_PALETTE.forEachIndexed { idx, swatch ->
                        val isSelected = idx == colorIndex
                        Box(
                            modifier = Modifier
                                .size(if (isSelected) 34.dp else 28.dp)
                                .clip(CircleShape)
                                .background(swatch)
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.45f),
                                    shape = CircleShape
                                )
                                .clickable { colorIndex = idx }
                        )
                    }
                }

                // Opacity Slider
                Slider(
                    value = colorOpacity,
                    onValueChange = { colorOpacity = it },
                    valueRange = 0.2f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    )
                )

                // Gradient Mesh Toggle Button
                Button(
                    onClick = { isGradientMeshActive = !isGradientMeshActive },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black.copy(alpha = 0.42f),
                        contentColor = Color.White
                    )
                ) {
                    Text(if (isGradientMeshActive) "Disable Gradient Mesh" else "Enable Gradient Mesh")
                }

                // Post Button
                Button(
                    onClick = {
                        val trimmed = statusText.trim()
                        if (trimmed.isNotEmpty()) {
                            onPostStatus(
                                StatusPayload(
                                    text = trimmed,
                                    color = selectedColor,
                                    font = selectedFont,
                                    offsetX = offsetX,
                                    offsetY = offsetY,
                                    scale = scale,
                                    rotation = rotation,
                                    opacity = colorOpacity,
                                    textAlign = textAlignment,
                                    pattern = selectedPattern,
                                    isGradientMeshActive = isGradientMeshActive,
                                    expiresAtEpochMs = System.currentTimeMillis() + TWENTY_FOUR_HOURS_MS
                                )
                            )
                        }
                    },
                    enabled = statusText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black,
                        contentColor = Color.White,
                        disabledContainerColor = Color.Black.copy(alpha = 0.45f),
                        disabledContentColor = Color.White.copy(alpha = 0.5f)
                    )
                ) {
                    Text("Post Status (24 Hours Live)", color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun StatusBackdropPatternCanvas(
    pattern: String,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val strokeColor = Color.White.copy(alpha = 0.10f)
        when (pattern) {
            "Grid" -> {
                val step = 48.dp.toPx()
                var x = 0f
                while (x <= size.width) {
                    drawLine(strokeColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y <= size.height) {
                    drawLine(strokeColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }
            }
            "Rings" -> {
                val maxRadius = min(size.width, size.height) * 0.65f
                val ringCount = 5
                for (i in 1..ringCount) {
                    drawCircle(
                        color = strokeColor,
                        radius = (maxRadius / ringCount) * i,
                        center = center,
                        style = Stroke(width = 1.4f)
                    )
                }
            }
            "Dots" -> {
                val step = 36.dp.toPx()
                var x = step / 2f
                while (x < size.width) {
                    var y = step / 2f
                    while (y < size.height) {
                        drawCircle(color = strokeColor, radius = 2.2f, center = Offset(x, y))
                        y += step
                    }
                    x += step
                }
            }
        }
    }
}
