package com.splender.chat

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ProcessLifecycleOwner
import com.getcapacitor.BridgeActivity
import com.splender.chat.core.SplenderApplication
import com.splender.chat.lifecycle.SplenderAudioLifecycleGuard
import com.splender.chat.plugins.BiometricPlugin
import com.splender.chat.plugins.MediaCompressionPlugin
import com.splender.chat.plugins.SplenderNativePlugin
import com.splender.chat.security.BiometricManager
import com.splender.chat.service.SplenderNotificationHelper
import com.splender.chat.ui.navigation.SingleWindowComposeBridge
import com.splender.chat.ui.navigation.SingleWindowRouterViewModel
import com.splender.chat.ui.navigation.SplenderSection
import com.splender.chat.work.SplenderOutboxWorker
import org.json.JSONObject

/**
 * MainActivity (Android 17 / API 37 Single-Window Host Activity)
 *
 * Serves as the sole `singleTask` host window for all application sections:
 * `Home`, `Chats`, `Camera`, `Shorts`, and `World`.
 * - Preserves Compose + WebView state seamlessly across tab switches and configuration changes
 *   via `SingleWindowRouterViewModel` (`SavedStateHandle`) and `SaveableStateHolder`.
 * - Enforces Android 17 edge-to-edge display, predictive back navigation, and Zero-Trust
 *   snapshot / screen-recording shields (`FLAG_SECURE` + `ZeroTrustLifecycleLockManager`).
 */
class MainActivity : BridgeActivity() {

    val windowRouterViewModel: SingleWindowRouterViewModel by viewModels()

    private var audioLifecycleGuard: SplenderAudioLifecycleGuard? = null
    private var biometricManager: BiometricManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // 1. Install Android 12–17 SplashScreen & Edge-to-Edge window insets before super.onCreate
        installSplashScreen()
        enableEdgeToEdge()

        // 2. Register hybrid C++/Rust/Keystore, BiometricPrompt, and MediaCompression Capacitor plugins
        registerPlugin(SplenderNativePlugin::class.java)
        registerPlugin(BiometricPlugin::class.java)
        registerPlugin(MediaCompressionPlugin::class.java)

        super.onCreate(savedInstanceState)

        // 3. Provision VISIBILITY_PRIVATE Android 8–17 notification channels
        SplenderNotificationHelper.ensureChannels(this)

        // 4. Enforce Zero-Trust FLAG_SECURE & Recents snapshot redaction on the single host window
        val app = application as? SplenderApplication
        app?.zeroTrustLockManager?.setFlagSecurePolicy(this, enabled = true)

        // 5. Enforce Android 17 background-audio focus release when no call ForegroundService is active
        val audioGuard = SplenderAudioLifecycleGuard(this)
        audioLifecycleGuard = audioGuard
        ProcessLifecycleOwner.get().lifecycle.addObserver(audioGuard)

        // 6. Attach BiometricManager session lock observer for background -> foreground transitions
        val bioMgr = BiometricManager.getInstance(this)
        biometricManager = bioMgr
        bioMgr.attachHostActivity(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(bioMgr)

        // 7. Mount Jetpack Compose Single-Window State Router & Zero-Trust Privacy Curtain overlay
        val rootContent = findViewById<ViewGroup>(android.R.id.content)
        if (rootContent != null && app != null) {
            val composeOverlay = SingleWindowComposeBridge.createSingleWindowOverlay(
                context = this,
                routerViewModel = windowRouterViewModel,
                zeroTrustStateFlow = app.zeroTrustLockManager.lockState,
                oledMode = false,
                webViewProvider = { bridge?.webView },
                onAcknowledgeCaptureWarning = {
                    app.zeroTrustLockManager.acknowledgeCaptureWarning()
                }
            )
            val params = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.TOP
            )
            rootContent.addView(composeOverlay, params)
        }

        // 8. Register Android 14–17 Predictive Back dispatcher inside the single window
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val consumedInWindow = windowRouterViewModel.navigateBackWithinWindow()
                    if (consumedInWindow) {
                        windowRouterViewModel.syncToWebView(bridge?.webView)
                    } else {
                        moveTaskToBack(true)
                    }
                }
            }
        )

        // 9. Schedule quota-safe WorkManager encrypted outbox verification & handle launch deep-links
        SplenderOutboxWorker.enqueueExpeditedOrStandard(this)
        dispatchWindowIntentIfPresent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        dispatchWindowIntentIfPresent(intent)
    }

    private fun dispatchWindowIntentIfPresent(intent: Intent?) {
        if (intent == null) return

        // Route optional single-window tab intent without reloading window
        val requestedTab = intent.getStringExtra(EXTRA_WINDOW_TAB)
        if (!requestedTab.isNullOrBlank()) {
            intent.removeExtra(EXTRA_WINDOW_TAB)
            windowRouterViewModel.selectSection(SplenderSection.fromRoute(requestedTab))
        }

        val convId = intent.getStringExtra(SplenderNotificationHelper.EXTRA_CONVERSATION_ID)
        if (convId.isNullOrBlank()) return
        intent.removeExtra(SplenderNotificationHelper.EXTRA_CONVERSATION_ID)

        val trimmedConvId = convId.trim()
        windowRouterViewModel.selectSection(SplenderSection.CHATS, conversationId = trimmedConvId)

        val webView = bridge?.webView ?: return
        val safeQuoted = JSONObject.quote(trimmedConvId)
        webView.post {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('splender:navigate-conversation',{detail:{conversationId:$safeQuoted}}));",
                null
            )
        }
    }

    override fun onDestroy() {
        audioLifecycleGuard?.let {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(it)
        }
        biometricManager?.let {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(it)
            it.attachHostActivity(null)
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_WINDOW_TAB = "splender_window_tab"
    }
}
