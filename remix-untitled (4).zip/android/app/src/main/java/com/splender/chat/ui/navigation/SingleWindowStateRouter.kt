package com.splender.chat.ui.navigation

import android.content.Context
import android.webkit.WebView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.splender.chat.security.ZeroTrustLockState
import com.splender.chat.ui.SplenderSecurityStatusBanner
import com.splender.chat.ui.status.StatusPayload
import com.splender.chat.ui.status.UltimateAdvancedStatusCreatorScreen
import com.splender.chat.ui.theme.SplenderMaterial3Theme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

/**
 * SplenderSection
 * Enumerates all 5 primary application tabs hosted inside the Single-Window (`MainActivity`)
 * architecture without ever tearing down or reloading the window.
 */
enum class SplenderSection(val route: String, val label: String) {
    HOME("home", "Home"),
    CHATS("chats", "Chats"),
    CAMERA("camera", "Camera"),
    SHORTS("shorts", "Shorts"),
    WORLD("world", "World");

    companion object {
        fun fromRoute(route: String?): SplenderSection {
            if (route.isNullOrBlank()) return CHATS
            return entries.firstOrNull { it.route.equals(route.trim(), ignoreCase = true) } ?: CHATS
        }
    }
}

/**
 * SectionSavedViewport
 * Per-tab retained state preserved across tab switches, configuration changes, and process recreation.
 */
data class SectionSavedViewport(
    val scrollOffsetPx: Int = 0,
    val selectedConversationId: String? = null,
    val draftFilterQuery: String = "",
    val activeFeedCursor: Int = 0,
    val cameraFrontLens: Boolean = false
)

data class SingleWindowUiState(
    val activeSection: SplenderSection = SplenderSection.CHATS,
    val backStack: List<SplenderSection> = listOf(SplenderSection.HOME, SplenderSection.CHATS),
    val sectionViewports: Map<SplenderSection, SectionSavedViewport> =
        SplenderSection.entries.associateWith { SectionSavedViewport() },
    val isStatusCreatorOpen: Boolean = false,
    val transitionEpoch: Long = 0L
)

/**
 * SingleWindowRouterViewModel
 *
 * Stateful Single-Window navigation engine backed by `SavedStateHandle`:
 * - Switches seamlessly between `Home`, `Chats`, `Camera`, `Shorts`, and `World` inside one window.
 * - Hosts modal Jetpack Compose overlays such as `UltimateAdvancedStatusCreatorScreen` without tearing down tabs.
 * - Retains scroll offsets, active conversation IDs, camera lens state, and shorts feed cursors
 *   across configuration changes (rotation, foldable posture, multi-window resize) and process death.
 * - Bridges tab changes and native status posts to the live Capacitor WebView via CustomEvents
 *   without triggering any `WebView.reload()` or Activity recreation.
 */
class SingleWindowRouterViewModel(
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val initialSection = SplenderSection.fromRoute(
        savedStateHandle.get<String>(KEY_ACTIVE_SECTION) ?: SplenderSection.CHATS.route
    )

    private val _uiState = MutableStateFlow(
        SingleWindowUiState(
            activeSection = initialSection,
            backStack = restoreBackStack(savedStateHandle, initialSection),
            sectionViewports = restoreViewports(savedStateHandle),
            isStatusCreatorOpen = savedStateHandle.get<Boolean>(KEY_STATUS_CREATOR_OPEN) ?: false
        )
    )
    val uiState: StateFlow<SingleWindowUiState> = _uiState.asStateFlow()

    fun selectSection(
        target: SplenderSection,
        conversationId: String? = null
    ) {
        _uiState.update { current ->
            val updatedStack = current.backStack
                .filterNot { it == target }
                .plus(target)
                .takeLast(SplenderSection.entries.size)

            val updatedViewports = if (!conversationId.isNullOrBlank()) {
                val existing = current.sectionViewports[target] ?: SectionSavedViewport()
                current.sectionViewports + (target to existing.copy(selectedConversationId = conversationId))
            } else {
                current.sectionViewports
            }

            persistState(target, updatedStack, updatedViewports, isStatusCreatorOpen = false)

            current.copy(
                activeSection = target,
                backStack = updatedStack,
                sectionViewports = updatedViewports,
                isStatusCreatorOpen = false,
                transitionEpoch = current.transitionEpoch + 1L
            )
        }
    }

    fun openStatusCreator() {
        savedStateHandle[KEY_STATUS_CREATOR_OPEN] = true
        _uiState.update { current ->
            current.copy(
                isStatusCreatorOpen = true,
                transitionEpoch = current.transitionEpoch + 1L
            )
        }
    }

    fun closeStatusCreator() {
        savedStateHandle[KEY_STATUS_CREATOR_OPEN] = false
        _uiState.update { current ->
            current.copy(
                isStatusCreatorOpen = false,
                transitionEpoch = current.transitionEpoch + 1L
            )
        }
    }

    fun publishNativeStatusToWebView(webView: WebView?, payload: StatusPayload) {
        closeStatusCreator()
        if (webView == null) return
        val json = payload.toJsonObject().toString()
        webView.post {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('splender:native-status-posted',{detail:$json}));",
                null
            )
        }
    }

    fun updateSectionViewport(
        section: SplenderSection,
        transform: (SectionSavedViewport) -> SectionSavedViewport
    ) {
        _uiState.update { current ->
            val existing = current.sectionViewports[section] ?: SectionSavedViewport()
            val updatedMap = current.sectionViewports + (section to transform(existing))
            persistState(current.activeSection, current.backStack, updatedMap, current.isStatusCreatorOpen)
            current.copy(sectionViewports = updatedMap)
        }
    }

    /**
     * Handles Android 14–17 predictive back navigation inside the single window.
     * Dismisses transient Compose overlays (e.g. Status Creator) first, then pops section back-stack.
     */
    fun navigateBackWithinWindow(): Boolean {
        val snapshot = _uiState.value
        if (snapshot.isStatusCreatorOpen) {
            closeStatusCreator()
            return true
        }

        if (snapshot.backStack.size <= 1) {
            if (snapshot.activeSection != SplenderSection.HOME) {
                selectSection(SplenderSection.HOME)
                return true
            }
            return false
        }

        val poppedStack = snapshot.backStack.dropLast(1)
        val previousSection = poppedStack.last()
        persistState(previousSection, poppedStack, snapshot.sectionViewports, isStatusCreatorOpen = false)

        _uiState.update {
            it.copy(
                activeSection = previousSection,
                backStack = poppedStack,
                isStatusCreatorOpen = false,
                transitionEpoch = it.transitionEpoch + 1L
            )
        }
        return true
    }

    fun syncToWebView(webView: WebView?) {
        if (webView == null) return
        val state = _uiState.value
        val active = state.activeSection
        val viewport = state.sectionViewports[active] ?: SectionSavedViewport()
        val payload = JSONObject().apply {
            put("tab", active.route)
            put("label", active.label)
            put("scrollOffsetPx", viewport.scrollOffsetPx)
            put("conversationId", viewport.selectedConversationId ?: JSONObject.NULL)
            put("isStatusCreatorOpen", state.isStatusCreatorOpen)
            put("epoch", state.transitionEpoch)
        }.toString()

        webView.post {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('splender:single-window-tab',{detail:$payload}));",
                null
            )
        }
    }

    private fun persistState(
        active: SplenderSection,
        stack: List<SplenderSection>,
        viewports: Map<SplenderSection, SectionSavedViewport>,
        isStatusCreatorOpen: Boolean
    ) {
        savedStateHandle[KEY_ACTIVE_SECTION] = active.route
        savedStateHandle[KEY_BACK_STACK] = ArrayList(stack.map { it.route })
        savedStateHandle[KEY_STATUS_CREATOR_OPEN] = isStatusCreatorOpen
        viewports.forEach { (section, vp) ->
            savedStateHandle["vp_scroll_${section.route}"] = vp.scrollOffsetPx
            savedStateHandle["vp_conv_${section.route}"] = vp.selectedConversationId
            savedStateHandle["vp_query_${section.route}"] = vp.draftFilterQuery
            savedStateHandle["vp_cursor_${section.route}"] = vp.activeFeedCursor
            savedStateHandle["vp_cam_${section.route}"] = vp.cameraFrontLens
        }
    }

    companion object {
        private const val KEY_ACTIVE_SECTION = "splender_active_section_v17"
        private const val KEY_BACK_STACK = "splender_back_stack_v17"
        private const val KEY_STATUS_CREATOR_OPEN = "splender_status_creator_open_v17"

        private fun restoreBackStack(
            handle: SavedStateHandle,
            fallbackActive: SplenderSection
        ): List<SplenderSection> {
            val raw = handle.get<ArrayList<String>>(KEY_BACK_STACK)
            if (raw.isNullOrEmpty()) {
                return listOf(SplenderSection.HOME, fallbackActive).distinct()
            }
            return raw.map { SplenderSection.fromRoute(it) }.distinct()
        }

        private fun restoreViewports(
            handle: SavedStateHandle
        ): Map<SplenderSection, SectionSavedViewport> {
            return SplenderSection.entries.associateWith { section ->
                SectionSavedViewport(
                    scrollOffsetPx = handle.get<Int>("vp_scroll_${section.route}") ?: 0,
                    selectedConversationId = handle.get<String>("vp_conv_${section.route}"),
                    draftFilterQuery = handle.get<String>("vp_query_${section.route}") ?: "",
                    activeFeedCursor = handle.get<Int>("vp_cursor_${section.route}") ?: 0,
                    cameraFrontLens = handle.get<Boolean>("vp_cam_${section.route}") ?: false
                )
            }
        }
    }
}

/**
 * SplenderSingleWindowComposeHost
 *
 * Hosts the retained Jetpack Compose state slots (`SaveableStateHolder`) for all 5 tabs
 * (`Home`, `Chats`, `Camera`, `Shorts`, `World`), the `UltimateAdvancedStatusCreatorScreen`
 * interactive gesture studio, and the Zero-Trust Privacy Curtain that shields the single window
 * whenever backgrounded or targeted by screen capture/recording.
 */
@Composable
fun SplenderSingleWindowComposeHost(
    routerViewModel: SingleWindowRouterViewModel,
    zeroTrustStateFlow: StateFlow<ZeroTrustLockState>,
    oledMode: Boolean = false,
    webViewProvider: () -> WebView? = { null },
    onAcknowledgeCaptureWarning: () -> Unit = {}
) {
    val windowState by routerViewModel.uiState.collectAsStateWithLifecycle()
    val lockState by zeroTrustStateFlow.collectAsStateWithLifecycle()
    val saveableStateHolder = rememberSaveableStateHolder()

    LaunchedEffect(windowState.activeSection, windowState.transitionEpoch) {
        routerViewModel.syncToWebView(webViewProvider())
    }

    SplenderMaterial3Theme(oledMode = oledMode) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Retained per-tab state slots: each section keeps its Compose SaveableState across switches
            Crossfade(
                targetState = windowState.activeSection,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "splender_single_window_tab_crossfade"
            ) { section ->
                saveableStateHolder.SaveableStateProvider(key = section.route) {
                    // Transparent single-window HUD slot coexisting cleanly above the live P2P surface
                    Box(modifier = Modifier.fillMaxSize()) {
                        SplenderSecurityStatusBanner(oledMode = oledMode, initiallyVisible = false)
                    }
                }
            }

            // Native Jetpack Compose Ultimate Advanced Status Creator Overlay (Single-Window retained)
            AnimatedVisibility(
                visible = windowState.isStatusCreatorOpen,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                saveableStateHolder.SaveableStateProvider(key = "splender_status_creator_v17") {
                    UltimateAdvancedStatusCreatorScreen(
                        onPostStatus = { statusPayload ->
                            routerViewModel.publishNativeStatusToWebView(webViewProvider(), statusPayload)
                        },
                        onDismiss = {
                            routerViewModel.closeStatusCreator()
                        }
                    )
                }
            }

            // Zero-Trust Snapshot & Screen-Recording Privacy Curtain (API 33–37)
            AnimatedVisibility(
                visible = lockState.isPrivacyCurtainEngaged,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        ),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Splender Zero-Trust Shield Active",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when {
                                lockState.isScreenRecordingActive ->
                                    "Screen recording or display mirroring detected. End recording to view encrypted P2P conversations."
                                lockState.isScreenCaptureDetected ->
                                    "Screen capture blocked to protect end-to-end encrypted messages."
                                else ->
                                    "Window protected while in background."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        if (lockState.isScreenCaptureDetected && !lockState.isScreenRecordingActive) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onAcknowledgeCaptureWarning,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(text = "Resume Secure Session")
                            }
                        }
                    }
                }
            }
        }
    }
}

object SingleWindowComposeBridge {
    @JvmStatic
    fun createSingleWindowOverlay(
        context: Context,
        routerViewModel: SingleWindowRouterViewModel,
        zeroTrustStateFlow: StateFlow<ZeroTrustLockState>,
        oledMode: Boolean,
        webViewProvider: () -> WebView?,
        onAcknowledgeCaptureWarning: () -> Unit
    ): ComposeView {
        return ComposeView(context).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                SplenderSingleWindowComposeHost(
                    routerViewModel = routerViewModel,
                    zeroTrustStateFlow = zeroTrustStateFlow,
                    oledMode = oledMode,
                    webViewProvider = webViewProvider,
                    onAcknowledgeCaptureWarning = onAcknowledgeCaptureWarning
                )
            }
        }
    }
}
