package com.splender.chat.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.splender.chat.work.SplenderOutboxWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * SplenderSyncService (Android 17 / API 37 Sealed Outbox DataSync Service)
 *
 * - Runs short-lived foreground flush bursts on `Dispatchers.IO` for encrypted offline outbox
 *   envelopes and P2P chunk resume checkpoints when initiated from a user-visible state.
 * - Implements Android 15–17 mandatory `onTimeout(startId, fgsType)` for `dataSync` services and
 *   cleanly hands off remaining retries to `SplenderOutboxWorker` (`WorkManager`).
 */
class SplenderSyncService : Service() {

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        SplenderNotificationHelper.ensureChannels(this)
        val notification = NotificationCompat.Builder(this, SplenderNotificationHelper.CHANNEL_OUTBOX_SYNC)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle("Splender Chat")
            .setContentText("Syncing encrypted outbox…")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setOngoing(true)
            .build()

        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
            0
        }

        val enteredForeground = try {
            ServiceCompat.startForeground(this, SYNC_NOTIFICATION_ID, notification, fgsType)
            true
        } catch (t: Throwable) {
            Log.w(TAG, "DataSync ForegroundService deferred to WorkManager: ${t.message}")
            SplenderOutboxWorker.enqueueExpeditedOrStandard(applicationContext)
            stopSelf(startId)
            false
        }

        if (enteredForeground) {
            syncScope.launch {
                try {
                    SplenderOutboxWorker.enqueueExpeditedOrStandard(applicationContext)
                } catch (t: Throwable) {
                    Log.e(TAG, "Encrypted outbox scheduling failed", t)
                } finally {
                    ServiceCompat.stopForeground(
                        this@SplenderSyncService,
                        ServiceCompat.STOP_FOREGROUND_REMOVE
                    )
                    stopSelf(startId)
                }
            }
        }

        return START_NOT_STICKY
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        Log.w(TAG, "DataSync ForegroundService reached OS time quota (type=$fgsType); handing off to WorkManager.")
        SplenderOutboxWorker.enqueueExpeditedOrStandard(applicationContext)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        syncScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SplenderSyncService"
        private const val SYNC_NOTIFICATION_ID = 17002

        @JvmStatic
        fun startFlushBurst(context: Context) {
            val appCtx = context.applicationContext
            val intent = Intent(appCtx, SplenderSyncService::class.java)
            try {
                ContextCompat.startForegroundService(appCtx, intent)
            } catch (t: Throwable) {
                Log.w(TAG, "Foreground DataSync start restricted; falling back to WorkManager: ${t.message}")
                SplenderOutboxWorker.enqueueExpeditedOrStandard(appCtx)
            }
        }
    }
}
