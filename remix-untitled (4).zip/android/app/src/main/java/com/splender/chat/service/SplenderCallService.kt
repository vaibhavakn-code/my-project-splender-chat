package com.splender.chat.service

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

/**
 * SplenderCallService (Android 17 / API 37 Foreground VoIP Call Service)
 *
 * Enforces Android 14–17 strict ForegroundService type & runtime permission eligibility:
 * - Dynamically computes foregroundServiceType flags (`phoneCall`, `microphone`, `camera`)
 *   strictly from granted runtime permissions so `startForeground` never triggers a SecurityException.
 * - Exposes `Companion.isCallActive()` to `SplenderAudioLifecycleGuard` so call audio continues
 *   cleanly in the background while transient voice-note audio is released.
 */
class SplenderCallService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_CALL
        if (action == ACTION_STOP_CALL) {
            callActive.set(false)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val isVideo = intent?.getBooleanExtra(EXTRA_IS_VIDEO, false) ?: false
        val conversationId = intent?.getStringExtra(SplenderNotificationHelper.EXTRA_CONVERSATION_ID)

        SplenderNotificationHelper.ensureChannels(this)
        val tapIntent = SplenderNotificationHelper.buildConversationTapIntent(this, conversationId)

        val stopIntent = Intent(this, SplenderCallService::class.java).apply {
            this.action = ACTION_STOP_CALL
        }
        val stopPending = android.app.PendingIntent.getService(
            this,
            901,
            stopIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, SplenderNotificationHelper.CHANNEL_VOIP_CALLS)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentTitle("Splender Encrypted Call")
            .setContentText(if (isVideo) "Peer-to-peer video call active" else "Peer-to-peer voice call active")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setContentIntent(tapIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "End Call", stopPending)
            .build()

        val fgsType = resolveEligibleForegroundServiceType(this, isVideo)
        return try {
            ServiceCompat.startForeground(this, CALL_NOTIFICATION_ID, notification, fgsType)
            callActive.set(true)
            START_NOT_STICKY
        } catch (t: Throwable) {
            Log.w(TAG, "Call ForegroundService start blocked by OS policy: ${t.message}")
            callActive.set(false)
            stopSelf()
            START_NOT_STICKY
        }
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        Log.w(TAG, "ForegroundService timeout reached for type=$fgsType; stopping cleanly.")
        callActive.set(false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        callActive.set(false)
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SplenderCallService"
        private const val CALL_NOTIFICATION_ID = 17001
        const val ACTION_START_CALL = "com.splender.chat.action.START_CALL"
        const val ACTION_STOP_CALL = "com.splender.chat.action.STOP_CALL"
        const val EXTRA_IS_VIDEO = "extra_is_video"

        private val callActive = AtomicBoolean(false)

        fun isCallActive(): Boolean = callActive.get()

        @JvmStatic
        fun resolveEligibleForegroundServiceType(context: Context, isVideo: Boolean): Int {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                return 0
            }
            var mask = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val micGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (micGranted) {
                    mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }

                val camGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
                if (isVideo && camGranted) {
                    mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
            }
            val phoneCallEligible = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.MANAGE_OWN_CALLS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
            if (phoneCallEligible) {
                mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
            }
            return mask
        }

        @JvmStatic
        fun startActiveCall(context: Context, isVideo: Boolean, conversationId: String?) {
            val intent = Intent(context, SplenderCallService::class.java).apply {
                action = ACTION_START_CALL
                putExtra(EXTRA_IS_VIDEO, isVideo)
                if (!conversationId.isNullOrBlank()) {
                    putExtra(SplenderNotificationHelper.EXTRA_CONVERSATION_ID, conversationId)
                }
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (t: Throwable) {
                Log.w(TAG, "Unable to launch SplenderCallService from current app state: ${t.message}")
            }
        }

        @JvmStatic
        fun stopActiveCall(context: Context) {
            callActive.set(false)
            try {
                context.stopService(Intent(context, SplenderCallService::class.java))
            } catch (_: Throwable) {
                // Service already stopped
            }
        }
    }
}
