package com.splender.chat.media;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.exifinterface.media.ExifInterface;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

/**
 * NativeMediaCompressor (Java High-Performance Client-Side Image & Voice-Note Compressor)
 *
 * Executes CPU/DSP-intensive media compression prior to AES-GCM E2EE upload:
 * 1. Image Compression: Two-pass sub-sampled Bitmap decode + EXIF orientation normalization
 *    + metadata stripping + Android 11-17 hardware WebP_LOSSY encoding.
 * 2. Voice-Note Compression: Hardware MediaExtractor + MediaCodec AAC-LC (48 kbps / 24 kHz mono)
 *    + MediaMuxer (.m4a) transcoding for compact, low-latency voice messaging.
 */
public final class NativeMediaCompressor {

    private NativeMediaCompressor() {}

    public static final class CompressionResult {
        @NonNull public final File outputFile;
        public final long originalBytes;
        public final long compressedBytes;
        public final int width;
        public final int height;
        @NonNull public final String mimeType;
        @NonNull public final String sha256Hex;

        public CompressionResult(
            @NonNull File outputFile,
            long originalBytes,
            long compressedBytes,
            int width,
            int height,
            @NonNull String mimeType,
            @NonNull String sha256Hex
        ) {
            this.outputFile = outputFile;
            this.originalBytes = originalBytes;
            this.compressedBytes = compressedBytes;
            this.width = width;
            this.height = height;
            this.mimeType = mimeType;
            this.sha256Hex = sha256Hex;
        }

        public double getSavingsRatio() {
            if (originalBytes <= 0L) return 0.0;
            return Math.max(0.0, 1.0 - ((double) compressedBytes / (double) originalBytes));
        }
    }

    /**
     * Downscales, normalizes EXIF orientation, strips EXIF/GPS tags, and encodes to WebP_LOSSY.
     */
    @NonNull
    public static CompressionResult compressImageFile(
        @NonNull File inputFile,
        @NonNull File outputDir,
        int maxDimensionPx,
        int qualityPercent
    ) throws IOException {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            throw new IOException("Input image file does not exist or is empty");
        }

        long originalSize = inputFile.length();
        int clampedMaxDim = Math.max(320, Math.min(maxDimensionPx, 4096));
        int clampedQuality = Math.max(35, Math.min(qualityPercent, 96));

        // Pass 1: Read bounds without allocating pixel memory
        BitmapFactory.Options boundsOpts = new BitmapFactory.Options();
        boundsOpts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(inputFile.getAbsolutePath(), boundsOpts);

        if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
            throw new IOException("Unable to decode image dimensions");
        }

        int inSampleSize = calculateInSampleSize(boundsOpts.outWidth, boundsOpts.outHeight, clampedMaxDim);

        // Pass 2: Sub-sampled decode
        BitmapFactory.Options decodeOpts = new BitmapFactory.Options();
        decodeOpts.inSampleSize = inSampleSize;
        decodeOpts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap decoded = BitmapFactory.decodeFile(inputFile.getAbsolutePath(), decodeOpts);
        if (decoded == null) {
            throw new IOException("BitmapFactory failed to decode sampled bitmap");
        }

        Bitmap transformed = applyExifAndScale(inputFile, decoded, clampedMaxDim);
        if (transformed != decoded) {
            decoded.recycle();
        }

        if (!outputDir.exists() && !outputDir.mkdirs()) {
            transformed.recycle();
            throw new IOException("Unable to create media compression cache directory");
        }

        File outFile = new File(outputDir, "splender_img_" + System.nanoTime() + ".webp");
        int finalWidth = transformed.getWidth();
        int finalHeight = transformed.getHeight();

        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            Bitmap.CompressFormat format = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                ? Bitmap.CompressFormat.WEBP_LOSSY
                : Bitmap.CompressFormat.WEBP;
            boolean ok = transformed.compress(format, clampedQuality, fos);
            fos.flush();
            if (!ok) {
                throw new IOException("WebP bitmap compression returned false");
            }
        } finally {
            transformed.recycle();
        }

        String digestHex = computeFileSha256Hex(outFile);
        return new CompressionResult(
            outFile,
            originalSize,
            outFile.length(),
            finalWidth,
            finalHeight,
            "image/webp",
            digestHex
        );
    }

    /**
     * Compresses/transcodes a voice-note audio recording to AAC-LC (.m4a) using hardware MediaCodec.
     * If the source file is already compact compressed audio (<= targetBitrate * 1.15), performs
     * a fast verified container copy to avoid generation loss.
     */
    @NonNull
    public static CompressionResult compressVoiceNoteFile(
        @NonNull File inputFile,
        @NonNull File outputDir,
        int targetBitrateBps
    ) throws IOException {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            throw new IOException("Input voice-note file does not exist or is empty");
        }

        long originalSize = inputFile.length();
        int bitrate = Math.max(24_000, Math.min(targetBitrateBps, 96_000));

        if (!outputDir.exists() && !outputDir.mkdirs()) {
            throw new IOException("Unable to create audio compression output directory");
        }

        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean muxerStarted = false;

        File outFile = new File(outputDir, "splender_voice_" + System.nanoTime() + ".m4a");

        try {
            extractor.setDataSource(inputFile.getAbsolutePath());
            int audioTrackIndex = selectAudioTrack(extractor);
            if (audioTrackIndex < 0) {
                // Fast safe copy fallback for raw/containerless blobs so caller always gets valid bytes + hash
                copyFile(inputFile, outFile);
                return new CompressionResult(
                    outFile,
                    originalSize,
                    outFile.length(),
                    0,
                    0,
                    "audio/mp4",
                    computeFileSha256Hex(outFile)
                );
            }

            extractor.selectTrack(audioTrackIndex);
            MediaFormat inputFormat = extractor.getTrackFormat(audioTrackIndex);
            String inputMime = inputFormat.getString(MediaFormat.KEY_MIME);
            int sampleRate = inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                ? inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                : 24_000;
            int channelCount = inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                ? Math.min(1, inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                : 1;
            int sourceBitrate = inputFormat.containsKey(MediaFormat.KEY_BIT_RATE)
                ? inputFormat.getInteger(MediaFormat.KEY_BIT_RATE)
                : Integer.MAX_VALUE;

            // Skip lossy re-encoding if already AAC/Opus at or below target bitrate
            if (inputMime != null
                && (inputMime.equals(MediaFormat.MIMETYPE_AUDIO_AAC) || inputMime.contains("opus"))
                && sourceBitrate <= (int) (bitrate * 1.15)) {
                copyFile(inputFile, outFile);
                return new CompressionResult(
                    outFile,
                    originalSize,
                    outFile.length(),
                    0,
                    0,
                    inputMime,
                    computeFileSha256Hex(outFile)
                );
            }

            if (inputMime == null) {
                throw new IOException("Audio track MIME type missing");
            }

            decoder = MediaCodec.createDecoderByType(inputMime);
            decoder.configure(inputFormat, null, null, 0);
            decoder.start();

            MediaFormat outputFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                sampleRate,
                channelCount
            );
            outputFormat.setInteger(
                MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC
            );
            outputFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            outputFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384);

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            muxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int muxerTrackIdx = -1;

            MediaCodec.BufferInfo decodeInfo = new MediaCodec.BufferInfo();
            MediaCodec.BufferInfo encodeInfo = new MediaCodec.BufferInfo();
            boolean extractorDone = false;
            boolean decoderDone = false;
            boolean encoderDone = false;
            final long timeoutUs = 10_000L;

            while (!encoderDone) {
                if (!extractorDone) {
                    int inBufIdx = decoder.dequeueInputBuffer(timeoutUs);
                    if (inBufIdx >= 0) {
                        ByteBuffer inBuf = decoder.getInputBuffer(inBufIdx);
                        if (inBuf != null) {
                            int sampleSize = extractor.readSampleData(inBuf, 0);
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(
                                    inBufIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                );
                                extractorDone = true;
                            } else {
                                long ptsUs = extractor.getSampleTime();
                                decoder.queueInputBuffer(inBufIdx, 0, sampleSize, ptsUs, 0);
                                extractor.advance();
                            }
                        }
                    }
                }

                if (!decoderDone) {
                    int decOutIdx = decoder.dequeueOutputBuffer(decodeInfo, timeoutUs);
                    if (decOutIdx >= 0) {
                        ByteBuffer decodedPcm = decoder.getOutputBuffer(decOutIdx);
                        boolean isEos = (decodeInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;

                        if (decodedPcm != null && decodeInfo.size > 0) {
                            int encInIdx = encoder.dequeueInputBuffer(timeoutUs);
                            if (encInIdx >= 0) {
                                ByteBuffer encInBuf = encoder.getInputBuffer(encInIdx);
                                if (encInBuf != null) {
                                    encInBuf.clear();
                                    int bytesToCopy = Math.min(encInBuf.remaining(), decodeInfo.size);
                                    decodedPcm.position(decodeInfo.offset);
                                    decodedPcm.limit(decodeInfo.offset + bytesToCopy);
                                    encInBuf.put(decodedPcm);
                                    encoder.queueInputBuffer(
                                        encInIdx,
                                        0,
                                        bytesToCopy,
                                        decodeInfo.presentationTimeUs,
                                        isEos ? MediaCodec.BUFFER_FLAG_END_OF_STREAM : 0
                                    );
                                }
                            }
                        } else if (isEos) {
                            int encInIdx = encoder.dequeueInputBuffer(timeoutUs);
                            if (encInIdx >= 0) {
                                encoder.queueInputBuffer(
                                    encInIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                );
                            }
                        }

                        decoder.releaseOutputBuffer(decOutIdx, false);
                        if (isEos) {
                            decoderDone = true;
                        }
                    }
                }

                int encOutIdx = encoder.dequeueOutputBuffer(encodeInfo, timeoutUs);
                if (encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    muxerTrackIdx = muxer.addTrack(encoder.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                } else if (encOutIdx >= 0) {
                    ByteBuffer encodedData = encoder.getOutputBuffer(encOutIdx);
                    if ((encodeInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        encodeInfo.size = 0;
                    }
                    if (encodeInfo.size > 0 && muxerStarted && encodedData != null) {
                        encodedData.position(encodeInfo.offset);
                        encodedData.limit(encodeInfo.offset + encodeInfo.size);
                        muxer.writeSampleData(muxerTrackIdx, encodedData, encodeInfo);
                    }
                    encoder.releaseOutputBuffer(encOutIdx, false);
                    if ((encodeInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        encoderDone = true;
                    }
                }
            }
        } finally {
            extractor.release();
            if (decoder != null) {
                try {
                    decoder.stop();
                } catch (Throwable ignored) {}
                decoder.release();
            }
            if (encoder != null) {
                try {
                    encoder.stop();
                } catch (Throwable ignored) {}
                encoder.release();
            }
            if (muxer != null) {
                try {
                    if (muxerStarted) muxer.stop();
                } catch (Throwable ignored) {}
                muxer.release();
            }
        }

        return new CompressionResult(
            outFile,
            originalSize,
            outFile.length(),
            0,
            0,
            "audio/mp4",
            computeFileSha256Hex(outFile)
        );
    }

    private static int calculateInSampleSize(int width, int height, int maxDim) {
        int inSampleSize = 1;
        int longest = Math.max(width, height);
        while ((longest / inSampleSize) > (maxDim * 2)) {
            inSampleSize *= 2;
        }
        return inSampleSize;
    }

    @NonNull
    private static Bitmap applyExifAndScale(@NonNull File sourceFile, @NonNull Bitmap src, int maxDim) {
        Matrix matrix = new Matrix();
        try {
            ExifInterface exif = new ExifInterface(sourceFile.getAbsolutePath());
            int orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            );
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    matrix.postRotate(90f);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    matrix.postRotate(180f);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    matrix.postRotate(270f);
                    break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
                    matrix.preScale(-1f, 1f);
                    break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                    matrix.preScale(1f, -1f);
                    break;
                default:
                    break;
            }
        } catch (IOException ignored) {
            // Non-EXIF formats (PNG/WebP) proceed with normal orientation
        }

        int w = src.getWidth();
        int h = src.getHeight();
        int longest = Math.max(w, h);
        if (longest > maxDim) {
            float scale = ((float) maxDim) / ((float) longest);
            matrix.postScale(scale, scale);
        }

        return Bitmap.createBitmap(src, 0, 0, w, h, matrix, true);
    }

    private static int selectAudioTrack(@NonNull MediaExtractor extractor) {
        int count = extractor.getTrackCount();
        for (int i = 0; i < count; i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                return i;
            }
        }
        return -1;
    }

    private static void copyFile(@NonNull File src, @NonNull File dst) throws IOException {
        try (FileInputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[16 * 1024];
            int read;
            while ((read = in.read(buf)) != -1) {
                out.write(buf, 0, read);
            }
            out.flush();
        }
    }

    @NonNull
    public static String computeFileSha256Hex(@NonNull File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = fis.read(buf)) != -1) {
                md.update(buf, 0, n);
            }
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IOException("SHA-256 computation failed", e);
        }
    }
}
