package com.splender.chat.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AuroraObsidianNight = Color(0xFF080B14)
val AuroraDeepSpace = Color(0xFF0D1424)
val AuroraElevatedSurface = Color(0xFF131D32)
val AuroraElectricViolet = Color(0xFF8B5CF6)
val AuroraNeonCyan = Color(0xFF22D3EE)
val AuroraBlue = Color(0xFF3B82F6)
val AuroraSoftMagenta = Color(0xFFF472B6)
val AuroraTextPrimary = Color(0xFFF4F7FF)
val AuroraTextSecondary = Color(0xFFA8B3CC)
val AuroraSubtleBorder = Color(0xFF293650)

// Preserved public tokens mapped to Aurora Nebula palette
val SplenderEmerald = Color(0xFF10B981)
val SplenderDeepTeal = Color(0xFF0891B2)
val SplenderIvorySurface = Color(0xFFF8FAFC)
val SplenderCreamContainer = Color(0xFFF1F5F9)
val SplenderObsidianSurface = AuroraObsidianNight
val SplenderObsidianCard = AuroraDeepSpace
val SplenderPureOled = Color(0xFF000000)

private val SplenderAuroraLightScheme = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    secondary = SplenderDeepTeal,
    onSecondary = Color.White,
    tertiary = AuroraBlue,
    background = SplenderIvorySurface,
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = SplenderCreamContainer,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1)
)

private val SplenderAuroraNebulaDarkScheme = darkColorScheme(
    primary = AuroraElectricViolet,
    onPrimary = Color.White,
    secondary = AuroraNeonCyan,
    onSecondary = AuroraObsidianNight,
    tertiary = AuroraBlue,
    background = AuroraObsidianNight,
    onBackground = AuroraTextPrimary,
    surface = AuroraDeepSpace,
    onSurface = AuroraTextPrimary,
    surfaceVariant = AuroraElevatedSurface,
    onSurfaceVariant = AuroraTextSecondary,
    outline = AuroraSubtleBorder
)

private val SplenderOledDarkScheme = darkColorScheme(
    primary = AuroraNeonCyan,
    onPrimary = Color.Black,
    secondary = AuroraElectricViolet,
    onSecondary = Color.White,
    tertiary = AuroraBlue,
    background = SplenderPureOled,
    onBackground = AuroraTextPrimary,
    surface = AuroraObsidianNight,
    onSurface = AuroraTextPrimary,
    surfaceVariant = AuroraDeepSpace,
    onSurfaceVariant = AuroraTextSecondary,
    outline = AuroraSubtleBorder
)

private val SplenderTypography = Typography(
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun SplenderMaterial3Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    oledMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme && oledMode -> SplenderOledDarkScheme
        darkTheme -> SplenderAuroraNebulaDarkScheme
        else -> SplenderAuroraLightScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SplenderTypography,
        content = content
    )
}
