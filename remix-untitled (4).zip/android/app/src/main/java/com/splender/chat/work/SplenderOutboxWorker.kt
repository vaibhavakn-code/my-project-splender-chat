package com.splender.chat.work

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.splender.chat.nativecore.SplenderNativeCore
import com.splender.chat.security.SplenderKeystoreVault
import java.util.concurrent.TimeUnit

/**
 * SplenderOutboxWorker
 * Respects Android 17 (API 37) background execution quotas and standby buckets:
 * - Uses NetworkType.CONNECTED constraints so radio wakeups are batched by the OS.
 * - Uses OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST so outbox flushes never throw
 *   ForegroundServiceStartNotAllowedException when expedited quota is exhausted.
 */
class SplenderOutboxWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val prefs = applicationContext.getSharedPreferences(OUTBOX_PREFS, Context.MODE_PRIVATE)
            val sealedBatch = prefs.getString(KEY_PENDING_SEALED_OUTBOX, null)
            if (sealedBatch.isNullOrEmpty()) {
                return Result.success()
            }

            // Verify integrity of encrypted local outbox page using Keystore-wrapped master key
            val masterKey = SplenderKeystoreVault.getOrCreateLocalDbMasterKey(applicationContext)
            val decoded = android.util.Base64.decode(sealedBatch, android.util.Base64.NO_WRAP)
            val verifiedPlain = SplenderNativeCore.decryptLocalDbPage(masterKey, 1, decoded)

            if (verifiedPlain != null) {
                Log.i(TAG, "Verified encrypted offline outbox batch (${verifiedPlain.size} bytes) ready for flush.")
            }
            Result.success()
        } catch (t: Throwable) {
            Log.w(TAG, "Outbox worker deferred under Android 17 execution quota: ${t.message}")
            if (runAttemptCount < 4) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val TAG = "SplenderOutboxWorker"
        private const val UNIQUE_WORK_NAME = "splender_encrypted_outbox_flush_v17"
        const val OUTBOX_PREFS = "splender_encrypted_outbox_v17"
        const val KEY_PENDING_SEALED_OUTBOX = "sealed_page_1"

        @JvmStatic
        fun enqueueExpeditedOrStandard(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<SplenderOutboxWorker>()
                .setConstraints(constraints)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                UNIQUE_WORK_NAME,
                ExistingWorkPolicy.KEEP,
                request
            )
        }
    }
}
