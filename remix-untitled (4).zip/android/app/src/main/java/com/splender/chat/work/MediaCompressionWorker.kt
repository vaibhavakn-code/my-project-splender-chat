package com.splender.chat.work

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.splender.chat.media.NativeMediaCompressor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * MediaCompressionWorker (Kotlin CoroutineWorker for Background Image & Voice-Note Compression)
 *
 * Executes client-side media compression asynchronously via WorkManager on `Dispatchers.IO`
 * while adhering to Android 17 (API 37) background execution quotas (`RUN_AS_NON_EXPEDITED_WORK_REQUEST`).
 */
class MediaCompressionWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val mediaKind = inputData.getString(KEY_MEDIA_KIND) ?: KIND_IMAGE
        val inputPath = inputData.getString(KEY_INPUT_PATH)

        if (inputPath.isNullOrBlank()) {
            return@withContext Result.failure(
                workDataOf(KEY_ERROR to "Missing inputPath for MediaCompressionWorker")
            )
        }

        val inputFile = File(inputPath)
        if (!inputFile.exists()) {
            return@withContext Result.failure(
                workDataOf(KEY_ERROR to "Source media file not found: $inputPath")
            )
        }

        if (isStopped) {
            return@withContext Result.retry()
        }

        return@withContext try {
            setProgress(workDataOf(KEY_PROGRESS to 15))
            val outputDir = File(applicationContext.cacheDir, "splender_compressed_media")

            val compressionResult = if (mediaKind == KIND_VOICE) {
                val targetBitrate = inputData.getInt(KEY_VOICE_BITRATE, 48_000)
                NativeMediaCompressor.compressVoiceNoteFile(inputFile, outputDir, targetBitrate)
            } else {
                val maxDimension = inputData.getInt(KEY_MAX_DIMENSION, 1440)
                val quality = inputData.getInt(KEY_QUALITY_PERCENT, 82)
                NativeMediaCompressor.compressImageFile(inputFile, outputDir, maxDimension, quality)
            }

            setProgress(workDataOf(KEY_PROGRESS to 100))

            val outputData = workDataOf(
                KEY_OUTPUT_PATH to compressionResult.outputFile.absolutePath,
                KEY_ORIGINAL_BYTES to compressionResult.originalBytes,
                KEY_COMPRESSED_BYTES to compressionResult.compressedBytes,
                KEY_WIDTH to compressionResult.width,
                KEY_HEIGHT to compressionResult.height,
                KEY_MIME_TYPE to compressionResult.mimeType,
                KEY_SHA256_HEX to compressionResult.sha256Hex,
                KEY_SAVINGS_RATIO to compressionResult.savingsRatio
            )

            Log.i(
                TAG,
                "Compressed $mediaKind: ${compressionResult.originalBytes}B -> ${compressionResult.compressedBytes}B " +
                    "(SHA-256: ${compressionResult.sha256Hex.take(12)}...)"
            )
            Result.success(outputData)
        } catch (t: Throwable) {
            Log.e(TAG, "Background media compression error: ${t.message}", t)
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure(workDataOf(KEY_ERROR to (t.message ?: "Compression worker failed")))
            }
        }
    }

    companion object {
        private const val TAG = "MediaCompressionWorker"

        const val KIND_IMAGE = "image"
        const val KIND_VOICE = "voice"

        const val KEY_MEDIA_KIND = "media_kind"
        const val KEY_INPUT_PATH = "input_path"
        const val KEY_MAX_DIMENSION = "max_dimension"
        const val KEY_QUALITY_PERCENT = "quality_percent"
        const val KEY_VOICE_BITRATE = "voice_bitrate"

        const val KEY_PROGRESS = "progress"
        const val KEY_OUTPUT_PATH = "output_path"
        const val KEY_ORIGINAL_BYTES = "original_bytes"
        const val KEY_COMPRESSED_BYTES = "compressed_bytes"
        const val KEY_WIDTH = "width"
        const val KEY_HEIGHT = "height"
        const val KEY_MIME_TYPE = "mime_type"
        const val KEY_SHA256_HEX = "sha256_hex"
        const val KEY_SAVINGS_RATIO = "savings_ratio"
        const val KEY_ERROR = "error"

        @JvmStatic
        fun enqueueJob(
            context: Context,
            mediaKind: String,
            inputPath: String,
            maxDimension: Int = 1440,
            qualityPercent: Int = 82,
            voiceBitrateBps: Int = 48_000
        ): UUID {
            val input: Data = workDataOf(
                KEY_MEDIA_KIND to mediaKind,
                KEY_INPUT_PATH to inputPath,
                KEY_MAX_DIMENSION to maxDimension,
                KEY_QUALITY_PERCENT to qualityPercent,
                KEY_VOICE_BITRATE to voiceBitrateBps
            )

            val request = OneTimeWorkRequestBuilder<MediaCompressionWorker>()
                .setInputData(input)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .build()

            val uniqueName = "splender_media_compress_${UUID.randomUUID()}"
            WorkManager.getInstance(context).enqueueUniqueWork(
                uniqueName,
                ExistingWorkPolicy.KEEP,
                request
            )
            return request.id
        }
    }
}
