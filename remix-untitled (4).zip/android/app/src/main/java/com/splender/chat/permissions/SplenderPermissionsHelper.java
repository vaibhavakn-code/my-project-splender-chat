package com.splender.chat.permissions;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * SplenderPermissionsHelper (Android 17 / API 37 Runtime Permission Governance)
 *
 * Centralizes Android 17 permission checks:
 * - ACCESS_LOCAL_NETWORK (API 37+) for direct LAN WebRTC ICE host candidates
 * - Scoped Android Photo Picker (PickVisualMedia) + READ_MEDIA_VISUAL_USER_SELECTED (API 34+)
 * - POST_NOTIFICATIONS (API 33+)
 * - CAMERA & RECORD_AUDIO for calls and voice notes
 */
public final class SplenderPermissionsHelper {
    public static final String PERMISSION_ACCESS_LOCAL_NETWORK = "android.permission.ACCESS_LOCAL_NETWORK";

    private SplenderPermissionsHelper() {}

    @NonNull
    public static Map<String, Boolean> getPermissionSnapshot(@NonNull Context context) {
        Map<String, Boolean> map = new LinkedHashMap<>();
        map.put("camera", isGranted(context, Manifest.permission.CAMERA));
        map.put("microphone", isGranted(context, Manifest.permission.RECORD_AUDIO));

        if (Build.VERSION.SDK_INT >= 33) {
            map.put("notifications", isGranted(context, Manifest.permission.POST_NOTIFICATIONS));
            map.put("nearbyWifi", isGranted(context, Manifest.permission.NEARBY_WIFI_DEVICES));
        } else {
            map.put("notifications", true);
            map.put("nearbyWifi", true);
        }

        // Android 17 (API 37) enforces runtime ACCESS_LOCAL_NETWORK for LAN P2P discovery
        if (Build.VERSION.SDK_INT >= 37) {
            map.put("localNetwork", isGranted(context, PERMISSION_ACCESS_LOCAL_NETWORK));
        } else {
            map.put("localNetwork", true);
        }

        // Android Photo Picker works without broad storage permissions on API 33+,
        // and supports partial user-selected visual access on API 34+.
        if (Build.VERSION.SDK_INT >= 34) {
            boolean fullOrPartial = isGranted(context, Manifest.permission.READ_MEDIA_IMAGES)
                || isGranted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
            map.put("scopedPhotoPicker", true);
            map.put("mediaSelectionGranted", fullOrPartial);
        } else {
            map.put("scopedPhotoPicker", ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(context));
            map.put("mediaSelectionGranted", true);
        }

        return map;
    }

    @NonNull
    public static String[] buildRequiredP2pPermissions() {
        List<String> perms = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT >= 37) {
            perms.add(PERMISSION_ACCESS_LOCAL_NETWORK);
        }
        return perms.toArray(new String[0]);
    }

    @NonNull
    public static String[] buildCaptureAndNotificationPermissions(
        boolean requireCamera,
        boolean requireMicrophone,
        boolean requireNotifications
    ) {
        List<String> perms = new ArrayList<>();
        if (requireCamera) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (requireMicrophone) {
            perms.add(Manifest.permission.RECORD_AUDIO);
        }
        if (requireNotifications && Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        return perms.toArray(new String[0]);
    }

    @NonNull
    public static PickVisualMediaRequest buildScopedPhotoPickerRequest(boolean includeVideo) {
        ActivityResultContracts.PickVisualMedia.VisualMediaType mediaType = includeVideo
            ? ActivityResultContracts.PickVisualMedia.ImageAndVideo.INSTANCE
            : ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE;
        return new PickVisualMediaRequest.Builder()
            .setMediaType(mediaType)
            .build();
    }

    private static boolean isGranted(@NonNull Context context, @NonNull String permission) {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }
}
