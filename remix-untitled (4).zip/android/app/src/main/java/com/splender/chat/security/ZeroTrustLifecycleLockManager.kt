package com.splender.chat.security

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.WeakHashMap
import java.util.function.Consumer

/**
 * ZeroTrustLockState
 * Immutable snapshot of Android 17 (API 37) window security & anti-exfiltration posture.
 */
data class ZeroTrustLockState(
    val flagSecureEnforced: Boolean = true,
    val recentsSnapshotBlocked: Boolean = true,
    val isInBackground: Boolean = false,
    val isPrivacyCurtainEngaged: Boolean = false,
    val isScreenCaptureDetected: Boolean = false,
    val isScreenRecordingActive: Boolean = false,
    val lastScrubbedEpochMs: Long = 0L
)

/**
 * ZeroTrustLifecycleLockManager (Android 17 / API 37 Zero-Trust Window & Snapshot Guard)
 *
 * Prevents visual and memory data leaks across single-window lifecycle transitions:
 * 1. Enforces `WindowManager.LayoutParams.FLAG_SECURE` to block MediaProjection, Cast, and ADB screencap.
 * 2. Disables OS Recents task-switcher thumbnails via `Activity.setRecentsScreenshotEnabled(false)` (API 33+).
 * 3. Monitors `Activity.ScreenCaptureCallback` (API 34+) and `WindowManager.addScreenRecordingCallback` (API 35–37)
 *    to immediately raise the Compose Zero-Trust Privacy Curtain during capture attempts.
 * 4. Scrubs ephemeral in-memory cryptographic material on `Dispatchers.IO` whenever the app moves to background.
 */
class ZeroTrustLifecycleLockManager(
    private val onEphemeralMemoryScrub: suspend () -> Unit = {}
) : DefaultLifecycleObserver, Application.ActivityLifecycleCallbacks {

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _lockState = MutableStateFlow(ZeroTrustLockState())
    val lockState: StateFlow<ZeroTrustLockState> = _lockState.asStateFlow()

    private val captureCallbacks = Collections.synchronizedMap(WeakHashMap<Activity, Any>())
    private val recordingCallbacks = Collections.synchronizedMap(WeakHashMap<Activity, Consumer<Int>>())

    fun setFlagSecurePolicy(activity: Activity?, enabled: Boolean) {
        _lockState.update { it.copy(flagSecureEnforced = enabled) }
        activity?.runOnUiThread {
            applyWindowProtectionFlags(activity, enabled)
        }
    }

    private fun applyWindowProtectionFlags(activity: Activity, secureEnabled: Boolean) {
        try {
            if (secureEnabled) {
                activity.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                activity.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                activity.setRecentsScreenshotEnabled(!secureEnabled)
                _lockState.update { it.copy(recentsSnapshotBlocked = secureEnabled) }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to apply zero-trust window flags: ${t.message}")
        }
    }

    private fun registerCaptureAndRecordingMonitors(activity: Activity) {
        val mainExecutor = ContextCompat.getMainExecutor(activity)

        // Android 14+ (API 34+) Hardware/OS Screenshot Attempt Detection
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && !captureCallbacks.containsKey(activity)) {
            try {
                val callback = Activity.ScreenCaptureCallback {
                    Log.w(TAG, "Screen capture attempt intercepted on single window")
                    _lockState.update {
                        it.copy(
                            isScreenCaptureDetected = true,
                            isPrivacyCurtainEngaged = true
                        )
                    }
                }
                activity.registerScreenCaptureCallback(mainExecutor, callback)
                captureCallbacks[activity] = callback
            } catch (t: Throwable) {
                Log.w(TAG, "ScreenCaptureCallback registration skipped: ${t.message}")
            }
        }

        // Android 15–17 (API 35–37) Live Screen-Recording / MediaProjection Detection
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM && !recordingCallbacks.containsKey(activity)) {
            try {
                val consumer = Consumer<Int> { state ->
                    val recording = state == WindowManager.SCREEN_RECORDING_STATE_VISIBLE
                    if (recording) {
                        Log.w(TAG, "Active screen recording detected; engaging Zero-Trust Privacy Curtain")
                    }
                    _lockState.update {
                        it.copy(
                            isScreenRecordingActive = recording,
                            isPrivacyCurtainEngaged = recording || it.isInBackground
                        )
                    }
                }
                val initialState = activity.windowManager.addScreenRecordingCallback(mainExecutor, consumer)
                val initiallyRecording = initialState == WindowManager.SCREEN_RECORDING_STATE_VISIBLE
                recordingCallbacks[activity] = consumer
                _lockState.update {
                    it.copy(
                        isScreenRecordingActive = initiallyRecording,
                        isPrivacyCurtainEngaged = initiallyRecording || it.isInBackground
                    )
                }
            } catch (t: Throwable) {
                Log.w(TAG, "ScreenRecordingCallback registration skipped: ${t.message}")
            }
        }
    }

    private fun unregisterCaptureAndRecordingMonitors(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val cb = captureCallbacks.remove(activity) as? Activity.ScreenCaptureCallback
            if (cb != null) {
                try {
                    activity.unregisterScreenCaptureCallback(cb)
                } catch (_: Throwable) {
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            val recCb = recordingCallbacks.remove(activity)
            if (recCb != null) {
                try {
                    activity.windowManager.removeScreenRecordingCallback(recCb)
                } catch (_: Throwable) {
                }
            }
        }
    }

    fun acknowledgeCaptureWarning() {
        _lockState.update { state ->
            state.copy(
                isScreenCaptureDetected = false,
                isPrivacyCurtainEngaged = state.isInBackground || state.isScreenRecordingActive
            )
        }
    }

    // --- ProcessLifecycleOwner Callbacks (Whole-App Foreground / Background) ---
    override fun onStart(owner: LifecycleOwner) {
        _lockState.update { state ->
            state.copy(
                isInBackground = false,
                isPrivacyCurtainEngaged = state.isScreenRecordingActive
            )
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        _lockState.update {
            it.copy(
                isInBackground = true,
                isPrivacyCurtainEngaged = true
            )
        }
        ioScope.launch {
            try {
                onEphemeralMemoryScrub()
                _lockState.update { it.copy(lastScrubbedEpochMs = System.currentTimeMillis()) }
            } catch (t: Throwable) {
                Log.e(TAG, "Zero-trust background memory scrub failed", t)
            }
        }
    }

    // --- ActivityLifecycleCallbacks (Immediate Window Pre-Snapshot Protection) ---
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        applyWindowProtectionFlags(activity, _lockState.value.flagSecureEnforced)
    }

    override fun onActivityStarted(activity: Activity) {
        applyWindowProtectionFlags(activity, _lockState.value.flagSecureEnforced)
        registerCaptureAndRecordingMonitors(activity)
    }

    override fun onActivityResumed(activity: Activity) {
        _lockState.update { state ->
            state.copy(
                isInBackground = false,
                isPrivacyCurtainEngaged = state.isScreenRecordingActive
            )
        }
    }

    override fun onActivityPaused(activity: Activity) {
        // Engage curtain prior to OS Recents frame snapshot if FLAG_SECURE is active
        if (_lockState.value.flagSecureEnforced && !activity.isChangingConfigurations) {
            _lockState.update { it.copy(isPrivacyCurtainEngaged = true) }
        }
    }

    override fun onActivityStopped(activity: Activity) {
        unregisterCaptureAndRecordingMonitors(activity)
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit

    override fun onActivityDestroyed(activity: Activity) {
        unregisterCaptureAndRecordingMonitors(activity)
    }

    companion object {
        private const val TAG = "ZeroTrustLockManager"
    }
}
