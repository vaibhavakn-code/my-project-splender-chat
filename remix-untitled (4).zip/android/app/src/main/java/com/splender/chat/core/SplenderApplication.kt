package com.splender.chat.core

import android.app.Application
import android.content.SharedPreferences
import android.os.Build
import android.util.Base64
import android.util.Log
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.splender.chat.nativecore.SplenderNativeCore
import com.splender.chat.security.SplenderKeystoreVault
import com.splender.chat.security.ZeroTrustLifecycleLockManager
import com.splender.chat.webrtc.SplenderP2PStreamingPipeline
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

/**
 * SplenderApplication
 *
 * Global Android 17 (API 37) process initializer & Zero-Trust Core:
 * 1. Initializes a non-extractable Android Keystore `MasterKey` (`AES256_GCM` backed by StrongBox/TEE)
 *    and `EncryptedSharedPreferences` (`AES256_SIV` keys + `AES256_GCM` values) on `Dispatchers.IO`.
 * 2. Provides thread-safe, coroutine-scoped (`Dispatchers.IO`) APIs for sealed auth tokens,
 *    salted HMAC-SHA256 PIN verifiers, and hardware-wrapped Double Ratchet / X25519 keys.
 * 3. Pre-warms the incremental FIPS 180-4 `StreamingSha256` + 64 KB SCTP DataChannel pipeline
 *    for bounded-memory 1 GB+ P2P file streaming and WebRTC foreground services.
 * 4. Attaches `ZeroTrustLifecycleLockManager` across `ProcessLifecycleOwner` and all window lifecycles.
 */
class SplenderApplication : Application() {

    private val coreExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        Log.e(TAG, "Uncaught exception in SplenderApplication background scope", throwable)
    }

    private val applicationScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + coreExceptionHandler
    )

    private val vaultMutex = Mutex()
    private val ephemeralDecryptedKeyCache = ConcurrentHashMap<String, ByteArray>()

    @Volatile
    private var encryptedVaultPreferences: SharedPreferences? = null

    @Volatile
    private var webRtcPipelineReady: Boolean = false

    lateinit var zeroTrustLockManager: ZeroTrustLifecycleLockManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        zeroTrustLockManager = ZeroTrustLifecycleLockManager(
            onEphemeralMemoryScrub = { wipeEphemeralSessionCache() }
        )
        registerActivityLifecycleCallbacks(zeroTrustLockManager)
        ProcessLifecycleOwner.get().lifecycle.addObserver(zeroTrustLockManager)

        initializeSecurityVault()
        initializeWebRTCPipeline()
    }

    private fun initializeSecurityVault() {
        applicationScope.launch {
            try {
                ensureEncryptedVaultReady()
            } catch (t: Throwable) {
                Log.e(TAG, "Security vault initialization error", t)
            }
        }
    }

    private suspend fun ensureEncryptedVaultReady(): SharedPreferences = withContext(Dispatchers.IO) {
        encryptedVaultPreferences?.let { return@withContext it }

        vaultMutex.withLock {
            encryptedVaultPreferences?.let { return@withLock it }

            // Initialize Non-Extractable Android KeyStore & AES-256-GCM Cipher Vault (StrongBox -> TEE)
            val masterKeyBuilder = MasterKey.Builder(applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                masterKeyBuilder.setRequestStrongBoxBacked(true)
            }

            val masterKey = try {
                masterKeyBuilder.build()
            } catch (_: Throwable) {
                MasterKey.Builder(applicationContext)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
            }

            val sharedPreferences = try {
                EncryptedSharedPreferences.create(
                    applicationContext,
                    VAULT_PREFS_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (corruptEx: Throwable) {
                // Self-heal if OS lockscreen credential reset invalidated previous KeyStore keyset
                Log.w(TAG, "Recovering invalidated EncryptedSharedPreferences keyset", corruptEx)
                applicationContext.deleteSharedPreferences(VAULT_PREFS_FILE)
                EncryptedSharedPreferences.create(
                    applicationContext,
                    VAULT_PREFS_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }

            // Warm up hardware-wrapped 32-byte local database encryption key & zero transient buffer
            val dbMasterKey = SplenderKeystoreVault.getOrCreateLocalDbMasterKey(applicationContext)
            dbMasterKey.fill(0)

            sharedPreferences.edit()
                .putLong("vault_last_verified_epoch_ms", System.currentTimeMillis())
                .putInt("vault_schema_version", 17)
                .apply()

            encryptedVaultPreferences = sharedPreferences
            sharedPreferences
        }
    }

    private fun initializeWebRTCPipeline() {
        // WebRTC 64KB chunked P2P transfer pipeline for 1GB+ files & encrypted audio/video calls
        applicationScope.launch {
            try {
                val prewarmed = SplenderP2PStreamingPipeline.prewarmPipeline(
                    context = applicationContext,
                    ioDispatcher = Dispatchers.IO
                )
                val nativeReady = SplenderNativeCore.isNativeReady()
                webRtcPipelineReady = prewarmed

                Log.i(
                    TAG,
                    "WebRTC P2P pipeline ready (chunk=${P2P_CHUNK_SIZE_BYTES}B, " +
                        "lowWatermark=${SCTP_LOW_WATERMARK_BYTES}B, " +
                        "highWatermark=${SCTP_HIGH_WATERMARK_BYTES}B, nativeJni=$nativeReady)"
                )
            } catch (t: Throwable) {
                Log.e(TAG, "WebRTC P2P pipeline initialization error", t)
            }
        }
    }

    // --- Coroutine-Scoped (Dispatchers.IO) Vault Operations for Tokens, PINs & Keys ---

    suspend fun putSecureToken(alias: String, rawToken: String, ttlMs: Long = 0L): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(alias.isNotBlank() && rawToken.isNotBlank()) { "Token alias and value required" }
                val prefs = ensureEncryptedVaultReady()
                val wrapped = SplenderKeystoreVault.wrapSecret(
                    rawToken.toByteArray(Charsets.UTF_8),
                    aadContext = "token:$alias"
                )
                val expiresAt = if (ttlMs > 0L) System.currentTimeMillis() + ttlMs else 0L
                prefs.edit()
                    .putString("tok_val_$alias", wrapped)
                    .putLong("tok_exp_$alias", expiresAt)
                    .commit()
                Unit
            }
        }

    suspend fun getSecureToken(alias: String): String? = withContext(Dispatchers.IO) {
        try {
            val prefs = ensureEncryptedVaultReady()
            val expiresAt = prefs.getLong("tok_exp_$alias", 0L)
            if (expiresAt > 0L && System.currentTimeMillis() > expiresAt) {
                revokeSecureToken(alias)
                return@withContext null
            }
            val wrapped = prefs.getString("tok_val_$alias", null) ?: return@withContext null
            val bytes = SplenderKeystoreVault.unwrapSecret(wrapped, aadContext = "token:$alias")
            try {
                String(bytes, Charsets.UTF_8)
            } finally {
                bytes.fill(0)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to unseal secure token '$alias': ${t.message}")
            null
        }
    }

    suspend fun revokeSecureToken(alias: String) = withContext(Dispatchers.IO) {
        val prefs = ensureEncryptedVaultReady()
        prefs.edit()
            .remove("tok_val_$alias")
            .remove("tok_exp_$alias")
            .commit()
    }

    /**
     * Stores a per-installation 32-byte CSPRNG salt + iterated HMAC-SHA256 PIN verifier inside
     * `EncryptedSharedPreferences` so plaintext PINs never touch RAM caches or disk.
     */
    suspend fun storePinVerifier(rawPin: CharArray): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(rawPin.size >= 4) { "PIN must contain at least 4 digits" }
            val prefs = ensureEncryptedVaultReady()
            val salt = ByteArray(32).also { SecureRandom().nextBytes(it) }
            val verifier = deriveStretchedPinVerifier(rawPin, salt)
            try {
                prefs.edit()
                    .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString(KEY_PIN_VERIFIER, Base64.encodeToString(verifier, Base64.NO_WRAP))
                    .commit()
                Unit
            } finally {
                salt.fill(0)
                verifier.fill(0)
            }
        }
    }

    suspend fun verifyPin(candidatePin: CharArray): Boolean = withContext(Dispatchers.IO) {
        try {
            val prefs = ensureEncryptedVaultReady()
            val saltB64 = prefs.getString(KEY_PIN_SALT, null) ?: return@withContext false
            val expectedB64 = prefs.getString(KEY_PIN_VERIFIER, null) ?: return@withContext false
            val salt = Base64.decode(saltB64, Base64.NO_WRAP)
            val expected = Base64.decode(expectedB64, Base64.NO_WRAP)
            val actual = deriveStretchedPinVerifier(candidatePin, salt)
            try {
                MessageDigest.isEqual(expected, actual)
            } finally {
                salt.fill(0)
                expected.fill(0)
                actual.fill(0)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "PIN verification failure", t)
            false
        }
    }

    suspend fun storeWrappedKeyMaterial(keyId: String, keyBytes: ByteArray): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(keyId.isNotBlank() && keyBytes.isNotEmpty()) { "Key ID and material required" }
                val prefs = ensureEncryptedVaultReady()
                val hardwareWrapped = SplenderKeystoreVault.wrapSecret(
                    keyBytes,
                    aadContext = "e2ee-key:$keyId"
                )
                prefs.edit().putString("key_blob_$keyId", hardwareWrapped).commit()
                ephemeralDecryptedKeyCache[keyId] = keyBytes.copyOf()
                Unit
            }
        }

    suspend fun loadWrappedKeyMaterial(keyId: String): ByteArray? = withContext(Dispatchers.IO) {
        ephemeralDecryptedKeyCache[keyId]?.let { return@withContext it.copyOf() }
        try {
            val prefs = ensureEncryptedVaultReady()
            val wrapped = prefs.getString("key_blob_$keyId", null) ?: return@withContext null
            val unwrapped = SplenderKeystoreVault.unwrapSecret(wrapped, aadContext = "e2ee-key:$keyId")
            ephemeralDecryptedKeyCache[keyId] = unwrapped.copyOf()
            unwrapped
        } catch (t: Throwable) {
            Log.w(TAG, "Key unwrap failed for '$keyId': ${t.message}")
            null
        }
    }

    suspend fun wipeEphemeralSessionCache() = withContext(Dispatchers.IO) {
        val iterator = ephemeralDecryptedKeyCache.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            entry.value.fill(0)
            iterator.remove()
        }
    }

    private fun deriveStretchedPinVerifier(pin: CharArray, salt: ByteArray): ByteArray {
        val pinBytes = Charsets.UTF_8.encode(java.nio.CharBuffer.wrap(pin)).let { buf ->
            ByteArray(buf.remaining()).also { buf.get(it) }
        }
        return try {
            var state = SplenderNativeCore.computeHmacSha256(salt, pinBytes)
            repeat(PIN_KDF_ITERATIONS) { round ->
                val roundBytes = byteArrayOf(
                    ((round ushr 8) and 0xFF).toByte(),
                    (round and 0xFF).toByte()
                )
                state = SplenderNativeCore.computeHmacSha256(state, salt + roundBytes)
            }
            state
        } finally {
            pinBytes.fill(0)
        }
    }

    fun getEncryptedVaultPreferences(): SharedPreferences? = encryptedVaultPreferences

    fun isWebRtcPipelineReady(): Boolean = webRtcPipelineReady

    companion object {
        private const val TAG = "SplenderApplication"
        const val VAULT_PREFS_FILE = "secure_splender_vault"
        private const val KEY_PIN_SALT = "vault_pin_salt_v17"
        private const val KEY_PIN_VERIFIER = "vault_pin_verifier_v17"
        private const val PIN_KDF_ITERATIONS = 4096

        const val P2P_CHUNK_SIZE_BYTES = 64 * 1024 // 64 KB SCTP-safe binary frame
        const val SCTP_LOW_WATERMARK_BYTES = 256 * 1024 // 256 KB buffer drain resume threshold
        const val SCTP_HIGH_WATERMARK_BYTES = 1024 * 1024 // 1 MB max buffered ceiling for 1GB+ streams
        const val LARGE_FILE_STREAM_THRESHOLD_BYTES = 16L * 1024L * 1024L

        @Volatile
        private var instance: SplenderApplication? = null

        @JvmStatic
        fun getInstance(): SplenderApplication? = instance
    }
}
