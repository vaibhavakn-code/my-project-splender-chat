package com.splender.chat.plugins

import androidx.fragment.app.FragmentActivity
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.splender.chat.security.BiometricManager

/**
 * BiometricPlugin (Kotlin Capacitor Bridge for Native Biometric Session Locking)
 *
 * Bridges Java `BiometricManager` (`androidx.biometric.BiometricPrompt`) to the
 * Splender Chat React/TypeScript security layer and streams real-time
 * `sessionLockChanged` events when transitioning from background to foreground.
 */
@CapacitorPlugin(name = "SplenderBiometric")
class BiometricPlugin : Plugin(), BiometricManager.SessionLockListener {

    private lateinit var biometricController: BiometricManager

    override fun load() {
        super.load()
        biometricController = BiometricManager.getInstance(context)
        biometricController.attachHostActivity(activity as? FragmentActivity)
        biometricController.addSessionLockListener(this)
    }

    override fun handleOnResume() {
        super.handleOnResume()
        biometricController.attachHostActivity(activity as? FragmentActivity)
    }

    override fun handleOnDestroy() {
        if (::biometricController.isInitialized) {
            biometricController.removeSessionLockListener(this)
            biometricController.attachHostActivity(null)
        }
        super.handleOnDestroy()
    }

    override fun onSessionLockStateChanged(isLocked: Boolean, reason: String, timestampMs: Long) {
        val payload = JSObject().apply {
            put("locked", isLocked)
            put("reason", reason)
            put("timestamp", timestampMs)
        }
        notifyListeners("sessionLockChanged", payload, true)
    }

    @PluginMethod
    fun checkBiometricAvailability(call: PluginCall) {
        val report = biometricController.checkCapability()
        val ret = JSObject().apply {
            put("available", report.available)
            put("strongBiometricReady", report.strongBiometricReady)
            put("deviceCredentialSupported", report.deviceCredentialSupported)
            put("statusCode", report.statusCode)
            put("autoLockEnabled", biometricController.isAutoLockEnabled)
            put("gracePeriodMs", biometricController.gracePeriodMs)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun authenticateSession(call: PluginCall) {
        val hostActivity = activity as? FragmentActivity
        if (hostActivity == null || hostActivity.isFinishing) {
            call.reject("Host FragmentActivity is unavailable for BiometricPrompt", "ACTIVITY_UNAVAILABLE")
            return
        }

        val title = call.getString("title", "Splender Security Gate") ?: "Splender Security Gate"
        val subtitle = call.getString(
            "subtitle",
            "Authenticate with fingerprint, face unlock, or device credential"
        ) ?: "Authenticate with fingerprint, face unlock, or device credential"

        biometricController.authenticateSession(
            hostActivity,
            title,
            subtitle,
            object : BiometricManager.AuthResultCallback {
                override fun onAuthSucceeded(authenticationType: Int) {
                    val ret = JSObject().apply {
                        put("verified", true)
                        put("authenticationType", authenticationType)
                        put("timestamp", System.currentTimeMillis())
                    }
                    call.resolve(ret)
                }

                override fun onAuthFailed(reason: String) {
                    // BiometricPrompt stays open for retry on single sensor mismatch; notify listeners
                    val attemptEvent = JSObject().apply {
                        put("reason", reason)
                        put("timestamp", System.currentTimeMillis())
                    }
                    notifyListeners("biometricAttemptFailed", attemptEvent)
                }

                override fun onAuthError(errorCode: Int, errString: String) {
                    call.reject(errString, "BIOMETRIC_ERROR_$errorCode")
                }
            }
        )
    }

    @PluginMethod
    fun configureSessionLock(call: PluginCall) {
        val enabled = call.getBoolean("enabled", false) ?: false
        val gracePeriodMs = call.getInt("gracePeriodMs", 10_000)?.toLong() ?: 10_000L
        biometricController.configureAutoLock(enabled, gracePeriodMs)

        val ret = JSObject().apply {
            put("enabled", biometricController.isAutoLockEnabled)
            put("gracePeriodMs", biometricController.gracePeriodMs)
            put("locked", biometricController.isSessionLocked)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun lockSessionNow(call: PluginCall) {
        val reason = call.getString("reason", "manual_lock") ?: "manual_lock"
        biometricController.lockNow(reason)
        val ret = JSObject().apply {
            put("locked", true)
            put("reason", reason)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun getSessionLockState(call: PluginCall) {
        val ret = JSObject().apply {
            put("locked", biometricController.isSessionLocked)
            put("autoLockEnabled", biometricController.isAutoLockEnabled)
            put("gracePeriodMs", biometricController.gracePeriodMs)
        }
        call.resolve(ret)
    }
}
