package com.splender.chat.security;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * BiometricManager (Native Android Java Session Lock Controller)
 *
 * Integrates AndroidX BiometricPrompt (BIOMETRIC_STRONG | DEVICE_CREDENTIAL)
 * with ProcessLifecycleOwner foreground/background transitions to automatically
 * lock and unlock the Splender Chat session when moving from background to foreground.
 */
public final class BiometricManager implements DefaultLifecycleObserver {
    private static final String PREFS_NAME = "splender_biometric_prefs_v17";
    private static final String KEY_AUTO_LOCK_ENABLED = "auto_lock_enabled";
    private static final String KEY_GRACE_PERIOD_MS = "grace_period_ms";
    private static final long DEFAULT_GRACE_PERIOD_MS = 10_000L;

    public interface SessionLockListener {
        void onSessionLockStateChanged(boolean isLocked, @NonNull String reason, long timestampMs);
    }

    public interface AuthResultCallback {
        void onAuthSucceeded(int authenticationType);
        void onAuthFailed(@NonNull String reason);
        void onAuthError(int errorCode, @NonNull String errString);
    }

    public static final class CapabilityReport {
        public final boolean available;
        public final boolean strongBiometricReady;
        public final boolean deviceCredentialSupported;
        @NonNull public final String statusCode;

        public CapabilityReport(
            boolean available,
            boolean strongBiometricReady,
            boolean deviceCredentialSupported,
            @NonNull String statusCode
        ) {
            this.available = available;
            this.strongBiometricReady = strongBiometricReady;
            this.deviceCredentialSupported = deviceCredentialSupported;
            this.statusCode = statusCode;
        }
    }

    private static volatile BiometricManager instance;

    private final Context appContext;
    private final SharedPreferences prefs;
    private final AtomicBoolean sessionLocked = new AtomicBoolean(false);
    private final AtomicBoolean promptInFlight = new AtomicBoolean(false);
    private final Set<SessionLockListener> listeners = new CopyOnWriteArraySet<>();

    private volatile long lastBackgroundedElapsedMs = -1L;
    @Nullable private volatile FragmentActivity currentHostActivity;

    private BiometricManager(@NonNull Context context) {
        this.appContext = context.getApplicationContext();
        this.prefs = this.appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @NonNull
    public static BiometricManager getInstance(@NonNull Context context) {
        if (instance == null) {
            synchronized (BiometricManager.class) {
                if (instance == null) {
                    instance = new BiometricManager(context);
                }
            }
        }
        return instance;
    }

    public void attachHostActivity(@Nullable FragmentActivity activity) {
        this.currentHostActivity = activity;
    }

    public void addSessionLockListener(@NonNull SessionLockListener listener) {
        listeners.add(listener);
    }

    public void removeSessionLockListener(@NonNull SessionLockListener listener) {
        listeners.remove(listener);
    }

    public boolean isAutoLockEnabled() {
        return prefs.getBoolean(KEY_AUTO_LOCK_ENABLED, false);
    }

    public long getGracePeriodMs() {
        return prefs.getLong(KEY_GRACE_PERIOD_MS, DEFAULT_GRACE_PERIOD_MS);
    }

    public void configureAutoLock(boolean enabled, long gracePeriodMs) {
        long clampedGrace = Math.max(0L, Math.min(gracePeriodMs, 300_000L));
        prefs.edit()
            .putBoolean(KEY_AUTO_LOCK_ENABLED, enabled)
            .putLong(KEY_GRACE_PERIOD_MS, clampedGrace)
            .apply();

        if (!enabled && sessionLocked.compareAndSet(true, false)) {
            dispatchLockState(false, "auto_lock_disabled");
        }
    }

    public boolean isSessionLocked() {
        return sessionLocked.get();
    }

    public void lockNow(@NonNull String reason) {
        if (sessionLocked.compareAndSet(false, true)) {
            dispatchLockState(true, reason);
        } else {
            dispatchLockState(true, reason);
        }
    }

    @NonNull
    public CapabilityReport checkCapability() {
        androidx.biometric.BiometricManager androidBm =
            androidx.biometric.BiometricManager.from(appContext);

        int strongResult = androidBm.canAuthenticate(
            androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
        );
        int combinedResult = androidBm.canAuthenticate(
            androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
        );

        boolean strongReady = (strongResult == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS);
        boolean combinedReady = (combinedResult == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS);

        String code;
        switch (combinedResult) {
            case androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS:
                code = "BIOMETRIC_SUCCESS";
                break;
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                code = "BIOMETRIC_ERROR_NONE_ENROLLED";
                break;
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                code = "BIOMETRIC_ERROR_NO_HARDWARE";
                break;
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                code = "BIOMETRIC_ERROR_HW_UNAVAILABLE";
                break;
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED:
                code = "BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED";
                break;
            default:
                code = "BIOMETRIC_STATUS_UNKNOWN";
                break;
        }

        return new CapabilityReport(combinedReady, strongReady, combinedReady, code);
    }

    /**
     * Triggers Android's native BiometricPrompt on the UI thread to unlock the session.
     */
    public void authenticateSession(
        @NonNull FragmentActivity activity,
        @NonNull String title,
        @NonNull String subtitle,
        @NonNull AuthResultCallback callback
    ) {
        if (!promptInFlight.compareAndSet(false, true)) {
            callback.onAuthError(-1, "Biometric authentication prompt is already active");
            return;
        }

        Executor mainExecutor = ContextCompat.getMainExecutor(activity);
        activity.runOnUiThread(() -> {
            try {
                BiometricPrompt prompt = new BiometricPrompt(
                    activity,
                    mainExecutor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                            @NonNull BiometricPrompt.AuthenticationResult result
                        ) {
                            promptInFlight.set(false);
                            sessionLocked.set(false);
                            lastBackgroundedElapsedMs = -1L;
                            dispatchLockState(false, "biometric_verified");
                            callback.onAuthSucceeded(result.getAuthenticationType());
                        }

                        @Override
                        public void onAuthenticationFailed() {
                            callback.onAuthFailed("Biometric credential not recognized");
                        }

                        @Override
                        public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                            promptInFlight.set(false);
                            callback.onAuthError(errorCode, errString.toString());
                        }
                    }
                );

                BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setAllowedAuthenticators(
                        androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                            | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    )
                    .setConfirmationRequired(false)
                    .build();

                prompt.authenticate(promptInfo);
            } catch (Throwable t) {
                promptInFlight.set(false);
                callback.onAuthError(-2, "Failed to display BiometricPrompt: " + t.getMessage());
            }
        });
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        // App moved to background
        if (isAutoLockEnabled()) {
            lastBackgroundedElapsedMs = SystemClock.elapsedRealtime();
            if (getGracePeriodMs() == 0L) {
                sessionLocked.set(true);
                dispatchLockState(true, "background_immediate_lock");
            }
        }
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        // App returned from background to foreground
        if (!isAutoLockEnabled()) {
            return;
        }

        long bgAt = lastBackgroundedElapsedMs;
        if (bgAt > 0L) {
            long elapsedAway = SystemClock.elapsedRealtime() - bgAt;
            if (elapsedAway >= getGracePeriodMs()) {
                sessionLocked.set(true);
                dispatchLockState(true, "foreground_resume_lock");

                FragmentActivity host = currentHostActivity;
                if (host != null && !host.isFinishing() && !host.isDestroyed()) {
                    authenticateSession(
                        host,
                        "Splender Session Locked",
                        "Verify biometrics or device PIN to resume encrypted chat",
                        new AuthResultCallback() {
                            @Override
                            public void onAuthSucceeded(int authenticationType) {
                                // State already broadcast via dispatchLockState(false, ...)
                            }

                            @Override
                            public void onAuthFailed(@NonNull String reason) {
                                // Remains locked until succeeded
                            }

                            @Override
                            public void onAuthError(int errorCode, @NonNull String errString) {
                                // Remains locked so React BiometricAuthScreen stays engaged
                            }
                        }
                    );
                }
            } else {
                lastBackgroundedElapsedMs = -1L;
            }
        }
    }

    private void dispatchLockState(boolean locked, @NonNull String reason) {
        long now = System.currentTimeMillis();
        for (SessionLockListener listener : listeners) {
            try {
                listener.onSessionLockStateChanged(locked, reason, now);
            } catch (Throwable ignored) {
                // Prevent observer exceptions from disrupting lifecycle
            }
        }
    }
}
