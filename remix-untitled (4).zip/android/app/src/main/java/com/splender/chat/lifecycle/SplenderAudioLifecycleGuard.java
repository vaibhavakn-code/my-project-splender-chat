package com.splender.chat.lifecycle;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import com.splender.chat.service.SplenderCallService;

/**
 * SplenderAudioLifecycleGuard (Android 17 / API 37 Compliance)
 *
 * Enforces Android 17 background-audio execution restrictions:
 * - Transient voice-note playback may only hold audio focus while the process is in the foreground.
 * - When the app moves to background (onStop) without an active phoneCall/microphone ForegroundService,
 *   audio focus is cleanly abandoned so the OS never penalizes or kills the process.
 */
public final class SplenderAudioLifecycleGuard implements DefaultLifecycleObserver {
    private static final String TAG = "SplenderAudioLifecycle";
    private final AudioManager audioManager;
    private AudioFocusRequest activeVoiceNoteFocus;

    public SplenderAudioLifecycleGuard(@NonNull Context context) {
        this.audioManager = (AudioManager) context.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
    }

    public boolean requestTransientVoiceFocus() {
        if (audioManager == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
            activeVoiceNoteFocus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusChange -> {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                        abandonTransientVoiceFocus();
                    }
                })
                .build();
            return audioManager.requestAudioFocus(activeVoiceNoteFocus) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return true;
    }

    public void abandonTransientVoiceFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activeVoiceNoteFocus != null) {
            audioManager.abandonAudioFocusRequest(activeVoiceNoteFocus);
            activeVoiceNoteFocus = null;
        }
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        // Under Android 17 (API 37), background audio without an active Foreground Service is restricted.
        if (!SplenderCallService.Companion.isCallActive()) {
            Log.d(TAG, "App entered background with no active call FGS; releasing transient audio focus.");
            abandonTransientVoiceFocus();
        }
    }
}
