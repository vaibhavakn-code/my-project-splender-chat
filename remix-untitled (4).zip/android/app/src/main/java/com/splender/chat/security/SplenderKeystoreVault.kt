package com.splender.chat.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * SplenderKeystoreVault
 * Hardware-backed AndroidKeyStore AES-256-GCM envelope vault (API 24 -> API 37).
 * Ensures cryptographic identity keys and local DB master keys never exist unencrypted on disk.
 */
object SplenderKeystoreVault {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val MASTER_KEY_ALIAS = "com.splender.chat.master_vault_key_v17"
    private const val PREFS_NAME = "splender_keystore_envelopes_v17"
    private const val DB_KEY_PREF = "wrapped_local_db_key_32"

    private fun getOrCreateHardwareKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) {
            return existing.secretKey
        }

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        val builder = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Request StrongBox when available, gracefully falling back to TEE
            builder.setUnlockedDeviceRequired(false)
        }

        keyGenerator.init(builder.build())
        return keyGenerator.generateKey()
    }

    /**
     * Encrypts arbitrary secret material using the non-exportable AndroidKeyStore AES-256-GCM key.
     * Output format: [12-byte IV || ciphertext + 128-bit GCM tag] encoded in Base64 NO_WRAP.
     */
    fun wrapSecret(plaintext: ByteArray, aadContext: String = "splender-v17"): String {
        val secretKey = getOrCreateHardwareKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        cipher.updateAAD(aadContext.toByteArray(Charsets.UTF_8))
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext)

        val combined = ByteArray(1 + iv.size + ciphertext.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(ciphertext, 0, combined, 1 + iv.size, ciphertext.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Unwraps Base64-encoded secret material inside TEE/StrongBox.
     */
    fun unwrapSecret(wrappedBase64: String, aadContext: String = "splender-v17"): ByteArray {
        val combined = Base64.decode(wrappedBase64, Base64.NO_WRAP)
        require(combined.size > 16) { "Malformed Keystore envelope" }
        val ivLen = combined[0].toInt() and 0xFF
        require(ivLen in 12..16 && combined.size > 1 + ivLen) { "Invalid GCM IV length" }

        val iv = combined.copyOfRange(1, 1 + ivLen)
        val ciphertext = combined.copyOfRange(1 + ivLen, combined.size)

        val secretKey = getOrCreateHardwareKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
        cipher.updateAAD(aadContext.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(ciphertext)
    }

    /**
     * Retrieves or provisions a 32-byte local database encryption key wrapped by AndroidKeyStore.
     */
    @Synchronized
    fun getOrCreateLocalDbMasterKey(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existingWrapped = prefs.getString(DB_KEY_PREF, null)
        if (!existingWrapped.isNullOrEmpty()) {
            return try {
                unwrapSecret(existingWrapped, "splender-local-db-key")
            } catch (_: Throwable) {
                provisionFreshDbKey(prefs)
            }
        }
        return provisionFreshDbKey(prefs)
    }

    private fun provisionFreshDbKey(prefs: android.content.SharedPreferences): ByteArray {
        val freshKey = ByteArray(32)
        SecureRandom().nextBytes(freshKey)
        val wrapped = wrapSecret(freshKey, "splender-local-db-key")
        prefs.edit().putString(DB_KEY_PREF, wrapped).apply()
        return freshKey
    }
}
