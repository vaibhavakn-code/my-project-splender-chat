package com.splender.chat.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.splender.chat.MainActivity
import com.splender.chat.security.SplenderKeystoreVault

/**
 * SplenderNotificationHelper (Android 17 / API 37 Zero-Plaintext Notification & Push Token Manager)
 *
 * - Creates VISIBILITY_PRIVATE notification channels for E2EE messages, VoIP calls, and outbox sync.
 * - Never renders decrypted message previews on OS lock screens or system notification shade.
 * - Attaches FLAG_IMMUTABLE tap-to-navigate PendingIntents carrying only opaque conversationId metadata.
 * - Seals FCM push registration tokens via AndroidKeyStore before persisting locally.
 */
object SplenderNotificationHelper {
    const val CHANNEL_MESSAGES = "splender_e2ee_messages_v17"
    const val CHANNEL_VOIP_CALLS = "splender_voip_calls_v17"
    const val CHANNEL_OUTBOX_SYNC = "splender_outbox_sync_v17"
    const val EXTRA_CONVERSATION_ID = "splender_conversation_id"

    private const val PUSH_PREFS = "splender_push_vault_v17"
    private const val KEY_WRAPPED_FCM_TOKEN = "wrapped_fcm_token"

    @JvmStatic
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val messageChannel = NotificationChannel(
            CHANNEL_MESSAGES,
            "Encrypted Messages",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Zero-plaintext E2EE message arrival alerts"
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            enableVibration(true)
        }

        val callChannel = NotificationChannel(
            CHANNEL_VOIP_CALLS,
            "Peer-to-Peer Calls",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Ongoing encrypted WebRTC voice and video calls"
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            setSound(null, null)
        }

        val syncChannel = NotificationChannel(
            CHANNEL_OUTBOX_SYNC,
            "Encrypted Outbox Sync",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Background delivery of sealed offline outbox envelopes"
            lockscreenVisibility = Notification.VISIBILITY_SECRET
            setShowBadge(false)
        }

        nm.createNotificationChannels(listOf(messageChannel, callChannel, syncChannel))
    }

    @JvmStatic
    fun buildConversationTapIntent(context: Context, conversationId: String?): PendingIntent {
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (!conversationId.isNullOrBlank()) {
                putExtra(EXTRA_CONVERSATION_ID, conversationId)
            }
        }
        val reqCode = (conversationId ?: "root").hashCode()
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getActivity(context, reqCode, launchIntent, pendingFlags)
    }

    @JvmStatic
    fun postRedactedMessageNotification(
        context: Context,
        conversationId: String?,
        notificationId: Int = (conversationId ?: "msg").hashCode()
    ): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
        }

        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return false
        val pendingIntent = buildConversationTapIntent(context, conversationId)

        val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Splender Chat")
            .setContentText("New encrypted message")
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        nm.notify(notificationId, notification)
        return true
    }

    @JvmStatic
    fun storeSealedPushToken(context: Context, rawToken: String) {
        if (rawToken.isBlank()) return
        val wrapped = SplenderKeystoreVault.wrapSecret(
            rawToken.trim().toByteArray(Charsets.UTF_8),
            "splender-fcm-token-v17"
        )
        context.getSharedPreferences(PUSH_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_WRAPPED_FCM_TOKEN, wrapped)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    @JvmStatic
    fun loadSealedPushToken(context: Context): String? {
        val wrapped = context.getSharedPreferences(PUSH_PREFS, Context.MODE_PRIVATE)
            .getString(KEY_WRAPPED_FCM_TOKEN, null) ?: return null
        return try {
            String(
                SplenderKeystoreVault.unwrapSecret(wrapped, "splender-fcm-token-v17"),
                Charsets.UTF_8
            )
        } catch (_: Throwable) {
            null
        }
    }
}
