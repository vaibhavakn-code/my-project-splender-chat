package com.splender.chat.nativecore

import android.util.Log
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * SplenderNativeCore
 * Bridges high-performance C++/Rust cryptographic primitives via JNI
 * with automatic, seamless fallback to Java Standard Crypto when native library is unavailable.
 */
object SplenderNativeCore {
    private const val TAG = "SplenderNativeCore"
    private var isNativeLoaded = false

    init {
        try {
            System.loadLibrary("splender_p2p_core")
            isNativeLoaded = true
            Log.i(TAG, "Native core loaded successfully: " + getNativeCoreVersion())
        } catch (t: Throwable) {
            isNativeLoaded = false
            Log.w(TAG, "Native library 'splender_p2p_core' not loaded. Operating in Java/Kotlin cryptographic mode: " + t.message)
        }
    }

    fun isNativeReady(): Boolean = isNativeLoaded

    fun computeSha256(data: ByteArray): ByteArray {
        return if (isNativeLoaded) {
            try {
                computeSha256Native(data)
            } catch (t: Throwable) {
                fallbackSha256(data)
            }
        } else {
            fallbackSha256(data)
        }
    }

    fun computeHmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        return if (isNativeLoaded) {
            try {
                computeHmacSha256Native(key, data)
            } catch (t: Throwable) {
                fallbackHmacSha256(key, data)
            }
        } else {
            fallbackHmacSha256(key, data)
        }
    }

    fun deriveHkdf(salt: ByteArray?, ikm: ByteArray, info: ByteArray?, length: Int): ByteArray {
        return if (isNativeLoaded) {
            try {
                deriveHkdfNative(salt, ikm, info, length)
            } catch (t: Throwable) {
                fallbackHkdf(salt, ikm, info, length)
            }
        } else {
            fallbackHkdf(salt, ikm, info, length)
        }
    }

    /**
     * Signal Double Ratchet symmetric KDF_CK step:
     * Returns 64 bytes: [0..31] nextChainKey, [32..63] messageKey.
     */
    fun ratchetChainStep(chainKey32: ByteArray): ByteArray {
        require(chainKey32.size == 32) { "Chain key must be 32 bytes" }
        return if (isNativeLoaded) {
            try {
                ratchetChainStepNative(chainKey32)
            } catch (t: Throwable) {
                fallbackRatchetChainStep(chainKey32)
            }
        } else {
            fallbackRatchetChainStep(chainKey32)
        }
    }

    /**
     * Local DB Page Encryption:
     * Native path uses C11 ChaCha20 + HMAC-SHA256 (12-byte nonce + ciphertext + 32-byte MAC).
     * JVM fallback uses AES-256-GCM with 12-byte IV + 16-byte authentication tag.
     */
    fun encryptLocalDbPage(masterKey32: ByteArray, pageNumber: Int, plaintext: ByteArray): ByteArray {
        require(masterKey32.size == 32) { "Master key must be 32 bytes" }
        return if (isNativeLoaded) {
            try {
                encryptLocalDbPageNative(masterKey32, pageNumber, plaintext)
            } catch (t: Throwable) {
                fallbackEncryptPage(masterKey32, pageNumber, plaintext)
            }
        } else {
            fallbackEncryptPage(masterKey32, pageNumber, plaintext)
        }
    }

    fun decryptLocalDbPage(masterKey32: ByteArray, pageNumber: Int, sealedFrame: ByteArray): ByteArray? {
        require(masterKey32.size == 32) { "Master key must be 32 bytes" }
        return if (isNativeLoaded) {
            try {
                decryptLocalDbPageNative(masterKey32, pageNumber, sealedFrame)
            } catch (t: Throwable) {
                fallbackDecryptPage(masterKey32, pageNumber, sealedFrame)
            }
        } else {
            fallbackDecryptPage(masterKey32, pageNumber, sealedFrame)
        }
    }

    // --- Pure Java Fallback Implementations ---
    private fun fallbackSha256(data: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(data)
    }

    private fun fallbackHmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    private fun fallbackRatchetChainStep(chainKey32: ByteArray): ByteArray {
        val msgKey = fallbackHmacSha256(chainKey32, byteArrayOf(0x01))
        val nextChainKey = fallbackHmacSha256(chainKey32, byteArrayOf(0x02))
        val out = ByteArray(64)
        System.arraycopy(nextChainKey, 0, out, 0, 32)
        System.arraycopy(msgKey, 0, out, 32, 32)
        return out
    }

    private fun fallbackEncryptPage(masterKey32: ByteArray, pageNumber: Int, plaintext: ByteArray): ByteArray {
        val pageKey = fallbackHkdf(
            "SplenderLocalDbSaltV17".toByteArray(Charsets.UTF_8),
            masterKey32,
            "page:$pageNumber".toByteArray(Charsets.UTF_8),
            32
        )
        val iv = ByteArray(12)
        java.security.SecureRandom().nextBytes(iv)
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            javax.crypto.Cipher.ENCRYPT_MODE,
            SecretKeySpec(pageKey, "AES"),
            javax.crypto.spec.GCMParameterSpec(128, iv)
        )
        cipher.updateAAD("page:$pageNumber".toByteArray(Charsets.UTF_8))
        val ciphertext = cipher.doFinal(plaintext)
        val out = ByteArray(12 + ciphertext.size)
        System.arraycopy(iv, 0, out, 0, 12)
        System.arraycopy(ciphertext, 0, out, 12, ciphertext.size)
        return out
    }

    private fun fallbackDecryptPage(masterKey32: ByteArray, pageNumber: Int, sealedFrame: ByteArray): ByteArray? {
        if (sealedFrame.size < 28) return null
        return try {
            val pageKey = fallbackHkdf(
                "SplenderLocalDbSaltV17".toByteArray(Charsets.UTF_8),
                masterKey32,
                "page:$pageNumber".toByteArray(Charsets.UTF_8),
                32
            )
            val iv = sealedFrame.copyOfRange(0, 12)
            val ciphertext = sealedFrame.copyOfRange(12, sealedFrame.size)
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                javax.crypto.Cipher.DECRYPT_MODE,
                SecretKeySpec(pageKey, "AES"),
                javax.crypto.spec.GCMParameterSpec(128, iv)
            )
            cipher.updateAAD("page:$pageNumber".toByteArray(Charsets.UTF_8))
            cipher.doFinal(ciphertext)
        } catch (t: Throwable) {
            null
        }
    }

    private fun fallbackHkdf(salt: ByteArray?, ikm: ByteArray, info: ByteArray?, length: Int): ByteArray {
        val actualSalt = salt ?: ByteArray(32)
        val prk = fallbackHmacSha256(actualSalt, ikm)
        val okm = ByteArray(length)
        var t = ByteArray(0)
        var generated = 0
        var i = 1

        while (generated < length) {
            val stepData = java.io.ByteArrayOutputStream()
            stepData.write(t)
            if (info != null) stepData.write(info)
            stepData.write(i)
            t = fallbackHmacSha256(prk, stepData.toByteArray())
            val toCopy = Math.min(32, length - generated)
            System.arraycopy(t, 0, okm, generated, toCopy)
            generated += toCopy
            i++
        }
        return okm
    }

    // --- JNI External C/C++/Rust Declarations ---
    @JvmStatic
    external fun getNativeCoreVersion(): String

    @JvmStatic
    external fun computeSha256Native(input: ByteArray): ByteArray

    @JvmStatic
    external fun computeHmacSha256Native(key: ByteArray, data: ByteArray): ByteArray

    @JvmStatic
    external fun deriveHkdfNative(salt: ByteArray?, ikm: ByteArray, info: ByteArray?, length: Int): ByteArray

    @JvmStatic
    external fun ratchetChainStepNative(chainKey32: ByteArray): ByteArray

    @JvmStatic
    external fun encryptLocalDbPageNative(masterKey32: ByteArray, pageNumber: Int, plaintext: ByteArray): ByteArray

    @JvmStatic
    external fun decryptLocalDbPageNative(masterKey32: ByteArray, pageNumber: Int, sealedFrame: ByteArray): ByteArray?
}
