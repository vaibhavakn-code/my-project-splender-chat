package com.splender.chat.plugins

import android.util.Base64
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.splender.chat.media.NativeMediaCompressor
import com.splender.chat.work.MediaCompressionWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * MediaCompressionPlugin (Kotlin Capacitor Bridge for Client-Side Image & Voice-Note Compression)
 *
 * Exposes both direct off-main-thread coroutine compression and WorkManager-backed
 * background compression jobs (`MediaCompressionWorker`) to the React/TypeScript layer.
 */
@CapacitorPlugin(name = "SplenderMediaCompression")
class MediaCompressionPlugin : Plugin() {

    private val pluginScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun handleOnDestroy() {
        pluginScope.cancel()
        super.handleOnDestroy()
    }

    @PluginMethod
    fun compressImage(call: PluginCall) {
        val base64Input = call.getString("dataBase64")
        val filePathInput = call.getString("filePath")
        val maxDimension = call.getInt("maxDimension", 1440) ?: 1440
        val quality = call.getInt("quality", 82) ?: 82

        pluginScope.launch {
            var tempInput: File? = null
            try {
                val cacheDir = File(context.cacheDir, "splender_compressed_media").apply { mkdirs() }
                val sourceFile = when {
                    !filePathInput.isNullOrBlank() -> File(filePathInput)
                    !base64Input.isNullOrBlank() -> {
                        val decoded = Base64.decode(stripDataUriHeader(base64Input), Base64.DEFAULT)
                        File(cacheDir, "tmp_in_${System.nanoTime()}.img").also { tmp ->
                            FileOutputStream(tmp).use { it.write(decoded) }
                            tempInput = tmp
                        }
                    }
                    else -> {
                        call.reject("Either dataBase64 or filePath is required")
                        return@launch
                    }
                }

                val result = NativeMediaCompressor.compressImageFile(
                    sourceFile,
                    cacheDir,
                    maxDimension,
                    quality
                )

                val outBytes = result.outputFile.readBytes()
                val outBase64 = Base64.encodeToString(outBytes, Base64.NO_WRAP)

                val ret = JSObject().apply {
                    put("outputPath", result.outputFile.absolutePath)
                    put("dataBase64", outBase64)
                    put("mimeType", result.mimeType)
                    put("width", result.width)
                    put("height", result.height)
                    put("originalBytes", result.originalBytes)
                    put("compressedBytes", result.compressedBytes)
                    put("savingsRatio", result.savingsRatio)
                    put("sha256Hex", result.sha256Hex)
                }
                call.resolve(ret)
            } catch (t: Throwable) {
                call.reject("Native image compression failed: ${t.message}")
            } finally {
                tempInput?.delete()
            }
        }
    }

    @PluginMethod
    fun compressVoiceNote(call: PluginCall) {
        val base64Input = call.getString("dataBase64")
        val filePathInput = call.getString("filePath")
        val bitrateBps = call.getInt("bitrateBps", 48_000) ?: 48_000

        pluginScope.launch {
            var tempInput: File? = null
            try {
                val cacheDir = File(context.cacheDir, "splender_compressed_media").apply { mkdirs() }
                val sourceFile = when {
                    !filePathInput.isNullOrBlank() -> File(filePathInput)
                    !base64Input.isNullOrBlank() -> {
                        val decoded = Base64.decode(stripDataUriHeader(base64Input), Base64.DEFAULT)
                        File(cacheDir, "tmp_voice_${System.nanoTime()}.m4a").also { tmp ->
                            FileOutputStream(tmp).use { it.write(decoded) }
                            tempInput = tmp
                        }
                    }
                    else -> {
                        call.reject("Either dataBase64 or filePath is required")
                        return@launch
                    }
                }

                val result = NativeMediaCompressor.compressVoiceNoteFile(
                    sourceFile,
                    cacheDir,
                    bitrateBps
                )

                val outBytes = result.outputFile.readBytes()
                val outBase64 = Base64.encodeToString(outBytes, Base64.NO_WRAP)

                val ret = JSObject().apply {
                    put("outputPath", result.outputFile.absolutePath)
                    put("dataBase64", outBase64)
                    put("mimeType", result.mimeType)
                    put("originalBytes", result.originalBytes)
                    put("compressedBytes", result.compressedBytes)
                    put("savingsRatio", result.savingsRatio)
                    put("sha256Hex", result.sha256Hex)
                }
                call.resolve(ret)
            } catch (t: Throwable) {
                call.reject("Native voice-note compression failed: ${t.message}")
            } finally {
                tempInput?.delete()
            }
        }
    }

    @PluginMethod
    fun enqueueBackgroundCompression(call: PluginCall) {
        val mediaKind = call.getString("mediaKind", MediaCompressionWorker.KIND_IMAGE)
            ?: MediaCompressionWorker.KIND_IMAGE
        val inputPath = call.getString("inputPath")
        if (inputPath.isNullOrBlank()) {
            call.reject("inputPath is required for WorkManager background compression")
            return
        }

        val maxDimension = call.getInt("maxDimension", 1440) ?: 1440
        val quality = call.getInt("quality", 82) ?: 82
        val bitrateBps = call.getInt("bitrateBps", 48_000) ?: 48_000

        val workId = MediaCompressionWorker.enqueueJob(
            context,
            mediaKind,
            inputPath,
            maxDimension,
            quality,
            bitrateBps
        )

        val ret = JSObject().apply {
            put("workId", workId.toString())
            put("enqueued", true)
            put("mediaKind", mediaKind)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun getCompressionWorkStatus(call: PluginCall) {
        val workIdStr = call.getString("workId")
        if (workIdStr.isNullOrBlank()) {
            call.reject("workId is required")
            return
        }

        pluginScope.launch {
            try {
                val uuid = UUID.fromString(workIdStr)
                val info: WorkInfo? = WorkManager.getInstance(context).getWorkInfoById(uuid).get()
                if (info == null) {
                    call.reject("WorkInfo not found for $workIdStr")
                    return@launch
                }

                val out = info.outputData
                val ret = JSObject().apply {
                    put("workId", workIdStr)
                    put("state", info.state.name)
                    put("progress", info.progress.getInt(MediaCompressionWorker.KEY_PROGRESS, 0))
                    if (info.state == WorkInfo.State.SUCCEEDED) {
                        put("outputPath", out.getString(MediaCompressionWorker.KEY_OUTPUT_PATH))
                        put("mimeType", out.getString(MediaCompressionWorker.KEY_MIME_TYPE))
                        put("originalBytes", out.getLong(MediaCompressionWorker.KEY_ORIGINAL_BYTES, 0L))
                        put("compressedBytes", out.getLong(MediaCompressionWorker.KEY_COMPRESSED_BYTES, 0L))
                        put("sha256Hex", out.getString(MediaCompressionWorker.KEY_SHA256_HEX))
                    } else if (info.state == WorkInfo.State.FAILED) {
                        put("error", out.getString(MediaCompressionWorker.KEY_ERROR))
                    }
                }
                call.resolve(ret)
            } catch (t: Throwable) {
                call.reject("Failed to query compression job status: ${t.message}")
            }
        }
    }

    private fun stripDataUriHeader(raw: String): String {
        val commaIdx = raw.indexOf(',')
        return if (commaIdx >= 0) raw.substring(commaIdx + 1) else raw
    }
}
