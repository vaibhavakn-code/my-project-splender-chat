package com.splender.chat.webrtc

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.splender.chat.nativecore.SplenderNativeCore
import com.splender.chat.service.SplenderCallService
import com.splender.chat.service.SplenderNotificationHelper
import com.splender.chat.service.SplenderSyncService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext
import kotlin.math.min

/**
 * StreamingSha256 (Pure FIPS 180-4 Incremental SHA-256 State Machine)
 *
 * Processes arbitrarily large files (1 GB – 100 GB+) in bounded 64-byte blocks with a 64-bit
 * unsigned bit-length counter (`ULong`), maintaining strictly O(1) heap footprint without
 * ever allocating full-file byte arrays on mobile devices.
 */
class StreamingSha256 {
    private val state = intArrayOf(
        0x6a09e667,
        0xbb67ae85.toInt(),
        0x3c6ef372,
        0xa54ff53a.toInt(),
        0x510e527f,
        0x9b05688c.toInt(),
        0x1f83d9ab,
        0x5be0cd19
    )
    private val block = ByteArray(64)
    private val schedule = IntArray(64)
    private var blockLen = 0
    private var totalBytes: ULong = 0uL

    fun reset() {
        state[0] = 0x6a09e667
        state[1] = 0xbb67ae85.toInt()
        state[2] = 0x3c6ef372
        state[3] = 0xa54ff53a.toInt()
        state[4] = 0x510e527f
        state[5] = 0x9b05688c.toInt()
        state[6] = 0x1f83d9ab
        state[7] = 0x5be0cd19
        block.fill(0)
        schedule.fill(0)
        blockLen = 0
        totalBytes = 0uL
    }

    fun update(chunk: ByteArray, offset: Int = 0, length: Int = chunk.size - offset) {
        require(offset >= 0 && length >= 0 && offset + length <= chunk.size) {
            "Invalid chunk bounds (offset=$offset, length=$length, size=${chunk.size})"
        }
        var cursor = offset
        val end = offset + length
        totalBytes += length.toULong()

        if (blockLen > 0) {
            val needed = 64 - blockLen
            if (length < needed) {
                System.arraycopy(chunk, cursor, block, blockLen, length)
                blockLen += length
                return
            }
            System.arraycopy(chunk, cursor, block, blockLen, needed)
            compressBlock(block, 0)
            blockLen = 0
            cursor += needed
        }

        while (cursor + 64 <= end) {
            compressBlock(chunk, cursor)
            cursor += 64
        }

        if (cursor < end) {
            val tail = end - cursor
            System.arraycopy(chunk, cursor, block, 0, tail)
            blockLen = tail
        }
    }

    fun digestBytes(): ByteArray {
        val bitLen: ULong = totalBytes * 8uL
        block[blockLen++] = 0x80.toByte()

        if (blockLen > 56) {
            block.fill(0, blockLen, 64)
            compressBlock(block, 0)
            blockLen = 0
        }

        block.fill(0, blockLen, 56)
        ByteBuffer.wrap(block, 56, 8)
            .order(ByteOrder.BIG_ENDIAN)
            .putLong(bitLen.toLong())
        compressBlock(block, 0)

        val out = ByteArray(32)
        val outBuf = ByteBuffer.wrap(out).order(ByteOrder.BIG_ENDIAN)
        for (i in 0 until 8) {
            outBuf.putInt(state[i])
        }
        return out
    }

    fun digestHex(): String {
        return digestBytes().joinToString("") { "%02x".format(it) }
    }

    private fun compressBlock(src: ByteArray, offset: Int) {
        val w = schedule
        for (i in 0 until 16) {
            val j = offset + i * 4
            w[i] = ((src[j].toInt() and 0xFF) shl 24) or
                ((src[j + 1].toInt() and 0xFF) shl 16) or
                ((src[j + 2].toInt() and 0xFF) shl 8) or
                (src[j + 3].toInt() and 0xFF)
        }
        for (i in 16 until 64) {
            val v0 = w[i - 15]
            val s0 = v0.rotateRight(7) xor v0.rotateRight(18) xor (v0 ushr 3)
            val v1 = w[i - 2]
            val s1 = v1.rotateRight(17) xor v1.rotateRight(19) xor (v1 ushr 10)
            w[i] = w[i - 16] + s0 + w[i - 7] + s1
        }

        var a = state[0]
        var b = state[1]
        var c = state[2]
        var d = state[3]
        var e = state[4]
        var f = state[5]
        var g = state[6]
        var h = state[7]

        for (i in 0 until 64) {
            val bigS1 = e.rotateRight(6) xor e.rotateRight(11) xor e.rotateRight(25)
            val ch = (e and f) xor (e.inv() and g)
            val temp1 = h + bigS1 + ch + SHA256_K[i] + w[i]
            val bigS0 = a.rotateRight(2) xor a.rotateRight(13) xor a.rotateRight(22)
            val maj = (a and b) xor (a and c) xor (b and c)
            val temp2 = bigS0 + maj

            h = g
            g = f
            f = e
            e = d + temp1
            d = c
            c = b
            b = a
            a = temp1 + temp2
        }

        state[0] += a
        state[1] += b
        state[2] += c
        state[3] += d
        state[4] += e
        state[5] += f
        state[6] += g
        state[7] += h
    }

    companion object {
        private val SHA256_K = intArrayOf(
            0x428a2f98, 0x71374491, 0xb5c0fbcf.toInt(), 0xe9b5dba5.toInt(),
            0x3956c25b, 0x59f111f1, 0x923f82a4.toInt(), 0xab1c5ed5.toInt(),
            0xd807aa98.toInt(), 0x12835b01, 0x243185be, 0x550c7dc3,
            0x72be5d74, 0x80deb1fe.toInt(), 0x9bdc06a7.toInt(), 0xc19bf174.toInt(),
            0xe49b69c1.toInt(), 0xefbe4786.toInt(), 0x0fc19dc6, 0x240ca1cc,
            0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152.toInt(), 0xa831c66d.toInt(), 0xb00327c8.toInt(), 0xbf597fc7.toInt(),
            0xc6e00bf3.toInt(), 0xd5a79147.toInt(), 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
            0x650a7354, 0x766a0abb, 0x81c2c92e.toInt(), 0x92722c85.toInt(),
            0xa2bfe8a1.toInt(), 0xa81a664b.toInt(), 0xc24b8b70.toInt(), 0xc76c51a3.toInt(),
            0xd192e819.toInt(), 0xd6990624.toInt(), 0xf40e3585.toInt(), 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
            0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814.toInt(), 0x8cc70208.toInt(),
            0x90befffa.toInt(), 0xa4506ceb.toInt(), 0xbef9a3f7.toInt(), 0xc67178f2.toInt()
        )
    }
}

/**
 * SctpDataChannelSink
 * Abstraction over WebRTC `DataChannel` enabling backpressure-regulated 64 KB binary framing.
 */
interface SctpDataChannelSink {
    val isOpen: Boolean
    val bufferedAmountBytes: Long
    var bufferedAmountLowThreshold: Long
    fun registerBufferedAmountLowObserver(onDrain: () -> Unit)
    fun sendBinaryFrame(frame: ByteBuffer): Boolean
}

data class StreamTransferManifest(
    val transferId: String,
    val totalBytes: Long,
    val totalChunks: Int,
    val resumeFromChunk: Int,
    val fullStreamSha256Hex: String,
    val durationMs: Long
)

data class WebRtcCallSessionState(
    val active: Boolean = false,
    val conversationId: String? = null,
    val isVideo: Boolean = false,
    val speakerphoneEnabled: Boolean = false,
    val muted: Boolean = false
)

/**
 * SplenderP2PStreamingPipeline
 *
 * Pre-initialized 64 KB sliced SCTP DataChannel streaming engine & WebRTC Call/Sync coordinator:
 * - Streams 1 GB+ files using bounded 64 KB slices (`CHUNK_SIZE_BYTES = 65_536`) on `Dispatchers.IO`,
 *   matching the hybrid Web `Blob.slice` architecture with zero full-file RAM buffering.
 * - Enforces SCTP congestion control (`HIGH_WATERMARK = 1 MB`, `LOW_WATERMARK = 256 KB`).
 * - Computes both per-slice SHA-256 integrity tags (via JNI C++/Rust or JVM) and full-file
 *   incremental FIPS 180-4 `StreamingSha256` digests.
 * - Coordinates WebRTC Audio/Video foreground execution via `SplenderCallService` and sealed
 *   outbox burst synchronization via `SplenderSyncService`.
 */
object SplenderP2PStreamingPipeline {
    private const val TAG = "SplenderP2PPipeline"
    const val CHUNK_SIZE_BYTES: Int = 64 * 1024 // 64 KB SCTP frame slice
    const val SCTP_LOW_WATERMARK_BYTES: Long = 256L * 1024L // 256 KB resume threshold
    const val SCTP_HIGH_WATERMARK_BYTES: Long = 1024L * 1024L // 1 MB backpressure pause ceiling
    private const val FRAME_HEADER_BYTES: Int = 40 // [4B magic | 4B chunkIdx | 32B chunkSha256]
    private const val FRAME_MAGIC: Int = 0x53504C31 // "SPL1"

    private val _callState = MutableStateFlow(WebRtcCallSessionState())
    val callState: StateFlow<WebRtcCallSessionState> = _callState.asStateFlow()

    @Volatile
    private var pipelinePrewarmed = false

    /**
     * Pre-warms FIPS 180-4 SHA-256 self-test vectors, JNI crypto symbols, and notification channels
     * on `Dispatchers.IO` during `SplenderApplication.onCreate()`.
     */
    suspend fun prewarmPipeline(
        context: Context,
        ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    ): Boolean = withContext(ioDispatcher) {
        if (pipelinePrewarmed) return@withContext true

        SplenderNotificationHelper.ensureChannels(context.applicationContext)

        // FIPS 180-4 deterministic self-test ("abc") before accepting P2P transfers
        val selfTestHasher = StreamingSha256()
        selfTestHasher.update("abc".toByteArray(Charsets.UTF_8))
        val digest = selfTestHasher.digestHex()
        check(digest == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") {
            "FIPS 180-4 StreamingSha256 self-test failed: $digest"
        }

        // Touch JNI core so native page-aligned symbols are resolved off the UI thread
        val nativeReady = SplenderNativeCore.isNativeReady()
        pipelinePrewarmed = true
        Log.i(TAG, "1GB+ 64KB SCTP streaming pipeline pre-warmed (nativeJni=$nativeReady)")
        true
    }

    fun isPrewarmed(): Boolean = pipelinePrewarmed

    /**
     * Computes the full-file SHA-256 digest of a local `File` or `content://` `Uri` (1 GB+ safe)
     * in bounded 64 KB slices on `Dispatchers.IO`.
     */
    suspend fun computeFileSha256Streaming(
        context: Context,
        uriOrFile: Any,
        ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    ): String = withContext(ioDispatcher) {
        val hasher = StreamingSha256()
        val sliceBuffer = ByteArray(CHUNK_SIZE_BYTES)

        openBoundedStream(context, uriOrFile).use { input ->
            while (true) {
                coroutineContext.ensureActive()
                val read = input.read(sliceBuffer)
                if (read <= 0) break
                hasher.update(sliceBuffer, 0, read)
            }
        }
        hasher.digestHex()
    }

    /**
     * Streams a large file (including 1 GB+ media archives) across an `SctpDataChannelSink`
     * in 64 KB slices with backpressure throttling, resume support, and per-chunk + full-stream SHA-256.
     */
    suspend fun streamFileOverDataChannel(
        context: Context,
        transferId: String,
        sourceFile: File,
        sink: SctpDataChannelSink,
        resumeFromChunk: Int = 0,
        ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
        onProgress: (sentBytes: Long, totalBytes: Long, chunkIndex: Int) -> Unit = { _, _, _ -> }
    ): Result<StreamTransferManifest> = withContext(ioDispatcher) {
        runCatching {
            require(sourceFile.exists() && sourceFile.isFile) {
                "Source file does not exist: ${sourceFile.absolutePath}"
            }
            val totalBytes = sourceFile.length()
            val totalChunks = if (totalBytes == 0L) 1 else ((totalBytes + CHUNK_SIZE_BYTES - 1L) / CHUNK_SIZE_BYTES).toInt()
            val clampedResume = resumeFromChunk.coerceIn(0, (totalChunks - 1).coerceAtLeast(0))
            val startTimeMs = System.currentTimeMillis()

            sink.bufferedAmountLowThreshold = SCTP_LOW_WATERMARK_BYTES

            val fullFileHasher = StreamingSha256()
            val reusableSlice = ByteArray(CHUNK_SIZE_BYTES)
            val directFrame = ByteBuffer.allocateDirect(FRAME_HEADER_BYTES + CHUNK_SIZE_BYTES)
                .order(ByteOrder.BIG_ENDIAN)

            FileInputStream(sourceFile).channel.use { fileChannel ->
                var chunkIndex = 0
                var offsetBytes = 0L

                while (offsetBytes < totalBytes || (totalBytes == 0L && chunkIndex == 0)) {
                    coroutineContext.ensureActive()
                    check(sink.isOpen) { "SCTP DataChannel closed mid-stream at chunk $chunkIndex" }

                    val sliceSize = min(CHUNK_SIZE_BYTES.toLong(), totalBytes - offsetBytes).toInt()
                    if (sliceSize > 0) {
                        val readBuf = ByteBuffer.wrap(reusableSlice, 0, sliceSize)
                        var totalReadInSlice = 0
                        while (totalReadInSlice < sliceSize) {
                            val n = fileChannel.read(readBuf, offsetBytes + totalReadInSlice)
                            if (n <= 0) break
                            totalReadInSlice += n
                        }
                        check(totalReadInSlice == sliceSize) {
                            "Truncated slice read at offset $offsetBytes ($totalReadInSlice != $sliceSize)"
                        }
                        fullFileHasher.update(reusableSlice, 0, sliceSize)
                    }

                    // Skip network transmission for already-acknowledged chunks while keeping full-stream hash accurate
                    if (chunkIndex >= clampedResume) {
                        awaitSctpBackpressureDrain(sink)

                        val chunkSliceCopy = if (sliceSize == reusableSlice.size) {
                            reusableSlice
                        } else {
                            reusableSlice.copyOfRange(0, sliceSize)
                        }
                        val chunkDigest32 = SplenderNativeCore.computeSha256(chunkSliceCopy)

                        directFrame.clear()
                        directFrame.putInt(FRAME_MAGIC)
                        directFrame.putInt(chunkIndex)
                        directFrame.put(chunkDigest32, 0, 32)
                        if (sliceSize > 0) {
                            directFrame.put(reusableSlice, 0, sliceSize)
                        }
                        directFrame.flip()

                        val dispatched = sink.sendBinaryFrame(directFrame)
                        check(dispatched) { "DataChannel rejected binary frame at chunk $chunkIndex" }
                    }

                    offsetBytes += sliceSize.toLong()
                    chunkIndex += 1
                    onProgress(offsetBytes, totalBytes, chunkIndex)

                    if (totalBytes == 0L) break
                }
            }

            StreamTransferManifest(
                transferId = transferId,
                totalBytes = totalBytes,
                totalChunks = totalChunks,
                resumeFromChunk = clampedResume,
                fullStreamSha256Hex = fullFileHasher.digestHex(),
                durationMs = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(1L)
            )
        }
    }

    private suspend fun awaitSctpBackpressureDrain(sink: SctpDataChannelSink) {
        if (sink.bufferedAmountBytes < SCTP_HIGH_WATERMARK_BYTES) return

        val drainSignal = CompletableDeferred<Unit>()
        sink.registerBufferedAmountLowObserver {
            if (!drainSignal.isCompleted) {
                drainSignal.complete(Unit)
            }
        }
        if (sink.bufferedAmountBytes < SCTP_HIGH_WATERMARK_BYTES) {
            drainSignal.complete(Unit)
        }
        drainSignal.await()
    }

    private fun openBoundedStream(context: Context, uriOrFile: Any): InputStream {
        return when (uriOrFile) {
            is File -> FileInputStream(uriOrFile)
            is Uri -> requireNotNull(context.contentResolver.openInputStream(uriOrFile)) {
                "Unable to open ContentResolver stream for $uriOrFile"
            }
            else -> throw IllegalArgumentException("Unsupported stream source: ${uriOrFile::class.java.name}")
        }
    }

    // --- WebRTC Audio/Video Call & Outbox ForegroundService Integration ---
    suspend fun startEncryptedCallSession(
        context: Context,
        conversationId: String,
        isVideo: Boolean,
        enableSpeaker: Boolean = isVideo
    ) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        configureCallAudioRouting(appContext, active = true, speakerphone = enableSpeaker)
        SplenderCallService.startActiveCall(appContext, isVideo = isVideo, conversationId = conversationId)
        _callState.update {
            WebRtcCallSessionState(
                active = true,
                conversationId = conversationId,
                isVideo = isVideo,
                speakerphoneEnabled = enableSpeaker,
                muted = false
            )
        }
    }

    suspend fun endEncryptedCallSession(context: Context) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        SplenderCallService.stopActiveCall(appContext)
        configureCallAudioRouting(appContext, active = false, speakerphone = false)
        _callState.update { WebRtcCallSessionState() }
    }

    fun triggerForegroundOutboxSync(context: Context) {
        SplenderSyncService.startFlushBurst(context.applicationContext)
    }

    private fun configureCallAudioRouting(context: Context, active: Boolean, speakerphone: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (active) {
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val targetType = if (speakerphone) {
                        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    } else {
                        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                    }
                    val device = audioManager.availableCommunicationDevices
                        .firstOrNull { it.type == targetType }
                    if (device != null) {
                        audioManager.setCommunicationDevice(device)
                    }
                } else {
                    @Suppress("DEPRECATION")
                    audioManager.isSpeakerphoneOn = speakerphone
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    audioManager.clearCommunicationDevice()
                } else {
                    @Suppress("DEPRECATION")
                    audioManager.isSpeakerphoneOn = false
                }
                audioManager.mode = AudioManager.MODE_NORMAL
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Audio routing update warning: ${t.message}")
        }
    }
}
