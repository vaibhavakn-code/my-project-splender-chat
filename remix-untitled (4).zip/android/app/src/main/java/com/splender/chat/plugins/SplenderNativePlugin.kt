package com.splender.chat.plugins

import android.Manifest
import android.os.Build
import android.util.Base64
import android.view.WindowManager
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import com.splender.chat.nativecore.SplenderNativeCore
import com.splender.chat.permissions.SplenderPermissionsHelper
import com.splender.chat.security.SplenderKeystoreVault
import com.splender.chat.service.SplenderCallService
import com.splender.chat.service.SplenderNotificationHelper
import com.splender.chat.work.SplenderOutboxWorker

@CapacitorPlugin(
    name = "SplenderNative",
    permissions = [
        Permission(strings = [Manifest.permission.CAMERA], alias = "camera"),
        Permission(strings = [Manifest.permission.RECORD_AUDIO], alias = "microphone"),
        Permission(strings = ["android.permission.POST_NOTIFICATIONS"], alias = "notifications"),
        Permission(strings = ["android.permission.NEARBY_WIFI_DEVICES"], alias = "nearbyWifi"),
        Permission(strings = ["android.permission.ACCESS_LOCAL_NETWORK"], alias = "localNetwork")
    ]
)
class SplenderNativePlugin : Plugin() {

    @PluginMethod
    fun getCoreStatus(call: PluginCall) {
        val ret = JSObject()
        val nativeReady = SplenderNativeCore.isNativeReady()
        ret.put("isNativeReady", nativeReady)
        ret.put(
            "version",
            if (nativeReady) SplenderNativeCore.getNativeCoreVersion() else "Splender-Keystore-JVM/v17.0"
        )
        ret.put("targetSdk", 37)
        ret.put("minSdk", 24)
        ret.put("deviceSdk", Build.VERSION.SDK_INT)
        ret.put("arch", System.getProperty("os.arch"))
        ret.put("keystoreBacked", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun computeSha256(call: PluginCall) {
        val inputStr = call.getString("data")
        val inputBase64 = call.getString("dataBase64")
        val bytes = when {
            inputBase64 != null -> Base64.decode(inputBase64, Base64.NO_WRAP)
            inputStr != null -> inputStr.toByteArray(Charsets.UTF_8)
            else -> {
                call.reject("data or dataBase64 is required")
                return
            }
        }

        val digest = SplenderNativeCore.computeSha256(bytes)
        val hex = digest.joinToString("") { "%02x".format(it) }

        val ret = JSObject()
        ret.put("hex", hex)
        ret.put("base64", Base64.encodeToString(digest, Base64.NO_WRAP))
        call.resolve(ret)
    }

    @PluginMethod
    fun computeHmacSha256(call: PluginCall) {
        val keyStr = call.getString("key")
        val dataStr = call.getString("data")
        if (keyStr == null || dataStr == null) {
            call.reject("Key and Data are required")
            return
        }

        val key = keyStr.toByteArray(Charsets.UTF_8)
        val data = dataStr.toByteArray(Charsets.UTF_8)
        val mac = SplenderNativeCore.computeHmacSha256(key, data)
        val hex = mac.joinToString("") { "%02x".format(it) }

        val ret = JSObject()
        ret.put("macHex", hex)
        ret.put("macBase64", Base64.encodeToString(mac, Base64.NO_WRAP))
        call.resolve(ret)
    }

    @PluginMethod
    fun ratchetChainStep(call: PluginCall) {
        val chainKeyBase64 = call.getString("chainKeyBase64")
        if (chainKeyBase64.isNullOrEmpty()) {
            call.reject("chainKeyBase64 is required")
            return
        }
        val raw = Base64.decode(chainKeyBase64, Base64.NO_WRAP)
        val normalized = if (raw.size == 32) raw else SplenderNativeCore.computeSha256(raw)
        val stepped = SplenderNativeCore.ratchetChainStep(normalized)
        val nextChainKey = stepped.copyOfRange(0, 32)
        val messageKey = stepped.copyOfRange(32, 64)

        val ret = JSObject()
        ret.put("nextChainKeyBase64", Base64.encodeToString(nextChainKey, Base64.NO_WRAP))
        ret.put("messageKeyBase64", Base64.encodeToString(messageKey, Base64.NO_WRAP))
        call.resolve(ret)
    }

    @PluginMethod
    fun encryptLocalPage(call: PluginCall) {
        val plaintext = call.getString("plaintext")
        val pageNumber = call.getInt("pageNumber", 1) ?: 1
        if (plaintext == null) {
            call.reject("plaintext is required")
            return
        }
        val masterKey = SplenderKeystoreVault.getOrCreateLocalDbMasterKey(context)
        val sealed = SplenderNativeCore.encryptLocalDbPage(
            masterKey,
            pageNumber,
            plaintext.toByteArray(Charsets.UTF_8)
        )
        val ret = JSObject()
        ret.put("sealedBase64", Base64.encodeToString(sealed, Base64.NO_WRAP))
        call.resolve(ret)
    }

    @PluginMethod
    fun decryptLocalPage(call: PluginCall) {
        val sealedBase64 = call.getString("sealedBase64")
        val pageNumber = call.getInt("pageNumber", 1) ?: 1
        if (sealedBase64.isNullOrEmpty()) {
            call.reject("sealedBase64 is required")
            return
        }
        val masterKey = SplenderKeystoreVault.getOrCreateLocalDbMasterKey(context)
        val sealed = Base64.decode(sealedBase64, Base64.NO_WRAP)
        val plain = SplenderNativeCore.decryptLocalDbPage(masterKey, pageNumber, sealed)
        if (plain == null) {
            call.reject("Local DB page MAC verification failed")
            return
        }
        val ret = JSObject()
        ret.put("plaintext", String(plain, Charsets.UTF_8))
        call.resolve(ret)
    }

    @PluginMethod
    fun wrapSecretInKeystore(call: PluginCall) {
        val secret = call.getString("secret")
        val aad = call.getString("aad", "splender-v17") ?: "splender-v17"
        if (secret == null) {
            call.reject("secret is required")
            return
        }
        val wrapped = SplenderKeystoreVault.wrapSecret(secret.toByteArray(Charsets.UTF_8), aad)
        val ret = JSObject()
        ret.put("wrappedBase64", wrapped)
        call.resolve(ret)
    }

    @PluginMethod
    fun unwrapSecretFromKeystore(call: PluginCall) {
        val wrappedBase64 = call.getString("wrappedBase64")
        val aad = call.getString("aad", "splender-v17") ?: "splender-v17"
        if (wrappedBase64.isNullOrEmpty()) {
            call.reject("wrappedBase64 is required")
            return
        }
        return try {
            val unwrapped = SplenderKeystoreVault.unwrapSecret(wrappedBase64, aad)
            val ret = JSObject()
            ret.put("secret", String(unwrapped, Charsets.UTF_8))
            call.resolve(ret)
        } catch (t: Throwable) {
            call.reject("Keystore unwrap failed: ${t.message}")
        }
    }

    @PluginMethod
    fun setScreenGuard(call: PluginCall) {
        val enabled = call.getBoolean("enabled", true) ?: true
        val hostActivity = activity
        if (hostActivity == null) {
            call.reject("Activity unavailable")
            return
        }
        val app = hostActivity.application as? com.splender.chat.core.SplenderApplication
        if (app != null) {
            app.zeroTrustLockManager.setFlagSecurePolicy(hostActivity, enabled)
        } else {
            hostActivity.runOnUiThread {
                if (enabled) {
                    hostActivity.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    hostActivity.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }
        val ret = JSObject()
        ret.put("enabled", enabled)
        call.resolve(ret)
    }

    @PluginMethod
    fun switchWindowTab(call: PluginCall) {
        val tabRoute = call.getString("tab", "chats") ?: "chats"
        val conversationId = call.getString("conversationId")
        val scrollOffsetPx = call.getInt("scrollOffsetPx")
        val mainActivity = activity as? com.splender.chat.MainActivity
        if (mainActivity == null) {
            call.reject("Single-Window MainActivity unavailable")
            return
        }
        val targetSection = com.splender.chat.ui.navigation.SplenderSection.fromRoute(tabRoute)
        mainActivity.runOnUiThread {
            if (scrollOffsetPx != null) {
                val currentActive = mainActivity.windowRouterViewModel.uiState.value.activeSection
                mainActivity.windowRouterViewModel.updateSectionViewport(currentActive) {
                    it.copy(scrollOffsetPx = scrollOffsetPx)
                }
            }
            mainActivity.windowRouterViewModel.selectSection(targetSection, conversationId)
            val snapshot = mainActivity.windowRouterViewModel.uiState.value
            val ret = JSObject().apply {
                put("activeTab", snapshot.activeSection.route)
                put("label", snapshot.activeSection.label)
                put("epoch", snapshot.transitionEpoch)
                put("backStackDepth", snapshot.backStack.size)
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun getSingleWindowState(call: PluginCall) {
        val mainActivity = activity as? com.splender.chat.MainActivity
        if (mainActivity == null) {
            call.reject("Single-Window MainActivity unavailable")
            return
        }
        val snapshot = mainActivity.windowRouterViewModel.uiState.value
        val activeVp = snapshot.sectionViewports[snapshot.activeSection]
        val ret = JSObject().apply {
            put("activeTab", snapshot.activeSection.route)
            put("label", snapshot.activeSection.label)
            put("epoch", snapshot.transitionEpoch)
            put("scrollOffsetPx", activeVp?.scrollOffsetPx ?: 0)
            put("selectedConversationId", activeVp?.selectedConversationId)
            put("isStatusCreatorOpen", snapshot.isStatusCreatorOpen)
            put("backStackDepth", snapshot.backStack.size)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun openStatusCreator(call: PluginCall) {
        val mainActivity = activity as? com.splender.chat.MainActivity
        if (mainActivity == null) {
            call.reject("Single-Window MainActivity unavailable")
            return
        }
        mainActivity.runOnUiThread {
            mainActivity.windowRouterViewModel.openStatusCreator()
            val ret = JSObject().apply {
                put("isStatusCreatorOpen", true)
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun closeStatusCreator(call: PluginCall) {
        val mainActivity = activity as? com.splender.chat.MainActivity
        if (mainActivity == null) {
            call.reject("Single-Window MainActivity unavailable")
            return
        }
        mainActivity.runOnUiThread {
            mainActivity.windowRouterViewModel.closeStatusCreator()
            val ret = JSObject().apply {
                put("isStatusCreatorOpen", false)
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun getZeroTrustLockStatus(call: PluginCall) {
        val app = activity?.application as? com.splender.chat.core.SplenderApplication
        val state = app?.zeroTrustLockManager?.lockState?.value
        val ret = JSObject().apply {
            put("flagSecureEnforced", state?.flagSecureEnforced ?: true)
            put("recentsSnapshotBlocked", state?.recentsSnapshotBlocked ?: true)
            put("isInBackground", state?.isInBackground ?: false)
            put("isPrivacyCurtainEngaged", state?.isPrivacyCurtainEngaged ?: false)
            put("isScreenCaptureDetected", state?.isScreenCaptureDetected ?: false)
            put("isScreenRecordingActive", state?.isScreenRecordingActive ?: false)
            put("streamingPipelineReady", com.splender.chat.webrtc.SplenderP2PStreamingPipeline.isPrewarmed())
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun getAndroid17Permissions(call: PluginCall) {
        val snapshot = SplenderPermissionsHelper.getPermissionSnapshot(context)
        val ret = JSObject()
        snapshot.forEach { (k, v) -> ret.put(k, v) }
        call.resolve(ret)
    }

    @PluginMethod
    fun requestP2pPermissions(call: PluginCall) {
        val aliases = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) {
            aliases.add("notifications")
        }
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("nearbyWifi") != PermissionState.GRANTED) {
            aliases.add("nearbyWifi")
        }
        if (Build.VERSION.SDK_INT >= 37 && getPermissionState("localNetwork") != PermissionState.GRANTED) {
            aliases.add("localNetwork")
        }
        if (aliases.isEmpty()) {
            getAndroid17Permissions(call)
        } else {
            requestPermissionForAliases(aliases.toTypedArray(), call, "onP2pPermissionsResult")
        }
    }

    @PermissionCallback
    private fun onP2pPermissionsResult(call: PluginCall) {
        getAndroid17Permissions(call)
    }

    @PluginMethod
    fun requestAndroid17Permission(call: PluginCall) {
        val kind = call.getString("kind")
        if (kind.isNullOrBlank()) {
            call.reject("Permission kind is required")
            return
        }

        val targetAlias = when (kind) {
            "camera" -> "camera"
            "microphone" -> "microphone"
            "notifications" -> if (Build.VERSION.SDK_INT >= 33) "notifications" else null
            "nearbyWifi" -> if (Build.VERSION.SDK_INT >= 33) "nearbyWifi" else null
            "localNetwork" -> if (Build.VERSION.SDK_INT >= 37) "localNetwork" else null
            else -> null
        }

        if (targetAlias == null || getPermissionState(targetAlias) == PermissionState.GRANTED) {
            getAndroid17Permissions(call)
        } else {
            requestPermissionForAliases(arrayOf(targetAlias), call, "onP2pPermissionsResult")
        }
    }

    @PluginMethod
    fun scheduleOutboxSync(call: PluginCall) {
        com.splender.chat.service.SplenderSyncService.startFlushBurst(context)
        val ret = JSObject()
        ret.put("scheduled", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun startCallService(call: PluginCall) {
        val isVideo = call.getBoolean("isVideo", false) ?: false
        val conversationId = call.getString("conversationId")
        SplenderCallService.startActiveCall(context, isVideo, conversationId)
        val ret = JSObject()
        ret.put("active", SplenderCallService.isCallActive())
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCallService(call: PluginCall) {
        SplenderCallService.stopActiveCall(context)
        val ret = JSObject()
        ret.put("active", false)
        call.resolve(ret)
    }

    @PluginMethod
    fun registerPushToken(call: PluginCall) {
        val token = call.getString("token")
        if (token.isNullOrBlank()) {
            call.reject("Push token is required")
            return
        }
        SplenderNotificationHelper.storeSealedPushToken(context, token)
        val ret = JSObject()
        ret.put("sealed", true)
        call.resolve(ret)
    }
}
