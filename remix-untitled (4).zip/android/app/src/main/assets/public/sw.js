// Splender Chat PWA Service Worker
const CACHE_NAME = 'splender-cache-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {
        // Fallback for dev environments where some assets may not be available yet
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Only handle GET requests and skip Firebase/API live requests
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (
    url.hostname.includes('firestore.googleapis.com') ||
    url.hostname.includes('firebase') ||
    url.hostname.includes('identitytoolkit')
  ) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return (
        cachedResponse ||
        fetch(event.request).catch(() => {
          if (event.request.mode === 'navigate') {
            return caches.match('/index.html');
          }
        })
      );
    })
  );
});

self.addEventListener('push', (event) => {
  let conversationId = null;
  try {
    const parsed = event.data ? event.data.json() : null;
    conversationId = parsed && parsed.conversationId ? String(parsed.conversationId) : null;
  } catch {
    conversationId = null;
  }

  // Zero-plaintext push policy: never display unsealed message body previews on OS lock screens
  event.waitUntil(
    self.registration.showNotification('Splender Chat', {
      body: 'New encrypted message',
      icon: '/icon.svg',
      badge: '/icon.svg',
      tag: conversationId ? `chat_${conversationId}` : 'splender_encrypted_push',
      data: { conversationId },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const conversationId =
    event.notification && event.notification.data ? event.notification.data.conversationId : null;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({
            type: 'SPLENDER_NOTIFICATION_CLICK',
            conversationId,
          });
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        const targetUrl = conversationId ? `/?chat=${encodeURIComponent(conversationId)}` : '/';
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

