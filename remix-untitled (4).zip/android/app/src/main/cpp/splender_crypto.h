#ifndef SPLENDER_CRYPTO_H
#define SPLENDER_CRYPTO_H

#include <jni.h>
#include <cstdint>
#include <cstddef>
#include "splender_cipher_core.h"

#ifdef __cplusplus
extern "C" {
#endif

// SHA-256 Context & Operations
typedef struct {
    uint32_t state[8];
    uint64_t count;
    uint8_t buffer[64];
} splender_sha256_ctx;

void splender_sha256_init(splender_sha256_ctx *ctx);
void splender_sha256_update(splender_sha256_ctx *ctx, const uint8_t *data, size_t len);
void splender_sha256_final(splender_sha256_ctx *ctx, uint8_t digest[32]);

// HMAC-SHA256 (RFC 2104)
void splender_hmac_sha256(
    const uint8_t *key, size_t key_len,
    const uint8_t *data, size_t data_len,
    uint8_t mac[32]
);

// HKDF-SHA256 (RFC 5869)
void splender_hkdf_sha256(
    const uint8_t *salt, size_t salt_len,
    const uint8_t *ikm, size_t ikm_len,
    const uint8_t *info, size_t info_len,
    uint8_t *okm, size_t okm_len
);

// Signal Double Ratchet Symmetric Chain Step (returns 64 bytes: [32B nextChainKey | 32B messageKey])
void splender_signal_kdf_ck(const uint8_t chain_key[32], uint8_t out_next_ck[32], uint8_t out_mk[32]);

#ifdef SPLENDER_HAS_RUST_CORE
uint32_t splender_rust_core_version(void);
void splender_rust_x25519(const uint8_t scalar[32], const uint8_t point[32], uint8_t out_shared[32]);
#endif

// JNI Bridge Declarations for com.splender.chat.nativecore.SplenderNativeCore
JNIEXPORT jstring JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_getNativeCoreVersion(JNIEnv *env, jclass clazz);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_computeSha256Native(JNIEnv *env, jclass clazz, jbyteArray input);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_computeHmacSha256Native(JNIEnv *env, jclass clazz, jbyteArray key, jbyteArray data);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_deriveHkdfNative(JNIEnv *env, jclass clazz, jbyteArray salt, jbyteArray ikm, jbyteArray info, jint length);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_ratchetChainStepNative(JNIEnv *env, jclass clazz, jbyteArray chainKey);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_encryptLocalDbPageNative(JNIEnv *env, jclass clazz, jbyteArray masterKey, jbyteArray nonce, jbyteArray plaintext);

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_decryptLocalDbPageNative(JNIEnv *env, jclass clazz, jbyteArray masterKey, jbyteArray packet);

#ifdef __cplusplus
}
#endif

#endif // SPLENDER_CRYPTO_H
