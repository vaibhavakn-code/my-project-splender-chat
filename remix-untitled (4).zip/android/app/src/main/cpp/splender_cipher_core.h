#ifndef SPLENDER_CIPHER_CORE_H
#define SPLENDER_CIPHER_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Constant-time volatile memory wipe preventing dead-store optimization.
 */
void splender_c_secure_zero(void *ptr, size_t len);

/**
 * Constant-time byte array comparison (returns 0 if equal, non-zero otherwise).
 */
int splender_ct_memcmp(const uint8_t *a, const uint8_t *b, size_t len);

/**
 * RFC 7748 Section 5 Curve25519 scalar clamping for X25519 ECDH private keys.
 */
void splender_x25519_clamp(uint8_t scalar[32]);

/**
 * RFC 8439 ChaCha20 20-round stream cipher XOR operation.
 * Used for high-speed native local SQLite/IndexedDB page encryption & E2EE attachment streams.
 *
 * @param key     32-byte (256-bit) symmetric key
 * @param nonce   12-byte (96-bit) unique nonce
 * @param counter Initial 32-bit block counter
 * @param input   Input buffer (plaintext or ciphertext)
 * @param output  Output buffer (same length as input)
 * @param len     Buffer length in bytes
 */
void splender_chacha20_xor(
    const uint8_t key[32],
    const uint8_t nonce[12],
    uint32_t counter,
    const uint8_t *input,
    uint8_t *output,
    size_t len
);

#ifdef __cplusplus
}
#endif

#endif /* SPLENDER_CIPHER_CORE_H */
