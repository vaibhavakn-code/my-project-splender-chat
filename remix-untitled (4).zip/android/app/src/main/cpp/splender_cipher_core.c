#include "splender_cipher_core.h"
#include <string.h>

#define ROTL32(v, n) (((v) << (n)) | ((v) >> (32 - (n))))

#define QUARTERROUND(a, b, c, d) \
    do {                         \
        a += b; d ^= a; d = ROTL32(d, 16); \
        c += d; b ^= c; b = ROTL32(b, 12); \
        a += b; d ^= a; d = ROTL32(d, 8);  \
        c += d; b ^= c; b = ROTL32(b, 7);  \
    } while (0)

static uint32_t load32_le(const uint8_t src[4]) {
    return ((uint32_t)src[0]) |
           ((uint32_t)src[1] << 8) |
           ((uint32_t)src[2] << 16) |
           ((uint32_t)src[3] << 24);
}

static void store32_le(uint8_t dst[4], uint32_t val) {
    dst[0] = (uint8_t)(val & 0xffU);
    dst[1] = (uint8_t)((val >> 8) & 0xffU);
    dst[2] = (uint8_t)((val >> 16) & 0xffU);
    dst[3] = (uint8_t)((val >> 24) & 0xffU);
}

void splender_c_secure_zero(void *ptr, size_t len) {
    if (ptr == NULL || len == 0) {
        return;
    }
    volatile uint8_t *p = (volatile uint8_t *)ptr;
    while (len-- > 0) {
        *p++ = 0;
    }
}

int splender_ct_memcmp(const uint8_t *a, const uint8_t *b, size_t len) {
    uint8_t diff = 0;
    size_t i;
    for (i = 0; i < len; ++i) {
        diff |= (uint8_t)(a[i] ^ b[i]);
    }
    return (int)diff;
}

void splender_x25519_clamp(uint8_t scalar[32]) {
    scalar[0] &= 248U;
    scalar[31] &= 127U;
    scalar[31] |= 64U;
}

static void chacha20_block(const uint32_t state[16], uint8_t stream[64]) {
    uint32_t x[16];
    int i;
    for (i = 0; i < 16; ++i) {
        x[i] = state[i];
    }

    for (i = 0; i < 10; ++i) {
        /* Column rounds */
        QUARTERROUND(x[0], x[4], x[8],  x[12]);
        QUARTERROUND(x[1], x[5], x[9],  x[13]);
        QUARTERROUND(x[2], x[6], x[10], x[14]);
        QUARTERROUND(x[3], x[7], x[11], x[15]);
        /* Diagonal rounds */
        QUARTERROUND(x[0], x[5], x[10], x[15]);
        QUARTERROUND(x[1], x[6], x[11], x[12]);
        QUARTERROUND(x[2], x[7], x[8],  x[13]);
        QUARTERROUND(x[3], x[4], x[9],  x[14]);
    }

    for (i = 0; i < 16; ++i) {
        store32_le(stream + (i * 4), x[i] + state[i]);
    }
    splender_c_secure_zero(x, sizeof(x));
}

void splender_chacha20_xor(
    const uint8_t key[32],
    const uint8_t nonce[12],
    uint32_t counter,
    const uint8_t *input,
    uint8_t *output,
    size_t len
) {
    uint32_t state[16];
    uint8_t block[64];
    size_t offset = 0;
    size_t i;

    /* "expand 32-byte k" in little-endian */
    state[0]  = 0x61707865U;
    state[1]  = 0x3320646eU;
    state[2]  = 0x79622d32U;
    state[3]  = 0x6b206574U;
    state[4]  = load32_le(key + 0);
    state[5]  = load32_le(key + 4);
    state[6]  = load32_le(key + 8);
    state[7]  = load32_le(key + 12);
    state[8]  = load32_le(key + 16);
    state[9]  = load32_le(key + 20);
    state[10] = load32_le(key + 24);
    state[11] = load32_le(key + 28);
    state[12] = counter;
    state[13] = load32_le(nonce + 0);
    state[14] = load32_le(nonce + 4);
    state[15] = load32_le(nonce + 8);

    while (offset < len) {
        size_t chunk = (len - offset > 64) ? 64 : (len - offset);
        chacha20_block(state, block);
        for (i = 0; i < chunk; ++i) {
            output[offset + i] = (uint8_t)(input[offset + i] ^ block[i]);
        }
        state[12] += 1U;
        offset += chunk;
    }

    splender_c_secure_zero(state, sizeof(state));
    splender_c_secure_zero(block, sizeof(block));
}
