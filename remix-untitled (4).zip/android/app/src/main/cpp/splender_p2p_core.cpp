#include "splender_crypto.h"
#include <android/log.h>
#include <algorithm>
#include <cstring>
#include <vector>

#define LOG_TAG "SplenderNativeCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ----------------------------------------------------------------------------
// SHA-256 Engine (FIPS 180-4)
// ----------------------------------------------------------------------------
static const uint32_t K256[64] = {
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U, 0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U, 0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU, 0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U, 0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U, 0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U, 0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U, 0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U, 0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U
};

#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define CH(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define SIG0(x) (ROTR(x, 2) ^ ROTR(x, 13) ^ ROTR(x, 22))
#define SIG1(x) (ROTR(x, 6) ^ ROTR(x, 11) ^ ROTR(x, 25))
#define GAM0(x) (ROTR(x, 7) ^ ROTR(x, 18) ^ ((x) >> 3))
#define GAM1(x) (ROTR(x, 17) ^ ROTR(x, 19) ^ ((x) >> 10))

static void splender_sha256_transform(splender_sha256_ctx *ctx, const uint8_t *data) {
    uint32_t a, b, c, d, e, f, g, h, s0, s1, maj, ch, temp1, temp2;
    uint32_t w[64];

    for (size_t i = 0, j = 0; i < 16; ++i, j += 4) {
        w[i] = ((uint32_t)data[j] << 24) |
               ((uint32_t)data[j + 1] << 16) |
               ((uint32_t)data[j + 2] << 8) |
               ((uint32_t)data[j + 3]);
    }
    for (size_t i = 16; i < 64; ++i) {
        s0 = GAM0(w[i - 15]);
        s1 = GAM1(w[i - 2]);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }

    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];
    f = ctx->state[5];
    g = ctx->state[6];
    h = ctx->state[7];

    for (size_t i = 0; i < 64; ++i) {
        s1 = SIG1(e);
        ch = CH(e, f, g);
        temp1 = h + s1 + ch + K256[i] + w[i];
        s0 = SIG0(a);
        maj = MAJ(a, b, c);
        temp2 = s0 + maj;

        h = g;
        g = f;
        f = e;
        e = d + temp1;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2;
    }

    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
    splender_c_secure_zero(w, sizeof(w));
}

void splender_sha256_init(splender_sha256_ctx *ctx) {
    ctx->count = 0;
    ctx->state[0] = 0x6a09e667U;
    ctx->state[1] = 0xbb67ae85U;
    ctx->state[2] = 0x3c6ef372U;
    ctx->state[3] = 0xa54ff53aU;
    ctx->state[4] = 0x510e527fU;
    ctx->state[5] = 0x9b05688cU;
    ctx->state[6] = 0x1f83d9abU;
    ctx->state[7] = 0x5be0cd19U;
}

void splender_sha256_update(splender_sha256_ctx *ctx, const uint8_t *data, size_t len) {
    size_t i = 0;
    size_t buffer_idx = (size_t)((ctx->count / 8) % 64);
    ctx->count += (uint64_t)len * 8ULL;

    while (i < len) {
        ctx->buffer[buffer_idx++] = data[i++];
        if (buffer_idx == 64) {
            splender_sha256_transform(ctx, ctx->buffer);
            buffer_idx = 0;
        }
    }
}

void splender_sha256_final(splender_sha256_ctx *ctx, uint8_t digest[32]) {
    size_t buffer_idx = (size_t)((ctx->count / 8) % 64);
    ctx->buffer[buffer_idx++] = 0x80;

    if (buffer_idx > 56) {
        while (buffer_idx < 64) ctx->buffer[buffer_idx++] = 0;
        splender_sha256_transform(ctx, ctx->buffer);
        buffer_idx = 0;
    }

    while (buffer_idx < 56) ctx->buffer[buffer_idx++] = 0;

    for (int i = 7; i >= 0; --i) {
        ctx->buffer[56 + (7 - i)] = (uint8_t)((ctx->count >> (i * 8)) & 0xFFU);
    }

    splender_sha256_transform(ctx, ctx->buffer);

    for (int i = 0; i < 8; ++i) {
        digest[i * 4]     = (uint8_t)((ctx->state[i] >> 24) & 0xFFU);
        digest[i * 4 + 1] = (uint8_t)((ctx->state[i] >> 16) & 0xFFU);
        digest[i * 4 + 2] = (uint8_t)((ctx->state[i] >> 8) & 0xFFU);
        digest[i * 4 + 3] = (uint8_t)(ctx->state[i] & 0xFFU);
    }
    splender_c_secure_zero(ctx, sizeof(splender_sha256_ctx));
}

// ----------------------------------------------------------------------------
// HMAC-SHA256 & HKDF-SHA256
// ----------------------------------------------------------------------------
void splender_hmac_sha256(
    const uint8_t *key, size_t key_len,
    const uint8_t *data, size_t data_len,
    uint8_t mac[32]
) {
    uint8_t k0[64] = {0};
    if (key_len > 64) {
        splender_sha256_ctx ctx;
        splender_sha256_init(&ctx);
        splender_sha256_update(&ctx, key, key_len);
        splender_sha256_final(&ctx, k0);
    } else if (key && key_len > 0) {
        std::memcpy(k0, key, key_len);
    }

    uint8_t ipad[64], opad[64];
    for (size_t i = 0; i < 64; ++i) {
        ipad[i] = k0[i] ^ 0x36U;
        opad[i] = k0[i] ^ 0x5cU;
    }

    uint8_t inner_hash[32];
    splender_sha256_ctx inner_ctx;
    splender_sha256_init(&inner_ctx);
    splender_sha256_update(&inner_ctx, ipad, 64);
    if (data && data_len > 0) {
        splender_sha256_update(&inner_ctx, data, data_len);
    }
    splender_sha256_final(&inner_ctx, inner_hash);

    splender_sha256_ctx outer_ctx;
    splender_sha256_init(&outer_ctx);
    splender_sha256_update(&outer_ctx, opad, 64);
    splender_sha256_update(&outer_ctx, inner_hash, 32);
    splender_sha256_final(&outer_ctx, mac);

    splender_c_secure_zero(k0, sizeof(k0));
    splender_c_secure_zero(ipad, sizeof(ipad));
    splender_c_secure_zero(opad, sizeof(opad));
    splender_c_secure_zero(inner_hash, sizeof(inner_hash));
}

void splender_hkdf_sha256(
    const uint8_t *salt, size_t salt_len,
    const uint8_t *ikm, size_t ikm_len,
    const uint8_t *info, size_t info_len,
    uint8_t *okm, size_t okm_len
) {
    uint8_t prk[32];
    uint8_t default_salt[32] = {0};
    if (!salt || salt_len == 0) {
        salt = default_salt;
        salt_len = 32;
    }
    splender_hmac_sha256(salt, salt_len, ikm, ikm_len, prk);

    size_t n = (okm_len + 31) / 32;
    uint8_t t[32];
    size_t t_len = 0;
    size_t generated = 0;
    size_t bounded_info_len = std::min<size_t>(info_len, 256);

    for (uint8_t i = 1; i <= n; ++i) {
        uint8_t step_data[32 + 256 + 1];
        size_t step_len = 0;
        if (t_len > 0) {
            std::memcpy(step_data + step_len, t, t_len);
            step_len += t_len;
        }
        if (info && bounded_info_len > 0) {
            std::memcpy(step_data + step_len, info, bounded_info_len);
            step_len += bounded_info_len;
        }
        step_data[step_len++] = i;

        splender_hmac_sha256(prk, 32, step_data, step_len, t);
        t_len = 32;

        size_t to_copy = std::min<size_t>(32, okm_len - generated);
        std::memcpy(okm + generated, t, to_copy);
        generated += to_copy;
        splender_c_secure_zero(step_data, sizeof(step_data));
    }

    splender_c_secure_zero(prk, sizeof(prk));
    splender_c_secure_zero(t, sizeof(t));
}

// ----------------------------------------------------------------------------
// Signal Protocol Double Ratchet Symmetric Chain Step (Section 3.2)
// MK = HMAC-SHA256(CK, 0x01)
// NextCK = HMAC-SHA256(CK, 0x02)
// ----------------------------------------------------------------------------
void splender_signal_kdf_ck(const uint8_t chain_key[32], uint8_t out_next_ck[32], uint8_t out_mk[32]) {
    const uint8_t mk_const = 0x01U;
    const uint8_t ck_const = 0x02U;
    splender_hmac_sha256(chain_key, 32, &mk_const, 1, out_mk);
    splender_hmac_sha256(chain_key, 32, &ck_const, 1, out_next_ck);
}

// ----------------------------------------------------------------------------
// JNI Implementations
// ----------------------------------------------------------------------------
extern "C" {

JNIEXPORT jstring JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_getNativeCoreVersion(JNIEnv *env, jclass /* clazz */) {
#ifdef SPLENDER_HAS_RUST_CORE
    return env->NewStringUTF("Splender-P2P-Core/v17.1 (C11+C++20+Rust-X25519 API-37 16KB-Aligned)");
#else
    return env->NewStringUTF("Splender-P2P-Core/v17.1 (C11+C++20 ChaCha20-SHA256 API-37 16KB-Aligned)");
#endif
}

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_computeSha256Native(JNIEnv *env, jclass /* clazz */, jbyteArray input) {
    if (!input) return nullptr;
    jsize len = env->GetArrayLength(input);
    jbyte *bytes = env->GetByteArrayElements(input, nullptr);

    uint8_t digest[32];
    splender_sha256_ctx ctx;
    splender_sha256_init(&ctx);
    if (bytes && len > 0) {
        splender_sha256_update(&ctx, reinterpret_cast<const uint8_t*>(bytes), static_cast<size_t>(len));
    }
    splender_sha256_final(&ctx, digest);

    if (bytes) env->ReleaseByteArrayElements(input, bytes, JNI_ABORT);

    jbyteArray result = env->NewByteArray(32);
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(digest));
    splender_c_secure_zero(digest, sizeof(digest));
    return result;
}

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_computeHmacSha256Native(JNIEnv *env, jclass /* clazz */, jbyteArray key, jbyteArray data) {
    if (!key || !data) return nullptr;
    jsize k_len = env->GetArrayLength(key);
    jsize d_len = env->GetArrayLength(data);
    jbyte *k_bytes = env->GetByteArrayElements(key, nullptr);
    jbyte *d_bytes = env->GetByteArrayElements(data, nullptr);

    uint8_t mac[32];
    splender_hmac_sha256(
        reinterpret_cast<const uint8_t*>(k_bytes), static_cast<size_t>(k_len),
        reinterpret_cast<const uint8_t*>(d_bytes), static_cast<size_t>(d_len),
        mac
    );

    if (k_bytes) env->ReleaseByteArrayElements(key, k_bytes, JNI_ABORT);
    if (d_bytes) env->ReleaseByteArrayElements(data, d_bytes, JNI_ABORT);

    jbyteArray result = env->NewByteArray(32);
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(mac));
    splender_c_secure_zero(mac, sizeof(mac));
    return result;
}

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_deriveHkdfNative(
    JNIEnv *env, jclass /* clazz */,
    jbyteArray salt, jbyteArray ikm, jbyteArray info, jint length
) {
    if (!ikm || length <= 0 || length > 1024) return nullptr;
    jsize s_len = salt ? env->GetArrayLength(salt) : 0;
    jsize i_len = env->GetArrayLength(ikm);
    jsize inf_len = info ? env->GetArrayLength(info) : 0;

    jbyte *s_bytes = salt ? env->GetByteArrayElements(salt, nullptr) : nullptr;
    jbyte *i_bytes = env->GetByteArrayElements(ikm, nullptr);
    jbyte *inf_bytes = info ? env->GetByteArrayElements(info, nullptr) : nullptr;

    std::vector<uint8_t> okm(static_cast<size_t>(length));
    splender_hkdf_sha256(
        reinterpret_cast<const uint8_t*>(s_bytes), static_cast<size_t>(s_len),
        reinterpret_cast<const uint8_t*>(i_bytes), static_cast<size_t>(i_len),
        reinterpret_cast<const uint8_t*>(inf_bytes), static_cast<size_t>(inf_len),
        okm.data(), static_cast<size_t>(length)
    );

    if (salt && s_bytes) env->ReleaseByteArrayElements(salt, s_bytes, JNI_ABORT);
    if (i_bytes) env->ReleaseByteArrayElements(ikm, i_bytes, JNI_ABORT);
    if (info && inf_bytes) env->ReleaseByteArrayElements(info, inf_bytes, JNI_ABORT);

    jbyteArray result = env->NewByteArray(length);
    env->SetByteArrayRegion(result, 0, length, reinterpret_cast<const jbyte*>(okm.data()));
    splender_c_secure_zero(okm.data(), okm.size());
    return result;
}

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_ratchetChainStepNative(JNIEnv *env, jclass /* clazz */, jbyteArray chainKey) {
    if (!chainKey || env->GetArrayLength(chainKey) != 32) return nullptr;
    jbyte *ck_bytes = env->GetByteArrayElements(chainKey, nullptr);

    uint8_t out_material[64]; // [0..31] = nextChainKey, [32..63] = messageKey
    splender_signal_kdf_ck(
        reinterpret_cast<const uint8_t*>(ck_bytes),
        out_material,
        out_material + 32
    );

    env->ReleaseByteArrayElements(chainKey, ck_bytes, JNI_ABORT);

    jbyteArray result = env->NewByteArray(64);
    env->SetByteArrayRegion(result, 0, 64, reinterpret_cast<const jbyte*>(out_material));
    splender_c_secure_zero(out_material, sizeof(out_material));
    return result;
}

/**
 * Encrypts a local database page using Encrypt-then-MAC:
 * Subkeys derived via HKDF-SHA256 -> ChaCha20(encKey, nonce, counter=1) + HMAC-SHA256(macKey, nonce || ciphertext)
 * Output packet format: [12-byte nonce][ciphertext][32-byte HMAC tag]
 */
JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_encryptLocalDbPageNative(
    JNIEnv *env, jclass /* clazz */,
    jbyteArray masterKey, jbyteArray nonce, jbyteArray plaintext
) {
    if (!masterKey || !nonce || !plaintext) return nullptr;
    if (env->GetArrayLength(masterKey) != 32 || env->GetArrayLength(nonce) != 12) return nullptr;

    jsize pt_len = env->GetArrayLength(plaintext);
    jbyte *mk_bytes = env->GetByteArrayElements(masterKey, nullptr);
    jbyte *n_bytes = env->GetByteArrayElements(nonce, nullptr);
    jbyte *pt_bytes = env->GetByteArrayElements(plaintext, nullptr);

    const char *info_str = "splender_local_db_page_v1";
    uint8_t subkeys[64]; // [0..31] ChaCha20 key, [32..63] HMAC key
    splender_hkdf_sha256(
        reinterpret_cast<const uint8_t*>(n_bytes), 12,
        reinterpret_cast<const uint8_t*>(mk_bytes), 32,
        reinterpret_cast<const uint8_t*>(info_str), std::strlen(info_str),
        subkeys, 64
    );

    size_t packet_len = 12 + static_cast<size_t>(pt_len) + 32;
    std::vector<uint8_t> packet(packet_len);
    std::memcpy(packet.data(), n_bytes, 12);

    if (pt_len > 0) {
        splender_chacha20_xor(
            subkeys,
            reinterpret_cast<const uint8_t*>(n_bytes),
            1U,
            reinterpret_cast<const uint8_t*>(pt_bytes),
            packet.data() + 12,
            static_cast<size_t>(pt_len)
        );
    }

    splender_hmac_sha256(
        subkeys + 32, 32,
        packet.data(), 12 + static_cast<size_t>(pt_len),
        packet.data() + 12 + static_cast<size_t>(pt_len)
    );

    env->ReleaseByteArrayElements(masterKey, mk_bytes, JNI_ABORT);
    env->ReleaseByteArrayElements(nonce, n_bytes, JNI_ABORT);
    env->ReleaseByteArrayElements(plaintext, pt_bytes, JNI_ABORT);
    splender_c_secure_zero(subkeys, sizeof(subkeys));

    jbyteArray result = env->NewByteArray(static_cast<jsize>(packet_len));
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(packet_len), reinterpret_cast<const jbyte*>(packet.data()));
    splender_c_secure_zero(packet.data(), packet.size());
    return result;
}

JNIEXPORT jbyteArray JNICALL
Java_com_splender_chat_nativecore_SplenderNativeCore_decryptLocalDbPageNative(
    JNIEnv *env, jclass /* clazz */,
    jbyteArray masterKey, jbyteArray packetArr
) {
    if (!masterKey || !packetArr) return nullptr;
    jsize pkt_len = env->GetArrayLength(packetArr);
    if (env->GetArrayLength(masterKey) != 32 || pkt_len < 44) return nullptr;

    size_t ct_len = static_cast<size_t>(pkt_len) - 12 - 32;
    jbyte *mk_bytes = env->GetByteArrayElements(masterKey, nullptr);
    jbyte *pkt_bytes = env->GetByteArrayElements(packetArr, nullptr);

    const uint8_t *nonce_ptr = reinterpret_cast<const uint8_t*>(pkt_bytes);
    const uint8_t *ct_ptr = nonce_ptr + 12;
    const uint8_t *tag_ptr = ct_ptr + ct_len;

    const char *info_str = "splender_local_db_page_v1";
    uint8_t subkeys[64];
    splender_hkdf_sha256(
        nonce_ptr, 12,
        reinterpret_cast<const uint8_t*>(mk_bytes), 32,
        reinterpret_cast<const uint8_t*>(info_str), std::strlen(info_str),
        subkeys, 64
    );

    uint8_t expected_mac[32];
    splender_hmac_sha256(subkeys + 32, 32, nonce_ptr, 12 + ct_len, expected_mac);
    int mac_diff = splender_ct_memcmp(expected_mac, tag_ptr, 32);
    splender_c_secure_zero(expected_mac, sizeof(expected_mac));

    if (mac_diff != 0) {
        LOGE("Local DB page authentication failed: MAC mismatch");
        env->ReleaseByteArrayElements(masterKey, mk_bytes, JNI_ABORT);
        env->ReleaseByteArrayElements(packetArr, pkt_bytes, JNI_ABORT);
        splender_c_secure_zero(subkeys, sizeof(subkeys));
        return nullptr;
    }

    std::vector<uint8_t> plaintext(ct_len > 0 ? ct_len : 1);
    if (ct_len > 0) {
        splender_chacha20_xor(subkeys, nonce_ptr, 1U, ct_ptr, plaintext.data(), ct_len);
    }

    env->ReleaseByteArrayElements(masterKey, mk_bytes, JNI_ABORT);
    env->ReleaseByteArrayElements(packetArr, pkt_bytes, JNI_ABORT);
    splender_c_secure_zero(subkeys, sizeof(subkeys));

    jbyteArray result = env->NewByteArray(static_cast<jsize>(ct_len));
    if (ct_len > 0) {
        env->SetByteArrayRegion(result, 0, static_cast<jsize>(ct_len), reinterpret_cast<const jbyte*>(plaintext.data()));
    }
    splender_c_secure_zero(plaintext.data(), plaintext.size());
    return result;
}

} // extern "C"
