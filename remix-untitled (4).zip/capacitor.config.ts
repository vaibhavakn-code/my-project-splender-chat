import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.splender.chat',
  appName: 'Splender Chat',
  webDir: 'dist',
  backgroundColor: '#0B0F17',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      launchAutoHide: true,
      backgroundColor: '#0B0F17',
      androidSplashResourceName: 'splash',
      showSpinner: false
    }
  }
};

export default config;
