# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app.spec.ts >> Splender Chat — Mobile Device Edition & Android 17 (API 37) Acceptance Suite >> UltimateAdvancedStatusCreatorScreen — Jetpack Compose Gesture Studio, Single-Window Bridge & Live 24h SVG Engine
- Location: tests/app.spec.ts:1381:3

# Error details

```
Error: page.evaluate: TypeError: Failed to resolve module specifier 'react'
    at loadViteModule (eval at evaluate (:311:30), <anonymous>:2:65)
    at eval (eval at evaluate (:311:30), <anonymous>:5:28)
    at async <anonymous>:337:30
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e5]:
    - banner [ref=e6]:
      - generic [ref=e7]:
        - generic [ref=e8]: S
        - generic [ref=e10]: Splender Chat
      - generic [ref=e11]: Android 17 · API 37
    - generic [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]:
          - generic [ref=e15]: S
          - generic [ref=e17]:
            - heading "Splender Chat" [level=1] [ref=e18]
            - paragraph [ref=e19]: Peer-first end-to-end encrypted messaging with Signal Double Ratchet and direct WebRTC transport
        - generic [ref=e20]:
          - generic [ref=e21]:
            - button "Google" [ref=e22] [cursor=pointer]
            - button "Email & Password" [ref=e23] [cursor=pointer]
          - generic [ref=e24]:
            - button "Continue with Google" [ref=e25] [cursor=pointer]
            - button "Continue as Guest Peer" [ref=e32] [cursor=pointer]
            - generic [ref=e33]: Provisions non-extractable ECDH & AES-256 keys locally
      - generic [ref=e38]:
        - generic [ref=e39]: Signal Double Ratchet
        - generic [aria-hidden] [ref=e43]: ·
        - generic [ref=e44]: Android 17 (API 37) Keystore
  - generic [ref=e48]:
    - generic [ref=e49]:
      - generic [ref=e50]: S
      - generic [ref=e52]: Splender Chat
      - generic [aria-hidden] [ref=e53]: ·
      - generic [ref=e54]: Signal-Grade P2P Encrypted Messenger
    - generic [ref=e55]: Android 17 Edition (API 37)
```