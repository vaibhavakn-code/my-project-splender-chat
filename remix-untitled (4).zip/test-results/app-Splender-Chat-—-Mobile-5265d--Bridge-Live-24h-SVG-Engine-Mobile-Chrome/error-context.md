# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app.spec.ts >> Splender Chat — Mobile Device Edition & Android 17 (API 37) Acceptance Suite >> UltimateAdvancedStatusCreatorScreen — Jetpack Compose Gesture Studio, Single-Window Bridge & Live 24h SVG Engine
- Location: tests/app.spec.ts:1381:3

# Error details

```
Error: page.evaluate: TypeError: Failed to resolve module specifier 'react'
    at loadViteModule (eval at evaluate (:311:30), <anonymous>:2:65)
    at eval (eval at evaluate (:311:30), <anonymous>:5:28)
    at async <anonymous>:337:30
```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e6]: S
  - generic [ref=e8]:
    - heading "Splender Chat" [level=2] [ref=e9]
    - paragraph [ref=e10]: Initializing Android 17 (API 37) cryptographic vault...
```