// Splender Chat PWA Service Worker
const CACHE_NAME = 'splender-cache-v2';
const ASSETS_TO_CACHE = ['/', '/index.html', '/manifest.json', '/icon.svg'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {
        // Fallback for dev environments where some assets may not be available yet
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
          return Promise.resolve(false);
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Only handle standard GET requests; let HEAD/POST and no-store health probes hit the network directly
  if (event.request.method !== 'GET' || event.request.cache === 'no-store') {
    return;
  }

  const url = new URL(event.request.url);

  // Skip cross-origin API/Firebase endpoints and Vite dev module transforms
  if (
    url.origin !== self.location.origin ||
    url.pathname.startsWith('/@vite') ||
    url.pathname.startsWith('/@react-refresh') ||
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  // Network-first for HTML navigations so dev-server restarts always serve fresh markup when online
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((networkResp) => {
          if (networkResp && networkResp.ok) {
            const copy = networkResp.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', copy)).catch(() => {});
          }
          return networkResp;
        })
        .catch(async () => {
          const cached = await caches.match('/index.html');
          return (
            cached ||
            new Response('Offline', {
              status: 503,
              statusText: 'Offline',
              headers: { 'Content-Type': 'text/plain; charset=utf-8' },
            })
          );
        })
    );
    return;
  }

  // Stale-while-revalidate for static same-origin shell assets with guaranteed valid Response fallback
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request)
        .then((networkResp) => {
          if (networkResp && networkResp.ok) {
            const copy = networkResp.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          }
          return networkResp;
        })
        .catch(() => null);

      if (cachedResponse) {
        return cachedResponse;
      }

      return fetchPromise.then(
        (resp) =>
          resp ||
          new Response('', {
            status: 503,
            statusText: 'Service Unavailable',
          })
      );
    })
  );
});

self.addEventListener('push', (event) => {
  let conversationId = null;
  try {
    const parsed = event.data ? event.data.json() : null;
    conversationId = parsed && parsed.conversationId ? String(parsed.conversationId) : null;
  } catch {
    conversationId = null;
  }

  // Zero-plaintext push policy: never display unsealed message body previews on OS lock screens
  event.waitUntil(
    self.registration.showNotification('Splender Chat', {
      body: 'New encrypted message',
      icon: '/icon.svg',
      badge: '/icon.svg',
      tag: conversationId ? `chat_${conversationId}` : 'splender_encrypted_push',
      data: { conversationId },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const conversationId =
    event.notification && event.notification.data ? event.notification.data.conversationId : null;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({
            type: 'SPLENDER_NOTIFICATION_CLICK',
            conversationId,
          });
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        const targetUrl = conversationId ? `/?chat=${encodeURIComponent(conversationId)}` : '/';
        return self.clients.openWindow(targetUrl);
      }
      return undefined;
    })
  );
});
